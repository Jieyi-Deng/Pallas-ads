# ruff: noqa: E501
"""Consulting-style competitor advertising report from a validated, cited research brief.

No browsing, scraping or model call happens here. The host agent researches public sources;
this module only checks evidence rules (in the contract) and renders local files.
"""

from __future__ import annotations

import hashlib
import os
from collections import Counter
from datetime import UTC, datetime
from pathlib import Path
from string import Template
from uuid import uuid4

from pallas_ads.contracts.competitors import RELIABILITY, CompetitorBrief
from pallas_ads.contracts.status import OperationEnvelope, OperationIssue
from pallas_ads.observation_rendering import csv_text, dump, esc, fmt, table

RENDERER_VERSION = "1.0.0"
PLATFORMS = {"google": "Google", "meta": "Meta", "tiktok": "TikTok", "other": "其他渠道"}
FORMATS = {
    "video": "视频",
    "image": "单图",
    "carousel": "轮播",
    "search_text": "搜索文字广告",
    "collection": "精品栏/合集",
    "playable": "试玩",
    "other": "其他",
}
ANGLES = {
    "price_or_offer": "价格与优惠",
    "feature_demo": "功能演示",
    "social_proof": "社会证明",
    "creator_or_ugc": "达人/用户内容",
    "problem_solution": "痛点-方案",
    "comparison": "对比",
    "brand_story": "品牌故事",
    "urgency": "限时紧迫",
    "other": "其他",
}
LEVERS = {
    "creative": "素材制作",
    "messaging": "卖点与文案",
    "format": "广告格式",
    "audience_targeting": "受众定向",
    "bidding": "出价策略",
    "budget_allocation": "预算分配",
    "landing_page": "落地页",
    "offer": "自有优惠",
    "test_design": "测试设计",
    "platform_mix": "平台组合",
}
PRIORITY = {"now": "立即", "next": "下一步", "later": "后续"}
RELATION = {"direct": "直接竞品", "indirect": "间接竞品", "substitute": "替代方案"}
SOURCE_TYPES = {
    "ad_library": "广告资料库",
    "transparency_center": "广告透明度中心",
    "creative_center": "创意中心",
    "official_site": "官方网站",
    "app_store": "应用商店",
    "press_release": "新闻稿",
    "news": "新闻报道",
    "industry_report": "行业报告",
    "third_party_estimate": "第三方估算",
    "other": "其他",
}
RELIABILITY_TEXT = {"high": "高", "medium": "中", "low": "低"}


def template_path():
    bundled = Path(__file__).parent / "resources/skills/pallas-competitors/assets/report.html"
    return (
        bundled
        if bundled.is_file()
        else Path(__file__).parents[2] / "skills/pallas-competitors/assets/report.html"
    )


def cite(ids):
    if not ids:
        return ""
    return (
        '<span class="cite">['
        + ", ".join(f'<a href="#{esc(i)}">{esc(i)}</a>' for i in ids)
        + "]</span>"
    )


def tag(kind, confidence=None):
    if kind == "verified":
        return '<span class="tag verified">已核实</span>'
    level = {"low": "低", "medium": "中"}.get(confidence or "", "")
    return f'<span class="tag inference">推断 · 置信度{level}</span>'


def count_bars(items, title, unit, caption):
    """Sorted horizontal count bars, zero-based, with direct labels."""
    items = [(label, n) for label, n in items if n]
    if not items:
        return '<p class="small">没有可绘制的观察。</p>'
    top = max(n for _, n in items)
    height = len(items) * 36 + 40
    rows = [f'<text x="10" y="18" fill="#5f6d78">单位：{esc(unit)}</text>']
    for i, (label, n) in enumerate(items):
        y = 32 + i * 36
        width = n / top * 360
        color = "#1d4e89" if n == top else "#9fbad9"
        rows.append(
            f'<text x="10" y="{y + 17}">{esc(label)}</text><rect x="200" y="{y}" width="{width:.2f}" height="24" fill="{color}"><title>{esc(label)}：{fmt(n)} {esc(unit)}</title></rect><text x="{208 + width:.2f}" y="{y + 17}">{fmt(n)}</text>'
        )
    return f'<figure><div class="chart-scroll"><svg role="img" aria-label="{esc(title)}" viewBox="0 0 620 {height}"><title>{esc(title)}</title>{"".join(rows)}</svg></div><figcaption>{esc(caption)}</figcaption></figure>'


def heat(rows, columns, counts, row_label):
    top = max(counts.values(), default=0)
    head = (
        '<div class="table-wrap"><table><thead><tr><th scope="col">'
        + esc(row_label)
        + "</th>"
        + "".join(f'<th scope="col" class="number">{esc(c[1])}</th>' for c in columns)
        + "</tr></thead><tbody>"
    )
    body = ""
    for key, label in rows:
        body += f"<tr><td>{esc(label)}</td>"
        for column, _ in columns:
            n = counts.get((key, column), 0)
            level = 0 if not n else min(3, 1 + int(2 * n / top)) if top else 0
            body += f'<td class="heat h{level}">{fmt(n) if n else "–"}</td>'
        body += "</tr>"
    return head + body + "</tbody></table></div>"


def render(brief: CompetitorBrief):
    a, scope = brief.advertiser, brief.scope
    sources = {s.source_id: s for s in brief.sources}
    competitors = {c.competitor_id: c for c in brief.competitors}
    findings = {f.finding_id: f for f in brief.findings}
    synthetic = brief.evidence_mode == "synthetic_fixture"
    title = f"{a.product} 竞品广告分析"
    subtitle = (
        f"{a.category} · 面向 {'、'.join(a.regions)} 的 {'、'.join(a.audiences)}："
        "竞品是谁、他们在 {} 上用什么素材，以及你可以直接调整的动作。".format(
            "、".join(PLATFORMS[p] for p in a.platforms)
        )
    )
    meta = "".join(
        f"<span>{esc(k)}：{esc(v)}</span>"
        for k, v in (
            ("研究日期", scope.researched_on.isoformat()),
            ("观察时间范围", scope.lookback_note),
            ("来源", f"{fmt(len(sources))} 个"),
            ("素材观察", f"{fmt(len(brief.observations))} 条"),
        )
    )
    banner = (
        '<p class="banner">合成示例：本报告使用虚构的竞品、来源和素材，仅用于展示格式与校验规则，不是真实市场研究。</p>'
        if synthetic
        else ""
    )
    counts = Counter(f.kind for f in brief.findings)
    summary = (
        '<article><h3>关键结论</h3><ol class="takeaways">'
        + "".join(
            f"<li>{tag(findings[i].kind, findings[i].confidence)}{esc(findings[i].statement)}{cite(findings[i].source_ids)}</li>"
            for i in brief.headline_finding_ids
        )
        + "</ol></article>"
    )
    now = [r for r in brief.recommendations if r.priority == "now"]
    if now:
        summary += (
            '<div class="panel"><h3>最先做的事</h3><ul>'
            + "".join(
                f"<li><strong>{esc(LEVERS[r.lever])}</strong>：{esc(r.action)}</li>" for r in now
            )
            + "</ul></div>"
        )
    summary += f'<p class="small">共 {fmt(counts["verified"])} 条已核实结论、{fmt(counts["inference"])} 条推断、{fmt(len(brief.gaps))} 个证据缺口。只有已核实结论直接由来源支持；推断需要按“行动建议”中的测试验证。</p>'

    # Competitor set
    observed = Counter(o.competitor_id for o in brief.observations)
    platforms_by = {}
    for o in brief.observations:
        platforms_by.setdefault(o.competitor_id, set()).add(o.platform)
    if brief.competitors:
        comp = f'<p class="section-lead">根据产品类别、目标地区和受众，确认了 {fmt(len(brief.competitors))} 个竞争对象。每个对象都附有判断依据和来源；未能核实的候选不列入。</p>'
        comp += (
            '<div class="table-wrap"><table><thead><tr><th scope="col">竞品</th><th scope="col">类型</th><th scope="col">为什么算竞品</th><th scope="col">观察到的平台</th><th scope="col" class="number">素材观察</th></tr></thead><tbody>'
            + "".join(
                f"<tr><td><strong>{esc(c.name)}</strong><br><span class='small'>{esc(c.product)}</span></td><td>{esc(RELATION[c.relationship])}</td><td>{esc(c.basis)}{cite(c.source_ids)}</td><td>{esc('、'.join(PLATFORMS[p] for p in sorted(platforms_by.get(c.competitor_id, ()))) or '未观察到')}</td><td class='number'>{fmt(observed.get(c.competitor_id, 0))}</td></tr>"
                for c in brief.competitors
            )
            + "</tbody></table></div>"
        )
        silent = [c.name for c in brief.competitors if not observed.get(c.competitor_id)]
        if silent:
            comp += f'<p class="small">{esc("、".join(silent))} 在本次检索的公开广告来源中没有观察到素材。这不代表没有投放：资料库覆盖范围、地区和检索词都可能限制可见性。</p>'
    else:
        comp = '<p class="banner">没有找到有可靠来源支持的竞品。本报告不列出未经核实的名称。</p>'

    # Creative landscape
    if brief.observations:
        fmt_counts = Counter(o.format for o in brief.observations)
        angle_counts = Counter(o.angle for o in brief.observations)
        creative = f'<p class="section-lead">以下统计基于 {fmt(len(brief.observations))} 条可追溯到公开来源的素材观察。它们是研究样本，只能说明“看到了什么”，不能说明投放量、花费或效果。</p><div class="grid"><article><h3>格式分布</h3>'
        creative += count_bars(
            [(FORMATS[k], n) for k, n in fmt_counts.most_common()],
            "素材格式分布",
            "条观察",
            "按观察数降序，条形从零起算。",
        )
        creative += "</article><article><h3>诉求角度分布</h3>"
        creative += count_bars(
            [(ANGLES[k], n) for k, n in angle_counts.most_common()],
            "素材诉求角度分布",
            "条观察",
            "按观察数降序，条形从零起算。",
        )
        creative += "</article></div>"
        pair = Counter((o.competitor_id, o.angle) for o in brief.observations)
        used_angles = [(k, ANGLES[k]) for k, _ in angle_counts.most_common()]
        creative += "<article><h3>谁在用哪种诉求</h3>" + heat(
            [(c.competitor_id, c.name) for c in brief.competitors if observed.get(c.competitor_id)],
            used_angles,
            pair,
            "竞品 \\ 诉求角度",
        )
        creative += '<p class="small">单元格为观察条数，颜色越深越多；“–”表示本次样本中未观察到，不等于竞品从未使用。</p></article>'
        creative += "<article><h3>代表性素材观察</h3>" + table(
            [
                "竞品",
                "平台 · 地区",
                "格式 / 角度",
                "素材描述（转述）",
                "行动号召",
                "可见时间",
                "来源",
            ],
            [
                [
                    competitors[o.competitor_id].name,
                    PLATFORMS[o.platform] + (f" · {o.region}" if o.region else ""),
                    f"{FORMATS[o.format]} / {ANGLES[o.angle]}",
                    o.description + (f"（公开指标：{o.public_metric}）" if o.public_metric else ""),
                    o.call_to_action or "未记录",
                    " 至 ".join(d.isoformat() for d in (o.first_seen, o.last_seen) if d)
                    or "未记录",
                    ", ".join(o.source_ids),
                ]
                for o in brief.observations[:20]
            ],
        )
        if len(brief.observations) > 20:
            creative += f'<p class="small">仅展示前 20 条，全部 {fmt(len(brief.observations))} 条见 <a href="observations.csv">观察明细</a>。</p>'
        creative += "</article>"
    else:
        creative = '<p class="banner">没有取得可追溯的竞品素材观察，因此不分析素材类型。请查看“证据缺口”。</p>'

    # Per platform
    platforms = ""
    for p in a.platforms:
        rows = [o for o in brief.observations if o.platform == p]
        related = [
            f
            for f in brief.findings
            if f.observation_ids
            and all(
                next(o for o in brief.observations if o.observation_id == i).platform == p
                for i in f.observation_ids
            )
        ]
        platforms += f"<article><h3>{esc(PLATFORMS[p])}</h3>"
        if not rows:
            platforms += "<p>本次没有在该平台观察到竞品素材。请结合“证据缺口”判断是可见性限制还是竞品确实未投放。</p></article>"
            continue
        f_counts = Counter(o.format for o in rows)
        a_counts = Counter(o.angle for o in rows)
        platforms += f"<p>观察 {fmt(len(rows))} 条，涉及 {fmt(len({o.competitor_id for o in rows}))} 个竞品。最常见格式：{esc(FORMATS[f_counts.most_common(1)[0][0]])}；最常见诉求：{esc(ANGLES[a_counts.most_common(1)[0][0]])}。</p>"
        if related:
            platforms += (
                "<ul>"
                + "".join(
                    f"<li>{tag(f.kind, f.confidence)}{esc(f.statement)}{cite(f.source_ids)}</li>"
                    for f in related
                )
                + "</ul>"
            )
        platforms += "</article>"

    # Recommendations
    if brief.recommendations:
        order = {"now": 0, "next": 1, "later": 2}
        recs = '<p class="section-lead">每条建议只涉及你可以直接控制的因素（素材、文案、格式、定向、出价、预算、落地页、自有优惠、测试和平台组合），并对应到支持它的结论。竞品的预算、平台算法和市场环境不在建议范围内。</p>'
        recs += table(
            ["优先级", "调整因素", "具体动作", "依据", "如何判断有效"],
            [
                [
                    PRIORITY[r.priority],
                    LEVERS[r.lever],
                    r.action,
                    r.rationale
                    + "（"
                    + "、".join(
                        ("已核实 " if findings[i].kind == "verified" else "推断 ") + i
                        for i in r.finding_ids
                    )
                    + "）",
                    r.success_measure,
                ]
                for r in sorted(brief.recommendations, key=lambda r: order[r.priority])
            ],
        )
        if any(
            findings[i].kind == "inference" for r in brief.recommendations for i in r.finding_ids
        ):
            recs += (
                '<p class="small">基于推断的建议应先以小规模对照测试验证，不作为直接扩量依据。</p>'
            )
    else:
        recs = "<p>证据不足以提出具体调整建议。先补齐“证据缺口”中的信息。</p>"

    # Evidence, gaps, method
    method = (
        "<article><h3>全部结论</h3><ul>"
        + "".join(
            f'<li id="{esc(f.finding_id)}"><strong>{esc(f.finding_id)}</strong> {tag(f.kind, f.confidence)}{esc(f.statement)}{cite(f.source_ids)}'
            + (
                f'<span class="small">（依据观察：{esc("、".join(f.observation_ids))}）</span>'
                if f.observation_ids
                else ""
            )
            + "</li>"
            for f in brief.findings
        )
        + "</ul></article>"
    )
    method += "<article><h3>证据缺口</h3>"
    if brief.gaps:
        method += table(
            ["主题", "为什么缺失", "如何补齐"],
            [[g.topic, g.reason, g.how_to_close] for g in brief.gaps],
        )
    else:
        method += "<p>研究者未申报证据缺口。公开广告资料库本身不提供花费、转化和完整投放量，这类信息仍不可得。</p>"
    method += "</article>"
    method += f"<article><h3>方法</h3><p>{esc(scope.method)}</p>"
    if scope.queries:
        method += f'<p class="small">检索词：{esc("；".join(scope.queries))}</p>'
    method += "<p class='small'>来源可靠性由来源类型决定：广告资料库、透明度中心、官方网站、应用商店为高；创意中心、新闻稿、新闻、行业报告为中；第三方估算和其他为低。低可靠性来源不能单独支持“已核实”结论或素材观察。</p></article>"
    method += (
        '<article><h3>来源</h3><ol class="sources">'
        + "".join(
            f'<li id="{esc(s.source_id)}"><strong>{esc(s.source_id)}</strong> {esc(s.publisher)} ·《{esc(s.title)}》· {esc(SOURCE_TYPES[s.source_type])} · 可靠性{RELIABILITY_TEXT[RELIABILITY[s.source_type]]} · 访问于 {esc(s.accessed_on.isoformat())}'
            + (f" · 发布于 {esc(s.published_on.isoformat())}" if s.published_on else "")
            + f'<br><a href="{esc(s.url)}" rel="noreferrer noopener">{esc(s.url)}</a></li>'
            for s in brief.sources
        )
        + "</ol></article>"
    )
    links = '<p><a href="report.json">完整研究记录</a> · <a href="sources.csv">来源清单</a> · <a href="observations.csv">素材观察明细</a> · <a href="manifest.json">文件校验清单</a></p>'
    html_text = Template(template_path().read_text()).substitute(
        title=esc(title),
        subtitle=esc(subtitle),
        meta=meta,
        banner=banner,
        summary=summary,
        competitors=comp,
        creative=creative,
        platforms=platforms,
        recommendations=recs,
        method=method,
        links=links,
    )
    md = f"# {title}\n\n"
    if synthetic:
        md += "> 合成示例：虚构的竞品、来源和素材，不是真实市场研究。\n\n"
    md += f"研究日期 {scope.researched_on}；来源 {len(sources)} 个；素材观察 {len(brief.observations)} 条。\n\n## 关键结论\n\n"
    md += "\n".join(
        f"- [{'已核实' if findings[i].kind == 'verified' else '推断'}] {findings[i].statement} {' '.join('[' + s + ']' for s in findings[i].source_ids)}"
        for i in brief.headline_finding_ids
    )
    md += "\n\n## 行动建议\n\n" + (
        "\n".join(
            f"- {PRIORITY[r.priority]} · {LEVERS[r.lever]}：{r.action}（衡量：{r.success_measure}）"
            for r in brief.recommendations
        )
        or "- 证据不足，暂无具体建议。"
    )
    md += "\n\n## 证据缺口\n\n" + (
        "\n".join(f"- {g.topic}：{g.reason}" for g in brief.gaps) or "- 未申报。"
    )
    md += "\n\n## 来源\n\n" + "\n".join(
        f"- [{s.source_id}] {s.publisher}，{s.title}：{s.url}（访问于 {s.accessed_on}）"
        for s in brief.sources
    )
    md += "\n\n[HTML 报告](report.html)\n"
    return html_text, md


def build_competitor_report(workspace, brief: CompetitorBrief):
    root = workspace.layout.root / "reports/competitors"
    root.mkdir(parents=True, exist_ok=True)
    identifier = "competitor_" + uuid4().hex
    pending, destination = root / ("." + identifier), root / identifier
    pending.mkdir(mode=0o700)
    html_text, md = render(brief)
    record = {
        "schema_version": "1.0.0",
        "kind": "competitor_ad_report",
        "evidence_mode": brief.evidence_mode,
        "created_at": datetime.now(UTC).isoformat(),
        "brief": brief.model_dump(mode="json"),
    }
    files = {
        "report.html": html_text,
        "report.md": md,
        "chat.md": md,
        "report.json": dump(record),
        "sources.csv": csv_text(
            [
                {**s.model_dump(mode="json"), "reliability": RELIABILITY[s.source_type]}
                for s in brief.sources
            ],
            [
                "source_id",
                "source_type",
                "reliability",
                "publisher",
                "title",
                "url",
                "accessed_on",
                "published_on",
            ],
        ),
        "observations.csv": csv_text(
            [
                {**o.model_dump(mode="json"), "source_ids": " ".join(o.source_ids)}
                for o in brief.observations
            ],
            [
                "observation_id",
                "competitor_id",
                "platform",
                "region",
                "format",
                "angle",
                "description",
                "call_to_action",
                "first_seen",
                "last_seen",
                "active_when_accessed",
                "public_metric",
                "source_ids",
            ],
        ),
    }
    for name, text in files.items():
        (pending / name).write_text(text, encoding="utf-8")
    manifest = {
        "renderer": "competitor_report",
        "renderer_version": RENDERER_VERSION,
        "template_sha256": hashlib.sha256(template_path().read_bytes()).hexdigest(),
        "report_id": identifier,
        "evidence_mode": brief.evidence_mode,
        "files": {n: hashlib.sha256(t.encode()).hexdigest() for n, t in files.items()},
    }
    (pending / "manifest.json").write_text(dump(manifest), encoding="utf-8")
    os.rename(pending, destination)
    issues = []
    if brief.evidence_mode == "synthetic_fixture":
        issues.append(
            OperationIssue(
                code="synthetic_fixture",
                severity="warning",
                message="Synthetic example: invented competitors and sources, not market research.",
            )
        )
    if not brief.observations or not brief.competitors:
        issues.append(
            OperationIssue(
                code="competitor_evidence_insufficient",
                severity="warning",
                message="No verified competitors or creative observations; conclusions are limited.",
            )
        )
    return OperationEnvelope(
        operation="build_report",
        status="partial_result" if issues else "complete",
        issues=issues,
        result={
            "report_id": identifier,
            "evidence_mode": brief.evidence_mode,
            "counts": {
                "sources": len(brief.sources),
                "competitors": len(brief.competitors),
                "observations": len(brief.observations),
                "verified_findings": sum(f.kind == "verified" for f in brief.findings),
                "inferences": sum(f.kind == "inference" for f in brief.findings),
                "gaps": len(brief.gaps),
                "recommendations": len(brief.recommendations),
            },
            "artifacts": {
                "html": str(destination / "report.html"),
                "markdown": str(destination / "report.md"),
                "data": str(destination / "report.json"),
                "sources": str(destination / "sources.csv"),
                "manifest": str(destination / "manifest.json"),
            },
            "next_step": "Summarize headline findings with their evidence labels and link the HTML.",
        },
    )
