"""Internal (first-party) conversion files and their explicit match to one advertising file.

No network, no OAuth and no model call. Matching is rule-based and documented in
skills/pallas-workflow/references/internal-conversions.md: local date, confirmed platform
value and exact campaign ID. Names, fuzzy text and inferred channels never create a match.
"""

import hashlib
import json
from datetime import date
from decimal import Decimal
from pathlib import Path
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

from pallas_ads.contracts.status import OperationEnvelope, OperationIssue
from pallas_ads.file_import import ExportError, date_cell, decimal_cell, read_table, text_cell
from pallas_ads.observation_rendering import dump

FIELDS = {
    "date": ["date", "day", "signup_date", "acquisition_date", "日期"],
    "channel": ["channel", "acquisition_channel", "channel_group", "渠道"],
    "platform": ["platform", "source", "utm_source", "media_source", "媒体"],
    "campaign_id": ["campaign_id", "utm_campaign_id", "campaign id", "广告系列编号"],
    "new_users": ["new_users", "signups", "installs", "new users", "新增用户"],
    "conversions": ["conversions", "purchasers", "first_purchases", "转化次数", "转化用户"],
    "revenue": ["revenue", "conversion_value", "收入"],
    "retained_users": ["retained_users", "retained", "d7_retained", "留存用户"],
}
REQUIRED = {"date", "channel"}
COUNTS = ("new_users", "conversions", "retained_users")
METRICS = (*COUNTS, "revenue")
AUTO_CHANNEL = {"paid": "paid", "organic": "organic"}
AUTO_PLATFORM = {"google": "google", "meta": "meta", "tiktok": "tiktok"}
# Display threshold for a group's denominator. It is not a significance test.
MIN_GROUP_USERS = 30


def _count(value, field, line):
    number = decimal_cell(value, field, line)
    if number is not None and number != number.to_integral_value():
        raise ExportError(f"Row {line}: {field} must be an integer count.")
    return number


def prepare(path, options):
    raw, headers, body, sheet = read_table(path, options)
    if set(options.column_mapping) - set(FIELDS):
        raise ExportError("Mapping contains unsupported target fields; use the documented schema.")
    mapping = {}
    for target, aliases in FIELDS.items():
        candidates = [h for h in headers if h.casefold() in {a.casefold() for a in aliases}]
        if target in options.column_mapping:
            candidates = [options.column_mapping[target]]
        if len(candidates) > 1:
            raise ExportError(
                f"Multiple columns match {target}; choose one explicit column_mapping."
            )
        if candidates:
            if candidates[0] not in headers:
                raise ExportError(f"Mapped column for {target} is absent.")
            mapping[target] = candidates[0]
    if REQUIRED - mapping.keys():
        raise ExportError("Map required columns: " + ", ".join(sorted(REQUIRED - mapping.keys())))
    if not {"new_users", "conversions"} & mapping.keys():
        raise ExportError("Map new_users or conversions; a channel list alone has no outcome.")
    if len(set(mapping.values())) != len(mapping):
        raise ExportError("Each input column may map to only one field.")
    try:
        ZoneInfo(options.timezone)
    except (ZoneInfoNotFoundError, ValueError):
        raise ExportError("Timezone must be a valid IANA name.") from None
    if "revenue" in mapping and options.currency is None:
        raise ExportError("Confirm the revenue currency before importing revenue.")
    if "retained_users" in mapping and options.retention_definition is None:
        raise ExportError("Confirm retention_definition before importing retained users.")
    channels = {k.casefold(): v for k, v in AUTO_CHANNEL.items()}
    channels.update({k.casefold(): v for k, v in options.channel_mapping.items()})
    platforms = {k.casefold(): v for k, v in AUTO_PLATFORM.items()}
    platforms.update({k.casefold(): str(v) for k, v in options.platform_mapping.items()})
    rows, seen, unmapped_channels, unmapped_platforms = [], set(), set(), set()
    for line, source in body:
        item = {f: source.get(h) for f, h in mapping.items()}
        day = date_cell(item["date"], line)
        channel_raw = text_cell(item["channel"], "channel", line)
        if not channel_raw:
            raise ExportError(f"Row {line}: channel is required; remove summary rows.")
        platform_raw = text_cell(item.get("platform"), "platform", line)
        campaign = text_cell(item.get("campaign_id"), "campaign_id", line)
        key = (day, channel_raw, platform_raw, campaign)
        if key in seen:
            raise ExportError(f"Row {line}: duplicate date/channel/platform/campaign row.")
        seen.add(key)
        channel = channels.get(channel_raw.casefold())
        if channel is None:
            unmapped_channels.add(channel_raw)
        platform = None
        if platform_raw is not None:
            platform = platforms.get(platform_raw.casefold())
            if platform is None and channel == "paid":
                unmapped_platforms.add(platform_raw)
        values = {f: _count(item.get(f), f, line) for f in COUNTS}
        values["revenue"] = decimal_cell(item.get("revenue"), "revenue", line)
        rows.append(
            {
                "date": day,
                "channel": channel,
                "channel_raw": channel_raw,
                "platform": platform,
                "platform_raw": platform_raw,
                "campaign_id": campaign,
                "source_row": line,
                **values,
            }
        )
    dates = sorted({r["date"] for r in rows})
    summary = {
        "kind": "internal_conversions",
        "timezone": options.timezone,
        "currency": options.currency,
        "sheet": sheet,
        "row_count": len(rows),
        "period": {"start": dates[0], "end": dates[-1]},
        "observed_dates_continuous": len(dates)
        == (date.fromisoformat(dates[-1]) - date.fromisoformat(dates[0])).days + 1,
        "column_mapping": mapping,
        "ignored_columns": [h for h in headers if h not in mapping.values()],
        "channels": {
            c: sum(r["channel"] == c for r in rows)
            for c in ("paid", "organic", "excluded", "unknown")
        },
        # Shown in the preview (like preview rows) so the user can map them; never in errors.
        "channel_values_unmapped": sorted(unmapped_channels)[:50],
        "paid_platform_values_unmapped": sorted(unmapped_platforms)[:20],
        "campaign_ids_present": any(r["campaign_id"] for r in rows),
        "missing_values": {f: sum(r[f] is None for r in rows) for f in METRICS if f in mapping},
        "unavailable_fields": [
            f for f in (*METRICS, "platform", "campaign_id") if f not in mapping
        ],
        "conversion_definition": options.conversion_definition,
        "attribution_basis": options.attribution_basis,
        "cohort_basis": options.cohort_basis,
        "new_user_definition": options.new_user_definition,
        "retention_definition": options.retention_definition,
        "coverage": "internal_file_rows_only_not_reconciled_with_platform",
    }
    content = {
        "format_version": "1.0",
        "source_sha256": hashlib.sha256(raw).hexdigest(),
        "options": options.model_dump(mode="json"),
        "summary": summary,
        "rows": rows,
    }
    encoded = dump(content).encode()
    return content, encoded, hashlib.sha256(encoded).hexdigest()


def stage_internal(workspace, request):
    if not request.file_path or request.internal_options is None:
        raise ExportError("Supply file_path and internal_options for internal conversion data.")
    content, encoded, digest = prepare(Path(request.file_path), request.internal_options)
    identifier = "internal_" + digest
    if request.action == "internal_preview":
        return OperationEnvelope(
            operation="source_connect_or_import",
            status="pending_user_action",
            issues=[
                OperationIssue(
                    code="internal_interpretation_confirmation",
                    severity="info",
                    message="Confirm channel, platform, date basis and definitions first.",
                ),
                *(
                    [
                        OperationIssue(
                            code="internal_channel_mapping_required",
                            severity="warning",
                            message="Map channel values listed in channel_values_unmapped.",
                        )
                    ]
                    if content["summary"]["channel_values_unmapped"]
                    else []
                ),
            ],
            result={
                "review_hash": digest,
                "summary": content["summary"],
                "preview_rows": json.loads(dump(content["rows"][:5])),
                "next_step": (
                    "Show channel/platform mapping, timezone, cohort basis, conversion and "
                    "retention definitions and missing fields; confirm before internal_import."
                ),
                "canonical_data_written": False,
            },
        )
    if request.review_hash != digest or request.user_confirmed is not True:
        raise ExportError(
            "Confirm this exact interpretation; changed files/options need a new preview."
        )
    if content["summary"]["channel_values_unmapped"]:
        raise ExportError(
            "Map every channel value listed in the preview to paid/organic/excluded/unknown."
        )
    root = workspace.layout.root / "file_imports"
    if root.is_symlink():
        raise ExportError("Import storage cannot be a symlink.")
    root.mkdir(mode=0o700, parents=True, exist_ok=True)
    path = root / (identifier + ".json")
    reused = path.exists()
    if reused:
        if path.is_symlink() or path.read_bytes() != encoded:
            raise ExportError("Retained file integrity mismatch; existing data was preserved.")
    else:
        with path.open("xb") as handle:
            path.chmod(0o600)
            handle.write(encoded)
    return OperationEnvelope(
        operation="source_connect_or_import",
        status="complete",
        result={
            "internal_dataset_id": identifier,
            "summary": content["summary"],
            "reused": reused,
            "canonical_data_written": False,
            "next_step": "build_report(action=file_review,dataset_id=...,internal_dataset_id=...)",
        },
    )


def _d(value):
    return None if value is None else Decimal(str(value))


def _sum(rows, field):
    """Sum a field; any missing value makes the total unknown instead of an undercount."""
    if not rows:
        return None
    values = [_d(r.get(field)) for r in rows]
    return None if any(v is None for v in values) else sum(values, Decimal(0))


def _ratio(numerator, denominator):
    return numerator / denominator if numerator is not None and denominator else None


def _group(rows, fields):
    totals = {"rows": len(rows)}
    for field in fields:
        totals[field] = _sum(rows, field)
    return totals


def integrate(ad, internal):
    """Deterministic match of one retained ad file and one internal file."""
    a, s = ad["summary"], internal["summary"]
    present = [f for f in METRICS if f in s["column_mapping"]]
    limitations = [
        "内部数据按用户确认的渠道和媒体取值匹配；系列名称、模糊文本和推断渠道不参与匹配。",
        "付费与自然用户的差异是描述性对比，不是增量或因果测量；自然渠道可能受到广告的间接影响。",
        "内部归因口径为“" + s["attribution_basis"] + "”，与媒体归因窗口不同，两者转化数不应相加。",
    ]
    if s["cohort_basis"] == "event_date":
        limitations.append(
            "内部转化按事件发生日期记录，不是获客日同批用户；转化率和人均收入只是同期比率。"
        )
    tz_match = a["timezone"] == s["timezone"]
    ad_dates = {r["date"] for r in ad["rows"]}
    internal_dates = {r["date"] for r in internal["rows"]}
    overlap = sorted(ad_dates & internal_dates)
    alignment = {
        "ad_timezone": a["timezone"],
        "internal_timezone": s["timezone"],
        "timezone_match": tz_match,
        "daily_join": tz_match and bool(overlap),
        "overlap": {"start": overlap[0], "end": overlap[-1]} if overlap else None,
        "overlap_dates": len(overlap),
        "ad_dates_outside_overlap": len(ad_dates - internal_dates),
        "internal_dates_outside_overlap": len(internal_dates - ad_dates),
        "currency_match": (s["currency"] == a["currency"]) if "revenue" in present else None,
    }
    result = {
        "status": "integrated",
        "platform": a["platform"],
        "internal_summary": s,
        "alignment": alignment,
        "matching_rules": [
            "日期：两份文件都存在的本地日期；时区不同则不按日匹配。",
            "媒体：内部付费行的 platform 取值经确认映射为本广告文件的媒体。",
            "系列：仅当内部数据提供 campaign_id 时按完全相同的编号匹配。",
            "渠道：paid/organic/excluded/unknown 由用户确认；unknown 不并入任何一方。",
        ],
        "limitations": limitations,
        "unavailable": [],
    }
    if not overlap:
        result["status"] = "not_integrable"
        result["unavailable"].append(
            {"metric": "all", "reason": "广告文件与内部文件没有共同日期，不能匹配。"}
        )
        return result
    if not tz_match:
        result["status"] = "not_integrable"
        result["unavailable"].append(
            {
                "metric": "all",
                "reason": "两份文件的日期时区不同，同一日期代表不同时段；请按同一时区重新导出。",
            }
        )
        return result
    window = set(overlap)
    ad_rows = [r for r in ad["rows"] if r["date"] in window]
    rows = [r for r in internal["rows"] if r["date"] in window]
    has_platform = any(r["platform_raw"] is not None for r in rows)
    groups = {
        "paid_platform": [
            r for r in rows if r["channel"] == "paid" and r["platform"] == a["platform"]
        ],
        "paid_other_platform": [
            r for r in rows if r["channel"] == "paid" and r["platform"] not in (None, a["platform"])
        ],
        "paid_unattributed": [r for r in rows if r["channel"] == "paid" and r["platform"] is None],
        "organic": [r for r in rows if r["channel"] == "organic"],
        "unknown": [r for r in rows if r["channel"] == "unknown"],
    }
    result["groups"] = {k: _group(v, present) for k, v in groups.items()}
    result["groups"]["excluded"] = {"rows": sum(r["channel"] == "excluded" for r in rows)}
    ad_totals = {
        f: _sum(ad_rows, f)
        for f in ("spend", "impressions", "clicks", "conversions", "conversion_value")
    }
    result["ad_totals"] = ad_totals
    paid = result["groups"]["paid_platform"]
    if not has_platform:
        result["unavailable"].append(
            {
                "metric": "cac",
                "reason": "内部数据没有媒体字段，付费用户不能归到本媒体，不计算获客成本。",
            }
        )
    efficiency = {}
    if has_platform and paid["rows"]:
        spend = ad_totals["spend"]
        efficiency = {
            "internal_cac": _ratio(spend, paid.get("new_users")),
            "cost_per_internal_conversion": _ratio(spend, paid.get("conversions")),
            "internal_revenue_to_spend": _ratio(paid.get("revenue"), spend)
            if alignment["currency_match"]
            else None,
            "platform_to_internal_conversion_ratio": _ratio(
                ad_totals["conversions"], paid.get("conversions")
            ),
        }
        if "revenue" in present and not alignment["currency_match"]:
            result["unavailable"].append(
                {"metric": "internal_revenue_to_spend", "reason": "收入币种与广告花费币种不同。"}
            )
        if ad_totals["conversions"] is None:
            result["unavailable"].append(
                {
                    "metric": "platform_to_internal_conversion_ratio",
                    "reason": "广告文件没有完整的媒体转化列。",
                }
            )
    result["efficiency"] = efficiency
    comparisons = []
    # Without platform values, paid users cannot be tied to this medium's spend, but
    # paid-versus-organic quality can still be described for all confirmed paid users.
    if has_platform:
        paid_group, label = paid, "paid_platform"
    else:
        paid_group, label = result["groups"]["paid_unattributed"], "paid_all"
    for metric, numerator in (
        ("conversion_rate", "conversions"),
        ("revenue_per_new_user", "revenue"),
        ("retention_rate", "retained_users"),
    ):
        if numerator not in present or "new_users" not in present:
            result["unavailable"].append(
                {"metric": metric, "reason": f"内部文件缺少 {numerator} 或 new_users。"}
            )
            continue
        organic = result["groups"]["organic"]
        row = {"metric": metric, "paid_group": label}
        for side, g in (("paid", paid_group), ("organic", organic)):
            n = g.get("new_users")
            row[side + "_new_users"] = n
            row[side] = _ratio(g.get(numerator), n)
        eligible = all(
            row[side + "_new_users"] is not None and row[side + "_new_users"] >= MIN_GROUP_USERS
            for side in ("paid", "organic")
        )
        row["eligible"] = eligible and row["paid"] is not None and row["organic"] is not None
        if metric == "revenue_per_new_user" and s["currency"] is None:
            row["eligible"] = False
        row["reason"] = (
            None
            if row["eligible"]
            else f"至少一组缺少数据或新增用户少于 {MIN_GROUP_USERS}，不展示高低比较。"
        )
        row["difference"] = row["paid"] - row["organic"] if row["eligible"] else None
        comparisons.append(row)
    result["quality_comparison"] = comparisons
    # Campaign match: exact IDs, paid rows for this platform only.
    campaign = {"available": False}
    if any(r["campaign_id"] for r in groups["paid_platform"]):
        ad_ids = {r["campaign_id"] for r in ad_rows}
        by_id = {}
        for r in groups["paid_platform"]:
            if r["campaign_id"]:
                by_id.setdefault(r["campaign_id"], []).append(r)
        matched = []
        for identifier in sorted(set(by_id) & ad_ids):
            spend = _sum([r for r in ad_rows if r["campaign_id"] == identifier], "spend")
            g = _group(by_id[identifier], present)
            matched.append(
                {
                    "campaign_id": identifier,
                    "campaign_name": ad["campaign_names"].get(identifier, identifier),
                    "spend": spend,
                    **g,
                    "internal_cac": _ratio(spend, g.get("new_users")),
                    "conversion_rate": _ratio(g.get("conversions"), g.get("new_users")),
                }
            )
        campaign = {
            "available": True,
            "matched": matched,
            "internal_ids_without_ad_rows": sorted(set(by_id) - ad_ids)[:50],
            "ad_campaigns_without_internal_rows": sorted(ad_ids - set(by_id))[:50],
            "paid_rows_without_campaign_id": sum(
                1 for r in groups["paid_platform"] if not r["campaign_id"]
            ),
        }
    else:
        result["unavailable"].append(
            {"metric": "campaign_match", "reason": "内部付费行没有 campaign_id，只能做媒体级整合。"}
        )
    result["campaigns"] = campaign
    daily = []
    for day in overlap:
        day_ad = [r for r in ad_rows if r["date"] == day]
        entry = {"date": day, "spend": _sum(day_ad, "spend")}
        for key in ("paid_platform", "organic"):
            day_rows = [r for r in groups[key] if r["date"] == day]
            for f in ("new_users", "conversions"):
                if f in present:
                    # A date without rows for a group is unknown, not zero users.
                    entry[f"{key}_{f}"] = _sum(day_rows, f) if day_rows else None
        daily.append(entry)
    result["daily"] = daily
    result["organic_trend"] = _organic_trend(daily, present)
    return result


def _organic_trend(daily, present):
    """Equal-length halves of a contiguous overlap; descriptive, not a forecast."""
    if "new_users" not in present or len(daily) < 8:
        return None
    first, last = date.fromisoformat(daily[0]["date"]), date.fromisoformat(daily[-1]["date"])
    if (last - first).days + 1 != len(daily):
        return None
    half = len(daily) // 2
    before, after = daily[:half], daily[len(daily) - half :]
    out = {
        "before": {"start": before[0]["date"], "end": before[-1]["date"]},
        "after": {"start": after[0]["date"], "end": after[-1]["date"]},
    }
    for label, part in (("before", before), ("after", after)):
        users = [r.get("organic_new_users") for r in part]
        conversions = [r.get("organic_conversions") for r in part]
        out[label]["organic_new_users"] = (
            None if any(v is None for v in users) else sum(users, Decimal(0))
        )
        out[label]["organic_conversions"] = (
            None
            if "conversions" not in present or any(v is None for v in conversions)
            else sum(conversions, Decimal(0))
        )
        out[label]["organic_conversion_rate"] = _ratio(
            out[label]["organic_conversions"], out[label]["organic_new_users"]
        )
        paid = [r.get("paid_platform_new_users") for r in part]
        out[label]["paid_platform_new_users"] = (
            None if any(v is None for v in paid) else sum(paid, Decimal(0))
        )
        spend = [r.get("spend") for r in part]
        out[label]["spend"] = None if any(v is None for v in spend) else sum(spend, Decimal(0))
    return out
