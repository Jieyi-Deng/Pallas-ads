"""Deterministic routing for the shared Skill, MCP and CLI /pallas entrypoint."""

from pathlib import Path

from pallas_ads import __version__
from pallas_ads.contracts.command import AnalysisInput, DashboardInput
from pallas_ads.contracts.status import (
    MissingInput,
    OperationEnvelope,
    OperationIssue,
    OperationStatus,
)
from pallas_ads.dashboard import RENDERER_VERSION as DASHBOARD_RENDERER
from pallas_ads.dashboard_tools import inventory, verify
from pallas_ads.observation_rendering import RENDERER_VERSION as ANALYSIS_RENDERER
from pallas_ads.report_delivery import verify_report_artifacts

COMMAND_VERSION = "1.0"


def needs(field, reason, result=None):
    return OperationEnvelope(
        operation="pallas_command",
        status="needs_input",
        result=result,
        missing_inputs=[MissingInput(field_path=field, reason=reason)],
    )


def help_result():
    return {
        "command_version": COMMAND_VERSION,
        "versions": {
            "runtime": __version__,
            "analysis_renderer": ANALYSIS_RENDERER,
            "dashboard_renderer": DASHBOARD_RENDERER,
        },
        "commands": {
            "help": "Show commands without authorization, account reads or workspace creation.",
            "status": "Inspect only this workspace and retained dashboard integrity; no writes.",
            "analysis": "Diagnose an explicit file, dataset, host capture, connection or packet.",
            "dashboard": "Reuse one matching dashboard, or explicitly create one with sources.",
        },
        "aliases": {"analyze": "analysis", "update": "dashboard op=update"},
        "defaults": {"dashboard_history_days": 90, "dashboard_lookback_days": 7},
        "scheduling": "No background job is created. Scheduling requires a separate user request.",
        "preparation": "Use pallas-workflow for source setup; pallas-analysis/pallas-dashboard "
        "for interpretation and mapping. Source failures do not permit scraping.",
    }


def dispatch(runtime, request):
    workspace = runtime.workspace.layout.root.resolve()
    if request.workspace is not None and Path(request.workspace).resolve() != workspace:
        return needs(
            "/workspace",
            "This command cannot switch the bound workspace. "
            "Use the selected project's own Pallas runtime.",
        )
    intent = {"analyze": "analysis", "update": "dashboard"}.get(request.intent, request.intent)
    context = {"intent": intent, "workspace": str(workspace), **help_result()}
    if intent == "help":
        return OperationEnvelope(operation="pallas_command", status="complete", result=context)
    if not runtime.workspace.layout.workspace_file.is_file():
        return needs(
            "/workspace",
            "Set up Pallas in the selected project first; no workspace was created.",
            {**context, "workspace_state": "missing"},
        )
    runtime.workspace.load_manifest()
    if intent == "status":
        dashboards = inventory(workspace)
        for entry in dashboards:
            try:
                checked = verify(workspace, entry["dashboard_id"])
                entry["validation"] = checked
            except (ValueError, OSError, KeyError, IndexError, TypeError):
                entry["validation"] = {
                    "verified": False,
                    "next_step": "Repair with dashboard op=status, then verify again.",
                }
        return OperationEnvelope(
            operation="pallas_command",
            status="complete",
            result={
                **context,
                "workspace_state": "ready",
                "dashboards": dashboards,
                "claim_limit": "Local integrity only; no live authorization or data check.",
            },
        )
    if intent == "analysis":
        if request.file is not None:
            source = request.file.model_dump(mode="json", exclude_none=True)
            source["action"] = "file_import" if request.file.user_confirmed else "file_preview"
            prepared = runtime._invoke("source_connect_or_import", source)
            if not request.file.user_confirmed or prepared.status != "complete":
                return wrap(prepared, intent, workspace, "source:" + source["action"])
            analysis = AnalysisInput(dataset_id=prepared.result["dataset_id"])
        else:
            analysis = request.analysis or AnalysisInput()
        payload = analysis_request(analysis)
        if isinstance(payload, OperationEnvelope):
            return payload
        route = "build_report:" + payload["action"]
    else:
        options = request.dashboard or DashboardInput()
        if request.intent == "update":
            if options.op not in ("auto", "update"):
                return needs("/dashboard/op", "The update alias only accepts op=update.")
            options = options.model_copy(update={"op": "update"})
        payload = dashboard_request(workspace, options)
        if isinstance(payload, OperationEnvelope):
            return payload
        route = "build_report:dashboard:" + payload["dashboard"]["op"]
    response = runtime._invoke("build_report", payload)
    result = wrap(response, intent, workspace, route)
    if response.result is None or response.status in ("needs_input", "adapter_refresh_required"):
        return result
    try:
        if intent == "dashboard":
            validation = verify(workspace, payload["dashboard"]["dashboard_id"])
        else:
            validation = verify_report_artifacts(response, workspace)
    except (ValueError, OSError, KeyError, IndexError, TypeError):
        return result.model_copy(
            update={
                "status": OperationStatus.NEEDS_INPUT,
                "issues": [
                    *result.issues,
                    OperationIssue(
                        code="command_delivery_failed",
                        message="Report artifact verification failed.",
                    ),
                ],
                "missing_inputs": [
                    MissingInput(
                        field_path="/artifacts/html",
                        reason="Repair with the matching runtime; do not deliver invalid HTML.",
                    )
                ],
            }
        )
    result.result.update(
        {
            "artifacts": {"html": validation["html"]},
            "validation": validation,
            "next_step": "Link artifacts.html in the final answer and explain data limitations.",
        }
    )
    if intent == "dashboard":
        source_states = validation["data_status"]["sources"]
        missing_files = [
            key
            for key, source in source_states.items()
            if source["route"] == "file_import"
            and payload["dashboard"]["op"] != "status"
            and not any(i["source_key"] == key for i in payload["dashboard"].get("ingest", []))
        ]
        stale = [key for key, source in source_states.items() if source["freshness"] != "fresh"]
        if missing_files or stale:
            result = result.model_copy(
                update={
                    "status": OperationStatus.PARTIAL_RESULT
                    if result.status == "complete"
                    else result.status,
                    "issues": [
                        *result.issues,
                        OperationIssue(
                            code="dashboard_data_incomplete",
                            severity="warning",
                            message="The HTML is available, but some sources need new evidence. "
                            "No new file means no new advertising data. Inspect data_status.",
                        ),
                    ],
                }
            )
    return result


def analysis_request(analysis):
    routes = {
        "dataset_id": ("file_review", {"dataset_id", "internal_dataset_id"}),
        "capture_id": ("host_review", {"capture_id", "context_capture_ids"}),
        "connection_id": (
            "analyze",
            {"connection_id", "period", "max_windows", "max_pages", "history_before"},
        ),
        "packet_id": ("build", {"packet_id", "draft", "monitor_run_ids"}),
    }
    selected = [name for name in routes if getattr(analysis, name) is not None]
    if len(selected) != 1:
        return needs(
            "/analysis",
            "Select exactly one dataset_id, capture_id, connection_id or "
            "packet_id. For a new CSV/XLSX supply file with file_path/import_options "
            "for preview, then confirm its interpretation. No source is selected for you.",
        )
    action, allowed = routes[selected[0]]
    if analysis.model_fields_set - allowed:
        return needs(
            "/analysis",
            "Remove fields belonging to another analysis route; "
            "file/host reports review their entire retained snapshot.",
        )
    return {"action": action, **analysis.model_dump(mode="json", exclude_unset=True)}


def dashboard_request(workspace, options):
    entries = inventory(workspace)
    scope = set(options.source_scope)
    if len(scope) != len(options.source_scope):
        return needs("/dashboard/source_scope", "Remove duplicate source keys.")
    if options.op == "create":
        if not options.dashboard_id or not options.title or not options.sources:
            return needs(
                "/dashboard",
                "Creation needs an explicit dashboard_id, title and "
                "selected sources. Default history is 90 complete account-local days.",
            )
        if scope and scope != {s.key for s in options.sources}:
            return needs("/dashboard/source_scope", "Source scope must match all creation sources.")
        if any(e["dashboard_id"] == options.dashboard_id for e in entries):
            return needs("/dashboard/dashboard_id", "This dashboard exists; reuse it with update.")
    else:
        if options.sources or options.title or options.history_start:
            return needs(
                "/dashboard",
                "Use op=create for a new dashboard; existing source "
                "bindings, title and history_start are fixed.",
            )
        matches = [
            e
            for e in entries
            if (not options.dashboard_id or e["dashboard_id"] == options.dashboard_id)
            and (not scope or set(e["sources"]) == scope)
        ]
        if len(matches) != 1:
            return needs(
                "/dashboard/dashboard_id",
                "Choose a dashboard in this workspace with "
                "the exact requested source scope, or explicitly create a new one.",
                {"candidates": matches},
            )
        options = options.model_copy(update={"dashboard_id": matches[0]["dashboard_id"]})
    payload = options.model_dump(mode="json", exclude={"source_scope"}, exclude_none=True)
    payload["op"] = "update" if options.op == "auto" else options.op
    return {"action": "dashboard", "dashboard": payload}


def wrap(response, intent, workspace, route):
    details = response.result
    if hasattr(details, "model_dump"):
        details = details.model_dump(mode="json")
    return response.model_copy(
        update={
            "operation": "pallas_command",
            "result": {
                "intent": intent,
                "workspace": str(workspace),
                "route": route,
                "expected_artifacts": ["html"],
                "artifacts": {},
                "validation": {"verified": False},
                "details": details,
            },
        }
    )
