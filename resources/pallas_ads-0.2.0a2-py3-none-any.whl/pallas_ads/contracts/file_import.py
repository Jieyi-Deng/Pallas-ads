"""Explicit interpretation of a single-account, campaign/day advertising export."""

from typing import Literal

from pydantic import Field

from pallas_ads.contracts.base import ContractModel
from pallas_ads.contracts.common import MediaPlatform


class FileImportOptions(ContractModel):
    platform: MediaPlatform
    account_id: str | None = Field(default=None, min_length=1, max_length=100)
    currency: str | None = Field(default=None, pattern=r"^[A-Z]{3}$")
    timezone: str | None = Field(default=None, max_length=100)
    sheet: str | None = Field(default=None, max_length=200)
    header_row: int = Field(default=1, ge=1, le=20)
    delimiter: Literal[",", ";", "\t"] = ","
    column_mapping: dict[str, str] = Field(default_factory=dict, max_length=20)
    conversion_event: str | None = Field(default=None, min_length=1, max_length=100)
    attribution_window: str | None = Field(default=None, min_length=1, max_length=200)
    reporting_time_basis: Literal[
        "delivery_date", "ad_interaction_date", "conversion_date", "unknown"
    ] = "unknown"


InternalChannel = Literal["paid", "organic", "excluded", "unknown"]


class InternalConversionOptions(ContractModel):
    """User-confirmed meaning of an internal (first-party) acquisition/conversion export.

    Internal data is matched to one retained advertising file by explicit rules only:
    same local date basis, a confirmed platform value and exact campaign IDs. Names never match.
    """

    timezone: str = Field(max_length=100)
    currency: str | None = Field(default=None, pattern=r"^[A-Z]{3}$")
    conversion_definition: str = Field(min_length=1, max_length=200)
    attribution_basis: str = Field(min_length=1, max_length=200)
    cohort_basis: Literal["acquisition_date", "event_date"]
    new_user_definition: str | None = Field(default=None, min_length=1, max_length=200)
    retention_definition: str | None = Field(default=None, min_length=1, max_length=200)
    channel_mapping: dict[str, InternalChannel] = Field(default_factory=dict, max_length=50)
    platform_mapping: dict[str, MediaPlatform] = Field(default_factory=dict, max_length=50)
    sheet: str | None = Field(default=None, max_length=200)
    header_row: int = Field(default=1, ge=1, le=20)
    delimiter: Literal[",", ";", "\t"] = ","
    column_mapping: dict[str, str] = Field(default_factory=dict, max_length=20)
