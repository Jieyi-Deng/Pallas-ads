"""Evidence-bound competitor advertising research brief produced by the host agent.

The runtime never browses. The agent researches public sources and submits this brief; the
runtime validates citations, evidence layers and controllable recommendations, then renders.
"""

from __future__ import annotations

from datetime import date
from typing import Annotated, Literal
from urllib.parse import urlsplit

from pydantic import Field, model_validator

from pallas_ads.contracts.base import ContractModel

Text = Annotated[str, Field(min_length=1, max_length=600)]
Short = Annotated[str, Field(min_length=1, max_length=160)]
SourceId = Annotated[str, Field(pattern=r"^S[0-9]{1,3}$")]
CompetitorId = Annotated[str, Field(pattern=r"^C[0-9]{1,3}$")]
ObservationId = Annotated[str, Field(pattern=r"^O[0-9]{1,3}$")]
FindingId = Annotated[str, Field(pattern=r"^F[0-9]{1,3}$")]
AdPlatform = Literal["google", "meta", "tiktok", "other"]
SourceType = Literal[
    "ad_library",
    "transparency_center",
    "creative_center",
    "official_site",
    "app_store",
    "press_release",
    "news",
    "industry_report",
    "third_party_estimate",
    "other",
]
# Reliability is derived from the source type, never self-declared by the agent.
RELIABILITY: dict[str, str] = {
    "ad_library": "high",
    "transparency_center": "high",
    "official_site": "high",
    "app_store": "high",
    "creative_center": "medium",
    "press_release": "medium",
    "news": "medium",
    "industry_report": "medium",
    "third_party_estimate": "low",
    "other": "low",
}
# Public delivery figures may only come from a platform's own disclosure surface.
METRIC_SOURCES = frozenset({"ad_library", "transparency_center", "creative_center"})
SYNTHETIC_HOSTS = ("example.com", "example.org", "example.net")
Lever = Literal[
    "creative",
    "messaging",
    "format",
    "audience_targeting",
    "bidding",
    "budget_allocation",
    "landing_page",
    "offer",
    "test_design",
    "platform_mix",
]


class Advertiser(ContractModel):
    product: Short
    description: Text
    category: Short
    regions: list[Short] = Field(min_length=1, max_length=20)
    audiences: list[Short] = Field(min_length=1, max_length=10)
    platforms: list[AdPlatform] = Field(min_length=1, max_length=4)
    website: str | None = Field(default=None, pattern=r"^https://", max_length=500)


class ResearchScope(ContractModel):
    researched_on: date
    lookback_note: Text
    method: Text
    queries: list[Short] = Field(default_factory=list, max_length=50)


class Source(ContractModel):
    source_id: SourceId
    url: str = Field(pattern=r"^https://[^\s]+$", max_length=1000)
    title: Short
    publisher: Short
    source_type: SourceType
    accessed_on: date
    published_on: date | None = None


class Competitor(ContractModel):
    competitor_id: CompetitorId
    name: Short
    product: Short
    relationship: Literal["direct", "indirect", "substitute"]
    basis: Text
    regions: list[Short] = Field(default_factory=list, max_length=20)
    source_ids: list[SourceId] = Field(min_length=1, max_length=10)


class CreativeObservation(ContractModel):
    """One publicly visible ad or ad set, described in the agent's words (no copied media)."""

    observation_id: ObservationId
    competitor_id: CompetitorId
    platform: AdPlatform
    region: Short | None = None
    format: Literal["video", "image", "carousel", "search_text", "collection", "playable", "other"]
    angle: Literal[
        "price_or_offer",
        "feature_demo",
        "social_proof",
        "creator_or_ugc",
        "problem_solution",
        "comparison",
        "brand_story",
        "urgency",
        "other",
    ]
    description: Text
    call_to_action: Short | None = None
    first_seen: date | None = None
    last_seen: date | None = None
    active_when_accessed: bool | None = None
    public_metric: Short | None = None
    source_ids: list[SourceId] = Field(min_length=1, max_length=5)


class Finding(ContractModel):
    finding_id: FindingId
    kind: Literal["verified", "inference"]
    statement: Text
    source_ids: list[SourceId] = Field(default_factory=list, max_length=10)
    observation_ids: list[ObservationId] = Field(default_factory=list, max_length=30)
    confidence: Literal["low", "medium"] | None = None


class EvidenceGap(ContractModel):
    topic: Short
    reason: Text
    how_to_close: Text


class Recommendation(ContractModel):
    lever: Lever
    action: Text
    rationale: Text
    finding_ids: list[FindingId] = Field(min_length=1, max_length=10)
    success_measure: Text
    priority: Literal["now", "next", "later"]


class CompetitorBrief(ContractModel):
    evidence_mode: Literal["public_research", "synthetic_fixture"]
    advertiser: Advertiser
    scope: ResearchScope
    sources: list[Source] = Field(min_length=1, max_length=150)
    competitors: list[Competitor] = Field(max_length=15)
    observations: list[CreativeObservation] = Field(default_factory=list, max_length=150)
    findings: list[Finding] = Field(min_length=1, max_length=40)
    headline_finding_ids: list[FindingId] = Field(min_length=1, max_length=5)
    gaps: list[EvidenceGap] = Field(default_factory=list, max_length=30)
    recommendations: list[Recommendation] = Field(default_factory=list, max_length=15)

    @model_validator(mode="after")
    def check_evidence(self):
        sources = {s.source_id: s for s in self.sources}
        competitors = {c.competitor_id for c in self.competitors}
        observations = {o.observation_id: o for o in self.observations}
        findings = {f.finding_id: f for f in self.findings}
        for label, ids in (
            ("source", [s.source_id for s in self.sources]),
            ("competitor", [c.competitor_id for c in self.competitors]),
            ("observation", list(observations)),
            ("finding", [f.finding_id for f in self.findings]),
        ):
            if len(ids) != len(set(ids)):
                raise ValueError(f"duplicate {label} IDs")
        synthetic = self.evidence_mode == "synthetic_fixture"
        for s in self.sources:
            host = (urlsplit(s.url).hostname or "").lower()
            placeholder = any(host == h or host.endswith("." + h) for h in SYNTHETIC_HOSTS)
            if synthetic != placeholder:
                raise ValueError(
                    "synthetic fixtures must use example.com/org/net URLs and public research "
                    "must not; never present invented sources as real"
                )
            if s.accessed_on > self.scope.researched_on:
                raise ValueError(f"{s.source_id} accessed after the research date")
        used = set()

        def cite(ids, owner):
            missing = set(ids) - set(sources)
            if missing:
                raise ValueError(f"{owner} cites unknown sources")
            used.update(ids)

        for c in self.competitors:
            cite(c.source_ids, c.competitor_id)
        for o in self.observations:
            cite(o.source_ids, o.observation_id)
            if o.competitor_id not in competitors:
                raise ValueError(f"{o.observation_id} references an unknown competitor")
            types = {sources[i].source_type for i in o.source_ids}
            if types <= {"third_party_estimate", "other"}:
                raise ValueError(
                    f"{o.observation_id}: creative observations need a primary public source; "
                    "third-party estimates alone are not observations"
                )
            if o.public_metric is not None and not types & METRIC_SOURCES:
                raise ValueError(
                    f"{o.observation_id}: public_metric must come from an ad library, "
                    "transparency center or creative center"
                )
            if o.first_seen and o.last_seen and o.first_seen > o.last_seen:
                raise ValueError(f"{o.observation_id}: first_seen is after last_seen")
        for f in self.findings:
            cite(f.source_ids, f.finding_id)
            if set(f.observation_ids) - set(observations):
                raise ValueError(f"{f.finding_id} references unknown observations")
            if f.kind == "verified":
                if not f.source_ids or f.confidence is not None:
                    raise ValueError(
                        f"{f.finding_id}: verified findings cite sources and take no confidence"
                    )
                if all(RELIABILITY[sources[i].source_type] == "low" for i in f.source_ids):
                    raise ValueError(
                        f"{f.finding_id}: low-reliability sources cannot verify a finding; "
                        "record it as an inference"
                    )
            elif not f.observation_ids and not f.source_ids or f.confidence is None:
                raise ValueError(
                    f"{f.finding_id}: inferences reference evidence and state low/medium confidence"
                )
        if set(self.headline_finding_ids) - set(findings):
            raise ValueError("headline findings must exist")
        for r in self.recommendations:
            if set(r.finding_ids) - set(findings):
                raise ValueError("recommendations must reference existing findings")
        if set(sources) - used:
            raise ValueError("every listed source must support a competitor, observation, finding")
        return self
