# ruff: noqa: E501
"""Human-facing three-part observation report, rendered from the shared Skill template."""

from __future__ import annotations

import csv
import hashlib
import html
import io
import json
import os
import unicodedata
from datetime import date, timedelta
from decimal import Decimal, InvalidOperation, localcontext
from pathlib import Path
from string import Template
from uuid import uuid4

RENDERER_VERSION = "2.4.0"
METRICS = {
    "spend": "花费",
    "impressions": "展示",
    "clicks": "点击",
    "ctr": "点击率",
    "cpc": "平均点击成本",
    "cpm": "千次展示成本",
}
GOALS = {
    "INSTALL": "安装",
    "APP_INSTALLS": "安装",
    "CLICK": "点击",
    "LINK_CLICKS": "链接点击",
    "CONVERT": "转化事件",
    "OFFSITE_CONVERSIONS": "站外转化",
    "CONVERSIONS": "转化事件",
    "VALUE": "转化价值",
    "CONVERSION_VALUE": "转化价值",
    "REACH": "覆盖人数",
    "IMPRESSION": "展示",
    "IMPRESSIONS": "展示",
    "LANDING_PAGE_VIEWS": "落地页浏览",
}
DIMENSIONS = {"age": "年龄", "gender": "性别", "country": "地区"}


def encode(value):
    if isinstance(value, Decimal):
        return str(value)
    if isinstance(value, date):
        return value.isoformat()
    if hasattr(value, "model_dump"):
        return value.model_dump(mode="json")
    raise TypeError("unsupported report value")


def dump(value):
    return json.dumps(value, default=encode, ensure_ascii=False, sort_keys=True, indent=2)


def esc(value):
    return html.escape(str(value), quote=True)


def number(value):
    if value is None or isinstance(value, bool):
        return None
    try:
        v = Decimal(str(value))
        return v if v.is_finite() else None
    except InvalidOperation:
        return None


def fmt(value, *, percent=False, signed=False):
    v = number(value)
    if v is None:
        return "未提供"
    with localcontext() as ctx:
        ctx.prec = max(38, len(v.as_tuple().digits) + abs(v.as_tuple().exponent) + 8)
        v = v * 100 if percent else v
        v = v.quantize(Decimal("0.01"))
    if not v:
        v = abs(v)
    precision = 0 if v == v.to_integral_value() else 2
    return format(v, ("+" if signed else "") + f",.{precision}f") + ("%" if percent else "")


def template_path():
    bundled = Path(__file__).parent / "resources/skills/pallas-analysis/assets/report.html"
    return (
        bundled
        if bundled.is_file()
        else Path(__file__).parents[2] / "skills/pallas-analysis/assets/report.html"
    )


def table(headers, rows, *, numeric=()):
    return (
        '<div class="table-wrap"><table><thead><tr>'
        + "".join(
            f'<th scope="col" class="{"number" if i in numeric else "text"}">{esc(h)}</th>'
            for i, h in enumerate(headers)
        )
        + "</tr></thead><tbody>"
        + "".join(
            "<tr>"
            + "".join(
                f'<td class="{"number" if i in numeric else "text"}">{esc(v)}</td>'
                for i, v in enumerate(row)
            )
            + "</tr>"
            for row in rows
        )
        + "</tbody></table></div>"
    )


def period_text(period):
    if isinstance(period, dict):
        return f"{period.get('start', '未知')} 至 {period.get('end', '未知')}"
    if isinstance(period, list) and len(period) == 2:
        return f"{period[0]} 至 {period[1]}"
    return "未提供"


def campaign_names(report):
    names = {}
    for c in report["context"].get("campaign_configuration", []):
        native = c.get("native", {})
        value = (
            native.get("campaign_name")
            or native.get("name")
            or native.get("campaign", {}).get("name")
        )
        names[c["campaign_id"]] = str(value or c["campaign_id"])
    return names


def bars(items, title, *, unit="", signed=False, caption=""):
    """Zero-based bars with direct value labels; signed contributions share a zero line."""
    valid = [(str(label), number(value)) for label, value in items if number(value) is not None]
    if not valid:
        return '<p class="muted">暂无可绘制的数据。</p>'
    scale = max(abs(v) for _, v in valid) or Decimal(1)
    zero, extent = (540, 210) if signed else (340, 410)
    height = len(valid) * 42 + 54
    svg = [
        f'<text x="12" y="20" class="chart-unit">单位：{esc(unit or "未提供")}</text>',
        f'<line x1="{zero}" x2="{zero}" y1="35" y2="{height - 10}" stroke="#ccd7d6"/>',
    ]
    for i, (label, v) in enumerate(valid):
        y = 42 + i * 42
        width = float(abs(v) / scale) * extent
        x = zero - width if v < 0 else zero
        color = (
            ("#b25836" if v > 0 else "#087c83") if signed else ("#087c83" if i == 0 else "#a5bcbe")
        )
        display, width_units = "", 0
        for character in label:
            width_units += 2 if unicodedata.east_asian_width(character) in ("W", "F") else 1
            if width_units > 38:
                display += "…"
                break
            display += character
        svg.append(
            f'<text x="12" y="{y + 18}">{esc(display)}<title>{esc(label)}</title></text><rect x="{x:.4f}" y="{y}" width="{width:.4f}" height="25" fill="{color}"><title>{esc(label)}：{fmt(v, signed=signed)} {esc(unit)}</title></rect><text x="800" y="{y + 18}">{fmt(v, signed=signed)}</text>'
        )
    compact = []
    for label, v in valid:
        width = float(abs(v) / scale) * (50 if signed else 100)
        left = (50 - width if v < 0 else 50) if signed else 0
        color = ("#b25836" if v > 0 else "#087c83") if signed else "#087c83"
        compact.append(
            f'<div class="compact-bar"><div>{esc(label)}</div><div class="compact-bar-value"><div class="bar-track"><span class="bar-zero" style="left:{50 if signed else 0}%"></span><span class="bar-fill" style="left:{left:.4f}%;width:{width:.4f}%;background:{color}"></span></div><strong>{fmt(v, signed=signed)}</strong></div></div>'
        )
    mobile = f'<div class="compact-bars"><p class="chart-note">单位：{esc(unit)}</p>{"".join(compact)}</div>'
    return f'<figure class="bar-figure"><div class="chart-scroll desktop-chart"><svg role="img" aria-label="{esc(title)}" viewBox="0 0 960 {height}"><title>{esc(title)}</title>{"".join(svg)}</svg></div>{mobile}<figcaption>{esc(caption)} 单位：{esc(unit)}。条形从零起算，数值直接标注。</figcaption></figure>'


def mobile_trend(valid, currency):
    """Same dates and values on a narrow, legible canvas, without horizontal scrolling."""
    first, last = valid[0][0], valid[-1][0]
    days = (last - first).days
    span = max(days, 1)
    top = max(v for _, v in valid if v is not None) or Decimal(1)
    svg = [f'<text x="60" y="18">花费（{esc(currency)}）</text>']
    for fraction in (Decimal(0), Decimal("0.5"), Decimal(1)):
        y = 180 - float(fraction) * 140
        svg.append(
            f'<line x1="60" x2="306" y1="{y}" y2="{y}" stroke="#e4ebe9"/><text x="54" y="{y + 4}" text-anchor="end">{fmt(top * fraction)}</text>'
        )
    previous = None
    for day, value in valid:
        if value is None:
            previous = None
            continue
        x, y = 60 + (day - first).days / span * 246, 180 - float(value / top) * 140
        if previous and (day - previous[0]).days == 1:
            svg.append(
                f'<line x1="{previous[1]}" y1="{previous[2]}" x2="{x}" y2="{y}" stroke="#087c83" stroke-width="2"/>'
            )
        svg.append(
            f'<circle cx="{x}" cy="{y}" r="2.5" fill="#087c83"><title>{day}：{fmt(value)} {esc(currency)}</title></circle>'
        )
        previous = day, x, y
    ticks = sorted({first, first + timedelta(days=days // 2), last})
    for day in ticks:
        x = 60 + (day - first).days / span * 246
        anchor = "start" if day == first else "end" if day == last else "middle"
        svg.append(f'<text x="{x}" y="211" text-anchor="{anchor}">{day:%m-%d}</text>')
    return f'<div class="mobile-trend"><svg role="img" aria-label="已观测分日花费，{first} 至 {last}" viewBox="0 0 320 230"><title>已观测分日花费</title>{"".join(svg)}</svg><p class="chart-note">{first} 至 {last}；缺失日期断线。</p></div>'


def trend(daily, currency):
    valid = [(date.fromisoformat(r["date"]), number(r.get("spend"))) for r in daily]
    if not valid or not any(v is not None for _, v in valid):
        return '<p class="muted">未取得可用的分日花费，不能绘制趋势。</p>'
    valid.sort()
    first, last = valid[0][0], valid[-1][0]
    span = max((last - first).days, 1)
    top = max(v for _, v in valid if v is not None) or Decimal(1)
    svg = [f'<text x="135" y="20" class="chart-unit">花费（{esc(currency)}）</text>']
    for fraction in (Decimal(0), Decimal("0.5"), Decimal(1)):
        y = 248 - float(fraction) * 200
        svg.append(
            f'<line x1="135" x2="920" y1="{y:.4f}" y2="{y:.4f}" stroke="#e4ebe9"/><text x="120" y="{y + 5:.4f}" text-anchor="end">{fmt(top * fraction)}</text>'
        )
    previous = None
    for day, v in valid:
        if v is None:
            previous = None
            continue
        x = 135 + (day - first).days / span * 785
        y = 248 - float(v / top) * 200
        if previous and (day - previous[0]).days == 1:
            svg.append(
                f'<line x1="{previous[1]:.4f}" y1="{previous[2]:.4f}" x2="{x:.4f}" y2="{y:.4f}" stroke="#087c83" stroke-width="2"/>'
            )
        svg.append(
            f'<circle cx="{x:.4f}" cy="{y:.4f}" r="3" fill="#087c83"><title>{day}：{fmt(v)} {esc(currency)}</title></circle>'
        )
        previous = (day, x, y)
    # Keep a readable number of calendar-spaced ticks, including a single-day range.
    days = (last - first).days
    step = next(
        (s for s in (1, 2, 3, 7, 14, 30, 60, 90, 180, 365) if s >= days / 5),
        max(1, (days + 4) // 5),
    )
    ticks = [first + timedelta(days=n) for n in range(0, days + 1, step)]
    if ticks[-1] != last:
        if len(ticks) > 1 and (last - ticks[-1]).days < step / 2:
            ticks.pop()
        ticks.append(last)
    # Endpoint labels face inward; their occupied width exceeds half a middle label.
    # Calendar spacing alone can leave the penultimate label overlapping the end date.
    spaced = [first]
    for day in ticks[1:-1]:
        left_gap = (day - spaced[-1]).days / span * 785
        right_gap = (last - day).days / span * 785
        if left_gap >= (160 if spaced[-1] == first else 110) and right_gap >= 160:
            spaced.append(day)
    if last != first:
        spaced.append(last)
    ticks = spaced
    for day in ticks:
        x = 135 + (day - first).days / span * 785
        anchor = "start" if day == first else "end" if day == last else "middle"
        svg.append(
            f'<line x1="{x:.4f}" x2="{x:.4f}" y1="248" y2="255" stroke="#ccd7d6"/><text class="date-tick" x="{x:.4f}" y="281" text-anchor="{anchor}">{day}</text>'
        )
    return f'<figure><div class="chart-scroll desktop-chart"><svg viewBox="0 0 960 304" role="img" aria-label="已观测分日花费"><title>已观测分日花费</title>{"".join(svg)}</svg></div>{mobile_trend(valid, currency)}<figcaption>单位：{esc(currency)}；横轴按实际日期间距绘制。缺失日期断线，不补零。所有日期保存在<a href="evidence/daily.csv">分日明细</a>。</figcaption></figure>'


def change_summary(change):
    if not change:
        return "可比较日期不足，暂不判断前后表现变化。"
    before, after = number(change["before"].get("cpc")), number(change["after"].get("cpc"))
    if before is None or after is None:
        return "比较区间存在缺失值或零点击，平均点击成本的变化无法完整计算。"
    direction = "上升" if after > before else "下降" if after < before else "不变"
    relative = (
        f"，相对变化 {fmt((after - before) / before, percent=True, signed=True)}"
        if before
        else "，基期为零，不计算相对变化"
    )
    return f"平均点击成本从 {fmt(before)} 变为 {fmt(after)}，{direction}{relative}。"


QUALITY = {
    "conversion_rate": ("内部转化率", "转化 / 新增用户"),
    "revenue_per_new_user": ("新增用户人均收入", "收入 / 新增用户"),
    "retention_rate": ("留存率", "留存用户 / 新增用户"),
}
EFFICIENCY = {
    "internal_cac": "内部口径获客成本",
    "cost_per_internal_conversion": "内部口径单次转化成本",
    "internal_revenue_to_spend": "内部收入 / 广告花费",
    "platform_to_internal_conversion_ratio": "媒体转化数 / 内部付费转化数",
}


def labelled(text, note, warned):
    """Mark a metric calculated from provided data and keep its warning beside it."""
    if not note or note.get("basis") != "provided_data":
        return text
    text += "（按已提供数据计算）"
    warned[text] = note["warnings"]
    return text


def internal_section(report, currency, label):
    """Keep decision-relevant internal outcomes in prose; export detail separately."""
    ig = report.get("internal_integration")
    if not ig:
        return "", [], [], ""
    s, al = ig["internal_summary"], ig["alignment"]
    # A metric from incomplete inputs carries its label and factual warning beside it.
    findings, actions, warned = [], [], {}
    basis = f"内部口径：{s['conversion_definition']}；{s['attribution_basis']}；{s['timezone']}；队列基准为{'获客日期' if s['cohort_basis'] == 'acquisition_date' else '事件日期'}。"
    if ig["status"] != "integrated":
        reason = ig["unavailable"][0]["reason"] if ig["unavailable"] else "数据不可匹配。"
        findings.append("内部转化数据未能与广告文件匹配：" + reason)
        actions.append(
            [
                "整合前置",
                "按同一时区和重叠日期重新导出内部数据",
                "匹配前不输出获客成本或付费/自然对比。",
            ]
        )
        markup = (
            "<article><h3>广告与内部转化未能与广告文件匹配</h3>"
            + f'<p>{esc(reason)}</p><p class="finding-note">{esc(basis)}</p>'
        )
    else:
        eff, notes = ig.get("efficiency") or {}, ig.get("metric_notes") or {}
        if eff.get("internal_cac") is not None:
            text = f"按内部口径，本媒体付费新增用户的获客成本为 {fmt(eff['internal_cac'])} {currency}。"
            findings.append(labelled(text, notes.get("internal_cac"), warned))
        for c in ig.get("quality_comparison", []):
            if c["eligible"]:
                name, _ = QUALITY[c["metric"]]
                percent = c["metric"] != "revenue_per_new_user"
                text = f"{name}：付费 {fmt(c['paid'], percent=percent)}，自然 {fmt(c['organic'], percent=percent)}（描述性差异，非因果）。"
                findings.append(labelled(text, c, warned))
        markup = "<article><h3>广告与内部转化：付费获客与自然增长</h3>"
        markup += (
            "".join(
                f"<p>{esc(f)}</p>"
                + (
                    f'<p class="finding-note">{esc("".join(warned[f]))}</p>'
                    if f in warned
                    else ""
                )
                for f in findings
            )
            or "<p>目前没有满足条件的付费与自然质量比较。</p>"
        )
        markup += f'<p class="finding-note">共同期间：{esc(period_text(al["overlap"]))}，{fmt(al["overlap_dates"])} 天；广告另有 {fmt(al["ad_dates_outside_overlap"])} 天、内部另有 {fmt(al["internal_dates_outside_overlap"])} 天未参与计算。{esc(basis)}</p>'
        ratio = eff.get("platform_to_internal_conversion_ratio")
        if ratio is not None:
            text = labelled(
                f"平台转化数为内部付费转化数的 {fmt(ratio)} 倍。",
                notes.get("platform_to_internal_conversion_ratio"),
                warned,
            )
            markup += f"<p>{esc(text)}两者不能相加；差异需核对事件定义、归因窗口与去重，不能直接判定哪方错误。</p>"
            if text in warned:
                markup += f'<p class="finding-note">{esc("".join(warned[text]))}</p>'
            actions.append(
                [
                    "先核对口径",
                    "对齐媒体事件与内部转化定义",
                    "核对事件、归因窗口及去重规则，确认业务采用的评价口径。",
                ]
            )
        unavailable = [
            f"{QUALITY.get(c['metric'], (c['metric'], ''))[0]}：{c['reason']}"
            for c in ig.get("quality_comparison", [])
            if not c["eligible"]
        ]
        unavailable.extend(f"{u['metric']}：{u['reason']}" for u in ig.get("unavailable", []))
        if unavailable:
            markup += (
                '<p class="finding-note">暂不能判断：'
                + esc("；".join(dict.fromkeys(unavailable)))
                + "</p>"
            )
        markup += '<p class="finding-note">只有映射为本媒体的付费数据才与广告花费计算效率；渠道未知、未标注及排除行不归给任一方。组间质量比较需满足原有样本门槛，不是显著性检验；同期自然增长不证明广告带动或挤占。</p>'
        campaigns = ig.get("campaigns") or {}
        if campaigns.get("available"):
            markup += f'<p class="finding-note">系列仅按完全相同编号匹配；内部未匹配编号 {fmt(len(campaigns.get("internal_ids_without_ad_rows", [])))} 个，无内部记录的系列 {fmt(len(campaigns.get("ad_campaigns_without_internal_rows", [])))} 个，缺编号的付费行 {fmt(campaigns.get("paid_rows_without_campaign_id"))} 行。</p>'
        if findings:
            actions.append(
                [
                    "随后验证",
                    "复核同批用户的付费与自然质量差异",
                    "保持转化定义、获客日期和观察期一致；不要用单期描述性差异决定扩量。",
                ]
            )
    markup += '<div class="evidence-links"><a href="evidence/internal_daily.csv">内部分日 CSV</a><a href="evidence/internal_quality.csv">质量比较 CSV</a><a href="evidence/internal_groups.csv">渠道分组 CSV</a><a href="evidence/internal_efficiency.csv">效率指标 CSV</a><a href="evidence/internal_campaigns.csv">系列匹配 CSV</a><a href="evidence/internal_organic_trend.csv">自然增长 CSV</a><a href="evidence/internal_matching.json">完整匹配规则与限制</a></div></article>'
    md = "\n\n### 广告与内部转化\n\n" + basis + "\n"
    md += "\n".join(
        "- " + f + ("\n  - 注意：" + "".join(warned[f]) if f in warned else "") for f in findings
    )
    md += "\n- 匹配规则：" + "；".join(ig["matching_rules"]) + "\n"
    return markup, findings, actions, md


def action_rows(actions):
    """Read decisions in order, without a wide table or parallel cards."""
    return (
        '<ol class="action-list">'
        + "".join(
            f'<li><div class="action-stage">{esc(stage)}</div><h3>{esc(title)}</h3><p>{esc(reason)}</p></li>'
            for stage, title, reason in actions
        )
        + "</ol>"
    )


def evidence_link(path, label):
    return f'<p class="source-link"><a href="{esc(path)}">{esc(label)}（CSV）</a></p>'


def render(report):
    scope, d, ctx = report["scope"], report["diagnostics"], report["context"]
    currency = scope.get("currency") or "币种未知"
    platform = {"tiktok": "TikTok", "google": "Google Ads", "meta": "Meta Ads"}.get(
        scope["platform"], scope["platform"]
    )
    title = f"{platform} 账户投放分析"
    names = campaign_names(report)

    def label(key):
        return names.get(key, str(key))

    products = sorted(
        {
            m["product_name"]
            for p in ctx.get("product_resolution", [])
            for m in p.get("matches", [])
            if p["status"] == "resolved"
        }
    )
    goals = sorted(
        {
            GOALS.get(g.get("optimization_goal"), g.get("optimization_goal") or "未核实")
            for g in ctx.get("optimization_context", [])
        }
    )
    windows = scope.get("windows", [])
    retrieved = scope.get("requested_period") or (
        {"start": min(w["start"] for w in windows), "end": max(w["end"] for w in windows)}
        if windows
        else None
    )
    coverage = (
        "已读取所选文件的全部有效行；媒体账户的完整覆盖尚未核实。"
        if report.get("evidence_mode") == "user_file"
        else "已获取花费与媒体可用 Lifetime 总量按系列核对一致。"
        if scope.get("lifetime_spend_reconciled")
        else "已读完媒体最大可用范围。"
        if scope.get("provider_maximum_read_complete")
        else "已完成指定日期读取。"
        if scope.get("requested_period_read_complete")
        else "历史检索尚未完成，以下仅总结已获取的数据。"
    )
    change = d.get("change")
    primary = change_summary(change)
    comparison = scope.get("diagnostic_comparison_period")
    campaigns = sorted(
        d.get("campaigns", []), key=lambda r: number(r.get("spend")) or Decimal(0), reverse=True
    )
    total = number(d["totals"].get("spend"))
    concentration = "暂无可用的系列花费构成。"
    if campaigns and total and number(campaigns[0].get("spend")) is not None:
        leader = campaigns[0]
        concentration = f"{label(leader['campaign_id'])} 占已获取花费的 {fmt(number(leader['spend']) / total, percent=True)}。"
    internal_html, internal_findings, internal_actions, internal_md = internal_section(
        report, currency, label
    )
    overview = f'<div class="scope"><span>账户 <strong>{esc(scope["account_id"])}</strong></span><span>{esc(period_text(retrieved))}</span><span>{esc(currency)} · {esc(scope.get("timezone") or "时区未核实")}</span></div>'
    overview += f'<p class="small">产品：{esc("、".join(products) or "归属尚待核实")} · 当前优化目标：{esc("、".join(goals) or "尚待核实")}。</p>'
    overview += f'<div class="takeaway"><p>{esc(primary)}</p><p class="next">下一步：先核对优化事件与业务目标，再检查主要系列的变化和下游质量。</p></div>'
    # These are the retained diagnostic metrics; no prototype conversion values or CPA are inferred.
    overview += (
        '<dl class="metrics">'
        + "".join(
            f'<div class="metric"><dt>{METRICS[key]}</dt><dd>{fmt(d["totals"].get(key), percent=key == "ctr")}</dd><div class="unit">{esc(currency if key in ("spend", "cpc") else "次" if key == "clicks" else "点击 / 展示")}</div></div>'
            for key in ("spend", "clicks", "cpc", "ctr")
        )
        + "</dl>"
    )
    qualifications = [
        coverage,
        "当前目标配置不是历史配置；这里的点击效率不代表购买或长期回收表现。",
    ]
    if report.get("evidence_mode") == "user_file":
        qualifications.append("来源为用户导入文件，未连接媒体 API，不是实时账户状态。")
        qualifications.append("仅含文件内的系列与日期；缺失值不补零，点击与转化归因口径待核实。")
        source = report["file_source"]
        if any(
            r.get("conversions") is not None or r.get("conversion_value") is not None
            for r in source["rows"]
        ):
            qualifications.append(
                f"文件转化事件：{scope.get('conversion_event') or '未确认'}；归因窗口：{scope.get('attribution_window') or '未确认'}。原生转化不自动等同购买，完整记录见来源明细 CSV。"
            )
    unresolved = [p for p in ctx.get("product_resolution", []) if p["status"] != "resolved"]
    if unresolved:
        qualifications.append(
            f"{fmt(len(unresolved))} 个系列的产品归属未解决，不能自动并入某个产品结论。"
        )
    failures = [a for a in report.get("attempts", []) if not a.get("usable")]
    if failures:
        qualifications.append(
            f"{fmt(len(failures))} 项读取未取得完整结果，相关目标或人群判断受限。"
        )
    overview += (
        '<div class="notice">' + " ".join(esc(q) for q in dict.fromkeys(qualifications)) + "</div>"
    )
    overview += f'<p class="small">已观测产生花费：{esc(scope.get("first_observed_spend_date") or "未发现")} 至 {esc(scope.get("last_observed_spend_date") or "未发现")}。波动比较范围：{esc(period_text(comparison))}。'
    overview += (
        "按用户指定期间比较。"
        if scope.get("diagnostic_comparison_policy") == "explicit_period"
        else "历史比较使用有花费的活动期间，避免停投后的零花费尾部拉偏结果。"
    ) + "</p>"
    overview += evidence_link("evidence/goals.csv", "查看各系列优化目标与事件")

    changes = f"<article><h3>{esc(primary)}</h3>"
    if change:
        changes += f'<p class="finding-note">前段：{esc(period_text(change["baseline"]))}；后段：{esc(period_text(change["comparison"]))}。两段等长，奇数跨度的中间一天不参与比较。</p>'
        components = change.get("components", [])
        if components:
            changes += (
                "<p>"
                + "；".join(
                    f"{'千次展示成本' if c['factor'] == 'CPM' else '点击率'}变化贡献 {fmt(c['cpc_delta'], signed=True)} {esc(currency)} / 点击"
                    for c in components
                )
                + "。</p>"
            )
            changes += bars(
                [(c["factor"], c["cpc_delta"]) for c in components],
                "点击成本的算术贡献",
                unit=f"{currency} / 点击",
                signed=True,
                caption="正值增加点击成本，负值抵消增加；分量来自同一留存计算。",
            )
        else:
            changes += "<p>分母缺失或为零，暂不能可靠拆解点击成本贡献。</p>"
    if change and change.get("components"):
        changes += '<p class="finding-note">这是算术分解，不证明竞价竞争、素材疲劳或受众变化。下一步需核对同期间配置、素材与转化证据。</p>'
    elif not change:
        changes += (
            '<p class="finding-note">补齐连续、可比较的日期后再判断变化；当前仅展示已获取数据。</p>'
        )
    changes += evidence_link("evidence/comparison.csv", "查看完整前后指标与贡献") + "</article>"

    if campaigns:
        changes += f"<article><h3>{esc(concentration)}</h3><p>先核对主要系列的目标和下游质量。花费集中说明优先检查的范围，不证明该系列低效。</p>"
        changes += bars(
            [(label(r["campaign_id"]), r.get("spend")) for r in campaigns[:5]],
            "主要系列花费",
            unit=currency,
            caption="按花费降序精选最多五个系列；其余系列保留在 CSV，不代表不存在。",
        )
        contributions = (change or {}).get("campaign_contributions", [])
        valid = [
            r
            for r in contributions
            if number(r.get("within_cpc")) is not None and number(r.get("mix_cpc")) is not None
        ]
        if valid:
            top = max(valid, key=lambda r: abs(number(r["within_cpc"]) + number(r["mix_cpc"])))
            changes += f"<p>{esc(label(top['campaign_id']))} 在可解析系列中对账户点击成本的净贡献绝对值最大：系列内效率贡献 {fmt(top['within_cpc'], signed=True)}，点击份额贡献 {fmt(top['mix_cpc'], signed=True)} {esc(currency)} / 点击。</p>"
            changes += '<p class="finding-note">这些是对账户变化的贡献，不是该系列自身 CPC 的变化。进入、退出或零点击组可能无法解析；份额贡献为零不证明预算未变。</p>'
        changes += evidence_link("evidence/campaigns.csv", "查看全部系列指标")
        changes += (
            evidence_link("evidence/campaign_contributions.csv", "查看系列贡献与未解析状态")
            + "</article>"
        )

    daily = d.get("daily", [])
    plotted = [
        r for r in daily if not comparison or comparison["start"] <= r["date"] <= comparison["end"]
    ]
    positives = [
        r for r in plotted if number(r.get("spend")) is not None and number(r["spend"]) > 0
    ]
    if positives:
        peak = max(positives, key=lambda r: number(r["spend"]))
        changes += f"<article><h3>{esc(peak['date'])} 的已观测日花费最高，为 {fmt(peak['spend'])} {esc(currency)}</h3>"
        changes += trend(plotted, currency)
        if d.get("anomalies"):
            changes += f'<p class="finding-note">筛查标记了 {fmt(len(d["anomalies"]))} 个需复核日期；先核对预算、暂停和数据延迟，不把标记当作原因或统计显著性。</p>'
        else:
            changes += '<p class="finding-note">峰值不等于异常。未返回筛查标记不证明筛查运行或业务正常；筛查需要至少 14 个可用日和非零中位绝对偏差。</p>'
        changes += evidence_link("evidence/anomalies.csv", "查看花费筛查标记") + "</article>"

    audience_notes = []
    for audience in report.get("delivered_audience", []):
        dim = DIMENSIONS.get(audience["dimension"], audience["dimension"])
        eligible = sorted(
            [
                r
                for r in audience["segments"]
                if number(r.get("clicks")) is not None
                and number(r["clicks"]) >= 30
                and number(r.get("cpc")) is not None
            ],
            key=lambda r: number(r["cpc"]),
        )
        if len(eligible) > 1:
            low, high = eligible[0], eligible[-1]
            audience_notes.append(
                f"{dim}分组：{high['segment']} 点击成本 {fmt(high['cpc'])}，{low['segment']} 为 {fmt(low['cpc'])} {currency}；各组仅比较同期间（{period_text(audience['period'])}），不是时间变化。"
            )
        else:
            audience_notes.append(
                f"{dim}分组在 {period_text(audience['period'])} 内不足两个可比较组，暂不排名。"
            )
    if audience_notes:
        changes += "<article><h3>人群点击成本差异还需要转化质量验证</h3>" + "".join(
            f"<p>{esc(n)}</p>" for n in audience_notes
        )
        changes += '<p class="finding-note">仅比较点击至少 30 次的分组；这是显示门槛，不是显著性检验。低 CPC 不证明购买或留存更好；配置定向不代表实际触达。</p>'
        changes += evidence_link("evidence/audience.csv", "查看完整人群指标与样本量") + "</article>"
    else:
        changes += '<p class="finding-note">人群变化暂不能判断：未取得可用的实际触达数据，不能用定向配置代替。</p>'
    changes += internal_html

    actions = [
        [
            "现在 · 确认评价口径",
            "核对优化事件与业务目标",
            "先确认产品归属、事件定义、归因窗口和历史适用期间，再决定用什么指标判断成效。",
        ],
        [
            "随后 · 检查主要变化",
            "复核主要系列的下游质量",
            "针对上文的系列和比较期间，检查同事件、同观察期的转化质量；缺失时先补数据，不据点击成本直接扩量。",
        ],
        *internal_actions,
    ]
    if d.get("restart_experiments"):
        actions.append(
            [
                "条件满足后 · 小范围验证",
                "一次只测试一个素材或受众因素",
                "先约定业务成功指标、质量护栏、预算和观察期；等待转化成熟后评估。实验结果只能支持或削弱假设，不能单独证明原因。",
            ]
        )
    recommendations = (
        "<p>当前可以确定检查顺序；预算与投放调整需等待目标口径和结果质量得到验证。</p>"
        + action_rows(actions)
    )
    recommendations += '<p class="finding-note">以上为验证建议，未修改广告。预算、成功阈值及扩量条件需要业务输入。</p>'
    links = '<div class="evidence-links">' + "".join(
        f'<a href="evidence/{path}">{name} CSV</a>'
        for path, name in [
            ("daily.csv", "分日"),
            ("campaigns.csv", "广告系列"),
            ("comparison.csv", "前后比较"),
            ("campaign_contributions.csv", "系列贡献"),
            ("audience.csv", "人群"),
            ("goals.csv", "目标与事件"),
        ]
    )
    if report.get("evidence_mode") == "user_file":
        links += '<a href="evidence/source_records.csv">原生转化与来源明细 CSV</a>'
    links += '<a href="report.json">完整原始证据</a><a href="evidence/notes.md">范围与口径说明</a><a href="manifest.json">文件校验</a></div>'
    output = Template(template_path().read_text()).substitute(
        title=esc(title),
        subtitle="看清主要变化，确定下一步。",
        overview=overview,
        changes=changes,
        recommendations=recommendations,
        evidence_links=links,
    )
    md = (
        f"# {title}\n\n## 一、账户与期间总结\n\n账户 {scope['account_id']}；{period_text(retrieved)}；{currency}。{coverage}\n\n{primary}\n\n"
        + "\n".join("- " + q for q in dict.fromkeys(qualifications))
    )
    md += (
        "\n\n## 二、变化与原因拆解\n\n"
        + primary
        + "\n\n"
        + concentration
        + "\n\n算术贡献不证明业务原因；图表、限定与精选证据见 [HTML 报告](report.html)。\n"
    )
    md += (
        internal_md
        + "\n\n## 三、主要发现与建议\n\n"
        + "\n".join(f"- {a[0]}：{a[1]}。{a[2]}" for a in actions)
    )
    md += "\n\n[分日 CSV](evidence/daily.csv) · [系列 CSV](evidence/campaigns.csv) · [前后比较 CSV](evidence/comparison.csv) · [完整证据](report.json) · [口径说明](evidence/notes.md)\n"
    return output, md


def flat(row):
    """Readable CSV cells for list/dict evidence; exact structures remain in JSON."""
    out = {}
    for key, value in row.items():
        if isinstance(value, dict):
            value = "；".join(f"{k}：{flat({'v': v})['v']}" for k, v in value.items())
        elif isinstance(value, list):
            value = "；".join(map(str, value))
        out[key] = value
    return out


def csv_text(rows, fields):
    out = io.StringIO(newline="")
    writer = csv.writer(out)
    writer.writerow(fields)
    for row in rows:
        values = []
        for field in fields:
            value = row.get(field)
            cell = "" if value is None else str(value)
            # Neutralize spreadsheet formulas in source labels; exact values remain in JSON.
            if cell.startswith(("=", "+", "@", "-")) and number(cell) is None:
                cell = "'" + cell
            values.append(cell)
        writer.writerow(values)
    return out.getvalue()


def save_report(workspace, report):
    root = workspace.layout.root / "reports/observations"
    root.mkdir(parents=True, exist_ok=True)
    identifier = "observation_" + uuid4().hex
    pending, destination = root / ("." + identifier), root / identifier
    pending.mkdir(mode=0o700)
    (pending / "evidence").mkdir()
    html_text, md = render(report)
    audience = [
        {"dimension": a["dimension"], "start": a["period"]["start"], "end": a["period"]["end"], **r}
        for a in report.get("delivered_audience", [])
        for r in a["segments"]
    ]
    notes = (
        "# 口径与缺失项\n\n"
        + "\n".join("- " + s for s in report.get("limitations", []))
        + "\n\n## 检索范围与读取记录\n\n```json\n"
        + dump({"scope": report["scope"], "attempts": report.get("attempts", [])})
        + "\n```\n"
    )
    files = {
        "report.json": dump(report),
        "report.html": html_text,
        "report.md": md,
        "chat.md": md,
        "evidence/context.json": dump(report["context"]),
        "evidence/diagnostics.json": dump(report["diagnostics"]),
        "evidence/daily.csv": csv_text(report["diagnostics"]["daily"], ["date", *METRICS]),
        "evidence/campaigns.csv": csv_text(
            report["diagnostics"]["campaigns"], ["campaign_id", *METRICS]
        ),
        "evidence/audience.csv": csv_text(
            audience, ["dimension", "start", "end", "segment", *METRICS]
        ),
        "evidence/notes.md": notes,
    }
    change = report["diagnostics"].get("change") or {}
    comparison_rows = []
    for key in METRICS:
        comparison_rows.append(
            {
                "metric": key,
                "before": change.get("before", {}).get(key),
                "after": change.get("after", {}).get(key),
                "baseline": period_text(change.get("baseline")),
                "comparison": period_text(change.get("comparison")),
                "currency": report["scope"].get("currency"),
            }
        )
    comparison_rows.extend(
        {
            "metric": c["factor"],
            "cpc_contribution": c["cpc_delta"],
            "currency": report["scope"].get("currency"),
        }
        for c in change.get("components", [])
    )
    files["evidence/comparison.csv"] = csv_text(
        comparison_rows,
        ["metric", "before", "after", "cpc_contribution", "baseline", "comparison", "currency"],
    )
    files["evidence/campaign_contributions.csv"] = csv_text(
        change.get("campaign_contributions", []),
        ["campaign_id", "status", "within_cpc", "mix_cpc", "contribution"],
    )
    files["evidence/anomalies.csv"] = csv_text(
        report["diagnostics"].get("anomalies", []), ["date", "spend", "method", "causality"]
    )
    goals = [
        {
            **g,
            "optimization_event": dump(g.get("optimization_event")),
            "historical_scope": "current_snapshot_history_unverified",
        }
        for g in report["context"].get("optimization_context", [])
    ]
    files["evidence/goals.csv"] = csv_text(
        goals, ["campaign_id", "optimization_goal", "optimization_event", "historical_scope"]
    )
    if report.get("evidence_mode") == "user_file":
        source_rows = report["file_source"]["rows"]
        source_fields = list(dict.fromkeys(key for row in source_rows for key in row))
        files["evidence/source_records.csv"] = csv_text(source_rows, source_fields)
    integration = report.get("internal_integration")
    if integration:
        files["evidence/internal_matching.json"] = dump(
            {k: v for k, v in integration.items() if k != "daily"}
        )
        daily_fields = [
            "date",
            "spend",
            "paid_platform_new_users",
            "paid_platform_conversions",
            "organic_new_users",
            "organic_conversions",
            "basis",
            "gaps",
        ]
        files["evidence/internal_daily.csv"] = csv_text(
            [flat(r) for r in integration.get("daily", [])], daily_fields
        )
        notes = integration.get("metric_notes") or {}
        reasons = {}
        for u in integration.get("unavailable", []):
            reasons.setdefault(u["metric"], []).append(u["reason"])
        exports = {
            "internal_quality": integration.get("quality_comparison", []),
            "internal_groups": [
                {"group": k, **v} for k, v in integration.get("groups", {}).items()
            ],
            "internal_efficiency": [
                {"metric": k, "value": v, **notes.get(k, {}), "unavailable": reasons.get(k)}
                for k, v in (integration.get("efficiency") or {}).items()
            ],
            "internal_campaigns": (integration.get("campaigns") or {}).get("matched", []),
            "internal_organic_trend": [
                {"period": k, **v}
                for k, v in (integration.get("organic_trend") or {}).items()
                if isinstance(v, dict)
            ],
        }
        for name, rows in exports.items():
            fields = list(dict.fromkeys(key for row in rows for key in row)) or ["status"]
            files[f"evidence/{name}.csv"] = csv_text([flat(r) for r in rows], fields)
    for name, text in files.items():
        (pending / name).write_text(text, encoding="utf-8")
    manifest = {
        "renderer_version": RENDERER_VERSION,
        "template_sha256": hashlib.sha256(template_path().read_bytes()).hexdigest(),
        "report_id": identifier,
        "files": {name: hashlib.sha256(text.encode()).hexdigest() for name, text in files.items()},
    }
    (pending / "manifest.json").write_text(dump(manifest), encoding="utf-8")
    os.rename(pending, destination)
    return {
        "report_id": identifier,
        "html": str(destination / "report.html"),
        "markdown": str(destination / "report.md"),
        "data": str(destination / "report.json"),
        "manifest": str(destination / "manifest.json"),
    }
