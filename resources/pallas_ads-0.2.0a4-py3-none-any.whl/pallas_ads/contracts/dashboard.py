"""Cross-platform advertising dashboard: a persistent, incrementally updated local view.

Each source is one authorized account read through an existing Pallas route. The runtime
records exactly which dates were read, when, and through which route; it never fills gaps.
"""

from __future__ import annotations

from datetime import date
from typing import Literal, Self

from pydantic import Field, model_validator

from pallas_ads.contracts.base import ContractModel
from pallas_ads.contracts.common import MediaPlatform

DashboardRoute = Literal["live_api", "host_capture", "file_import", "synthetic_fixture"]


class DashboardSource(ContractModel):
    platform: MediaPlatform
    route: DashboardRoute
    account_id: str = Field(pattern=r"^[0-9]{1,32}$")
    connection_id: str | None = Field(default=None, pattern=r"^connection_[a-z0-9][a-z0-9_-]*$")
    # Absolute path to a clearly marked synthetic fixture; never an account export.
    fixture_path: str | None = Field(default=None, min_length=1, max_length=1000)
    label: str | None = Field(default=None, min_length=1, max_length=80)

    @property
    def key(self):
        return f"{self.platform}:{self.account_id}"

    @model_validator(mode="after")
    def check_route(self) -> Self:
        if (self.route == "live_api") != (self.connection_id is not None):
            raise ValueError("connection_id is required for, and only for, live_api sources")
        if (self.route == "synthetic_fixture") != (self.fixture_path is not None):
            raise ValueError("fixture_path is required for, and only for, synthetic_fixture")
        if self.route == "host_capture" and self.platform != "meta":
            raise ValueError("host_capture is the Meta official MCP route")
        return self


class DashboardIngest(ContractModel):
    """Retained evidence to merge into one source: a Meta host capture or a file import."""

    source_key: str = Field(pattern=r"^(google|meta|tiktok):[0-9]{1,32}$")
    capture_id: str | None = Field(default=None, pattern=r"^host_[a-f0-9]{64}$")
    dataset_id: str | None = Field(default=None, pattern=r"^file_[a-f0-9]{64}$")

    data_path: str | None = Field(default=None, min_length=1, max_length=1000)

    @model_validator(mode="after")
    def one_reference(self) -> Self:
        if sum(v is not None for v in (self.capture_id, self.dataset_id, self.data_path)) != 1:
            raise ValueError("Supply exactly one capture_id, dataset_id or data_path")
        return self


class DashboardRequest(ContractModel):
    op: Literal["create", "update", "status"]
    dashboard_id: str = Field(pattern=r"^dash_[a-z0-9][a-z0-9_-]{0,40}$")
    title: str | None = Field(default=None, min_length=1, max_length=120)
    sources: list[DashboardSource] = Field(default_factory=list, max_length=12)
    history_start: date | None = None
    lookback_days: int = Field(default=7, ge=0, le=30)
    max_windows: int = Field(default=12, ge=1, le=60)
    ingest: list[DashboardIngest] = Field(default_factory=list, max_length=20)
    # Fixed "today" for synthetic fixtures and retained files only; live reads use the clock.
    as_of: date | None = None

    @model_validator(mode="after")
    def check_op(self) -> Self:
        if self.op == "create":
            if not self.title or not self.sources:
                raise ValueError("create requires a title and at least one source")
            keys = [s.key for s in self.sources]
            if len(keys) != len(set(keys)):
                raise ValueError("one route per platform account; remove duplicate sources")
            synthetic = {s.route == "synthetic_fixture" for s in self.sources}
            if len(synthetic) > 1:
                raise ValueError("synthetic fixtures cannot be mixed with account data")
        elif self.sources or self.title or self.history_start:
            raise ValueError("sources, title and history_start are fixed at create")
        if self.op == "status" and self.ingest:
            raise ValueError("ingest requires op=update")
        return self
