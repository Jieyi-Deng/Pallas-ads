"""The host-neutral /pallas request. Source preparation keeps its existing contracts."""

from datetime import date
from pathlib import Path
from typing import Annotated, Literal

from pydantic import Field, field_validator, model_validator

from pallas_ads.contracts.base import ContractModel, VersionedContract
from pallas_ads.contracts.dashboard import DashboardIngest, DashboardSource
from pallas_ads.contracts.delivery import AgentAnalysisDraft
from pallas_ads.contracts.file_import import FileImportOptions
from pallas_ads.contracts.query import DateRange


class AnalysisInput(ContractModel):
    dataset_id: str | None = Field(default=None, pattern=r"^file_[a-f0-9]{64}$")
    internal_dataset_id: str | None = Field(default=None, pattern=r"^internal_[a-f0-9]{64}$")
    capture_id: str | None = Field(default=None, pattern=r"^host_[a-f0-9]{64}$")
    context_capture_ids: list[Annotated[str, Field(pattern=r"^host_[a-f0-9]{64}$")]] = Field(
        default_factory=list, max_length=8
    )
    connection_id: str | None = Field(default=None, pattern=r"^connection_[a-z0-9][a-z0-9_-]*$")
    period: DateRange | None = None
    max_windows: int = Field(default=12, ge=1, le=60)
    max_pages: int = Field(default=20, ge=1, le=100)
    history_before: date | None = None
    packet_id: str | None = Field(default=None, min_length=1)
    draft: AgentAnalysisDraft | None = None
    monitor_run_ids: list[str] = Field(default_factory=list)


class FileAnalysisInput(ContractModel):
    file_path: str = Field(min_length=1, max_length=1000)
    import_options: FileImportOptions
    review_hash: str | None = Field(default=None, pattern=r"^[a-f0-9]{64}$")
    user_confirmed: Literal[True] | None = None

    @model_validator(mode="after")
    def confirmation_pair(self):
        if (self.review_hash is None) != (self.user_confirmed is None):
            raise ValueError(
                "Confirmation requires the preview hash and user confirmation together"
            )
        if not Path(self.file_path).is_absolute():
            raise ValueError("Use an absolute input path")
        return self


class DashboardInput(ContractModel):
    # auto only reuses an existing dashboard; creation must be explicit.
    op: Literal["auto", "create", "update", "status"] = "auto"
    dashboard_id: str | None = Field(default=None, pattern=r"^dash_[a-z0-9][a-z0-9_-]{0,40}$")
    source_scope: list[Annotated[str, Field(pattern=r"^(google|meta|tiktok):[0-9]{1,32}$")]] = (
        Field(default_factory=list, max_length=12)
    )
    title: str | None = Field(default=None, min_length=1, max_length=120)
    sources: list[DashboardSource] = Field(default_factory=list, max_length=12)
    history_start: date | None = None
    lookback_days: int = Field(default=7, ge=0, le=30)
    max_windows: int = Field(default=12, ge=1, le=60)
    ingest: list[DashboardIngest] = Field(default_factory=list, max_length=20)
    as_of: date | None = None


class CommandRequest(VersionedContract):
    intent: Literal["help", "status", "analysis", "analyze", "dashboard", "update"] = "help"
    # MCP is already bound to one workspace. This field asserts that binding, never switches it.
    workspace: str | None = Field(default=None, min_length=1, max_length=1000)
    analysis: AnalysisInput | None = None
    file: FileAnalysisInput | None = None
    dashboard: DashboardInput | None = None
    expected_artifacts: list[Literal["html"]] = Field(default=["html"], min_length=1, max_length=1)

    @field_validator("workspace")
    @classmethod
    def absolute_workspace(cls, value):
        if value is not None and not Path(value).is_absolute():
            raise ValueError("Use the absolute bound workspace")
        return value

    @model_validator(mode="after")
    def intent_fields(self):
        if self.intent in ("help", "status") and any((self.analysis, self.file, self.dashboard)):
            raise ValueError("help/status do not accept execution inputs")
        if self.intent in ("analysis", "analyze") and (
            self.dashboard or (self.analysis and self.file)
        ):
            raise ValueError("Choose one analysis input route")
        if self.intent in ("dashboard", "update") and (self.analysis or self.file):
            raise ValueError("dashboard uses dashboard inputs")
        return self
