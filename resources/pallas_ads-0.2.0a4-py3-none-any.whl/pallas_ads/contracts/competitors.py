"""Evidence-bound competitor research brief produced by the host agent.

The runtime never browses. The agent researches public sources in seven stages (scope, market
context, competitor selection, evidence profiles, acquisition, investment/performance and
synthesis) and submits this brief. The runtime validates citations, evidence labels, the metric
evidence hierarchy and hypothesis framing, then renders.
"""

from __future__ import annotations

import re
from datetime import date
from decimal import Decimal
from typing import Annotated, Literal
from urllib.parse import urlsplit

from pydantic import Field, model_validator

from pallas_ads.contracts.base import ContractModel

Text = Annotated[str, Field(min_length=1, max_length=600)]
Cell = Annotated[str, Field(min_length=1, max_length=300)]
Short = Annotated[str, Field(min_length=1, max_length=160)]
Amount = Annotated[Decimal, Field(allow_inf_nan=False)]
SourceId = Annotated[str, Field(pattern=r"^S[0-9]{1,3}$")]
QuestionId = Annotated[str, Field(pattern=r"^Q[0-9]{1,2}$")]
ProfileId = Annotated[str, Field(pattern=r"^C[0-9]{1,3}$")]
ObservationId = Annotated[str, Field(pattern=r"^O[0-9]{1,3}$")]
MetricId = Annotated[str, Field(pattern=r"^M[0-9]{1,3}$")]
PatternId = Annotated[str, Field(pattern=r"^P[0-9]{1,2}$")]
Confidence = Literal["low", "medium"]
SourceIds = Annotated[list[SourceId], Field(default_factory=list, max_length=10)]
SourceType = Literal[
    "official_site",
    "app_store",
    "marketplace_listing",
    "social_profile",
    "company_filing",
    "ad_library",
    "transparency_center",
    "creative_center",
    "press_release",
    "news",
    "industry_report",
    "community",
    "third_party_estimate",
    "other",
]
# Reliability is derived from the source type, never self-declared by the agent.
RELIABILITY: dict[str, str] = {
    "official_site": "high",
    "app_store": "high",
    "marketplace_listing": "high",
    "social_profile": "high",
    "company_filing": "high",
    "ad_library": "high",
    "transparency_center": "high",
    "creative_center": "medium",
    "press_release": "medium",
    "news": "medium",
    "industry_report": "medium",
    "community": "low",
    "third_party_estimate": "low",
    "other": "low",
}
# Public ad delivery figures may only come from a platform's own disclosure surface.
METRIC_SOURCES = frozenset({"ad_library", "transparency_center", "creative_center"})
PRIMARY_SOURCES = (
    frozenset(
        {
            "official_site",
            "app_store",
            "marketplace_listing",
            "social_profile",
            "company_filing",
            "press_release",
        }
    )
    | METRIC_SOURCES
)
# Tier-1 metrics need a first-party, platform or public-disclosure source.
DISCLOSURE_SOURCES = frozenset(
    {
        "official_site",
        "app_store",
        "marketplace_listing",
        "social_profile",
        "company_filing",
        "ad_library",
        "transparency_center",
        "creative_center",
        "press_release",
        "news",
    }
)
SYNTHETIC_HOSTS = ("example.com", "example.org", "example.net")
# Pallas performs the analysis: next steps ask for the user's data instead of other tools.
OTHER_ANALYTICS_TOOLS = re.compile(
    r"(?<![A-Za-z0-9])(similar\s?web|sensor\s?tower|data\.ai|app\s?annie|appfigures|apptopia|"
    r"pathmatics|adbeat|semrush|ahrefs|spyfu|looker\s?studio|google\s?analytics|ga4|mixpanel|"
    r"amplitude|tableau|power\s?bi|triple\s?whale|northbeam|supermetrics)(?![A-Za-z0-9])",
    re.IGNORECASE,
)
Basis = Literal["verified", "estimate", "observed", "inference"]
MetricTier = Literal[
    "disclosed", "third_party_estimate", "observed_signal", "inferred", "unavailable"
]
BusinessModel = Literal[
    "one_time_purchase",
    "subscription",
    "in_app_purchase",
    "advertising",
    "marketplace",
    "freemium",
    "licensing",
    "services",
    "other",
]
ChannelType = Literal[
    "search",
    "paid_social",
    "organic_social",
    "app_store",
    "creators",
    "retail",
    "marketplace",
    "partnerships",
    "affiliates",
    "community",
    "content_seo",
    "email_crm",
    "events",
    "other",
]
PropositionType = Literal[
    "product",
    "feature",
    "content",
    "creative_concept",
    "value_proposition",
    "offer",
    "user_scenario",
    "social_proof",
    "brand_positioning",
    "other",
]
Lever = Literal[
    "creative",
    "messaging",
    "format",
    "audience_targeting",
    "bidding",
    "budget_allocation",
    "landing_page",
    "offer",
    "pricing",
    "product_packaging",
    "channel_mix",
    "test_design",
]


class Evidenced(ContractModel):
    """A claim that carries its evidence label and the sources it rests on."""

    basis: Basis
    confidence: Confidence | None = None
    source_ids: SourceIds


class Subject(ContractModel):
    name: Short
    subject_type: Literal["product", "brand", "app", "game", "service", "other"]
    description: Text
    category: Short
    markets: list[Short] = Field(min_length=1, max_length=20)
    audiences: list[Short] = Field(min_length=1, max_length=10)
    business_models: list[BusinessModel] = Field(min_length=1, max_length=5)
    website: str | None = Field(default=None, pattern=r"^https://", max_length=500)


class ResearchQuestion(ContractModel):
    question_id: QuestionId
    question: Text
    origin: Literal["user", "research"] = "research"


class ResearchScope(ContractModel):
    """Stage 1: why the research is done and what decisions it must inform."""

    objective: Text
    questions: list[ResearchQuestion] = Field(default_factory=list, max_length=8)
    researched_on: date
    period_note: Text
    method: Text
    queries: list[Short] = Field(default_factory=list, max_length=50)


class Source(ContractModel):
    source_id: SourceId
    url: str = Field(pattern=r"^https://[^\s]+$", max_length=1000)
    title: Short
    publisher: Short
    source_type: SourceType
    accessed_on: date
    published_on: date | None = None


class ContextPoint(Evidenced):
    """Stage 2: product, audience and market structure used as the comparison frame."""

    dimension: Literal["product", "audience", "market"]
    aspect: Short
    statement: Text


class ProfileAttribute(Evidenced):
    """Stage 4: one adaptive profile field; labels follow the category, not a fixed schema."""

    dimension: Literal[
        "product",
        "audience",
        "positioning",
        "business_model",
        "pricing",
        "distribution",
        "marketing",
        "other",
    ]
    label: Short
    value: Cell


class Profile(ContractModel):
    """Stage 3/4: the subject itself or a competitor chosen for comparison value."""

    profile_id: ProfileId
    name: Short
    descriptor: Short | None = None
    role: Literal["subject", "direct", "adjacent", "benchmark"]
    selection_reason: Text
    website: str | None = Field(default=None, pattern=r"^https://", max_length=500)
    attributes: list[ProfileAttribute] = Field(default_factory=list, max_length=20)
    source_ids: list[SourceId] = Field(min_length=1, max_length=10)


class AcquisitionObservation(ContractModel):
    """Stage 5: where a profile acquires users and what it uses to do so, as observed."""

    observation_id: ObservationId
    profile_id: ProfileId
    channel_type: ChannelType
    channel: Short
    proposition_type: PropositionType
    proposition: Short
    description: Text
    evidence_kind: Literal[
        "paid_ad", "owned_content", "store_listing", "organic_content", "other"
    ] = "other"
    advertiser: Short | None = None
    evidence_locator: Short | None = None
    limitation: Text | None = None
    format: Short | None = None
    region: Short | None = None
    call_to_action: Short | None = None
    first_seen: date | None = None
    last_seen: date | None = None
    active_when_accessed: bool | None = None
    public_metric: Short | None = None
    source_ids: list[SourceId] = Field(min_length=1, max_length=5)


class Metric(ContractModel):
    """Stage 6: one scale, investment or performance signal on the evidence hierarchy."""

    metric_id: MetricId
    profile_id: ProfileId | None = None
    label: Short
    unit: Short | None = None
    value: Amount | None = None
    low: Amount | None = None
    high: Amount | None = None
    display: Short | None = None
    period: Short | None = None
    geography: Short | None = None
    tier: MetricTier
    confidence: Confidence | None = None
    note: Text | None = None
    source_ids: SourceIds


class Pattern(ContractModel):
    """Stage 7: Observation -> Evidence -> Implication -> Hypothesis / potential test."""

    pattern_id: PatternId
    kind: Literal["cross_competitor", "single_example", "measurement_proposal"] = "single_example"
    title: Short
    observation: Text
    evidence: Text
    implication: Text
    hypothesis: Text
    test: Text | None = None
    success_measure: Text | None = None
    lever: Lever | None = None
    confidence: Confidence
    impact: Literal["low", "medium", "high"] | None = None
    effort: Literal["low", "medium", "high"] | None = None
    question_ids: list[QuestionId] = Field(default_factory=list, max_length=8)
    source_ids: SourceIds
    observation_ids: list[ObservationId] = Field(default_factory=list, max_length=30)
    metric_ids: list[MetricId] = Field(default_factory=list, max_length=20)


class Answer(ContractModel):
    """Decision-relevant finding; link a question only when it actually motivated this finding."""

    question_id: QuestionId | None = None
    status: Literal["answered", "partial", "insufficient_evidence"]
    headline: Short
    answer: Text
    basis: Basis | None = None
    confidence: Confidence | None = None
    source_ids: SourceIds
    pattern_ids: list[PatternId] = Field(default_factory=list, max_length=10)
    metric_ids: list[MetricId] = Field(default_factory=list, max_length=10)


class PositionPoint(Evidenced):
    """Optional qualitative position of the subject (strength/weakness/opportunity/threat)."""

    quadrant: Literal["strength", "weakness", "opportunity", "threat"]
    statement: Cell
    pattern_ids: list[PatternId] = Field(default_factory=list, max_length=5)


class SeasonalWindow(Evidenced):
    label: Short
    start_month: int = Field(ge=1, le=12)
    end_month: int = Field(ge=1, le=12)
    lead_weeks: int | None = Field(default=None, ge=0, le=16)
    note: Cell | None = None


class JourneyStage(Evidenced):
    stage: Short
    tactics: list[Short] = Field(min_length=1, max_length=6)


class EvidenceGap(ContractModel):
    topic: Short
    reason: Text
    user_data: Text | None = None
    question_ids: list[QuestionId] = Field(default_factory=list, max_length=8)


class CompetitorBrief(ContractModel):
    evidence_mode: Literal["public_research", "synthetic_fixture"]
    report_language: Literal["en", "zh-CN"]
    subject: Subject
    scope: ResearchScope
    sources: list[Source] = Field(min_length=1, max_length=200)
    context: list[ContextPoint] = Field(default_factory=list, max_length=30)
    profiles: list[Profile] = Field(max_length=16)
    observations: list[AcquisitionObservation] = Field(default_factory=list, max_length=150)
    metrics: list[Metric] = Field(default_factory=list, max_length=120)
    patterns: list[Pattern] = Field(default_factory=list, max_length=12)
    answers: list[Answer] = Field(min_length=1, max_length=8)
    position: list[PositionPoint] = Field(default_factory=list, max_length=20)
    seasonality: list[SeasonalWindow] = Field(default_factory=list, max_length=12)
    journey: list[JourneyStage] = Field(default_factory=list, max_length=7)
    gaps: list[EvidenceGap] = Field(default_factory=list, max_length=30)

    @model_validator(mode="after")
    def check_evidence(self):
        sources = {s.source_id: s for s in self.sources}
        questions = {q.question_id for q in self.scope.questions}
        profiles = {p.profile_id: p for p in self.profiles}
        observations = {o.observation_id: o for o in self.observations}
        metrics = {m.metric_id: m for m in self.metrics}
        patterns = {p.pattern_id: p for p in self.patterns}
        for label, ids in (
            ("source", [s.source_id for s in self.sources]),
            ("question", [q.question_id for q in self.scope.questions]),
            ("profile", [p.profile_id for p in self.profiles]),
            ("observation", [o.observation_id for o in self.observations]),
            ("metric", [m.metric_id for m in self.metrics]),
            ("pattern", [p.pattern_id for p in self.patterns]),
        ):
            if len(ids) != len(set(ids)):
                raise ValueError(f"duplicate {label} IDs")
        synthetic = self.evidence_mode == "synthetic_fixture"
        for s in self.sources:
            host = (urlsplit(s.url).hostname or "").lower()
            placeholder = any(host == h or host.endswith("." + h) for h in SYNTHETIC_HOSTS)
            if synthetic != placeholder:
                raise ValueError(
                    "synthetic fixtures must use example.com/org/net URLs and public research "
                    "must not; never present invented sources as real"
                )
            if s.accessed_on > self.scope.researched_on:
                raise ValueError(f"{s.source_id} accessed after the research date")
        used: set[str] = set()

        def cite(ids, owner):
            if set(ids) - set(sources):
                raise ValueError(f"{owner} cites unknown sources")
            used.update(ids)
            return {sources[i].source_type for i in ids}

        def refs(found, known, kind, owner):
            if set(found) - set(known):
                raise ValueError(f"{owner} references unknown {kind}")

        def claim(item, owner, *, extra_refs=False):
            types = cite(item.source_ids, owner)
            if item.basis == "inference":
                if item.confidence is None or not (item.source_ids or extra_refs):
                    raise ValueError(
                        f"{owner}: inferences reference evidence and state low/medium confidence"
                    )
                return
            if not item.source_ids or item.confidence is not None:
                raise ValueError(
                    f"{owner}: {item.basis} claims cite sources and take no confidence"
                )
            if item.basis in {"verified", "observed"} and all(
                RELIABILITY[t] == "low" for t in types
            ):
                raise ValueError(
                    f"{owner}: low-reliability sources cannot verify or observe a claim; "
                    "record it as an estimate or inference"
                )

        def no_other_tools(text, owner):
            if text and OTHER_ANALYTICS_TOOLS.search(text):
                raise ValueError(
                    f"{owner}: do not recommend other analytics or dashboard tools; describe "
                    "the data the user can provide to Pallas instead"
                )

        for point in self.context:
            claim(point, f"context {point.aspect}")
        subjects = [p for p in self.profiles if p.role == "subject"]
        if len(subjects) > 1:
            raise ValueError("at most one profile can be the research subject")
        for p in self.profiles:
            cite(p.source_ids, p.profile_id)
            for a in p.attributes:
                claim(a, f"{p.profile_id} {a.label}")
        for o in self.observations:
            types = cite(o.source_ids, o.observation_id)
            if o.profile_id not in profiles:
                raise ValueError(f"{o.observation_id} references an unknown profile")
            if not types & PRIMARY_SOURCES:
                raise ValueError(
                    f"{o.observation_id}: acquisition observations need a primary public "
                    "source; third-party estimates alone are not observations"
                )
            if o.evidence_kind == "paid_ad" and (
                not types & METRIC_SOURCES
                or not o.advertiser
                or not o.region
                or not o.evidence_locator
            ):
                raise ValueError(
                    f"{o.observation_id}: paid ads need a platform disclosure source, "
                    "advertiser, region and evidence_locator; "
                    "store pages do not prove paid activity"
                )
            if o.public_metric is not None and not types & METRIC_SOURCES:
                raise ValueError(
                    f"{o.observation_id}: public_metric must come from an ad library, "
                    "transparency center or creative center"
                )
            if o.first_seen and o.last_seen and o.first_seen > o.last_seen:
                raise ValueError(f"{o.observation_id}: first_seen is after last_seen")
        for m in self.metrics:
            owner = m.metric_id
            types = cite(m.source_ids, owner)
            if m.profile_id is not None and m.profile_id not in profiles:
                raise ValueError(f"{owner} references an unknown profile")
            ranged = m.low is not None or m.high is not None
            if ranged and (m.low is None or m.high is None or m.low > m.high):
                raise ValueError(f"{owner}: ranges need low <= high")
            if ranged and m.value is not None:
                raise ValueError(f"{owner}: give a value or a range, not both")
            numeric = m.value is not None or ranged
            if m.tier == "unavailable":
                if numeric or m.display or m.confidence or not m.note:
                    raise ValueError(
                        f"{owner}: unavailable metrics carry no value (missing is not zero) "
                        "and state why in note"
                    )
                continue
            if m.tier == "inferred":
                if numeric:
                    raise ValueError(
                        f"{owner}: inferred metrics are described in display text, never "
                        "given numbers that could be read as measured"
                    )
                if not m.display or m.confidence is None or not (m.source_ids or m.note):
                    raise ValueError(
                        f"{owner}: inferred metrics need display text, evidence and confidence"
                    )
                continue
            if m.confidence is not None:
                raise ValueError(f"{owner}: only inferred metrics take a confidence")
            if not numeric and not m.display:
                raise ValueError(f"{owner}: give a value, range or display text")
            if not m.source_ids:
                raise ValueError(f"{owner}: {m.tier} metrics cite their source")
            if m.tier == "disclosed" and not types & DISCLOSURE_SOURCES:
                raise ValueError(
                    f"{owner}: disclosed metrics need a first-party, platform or public "
                    "disclosure source; label third-party figures as estimates"
                )
            if m.tier == "observed_signal" and all(RELIABILITY[t] == "low" for t in types):
                raise ValueError(f"{owner}: observed signals need a primary public source")
        for pt in self.patterns:
            cite(pt.source_ids, pt.pattern_id)
            refs(pt.observation_ids, observations, "observations", pt.pattern_id)
            refs(pt.metric_ids, metrics, "metrics", pt.pattern_id)
            refs(pt.question_ids, questions, "questions", pt.pattern_id)
            if not (pt.source_ids or pt.observation_ids or pt.metric_ids):
                raise ValueError(f"{pt.pattern_id}: patterns cite their evidence")
            usable_metrics = [
                metrics[i]
                for i in pt.metric_ids
                if metrics[i].tier not in {"unavailable", "inferred"}
            ]
            if pt.kind != "measurement_proposal" and not (
                pt.source_ids or pt.observation_ids or usable_metrics
            ):
                raise ValueError(
                    f"{pt.pattern_id}: missing metrics cannot support a competitor finding"
                )
            if pt.kind == "cross_competitor":
                compared = {observations[i].profile_id for i in pt.observation_ids}
                compared.update(m.profile_id for m in usable_metrics if m.profile_id)
                competitors = {i for i in compared if profiles[i].role != "subject"}
                if len(competitors) < 2:
                    raise ValueError(
                        f"{pt.pattern_id}: cross-competitor patterns need evidence from at least "
                        "two competitors; repeated sources or countries "
                        "are not independent examples"
                    )
            for field in ("hypothesis", "test", "success_measure"):
                no_other_tools(getattr(pt, field), pt.pattern_id)
        answered = [a.question_id for a in self.answers if a.question_id]
        user_questions = {q.question_id for q in self.scope.questions if q.origin == "user"}
        if len(answered) != len(set(answered)) or not user_questions <= set(answered):
            raise ValueError(
                "answer every user question exactly once; do not duplicate research questions"
            )
        refs(answered, questions, "questions", "answers")
        for a in self.answers:
            refs(a.pattern_ids, patterns, "patterns", a.question_id)
            refs(a.metric_ids, metrics, "metrics", a.question_id)
            if a.status == "insufficient_evidence":
                cite(a.source_ids, a.question_id)
                if a.basis is not None or a.confidence is not None:
                    raise ValueError(f"{a.question_id}: unanswered questions take no basis")
                continue
            if a.basis is None:
                raise ValueError(f"{a.question_id}: answers state their evidence basis")
            supported_refs = any(
                metrics[i].tier not in {"unavailable", "inferred"} for i in a.metric_ids
            ) or any(patterns[i].kind != "measurement_proposal" for i in a.pattern_ids)
            claim(a, a.question_id, extra_refs=supported_refs)
        if self.position and not subjects:
            raise ValueError("position points describe the subject; add its profile first")
        for point in self.position:
            refs(point.pattern_ids, patterns, "patterns", point.quadrant)
            claim(point, point.quadrant, extra_refs=bool(point.pattern_ids))
        for window in self.seasonality:
            claim(window, window.label)
        for stage in self.journey:
            claim(stage, stage.stage)
        for g in self.gaps:
            refs(g.question_ids, questions, "questions", g.topic)
            no_other_tools(g.user_data, g.topic)
        if set(sources) - used:
            raise ValueError("every listed source must support a claim, profile or metric")
        return self
