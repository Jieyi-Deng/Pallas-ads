"""Declarative file-to-dashboard mapping. No expressions, inferred units or row dropping."""

from __future__ import annotations

import csv
import hashlib
import io
import json
import os
import re
from collections import defaultdict
from datetime import date, datetime
from decimal import Decimal
from pathlib import Path
from typing import Literal

from pydantic import Field, model_validator

from pallas_ads.contracts.base import ContractModel
from pallas_ads.contracts.query import DateRange
from pallas_ads.dashboard_data import ConversionDefinition, DashboardData, DataSource

METRICS = ("spend", "impressions", "clicks", "conversions", "conversion_value")
FIELDS = {
    "account_id",
    "currency",
    "date",
    "campaign_id",
    "campaign_name",
    "status",
    "ad_type",
    "ad_group_id",
    "ad_group_name",
    "creative_id",
    "creative_name",
    "format",
    "os",
    "video_views",
    "video_completions",
    *METRICS,
}
MAX_BYTES = 20 * 1024 * 1024
MAX_ROWS = 200_000


class FileMapping(ContractModel):
    schema_version: Literal["1.0"]
    source: DataSource
    kind: Literal["uploaded_file", "authorized_account"] = "uploaded_file"
    period: DateRange
    complete: Literal[True]
    grain: Literal["campaign_day", "creative_day"]
    columns: dict[str, str] = Field(min_length=1)
    spend_unit: Literal["currency", "micros"]
    value_unit: Literal["currency", "micros"] = "currency"
    conversion_definition: ConversionDefinition | None = None
    sheet: str | None = None

    @model_validator(mode="after")
    def check_columns(self):
        required = {"date", "campaign_id", "spend", "impressions", "clicks"}
        if self.grain == "creative_day":
            required |= {"ad_group_id", "creative_id", "format"}
        elif set(self.columns) & {
            "ad_group_id",
            "ad_group_name",
            "creative_id",
            "creative_name",
            "format",
            "os",
            "video_views",
            "video_completions",
        }:
            raise ValueError("Creative columns require creative_day grain")
        if not required <= self.columns.keys() or self.columns.keys() - FIELDS:
            raise ValueError("Unknown or missing mapped fields")
        if len(set(self.columns.values())) != len(self.columns) or any(
            not v for v in self.columns.values()
        ):
            raise ValueError("Each field must map to a distinct nonempty column")
        return self


def read_bytes(path: Path):
    if not path.is_absolute() or path.is_symlink() or not path.is_file():
        raise ValueError("Use an absolute regular file path")
    if path.stat().st_size > MAX_BYTES:
        raise ValueError("File exceeds 20 MiB")
    return path.read_bytes()


def read_rows(raw: bytes, suffix: str, sheet: str | None, required_columns=()):
    if suffix == ".json":
        rows = json.loads(raw, parse_float=Decimal)
        if not isinstance(rows, list) or any(not isinstance(r, dict) for r in rows):
            raise ValueError("JSON must be a flat array of row objects")
        if len(rows) > MAX_ROWS:
            raise ValueError("Too many rows")
        return rows
    if suffix == ".csv":
        if sheet:
            raise ValueError("sheet applies only to XLSX")
        values = csv.reader(io.StringIO(raw.decode("utf-8-sig")), strict=True)
        workbook = None
    elif suffix == ".xlsx":
        from openpyxl import load_workbook

        workbook = load_workbook(io.BytesIO(raw), read_only=True, data_only=False)
        if not sheet or sheet not in workbook.sheetnames:
            workbook.close()
            raise ValueError("Select an explicit existing XLSX sheet")
        values = workbook[sheet].iter_rows(values_only=True)
    else:
        raise ValueError("Supported formats: CSV, XLSX, flat JSON")
    try:
        headers = next(values, ())
        if not headers or any(not isinstance(h, str) or not h for h in headers):
            raise ValueError("Nonempty text column headers required")
        if len(set(headers)) != len(headers):
            raise ValueError("Duplicate column headers")
        if set(required_columns) - set(headers):
            raise ValueError("Mapped column missing from file header")
        rows = []
        for cells in values:
            if len(cells) != len(headers):
                raise ValueError("Row width differs from header")
            if len(rows) >= MAX_ROWS:
                raise ValueError("Too many rows")
            rows.append(dict(zip(headers, cells, strict=True)))
        return rows
    finally:
        if workbook:
            workbook.close()


def identifier(value):
    # Excel numbers cannot preserve long account/entity IDs. Require text in that case.
    if isinstance(value, (bool, float, Decimal)):
        raise ValueError("Identifiers must be text or exact small integers")
    if isinstance(value, int) and len(str(abs(value))) > 15:
        raise ValueError("Long identifiers must be exported as text")
    if value is None or not str(value).strip():
        raise ValueError("Missing identifier")
    return str(value).strip()


def numeric(value, *, count=False, micros=False):
    if value is None or value == "":
        return None
    if isinstance(value, bool) or not re.fullmatch(r"[0-9]+(?:\.[0-9]+)?", str(value)):
        raise ValueError("Use plain nonnegative numbers; no formulas, separators or symbols")
    number = Decimal(str(value))
    if count and number != number.to_integral_value():
        raise ValueError("Counts must be whole numbers")
    return int(number) if count else number / (1_000_000 if micros else 1)


def normalize(raw: bytes, suffix: str, mapping: FileMapping):
    rows = read_rows(raw, suffix, mapping.sheet, mapping.columns.values())
    campaigns, groups, creatives, parents, leaves = {}, {}, {}, [], []

    def remember(store, item):
        previous = store.setdefault(item["id"], item)
        if previous != item:
            raise ValueError("Conflicting metadata for the same ID")

    for index, original in enumerate(rows, 2):
        try:
            if set(mapping.columns.values()) - original.keys():
                raise ValueError("Mapped column missing")
            row = {k: original[v] for k, v in mapping.columns.items()}
            if "account_id" in row and identifier(row["account_id"]) != mapping.source.account_id:
                raise ValueError("Account mismatch")
            if "currency" in row and row["currency"] != mapping.source.currency:
                raise ValueError("Currency mismatch")
            raw_date = row["date"]
            if isinstance(raw_date, datetime):
                if raw_date.time().isoformat() != "00:00:00":
                    raise ValueError("Expected daily date, not timestamp")
                raw_date = raw_date.date()
            day = date.fromisoformat(str(raw_date))
            cid = identifier(row["campaign_id"])
            remember(
                campaigns,
                {
                    "id": cid,
                    "name": str(row.get("campaign_name") or cid),
                    "status": row.get("status"),
                    "ad_type": row.get("ad_type"),
                },
            )
            metrics = {
                m: numeric(
                    row.get(m),
                    count=m in ("impressions", "clicks"),
                    micros=(m == "spend" and mapping.spend_unit == "micros")
                    or (m == "conversion_value" and mapping.value_unit == "micros"),
                )
                for m in METRICS
            }
            if mapping.grain == "campaign_day":
                parents.append({"campaign_id": cid, "date": day, **metrics})
                continue
            gid, creative_id = identifier(row["ad_group_id"]), identifier(row["creative_id"])
            remember(
                groups,
                {
                    "id": gid,
                    "campaign_id": cid,
                    "name": str(row.get("ad_group_name") or gid),
                },
            )
            remember(
                creatives,
                {
                    "id": creative_id,
                    "ad_group_id": gid,
                    "name": str(row.get("creative_name") or creative_id),
                    "format": row["format"],
                },
            )
            leaves.append(
                {
                    "creative_id": creative_id,
                    "date": day,
                    "os": row.get("os") or None,
                    **metrics,
                    "video_views": numeric(row.get("video_views"), count=True),
                    "video_completions": numeric(row.get("video_completions"), count=True),
                }
            )
        except (ValueError, TypeError, KeyError) as error:
            raise ValueError(f"Invalid source row {index}: {error}") from None
    if mapping.grain == "creative_day":
        buckets = defaultdict(list)
        for leaf in leaves:
            cid = groups[creatives[leaf["creative_id"]]["ad_group_id"]]["campaign_id"]
            buckets[(cid, leaf["date"])].append(leaf)
        for (cid, day), partition in sorted(buckets.items()):
            parents.append(
                {
                    "campaign_id": cid,
                    "date": day,
                    **{
                        m: None
                        if any(r[m] is None for r in partition)
                        else sum(r[m] for r in partition)
                        for m in METRICS
                    },
                }
            )
    digest = hashlib.sha256(raw).hexdigest()
    return DashboardData.model_validate(
        {
            "schema_version": "1.0",
            "source": mapping.source,
            "period": mapping.period,
            "complete": mapping.complete,
            "conversion_definition": mapping.conversion_definition,
            "evidence": {
                "kind": mapping.kind,
                "reference": f"raw_{digest}{suffix}",
                "sha256": digest,
                "field_mapping": {
                    **mapping.columns,
                    "spend_unit": mapping.spend_unit,
                    "value_unit": mapping.value_unit,
                    "grain": mapping.grain,
                },
            },
            "campaigns": list(campaigns.values()),
            "rows": parents,
            "details": {
                "ad_groups": list(groups.values()),
                "creatives": list(creatives.values()),
                "rows": leaves,
            }
            if mapping.grain == "creative_day"
            else None,
        }
    )


def normalize_file(raw_path: Path, mapping_path: Path, output_dir: Path):
    raw, config = read_bytes(raw_path), read_bytes(mapping_path)
    mapping = FileMapping.model_validate_json(config)
    data = normalize(raw, raw_path.suffix.lower(), mapping)
    # Validate everything before writing. Outputs are content addressed and never overwritten.
    output_dir.mkdir(parents=True, exist_ok=True, mode=0o700)
    if output_dir.is_symlink():
        raise ValueError("Output directory cannot be a symlink")
    normalized = data.model_dump_json(indent=2).encode()
    files = {
        data.evidence.reference: raw,
        f"mapping_{hashlib.sha256(config).hexdigest()}.json": config,
        f"normalized_{hashlib.sha256(normalized).hexdigest()}.json": normalized,
    }
    for name, content in files.items():
        path = output_dir / name
        if path.is_symlink():
            raise ValueError("Output cannot be a symlink")
        if path.exists():
            if path.read_bytes() != content:
                raise ValueError("Existing content-addressed evidence was modified")
            continue
        fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        with os.fdopen(fd, "wb") as handle:
            handle.write(content)
    return {
        "data_path": str((output_dir / list(files)[-1]).resolve()),
        "raw_path": str((output_dir / data.evidence.reference).resolve()),
        "mapping_path": str((output_dir / list(files)[1]).resolve()),
        "campaign_rows": len(data.rows),
        "creative_rows": len(data.details.rows) if data.details else 0,
        "totals": {
            m: None
            if any(getattr(r, m) is None for r in data.rows)
            else str(sum(getattr(r, m) for r in data.rows))
            for m in METRICS
        },
    }
