"""Self-contained interactive dashboard. Inline code is authorized by an exact CSP hash."""

import base64
import hashlib
import json
from html import escape
from pathlib import Path
from string import Template


def render_interactive(state, today, assets: Path, payload=None):
    from pallas_ads.dashboard_data import view_data

    payload = payload if payload is not None else view_data(state, today)
    encoded = (
        json.dumps(payload, ensure_ascii=True, separators=(",", ":"))
        .replace("<", "\\u003c")
        .replace(">", "\\u003e")
        .replace("&", "\\u0026")
    )
    script = "const DASHBOARD = " + encoded + ";\n" + (assets / "dashboard.js").read_text()
    digest = base64.b64encode(hashlib.sha256(script.encode()).digest()).decode()
    return Template((assets / "dashboard.html").read_text()).substitute(
        title=escape(state["title"]),
        script=script,
        script_hash=digest,
        css=(assets / "dashboard.css").read_text(),
        logo="data:image/png;base64,"
        + base64.b64encode((assets / "pallas-logo.png").read_bytes()).decode(),
        synthetic='<span class="demo">Synthetic data</span>' if payload["synthetic"] else "",
    )
