"""Versioned evidence template and the dashboard's sole presentation data projection."""

from __future__ import annotations

import hashlib
import json
from collections import defaultdict
from datetime import date, datetime, timedelta
from decimal import Decimal
from pathlib import Path
from typing import Annotated, Literal
from zoneinfo import ZoneInfo

from pydantic import Field, model_validator

from pallas_ads.contracts.base import ContractModel
from pallas_ads.contracts.query import DateRange

Amount = Annotated[Decimal, Field(ge=0, allow_inf_nan=False)]
Count = Annotated[int, Field(ge=0, strict=True)]
Identifier = Annotated[str, Field(min_length=1, max_length=200)]
EntityName = Annotated[str, Field(min_length=1, max_length=2000)]


class DataSource(ContractModel):
    platform: Literal["google", "meta", "tiktok"]
    account_id: str = Field(pattern=r"^[0-9]{1,32}$")
    account_name: Identifier
    currency: str = Field(pattern=r"^[A-Z]{3}$")
    timezone: Identifier

    @model_validator(mode="after")
    def valid_zone(self):
        try:
            ZoneInfo(self.timezone)
        except (KeyError, ValueError) as error:
            raise ValueError("Invalid source timezone") from error
        return self


class Provenance(ContractModel):
    kind: Literal["uploaded_file", "authorized_account"]
    reference: Identifier  # Retained evidence ID or local file label, never credentials.
    sha256: str = Field(pattern=r"^[a-f0-9]{64}$")
    field_mapping: dict[str, str] = Field(min_length=1)


class ConversionDefinition(ContractModel):
    event: Identifier
    attribution_window: Identifier
    counting_method: Identifier
    value_currency: str = Field(pattern=r"^[A-Z]{3}$")
    evidence_reference: Identifier


class DailyMetrics(ContractModel):
    date: date
    spend: Amount | None
    impressions: Count | None
    clicks: Count | None
    conversions: Amount | None = None
    conversion_value: Amount | None = None


class CampaignRow(DailyMetrics):
    campaign_id: Identifier


class Campaign(ContractModel):
    id: Identifier
    name: EntityName
    status: str | None = None
    ad_type: str | None = None
    target_cpa: Annotated[Decimal, Field(gt=0, allow_inf_nan=False)] | None = None


class AdGroup(ContractModel):
    id: Identifier
    campaign_id: Identifier
    name: EntityName
    os: Literal["iOS", "Android", "Others"] | None = None


class Creative(ContractModel):
    id: Identifier
    ad_group_id: Identifier
    name: EntityName
    format: Literal["Image", "Video", "Carousel", "Other"]
    preview_data: str | None = Field(default=None, max_length=2_000_000)
    original_url: str | None = Field(default=None, max_length=2000)


class CreativeRow(DailyMetrics):
    creative_id: Identifier
    os: Literal["iOS", "Android", "Others"] | None = None
    video_views: Count | None = None
    video_completions: Count | None = None


class Details(ContractModel):
    ad_groups: list[AdGroup]
    creatives: list[Creative]
    rows: list[CreativeRow]


class DashboardData(ContractModel):
    """One complete source window; additive counts only, never precomputed ratios."""

    schema_version: Literal["1.0"]
    source: DataSource
    evidence: Provenance
    period: DateRange
    complete: Literal[True]
    conversion_definition: ConversionDefinition | None = None
    campaigns: list[Campaign]
    rows: list[CampaignRow]
    details: Details | None = None

    @model_validator(mode="after")
    def reconcile(self):
        campaigns = {c.id for c in self.campaigns}
        if len(campaigns) != len(self.campaigns):
            raise ValueError("Duplicate campaign metadata")
        parent = {}
        for r in self.rows:
            key = (r.campaign_id, r.date)
            if key in parent or r.campaign_id not in campaigns:
                raise ValueError("Duplicate or unknown campaign/day")
            if not self.period.start <= r.date <= self.period.end:
                raise ValueError("Row outside complete window")
            parent[key] = r
        leaves = [] if self.details is None else self.details.rows
        if not self.conversion_definition and any(
            r.conversions is not None or r.conversion_value is not None
            for r in [*self.rows, *leaves]
        ):
            raise ValueError("Conversion metrics require a documented definition")
        if (
            self.conversion_definition
            and self.conversion_definition.value_currency != self.source.currency
        ):
            raise ValueError("Conversion value currency must match spend currency")
        if self.details is None:
            return self
        groups = {g.id: g for g in self.details.ad_groups}
        creatives = {c.id: c for c in self.details.creatives}
        if len(groups) != len(self.details.ad_groups) or len(creatives) != len(
            self.details.creatives
        ):
            raise ValueError("Duplicate detail metadata")
        if any(g.campaign_id not in campaigns for g in groups.values()) or any(
            c.ad_group_id not in groups for c in creatives.values()
        ):
            raise ValueError("Broken campaign/group/creative relationship")
        buckets, seen = defaultdict(list), set()
        partitions = defaultdict(set)
        for r in leaves:
            if r.creative_id not in creatives:
                raise ValueError("Unknown creative")
            unique = (r.creative_id, r.date, r.os)
            if unique in seen:
                raise ValueError("Duplicate creative/day/OS")
            seen.add(unique)
            partitions[(r.creative_id, r.date)].add(r.os)
            if (
                len(partitions[(r.creative_id, r.date)]) > 1
                and None in partitions[(r.creative_id, r.date)]
            ):
                raise ValueError("Do not mix unsegmented and OS-partitioned daily rows")
            c = creatives[r.creative_id]
            g = groups[c.ad_group_id]
            if g.os and r.os and g.os != r.os:
                raise ValueError("Conflicting OS evidence")
            key = (g.campaign_id, r.date)
            if key not in parent:
                raise ValueError("Detail outside campaign evidence")
            if c.format != "Video" and (
                r.video_views is not None or r.video_completions is not None
            ):
                raise ValueError("Video metrics require video format")
            if r.video_completions is not None and (
                r.video_views is None or r.video_completions > r.video_views
            ):
                raise ValueError("Completions require sufficient video views")
            buckets[key].append(r)
        # Supplied details must be a complete partition, not a partial sample.
        if set(buckets) != set(parent):
            raise ValueError("Details must cover every supplied campaign/day")
        for key, rs in buckets.items():
            for metric in ("spend", "impressions", "clicks", "conversions", "conversion_value"):
                values = [getattr(r, metric) for r in rs]
                total = None if any(v is None for v in values) else sum(values)
                if total != getattr(parent[key], metric):
                    raise ValueError("Creative metrics do not reconcile with campaign/day")
        return self


def ingest_template(state, key, source, filename, now, today, store):
    from pallas_ads.dashboard import DashboardError, merge

    path = Path(filename)
    try:
        if (
            not path.is_absolute()
            or path.is_symlink()
            or not path.is_file()
            or path.stat().st_size > 20 * 1024 * 1024
        ):
            raise ValueError("Invalid template path")
        raw = path.read_bytes()
        bundle = DashboardData.model_validate_json(raw)
        data = bundle.model_dump(mode="json")
        today = (
            today or datetime.fromisoformat(now).astimezone(ZoneInfo(bundle.source.timezone)).date()
        )
        if bundle.period.end >= today:
            raise ValueError("Template must contain complete days before today")
        meta = data["source"]
        if f"{meta['platform']}:{meta['account_id']}" != key:
            raise ValueError("Source mismatch")
        if source.get("currency") and (source["currency"], source["timezone"]) != (
            meta["currency"],
            meta["timezone"],
        ):
            raise ValueError("Currency/timezone changed")
        definition = data["conversion_definition"]
        semantic_keys = ("event", "attribution_window", "counting_method", "value_currency")
        if source.get("conversion_definition") and (
            not definition
            or any(
                source["conversion_definition"].get(k) != definition.get(k) for k in semantic_keys
            )
        ):
            raise ValueError("Conversion definition changed; create a separate source dashboard")
        if data["details"]:
            previous = state.get("drilldown", {}).get(key, {})
            for name, fields in [
                ("ad_groups", ("campaign_id", "os")),
                ("creatives", ("ad_group_id", "format")),
            ]:
                old = {x["id"]: x for x in previous.get(name, [])}
                for x in data["details"][name]:
                    if x["id"] in old and any(x.get(k) != old[x["id"]].get(k) for k in fields):
                        raise ValueError("Retained entity identity changed")
        ref = "template_" + hashlib.sha256(raw).hexdigest()
    except (OSError, ValueError, KeyError) as error:
        raise DashboardError(
            "Invalid dashboard data template; check schema, scope and reconciliation."
        ) from error
    store.write("evidence/" + ref + ".json", raw.decode("utf-8"))
    period = (data["period"]["start"], data["period"]["end"])
    counts = merge(state, key, data["rows"], ref=ref, at=now, period=period, authoritative=True)
    source.update(meta)
    source["conversion_definition"] = definition
    source["template_evidence"] = data["evidence"]
    source["covered"].append(list(period))
    source["floor"] = min([a for a, _ in source["covered"]])
    # File windows are explicit; this does not claim complete API history.
    source["backfill_complete"] = True
    stores = state.setdefault("drilldown", {})
    old = stores.setdefault(key, {"ad_groups": [], "creatives": [], "rows": [], "campaigns": {}})
    for c in data["campaigns"]:
        state["campaign_names"][f"{key}|{c['id']}"] = c["name"]
        old["campaigns"][c["id"]] = {k: c[k] for k in ("status", "ad_type", "target_cpa")}
    old["rows"] = [r for r in old["rows"] if not period[0] <= r["date"] <= period[1]]
    if data["details"]:
        detail = data["details"]
        for name in ("ad_groups", "creatives"):
            merged = {x["id"]: x for x in old[name]}
            merged.update({x["id"]: x for x in detail[name]})
            old[name] = list(merged.values())
        old["rows"].extend(detail["rows"])
    return counts, period, ref


def view_data(state, today):
    """No credentials/paths. This exact data.json is embedded in the fixed template."""
    sources = {
        key: {
            k: s.get(k)
            for k in (
                "platform",
                "account_id",
                "account_name",
                "currency",
                "timezone",
                "covered",
                "conversion_definition",
            )
        }
        for key, s in state["sources"].items()
    }
    details = state.get("drilldown", {})
    rows = [
        {
            k: r.get(k)
            for k in (
                "source",
                "campaign_id",
                "date",
                "spend",
                "impressions",
                "clicks",
                "conversions",
                "conversion_value",
            )
        }
        for r in state["rows"].values()
    ]
    if state["evidence_mode"] == "synthetic_fixture":
        for s in sources.values():
            s["conversion_definition"] = {
                "event": "synthetic_purchase",
                "attribution_window": "synthetic_same_day",
                "counting_method": "synthetic_count",
                "value_currency": s["currency"],
            }
        totals = defaultdict(list)
        for source, detail in details.items():
            groups = {g["id"]: g for g in detail["ad_groups"]}
            creatives = {c["id"]: c for c in detail["creatives"]}
            for row in detail["rows"]:
                totals[
                    (
                        source,
                        groups[creatives[row["creative_id"]]["ad_group_id"]]["campaign_id"],
                        row["date"],
                    )
                ].append(row)
        for row in rows:
            leaves = totals.get((row["source"], row["campaign_id"], row["date"]), [])
            for metric in ("conversions", "conversion_value"):
                if leaves and all(r.get(metric) is not None for r in leaves):
                    row[metric] = sum(Decimal(str(r[metric])) for r in leaves)
    # Decimal values are encoded as numeric strings and summed explicitly by the UI.
    return json.loads(
        json.dumps(
            {
                "schema_version": "1.0",
                "id": state["dashboard_id"],
                "title": state["title"],
                "synthetic": state["evidence_mode"] == "synthetic_fixture",
                "end": (today - timedelta(days=1)).isoformat(),
                "sources": sources,
                "updated": max(
                    (
                        s["last_success_at"]
                        for s in state["sources"].values()
                        if s.get("last_success_at")
                    ),
                    default=None,
                ),
                "rows": rows,
                "names": state["campaign_names"],
                "details": details,
            },
            default=str,
        )
    )


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Validate a normalized dashboard evidence file")
    parser.add_argument("path", type=Path)
    args = parser.parse_args()
    try:
        validated = DashboardData.model_validate_json(args.path.read_bytes())
    except (OSError, ValueError) as error:
        parser.exit(1, "Invalid dashboard data: " + str(error) + "\n")
    print(f"Valid dashboard data 1.0: {len(validated.rows)} campaign/day rows")
