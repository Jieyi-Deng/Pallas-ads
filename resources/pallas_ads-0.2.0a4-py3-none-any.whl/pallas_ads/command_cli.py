"""CLI adapters for the same typed request used by the pallas Skill and MCP."""

import json
from pathlib import Path
from typing import Annotated

import typer

from pallas_ads.mcp_server import MAX_MESSAGE_BYTES
from pallas_ads.operations import Runtime, needs

Workspace = Annotated[Path | None, typer.Option("--workspace", help="Selected .pallas workspace.")]
Input = Annotated[Path | None, typer.Option("--input", help="Full pallas_command request JSON.")]


def execute_command(intent, workspace, input_path):
    # The current project is the only default, never a global/customer workspace.
    selected = (workspace if workspace is not None else Path.cwd() / ".pallas").resolve()
    runtime = Runtime(selected)
    try:
        payload = {}
        if input_path is not None:
            with input_path.open("rb") as handle:
                raw = handle.read(MAX_MESSAGE_BYTES + 1)
            if len(raw) > MAX_MESSAGE_BYTES:
                raise ValueError
            payload = json.loads(raw)
        if not isinstance(payload, dict):
            raise ValueError
        if intent is not None:
            supplied = payload.get("intent", intent)
            if not isinstance(supplied, str):
                raise ValueError
            canonical = {"analyze": "analysis", "update": "dashboard"}.get(supplied, supplied)
            if canonical != intent:
                raise ValueError
            payload["intent"] = supplied
        response = runtime.invoke("pallas_command", payload)
    except (ValueError, OSError):
        response = needs(
            "pallas_command",
            "Provide a bounded command JSON object whose intent "
            "matches this CLI command. Use pallas help for supported intents.",
        )
    finally:
        runtime.close()
    typer.echo(response.model_dump_json())
    raise typer.Exit(
        {"complete": 0, "partial_result": 2, "pending_user_action": 3}.get(response.status, 1)
    )


def register(app, dashboard):
    @app.command("command")
    def command(workspace: Workspace = None, input_path: Input = None):
        """Execute a host-neutral /pallas request (no input shows help)."""
        execute_command(None, workspace, input_path)

    @app.command("help")
    def help_command(workspace: Workspace = None):
        """Show the unified command capabilities without creating state."""
        execute_command("help", workspace, None)

    @app.command("status")
    def status(workspace: Workspace = None):
        """Inspect this workspace without account reads or artifact rewrites."""
        execute_command("status", workspace, None)

    @app.command("analysis")
    @app.command("analyze", hidden=True)
    def analysis(workspace: Workspace = None, input_path: Input = None):
        """Generate verified HTML analysis or return the required source inputs."""
        execute_command("analysis", workspace, input_path)

    @dashboard.callback(invoke_without_command=True)
    def dashboard_entry(ctx: typer.Context, workspace: Workspace = None, input_path: Input = None):
        """Reuse a unique dashboard; use --input with op=create for an explicit new one."""
        if ctx.invoked_subcommand is None:
            execute_command("dashboard", workspace, input_path)
        elif workspace is not None or input_path is not None:
            raise typer.BadParameter("Put options after the dashboard subcommand.")
