"""Optional, explicitly synthetic drill-down evidence. Never allocate real campaign totals.

The fixture generator supplies leaf rows. Every campaign/day must reconcile exactly before
any details are retained; older fixtures and account routes retain an honest empty state.
"""

from collections import defaultdict
from datetime import date
from decimal import Decimal, InvalidOperation


def validate_details(data):
    detail = data.get("dashboard_details")
    if detail is None:
        return None
    if data.get("synthetic_fixture") is not True or not isinstance(detail, dict):
        raise ValueError("Drill-down fixtures must be explicitly synthetic")
    for target in detail.get("campaign_targets", {}).values():
        try:
            number = Decimal(str(target))
        except InvalidOperation as error:
            raise ValueError("Invalid campaign target") from error
        if not number.is_finite() or number <= 0:
            raise ValueError("Invalid campaign target")
    groups, creatives = {}, {}
    for group in detail.get("ad_groups", []):
        key = str(group["id"])
        if key in groups or group.get("os") not in ("iOS", "Android", "Others"):
            raise ValueError("Invalid or duplicate ad group")
        groups[key] = group
    for creative in detail.get("creatives", []):
        key = str(creative["id"])
        if key in creatives or creative["ad_group_id"] not in groups:
            raise ValueError("Invalid or duplicate creative")
        # No remote media or HTML is needed by the synthetic fixture contract.
        creatives[key] = creative
    parent = {}
    platform = data["platform"]
    for row in data["performance"]:
        if platform == "google":
            key = (row["campaign"]["id"], row["segments"]["date"])
            m = row["metrics"]
            values = (Decimal(m["costMicros"]) / 1000000, int(m["impressions"]), int(m["clicks"]))
        elif platform == "meta":
            key = (row["campaign_id"], row["date_start"])
            values = (Decimal(row["spend"]), int(row["impressions"]), int(row["clicks"]))
        else:
            key = (row["dimensions"]["campaign_id"], row["dimensions"]["stat_time_day"][:10])
            m = row["metrics"]
            values = (Decimal(m["spend"]), int(m["impressions"]), int(m["clicks"]))
        if key in parent:
            raise ValueError("Duplicate campaign/day")
        parent[key] = values
    totals = defaultdict(lambda: [Decimal(0), 0, 0])
    seen = set()
    for row in detail.get("rows", []):
        creative = creatives[row["creative_id"]]
        group = groups[creative["ad_group_id"]]
        day = date.fromisoformat(row["date"]).isoformat()
        key = (group["campaign_id"], day)
        unique = (creative["id"], day)
        if unique in seen or key not in parent:
            raise ValueError("Duplicate or out-of-scope creative/day")
        seen.add(unique)
        try:
            values = (Decimal(str(row["spend"])), int(row["impressions"]), int(row["clicks"]))
        except (ValueError, InvalidOperation) as error:
            raise ValueError("Invalid detail metrics") from error
        if not values[0].is_finite() or any(v < 0 for v in values):
            raise ValueError("Invalid detail metrics")
        if values[1] != row["impressions"] or values[2] != row["clicks"]:
            raise ValueError("Counts must be integers")
        for metric in ("conversions", "conversion_value", "video_views", "video_completions"):
            if row.get(metric) is not None:
                try:
                    optional = Decimal(str(row[metric]))
                except InvalidOperation as error:
                    raise ValueError("Invalid optional detail metric") from error
                if not optional.is_finite() or optional < 0:
                    raise ValueError("Invalid optional detail metric")
        totals[key] = [a + b for a, b in zip(totals[key], values, strict=True)]
    if set(totals) != set(parent) or any(tuple(totals[k]) != v for k, v in parent.items()):
        raise ValueError("Creative totals do not reconcile with campaign/day evidence")
    return detail


def campaign_metadata(data):
    result = {}
    for item in data.get("campaigns", []):
        campaign = item.get("campaign", item)
        key = campaign.get("id") or campaign.get("campaign_id")
        result[str(key)] = {
            "target_cpa": data.get("dashboard_details", {})
            .get("campaign_targets", {})
            .get(str(key)),
            "status": campaign.get("status") or campaign.get("operation_status"),
            "ad_type": campaign.get("advertisingChannelType")
            or campaign.get("objective")
            or campaign.get("objective_type"),
        }
    return result


def retain_details(state, source_key, provider, start, stop):
    """Replace only a successfully read window, including authoritative removals."""
    detail = provider.details
    stores = state.setdefault("drilldown", {})
    if detail is None:
        stores.pop(source_key, None)
        return
    old = stores.setdefault(source_key, {"rows": []})
    old.update(
        {
            "ad_groups": detail["ad_groups"],
            "creatives": detail["creatives"],
            "campaigns": campaign_metadata(provider.data),
        }
    )
    begin, end = start.isoformat(), stop.isoformat()
    old["rows"] = [r for r in old["rows"] if not begin <= r["date"] <= end] + [
        r for r in detail["rows"] if begin <= r["date"] <= end
    ]
