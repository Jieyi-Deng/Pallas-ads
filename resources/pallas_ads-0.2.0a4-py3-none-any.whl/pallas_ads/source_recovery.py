"""Sanitized source-access failure taxonomy shared by reads, refresh and status inspection."""

from __future__ import annotations

from datetime import timedelta

from pallas_ads.contracts.status import MissingInput, OperationEnvelope, OperationIssue
from pallas_ads.credential_store import CredentialError

# Refresh slightly before expiry so a bounded read does not start with a token about to lapse.
REFRESH_SKEW = timedelta(seconds=60)

RECOVERY = {
    "connect_or_choose_connection": "Connect this source again or choose another saved connection.",
    "retry_after_current_operation": "Another Pallas operation is using this connection. Retry "
    "after it finishes; do not delete lock files while it runs.",
    "authorize_again": "Authorize this source again with action=connect. The existing credential "
    "is kept until the new connection succeeds.",
    "operator_configure_google_application": "The operator configures the Google Desktop "
    "application for this OS user with the runtime serving this project (pallas providers "
    "google-desktop --user-default), then retry. Never ask the advertiser for JSON or secrets.",
    "operator_verify_google_application": "The operator verifies that the configured Google "
    "Desktop application matches this connection's client and is still enabled.",
    "authorize_again_with_current_application": "This connection was created with a different "
    "Google application. Authorize again with the configured application; the old credential "
    "is kept until the new connection succeeds.",
    "retry_later": "The provider or network was temporarily unavailable. Retry later.",
    "check_account_access": "The provider rejected access. Check the authorized user's access to "
    "this account, or authorize again; do not switch to scraping or another connector.",
}

# code: (stage, category, recovery action, retriable, message)
FAILURES = {
    "source_connection_unavailable": (
        "connection_state",
        "connection",
        "connect_or_choose_connection",
        False,
        "The saved connection is missing or disconnected.",
    ),
    "source_busy": (
        "connection_lock",
        "concurrency",
        "retry_after_current_operation",
        True,
        "Another Pallas operation is using this connection.",
    ),
    "source_credential_unavailable": (
        "local_credential",
        "credential_storage",
        "authorize_again",
        False,
        "The local credential reference could not be read.",
    ),
    "source_credential_expired": (
        "local_expiry_check",
        "expiry",
        "authorize_again",
        False,
        "Local metadata shows the access credential expired; no provider request was sent.",
    ),
    "refresh_not_supported": (
        "refresh",
        "authorization",
        "authorize_again",
        False,
        "This connection has no Pallas-owned refresh credential.",
    ),
    "refresh_app_config_unavailable": (
        "refresh",
        "configuration",
        "operator_configure_google_application",
        False,
        "Refresh needs the operator's Google application for this connection's client.",
    ),
    "refresh_client_mismatch": (
        "refresh",
        "configuration",
        "authorize_again_with_current_application",
        False,
        "The configured Google application differs from this connection's client.",
    ),
    "refresh_client_rejected": (
        "refresh",
        "configuration",
        "operator_verify_google_application",
        False,
        "The provider rejected the application identity used for refresh.",
    ),
    "refresh_rejected": (
        "refresh",
        "authorization",
        "authorize_again",
        False,
        "The provider rejected the stored refresh grant.",
    ),
    "refresh_temporarily_unavailable": (
        "refresh",
        "transient",
        "retry_later",
        True,
        "Refresh could not reach the provider.",
    ),
    "refresh_failed": (
        "refresh",
        "unknown",
        "authorize_again",
        False,
        "Refresh did not complete.",
    ),
    "authentication_or_permission_failed": (
        "provider_api",
        "permission",
        "check_account_access",
        False,
        "The provider rejected authentication or account permission.",
    ),
    "provider_temporarily_unavailable": (
        "provider_api",
        "transient",
        "retry_later",
        True,
        "The provider was temporarily unavailable.",
    ),
    "transport_unavailable": (
        "provider_api",
        "transient",
        "retry_later",
        True,
        "The provider could not be reached.",
    ),
}


class SourceAccessError(CredentialError):
    """A classified, credential-free access failure. Only the code leaves the runtime."""

    def __init__(self, code: str) -> None:
        if code not in FAILURES:
            raise ValueError("unknown source access failure")
        super().__init__(code)
        self.code = code


def locally_expired(connection, now, skew=timedelta(0)):
    return connection.expires_at is not None and now >= connection.expires_at - skew


def issue(code, severity="error"):
    _, _, _, retriable, message = FAILURES[code]
    return OperationIssue(code=code, message=message, severity=severity, retriable=retriable)


def failure(code):
    stage, category, action, retriable, _ = FAILURES[code]
    return {
        "code": code,
        "stage": stage,
        "category": category,
        "retriable": retriable,
        "recovery_action": action,
        "recovery": RECOVERY[action],
    }


def failure_summary(issues):
    """First classified error, so callers keep the cause instead of a generic read failure."""
    for item in issues:
        if item.code in FAILURES and item.severity == "error":
            return failure(item.code)
    return None


def access_failure(operation, code):
    return OperationEnvelope(
        operation=operation,
        status="needs_input",
        issues=[issue(code)],
        missing_inputs=[MissingInput(field_path="/source", reason=RECOVERY[FAILURES[code][2]])],
    )


class RecoveringAdapter:
    """Adapter facade: recover each connection at most once before its first read."""

    def __init__(self, adapter, recover):
        self.adapter, self.recover, self.attempted = adapter, recover, set()

    def read(self, connection_id, request):
        if connection_id not in self.attempted:
            self.attempted.add(connection_id)
            response = self.recover(connection_id)
            if response is not None and response.status not in ("complete", "partial_result"):
                return response.model_copy(update={"operation": "source_read"})
        return self.adapter.read(connection_id, request)

    def __getattr__(self, name):
        return getattr(self.adapter, name)
