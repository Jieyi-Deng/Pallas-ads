# ruff: noqa: E501
"""Persistent cross-platform advertising dashboard with idempotent incremental updates.

Rows are keyed by platform account, campaign and local date. Re-reading a date replaces the
stored value only when the source returns a different value (a restatement) and logs it.
Dates are "covered" only after a complete read of that exact period; uncovered is never zero.
"""

from __future__ import annotations

import fcntl
import hashlib
import json
import os
from contextlib import contextmanager
from datetime import UTC, date, datetime, timedelta
from decimal import Decimal
from pathlib import Path
from uuid import uuid4
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

from pallas_ads.contracts.dashboard import DashboardRequest, DashboardSource
from pallas_ads.contracts.query import DateRange
from pallas_ads.contracts.source import SourceReadRequest
from pallas_ads.contracts.status import MissingInput, OperationEnvelope, OperationIssue
from pallas_ads.observation_rendering import csv_text, dump, esc, fmt, number

RENDERER_VERSION = "2.1.0"
FORMAT_VERSION = "1.0"
METRICS = ("spend", "impressions", "clicks")
PLATFORMS = {"google": "Google", "meta": "Meta", "tiktok": "TikTok"}
ROUTES = {
    "live_api": "Pallas 授权连接（API）",
    "host_capture": "Meta 官方 MCP（宿主会话）",
    "file_import": "用户上传文件",
    "synthetic_fixture": "合成样例（非真实账户）",
}
DEFAULT_HISTORY_DAYS = 90
MAX_FIXTURE_BYTES = 20 * 1024 * 1024
RECENT_DAYS = 28


class DashboardError(Exception):
    """Actionable failure whose message never echoes source values."""


class SourceUnavailable(Exception):
    def __init__(self, code):
        super().__init__(code)
        self.code = code


def months_before(day, months):
    total = day.year * 12 + day.month - 1 - months
    return date(total // 12, total % 12 + 1, min(day.day, 28))


def merge_intervals(intervals):
    merged = []
    for start, end in sorted((date.fromisoformat(a), date.fromisoformat(b)) for a, b in intervals):
        if merged and start <= merged[-1][1] + timedelta(days=1):
            merged[-1][1] = max(merged[-1][1], end)
        else:
            merged.append([start, end])
    return [[a.isoformat(), b.isoformat()] for a, b in merged]


def covered_days(intervals, start, end):
    days = set()
    for a, b in intervals:
        lo, hi = max(date.fromisoformat(a), start), min(date.fromisoformat(b), end)
        while lo <= hi:
            days.add(lo)
            lo += timedelta(days=1)
    return days


def text(value):
    return None if value is None else str(value)


# The earliest calendar date on Earth is UTC-12. A day before that date has ended in every
# timezone, so it bounds reads when the account timezone is unknown without assuming one.
EARLIEST_OFFSET = timedelta(hours=12)


def account_zone(value):
    """The account's IANA timezone from source evidence, or None when missing or invalid."""
    if not isinstance(value, str) or not value:
        return None
    try:
        return ZoneInfo(value)
    except (ZoneInfoNotFoundError, ValueError):
        return None


def local_today(moment, timezone):
    """Account-local date at `moment`; without a valid timezone, the earliest date anywhere."""
    zone = account_zone(timezone)
    if zone is None:
        return (moment.astimezone(UTC) - EARLIEST_OFFSET).date()
    return moment.astimezone(zone).date()


def source_coverage(key, source, rows):
    """Separate complete windows from observed-only rows and unknown dates.

    Inside a complete window a date without rows is a verified zero; outside one, file rows are
    observations (zeros included) and dates without rows are unknown, never zero.
    """
    windows = merge_intervals(source["covered"])
    days = {d.isoformat() for d in covered_days(windows, date.min, date.max)}
    observed = sorted({r["date"] for r in rows if r["source"] == key} - days)
    unknown = []
    if observed:
        day, last = date.fromisoformat(observed[0]), date.fromisoformat(observed[-1])
        while day <= last:
            if day.isoformat() not in days and day.isoformat() not in observed:
                unknown.append([day.isoformat()] * 2)
            day += timedelta(days=1)
    return {
        "established": bool(windows) and not observed,
        "complete_windows": windows,
        "observed_only": merge_intervals([[d, d] for d in observed]),
        "unknown_within_observed_span": merge_intervals(unknown),
    }


def repair_capture_coverage(state, workspace, now):
    """Once per host_capture source, drop coverage of days unfinished when they were captured.

    Earlier releases bounded reads by the UTC date and kept no account timezone. Each covered day
    is checked against the retained capture that wrote it, in the timezone that capture reports:
    the latest ingest window in the run log, else (the log keeps 50 runs) the capture each row
    records, else the latest retained capture whose daily query covered the day. Rows are kept;
    unverifiable days become observed-only until a complete capture re-reads them.
    """
    from pallas_ads.host_reporting import read_capture

    repairs = []
    for key, source in state["sources"].items():
        if source["route"] != "host_capture" or source.get("boundary_verified"):
            continue
        source["boundary_verified"] = True
        latest = {}
        for run in state["runs"]:
            for window in run["sources"].get(key, {}).get("windows", []):
                if window.get("kind") == "ingest" and window["start"] <= window["end"]:
                    for day in covered_days([[window["start"], window["end"]]], date.min, date.max):
                        latest[day] = window["ref"]
        written = {}
        for row in state["rows"].values():
            if row["source"] == key:
                written.setdefault(date.fromisoformat(row["date"]), set()).add(row["ref"])
        restated = {
            r["ref"] for r in state["restatements"] if r["row"].startswith(key + "|") and r["ref"]
        }
        refs = set(latest.values()) | set().union(*written.values()) | restated
        captures, zones = {}, set()
        for ref in refs:
            try:
                capture = read_capture(workspace, ref)
                zone = capture_timezone(capture, source["account_id"])
            except (DashboardError, OSError, ValueError):
                captures[ref] = None  # missing or altered provenance cannot verify these days
                continue
            if account_zone(zone):
                zones.add(zone)
            zone = zone if account_zone(zone) else source["timezone"]
            captures[ref] = (
                local_today(capture.observed_at, zone) - timedelta(days=1),
                capture.observed_at,
                covered_days(merge_intervals(capture_periods(capture)), date.min, date.max),
            )
        if not source["timezone"] and len(zones) == 1:
            source["timezone"] = zones.pop()
        current = covered_days(merge_intervals(source["covered"]), date.min, date.max)
        removed = sorted(day for day in current if not day_verified(day, latest, written, captures))
        if not removed:
            continue
        kept = sorted(current - set(removed))
        source["covered"] = merge_intervals([[d.isoformat()] * 2 for d in kept])
        source["watermark"] = kept[-1].isoformat() if kept else None
        repairs.append(
            {
                "at": now,
                "source": key,
                "removed": merge_intervals([[d.isoformat()] * 2 for d in removed]),
                "reason": "day_unfinished_in_account_timezone_or_capture_unverifiable",
            }
        )
    if repairs:
        state["coverage_repairs"] = [*state.get("coverage_repairs", []), *repairs][-100:]
    return repairs


def day_verified(day, latest, written, captures):
    """Whether the capture that last wrote a covered day read it after it ended."""
    if day in latest:
        found = captures[latest[day]]
        return found is not None and day <= found[0]
    if day in written:
        return all(captures[r] is not None and day <= captures[r][0] for r in written[day])
    if any(c is None for c in captures.values()):
        return False  # an unreadable capture may have been the last to read this day
    covering = [c for c in captures.values() if day in c[2]]
    return bool(covering) and day <= max(covering, key=lambda c: c[1])[0]


def repair_file_coverage(state, directory, now):
    """Keep file_import coverage only where retained complete templates support it.

    Earlier releases recorded a retained file's min/max dates as complete. Rows are kept; the
    unsupported windows become observed-only dates.
    """
    from pallas_ads.dashboard_data import DashboardData

    supported = {}
    for path in sorted((directory / "evidence").glob("template_*.json")):
        raw = path.read_bytes()
        if path.stem != "template_" + hashlib.sha256(raw).hexdigest():
            continue
        try:
            bundle = DashboardData.model_validate_json(raw)
        except ValueError:
            continue
        key = f"{bundle.source.platform}:{bundle.source.account_id}"
        supported.setdefault(key, []).append(
            [bundle.period.start.isoformat(), bundle.period.end.isoformat()]
        )
    repairs = []
    for key, source in state["sources"].items():
        if source["route"] != "file_import" or not source["covered"]:
            continue
        current = covered_days(merge_intervals(source["covered"]), date.min, date.max)
        allowed = covered_days(merge_intervals(supported.get(key, [])), date.min, date.max)
        removed = sorted(current - allowed)
        if not removed:
            continue
        kept = sorted(current & allowed)
        source["covered"] = merge_intervals([[d.isoformat()] * 2 for d in kept])
        source["watermark"] = kept[-1].isoformat() if kept else None
        source["floor"] = kept[0].isoformat() if kept else None
        repairs.append(
            {
                "at": now,
                "source": key,
                "removed": merge_intervals([[d.isoformat()] * 2 for d in removed]),
                "reason": "file_rows_do_not_establish_complete_coverage",
            }
        )
    if repairs:
        state["coverage_repairs"] = [*state.get("coverage_repairs", []), *repairs][-100:]
    return repairs


# ---------------------------------------------------------------- providers


class LiveProvider:
    """Existing Pallas adapter route: the connection's own credentials and bounded reads."""

    def __init__(self, adapter, source: DashboardSource):
        self.adapter, self.source = adapter, source

    def _read(self, mode, **kwargs):
        response = self.adapter.read(
            self.source.connection_id,
            SourceReadRequest(
                platform=self.source.platform,
                mode=mode,
                account_id=self.source.account_id,
                max_pages=100,
                **kwargs,
            ),
        )
        errors = [i.code for i in response.issues if i.severity == "error"]
        result = response.result
        if errors or result is None or not result.pagination_complete:
            raise SourceUnavailable(errors[0] if errors else "source_read_incomplete")
        return result.records, result.read_id

    def context(self):
        records, _ = self._read("account_context")
        if len(records) != 1:
            raise SourceUnavailable("missing_account_context")
        meta = records[0].metadata
        name = meta.get("name") or (meta.get("customer") or {}).get("descriptiveName")
        return meta.get("account_currency"), meta.get("source_timezone"), name

    def names(self):
        records, _ = self._read("entity_configuration")
        return {r.entity_id: campaign_name(r.metadata) for r in records if r.entity_id}

    def traffic(self, start, end):
        return self._read("traffic_performance", period=DateRange(start=start, end=end))


def campaign_name(meta):
    value = (
        meta.get("name")
        or meta.get("campaign_name")
        or (meta.get("campaign") or {}).get("name")
        or (meta.get("metrics") or {}).get("campaign_name")
    )
    return str(value)[:200] if value else None


class FixtureProvider:
    """Serve windowed reads from a synthetic platform-native fixture through the real normalizer.

    Rows pass through the same pagination parser and record normalizer as live API responses,
    so field paths, micros conversion, date grain and account scope are exercised exactly.
    """

    PAGE = 40

    def __init__(self, source: DashboardSource):
        from pallas_ads.adapter_service import _get

        path = Path(source.fixture_path or "")
        if not path.is_absolute() or path.is_symlink() or not path.is_file():
            raise DashboardError("fixture_path must be an absolute path to a regular file.")
        raw = path.read_bytes()
        if len(raw) > MAX_FIXTURE_BYTES:
            raise DashboardError("Fixture is too large.")
        data = json.loads(raw)
        if data.get("synthetic_fixture") is not True or data.get("platform") != source.platform:
            raise DashboardError(
                "Fixture must declare synthetic_fixture=true and the source platform."
            )
        if str(data.get("account_id")) != source.account_id:
            raise DashboardError("Fixture account does not match the source account.")
        from pallas_ads.dashboard_detail import validate_details

        try:
            self.details = validate_details(data)
        except (KeyError, TypeError, ValueError) as error:
            raise ValueError("Invalid synthetic drill-down evidence") from error
        self.source, self.data, self.get = source, data, _get
        self.sha256 = hashlib.sha256(raw).hexdigest()

    def _run(self, mode, rows, **kwargs):
        from pallas_ads.adapter_plans import plan_read
        from pallas_ads.adapter_service import SourceHTTPError, _pages, _record

        platform = self.source.platform
        plan = plan_read(
            SourceReadRequest(
                platform=platform, mode=mode, account_id=self.source.account_id, **kwargs
            )
        )
        chunks = [rows[i : i + self.PAGE] for i in range(0, len(rows), self.PAGE)] or [[]]
        records = []
        try:
            for index, chunk in enumerate(chunks, 1):
                more = index < len(chunks)
                if platform == "meta":
                    payload = (
                        chunk[0]
                        if mode == "account_context"
                        else {
                            "data": chunk,
                            **(
                                {
                                    "paging": {
                                        "cursors": {"after": f"c{index}"},
                                        "next": "https://graph.example.invalid/next",
                                    }
                                }
                                if more
                                else {}
                            ),
                        }
                    )
                elif platform == "tiktok":
                    payload = {
                        "code": 0,
                        "data": chunk
                        if mode == "account_context"
                        else {
                            "list": chunk,
                            "page_info": {"page": index, "total_page": len(chunks)},
                        },
                    }
                else:
                    payload = {"results": chunk, **({"nextPageToken": f"t{index}"} if more else {})}
                page_rows, _ = _pages(platform, plan.request.mode, payload)
                records.extend(_record(plan, row) for row in page_rows)
        except SourceHTTPError as error:
            raise SourceUnavailable(str(error)) from None
        return records, "fixture_" + self.sha256[:32]

    def _failure(self, start, end):
        for item in self.data.get("failures", []):
            if date.fromisoformat(item["start"]) <= end and start <= date.fromisoformat(
                item["end"]
            ):
                raise SourceUnavailable(item.get("code", "provider_request_failed"))

    def context(self):
        records, _ = self._run("account_context", [self.data["account_context"]])
        meta = records[0].metadata
        name = meta.get("name") or (meta.get("customer") or {}).get("descriptiveName")
        return meta.get("account_currency"), meta.get("source_timezone"), name

    def names(self):
        records, _ = self._run("entity_configuration", list(self.data.get("campaigns", [])))
        return {r.entity_id: campaign_name(r.metadata) for r in records if r.entity_id}

    def traffic(self, start, end):
        self._failure(start, end)
        field = {
            "meta": "date_start",
            "tiktok": "dimensions.stat_time_day",
            "google": "segments.date",
        }[self.source.platform]
        rows = [
            r
            for r in self.data["performance"]
            if start <= date.fromisoformat(str(self.get(r, field))[:10]) <= end
        ]
        return self._run("traffic_performance", rows, period=DateRange(start=start, end=end))


# ---------------------------------------------------------------- store


class DashboardStore:
    def __init__(self, workspace, dashboard_id):
        base = workspace.layout.root / "dashboards"
        if base.is_symlink():
            raise DashboardError("Dashboard directory cannot be a symlink.")
        self.dir = base / dashboard_id
        if self.dir.is_symlink():
            raise DashboardError("Dashboard directory cannot be a symlink.")
        self.path = self.dir / "state.json"

    def exists(self):
        return self.path.is_file()

    @contextmanager
    def locked(self):
        self.dir.mkdir(parents=True, exist_ok=True, mode=0o700)
        fd = os.open(self.dir / ".lock", os.O_RDWR | os.O_CREAT | os.O_NOFOLLOW, 0o600)
        try:
            try:
                fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
            except BlockingIOError:
                raise DashboardError(
                    "Another update of this dashboard is running; retry after it finishes."
                ) from None
            yield
        finally:
            os.close(fd)

    def load(self):
        if self.path.is_symlink():
            raise DashboardError("Dashboard state cannot be a symlink.")
        state = json.loads(self.path.read_text())
        if state.get("format_version") != FORMAT_VERSION:
            raise DashboardError("Unsupported dashboard state version.")
        return state

    def write(self, name, text):
        target = self.dir / name
        target.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
        tmp = target.with_name("." + target.name + "." + uuid4().hex)
        fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            handle.write(text)
        os.replace(tmp, target)

    def save(self, state):
        self.write("state.json", dump(state))


def merge(state, key, records, *, ref, at, period=None, authoritative=True):
    """Upsert campaign-day rows for one source. Returns counts; never double-counts a key."""
    incoming = {}
    for r in records:
        row_key = f"{key}|{r['campaign_id']}|{r['date']}"
        if row_key in incoming:
            raise SourceUnavailable("duplicate_campaign_day_rows")
        incoming[row_key] = r
    counts = {"inserted": 0, "restated": 0, "unchanged": 0, "removed": 0}
    rows = state["rows"]
    for row_key, r in incoming.items():
        values = {m: text(r.get(m)) for m in (*METRICS, "conversions", "conversion_value")}
        old = rows.get(row_key)
        if old and {m: old.get(m) for m in (*METRICS, "conversions", "conversion_value")} == values:
            counts["unchanged"] += 1
            continue
        revision = old["revision"] + 1 if old else 1
        if old:
            counts["restated"] += 1
            state["restatements"].append(
                {
                    "row": row_key,
                    "at": at,
                    "before": {
                        m: old.get(m) for m in (*METRICS, "conversions", "conversion_value")
                    },
                    "after": values,
                    "ref": ref,
                }
            )
        else:
            counts["inserted"] += 1
        rows[row_key] = {
            "source": key,
            "campaign_id": r["campaign_id"],
            "date": r["date"],
            **values,
            "ref": ref,
            "retrieved_at": at,
            "revision": revision,
        }
    if period and authoritative:
        # A complete re-read of this period no longer returns these rows: keep an audit record.
        start, end = period
        for row_key in [
            k
            for k, v in rows.items()
            if v["source"] == key and start <= v["date"] <= end and k not in incoming
        ]:
            old = rows.pop(row_key)
            counts["removed"] += 1
            state["restatements"].append(
                {
                    "row": row_key,
                    "at": at,
                    "before": {
                        m: old.get(m) for m in (*METRICS, "conversions", "conversion_value")
                    },
                    "after": None,
                    "ref": ref,
                }
            )
    state["restatements"] = state["restatements"][-500:]
    return counts


def record_rows(records, account):
    out = []
    for r in records:
        if r.account_id != account or not r.entity_id or r.event_date is None:
            raise SourceUnavailable("response_scope_mismatch")
        out.append(
            {
                "campaign_id": r.entity_id,
                "date": r.event_date.isoformat(),
                **{m: r.values.get(m) for m in METRICS},
            }
        )
    return out


# ---------------------------------------------------------------- service


class DashboardService:
    def __init__(self, workspace, *, adapter=None, clock=lambda: datetime.now(UTC)):
        self.workspace, self.adapter, self.clock = workspace, adapter, clock

    def handle(self, request: DashboardRequest):
        store = DashboardStore(self.workspace, request.dashboard_id)
        with store.locked():
            if request.op == "create":
                if store.exists():
                    raise DashboardError("Dashboard already exists; use op=update.")
                for source in request.sources:
                    if source.route == "synthetic_fixture":
                        try:
                            FixtureProvider(source)  # reject unmarked fixtures before any state
                        except (OSError, ValueError) as error:
                            raise DashboardError(
                                "Fixture is not readable synthetic JSON."
                            ) from error
                state = self.create(request)
            else:
                if not store.exists():
                    raise DashboardError("Unknown dashboard; create it first.")
                state = store.load()
            live = any(
                s["route"] in ("live_api", "host_capture") for s in state["sources"].values()
            )
            if request.as_of and live:
                raise DashboardError("as_of is only for synthetic fixtures and retained files.")
            run = {
                "run_id": "run_" + uuid4().hex[:16],
                "op": request.op,
                "started_at": self.clock().isoformat(),
                "sources": {},
                "coverage_repairs": (
                    []
                    if request.op == "create"
                    else [
                        *repair_file_coverage(state, store.dir, self.clock().isoformat()),
                        *repair_capture_coverage(state, self.workspace, self.clock().isoformat()),
                    ]
                ),
            }
            pending = []
            if request.op != "status":
                for item in request.ingest:
                    if item.source_key not in state["sources"]:
                        raise DashboardError("ingest source_key is not part of this dashboard.")
                for key, source in state["sources"].items():
                    # Bounded per source per run; backfill resumes from its cursor next run.
                    outcome = self.refresh(
                        state,
                        key,
                        source,
                        request,
                        [i for i in request.ingest if i.source_key == key],
                        request.max_windows,
                    )
                    run["sources"][key] = outcome
                    pending.extend(outcome.get("requested_reads", []))
                run["finished_at"] = self.clock().isoformat()
                state["runs"] = [*state["runs"], run][-50:]
            store.save(state)
            view = render(state, self.today_for(state, request))
            for name, content in view.items():
                store.write(name, content)
            manifest = {
                "renderer": "dashboard",
                "renderer_version": RENDERER_VERSION,
                "state_sha256": hashlib.sha256(store.path.read_bytes()).hexdigest(),
                "template_sha256": hashlib.sha256(template_path().read_bytes()).hexdigest(),
                "template_assets_sha256": {
                    name: hashlib.sha256((template_path().parent / name).read_bytes()).hexdigest()
                    for name in ("dashboard.html", "dashboard.css", "dashboard.js", "pallas-logo.png")
                },
                "dashboard_id": state["dashboard_id"],
                "evidence_mode": state["evidence_mode"],
                "files": {n: hashlib.sha256(c.encode()).hexdigest() for n, c in view.items()},
            }
            store.write("manifest.json", dump(manifest))
        return envelope(state, run, pending, store.dir)

    def create(self, request):
        now = self.clock().isoformat()
        synthetic = request.sources[0].route == "synthetic_fixture"
        return {
            "format_version": FORMAT_VERSION,
            "dashboard_id": request.dashboard_id,
            "title": request.title,
            "evidence_mode": "synthetic_fixture" if synthetic else "account_data",
            "created_at": now,
            "lookback_days": request.lookback_days,
            "sources": {
                s.key: {
                    **s.model_dump(mode="json"),
                    "history_start": request.history_start.isoformat()
                    if request.history_start
                    else None,
                    "currency": None,
                    "timezone": None,
                    "timezone_limitation": None,
                    "boundary_verified": True,
                    "account_name": None,
                    "watermark": None,
                    "backfill_cursor": None,
                    "backfill_complete": False,
                    "covered": [],
                    "last_attempt_at": None,
                    "last_success_at": None,
                    "last_error": None,
                    "requested_reads": [],
                    "fixture_sha256": None,
                }
                for s in request.sources
            },
            "rows": {},
            "campaign_names": {},
            "restatements": [],
            "runs": [],
        }

    def today_for(self, state, request):
        if request.as_of:
            return request.as_of
        # The earliest account-local date, so no source's unfinished day enters the view.
        moment = self.clock()
        return min(local_today(moment, s["timezone"]) for s in state["sources"].values())

    def refresh(self, state, key, source, request, ingests, budget):
        now = self.clock().isoformat()
        source["last_attempt_at"] = now
        outcome = {"windows": [], "inserted": 0, "restated": 0, "unchanged": 0, "removed": 0}
        try:
            if source["route"] in ("live_api", "synthetic_fixture"):
                self._api_refresh(state, key, source, request, budget, outcome, now)
            else:
                self._evidence_refresh(state, key, source, request, ingests, outcome, now)
        except SourceUnavailable as error:
            source["last_error"] = {"code": error.code, "at": now}
            outcome["error"] = error.code
        except DashboardError as error:
            source["last_error"] = {"code": "ingest_rejected", "at": now}
            outcome["error"] = "ingest_rejected"
            outcome["message"] = str(error)
        source["covered"] = merge_intervals(source["covered"])
        return outcome

    def _floor(self, source, end):
        if source["history_start"]:
            return date.fromisoformat(source["history_start"])
        return end - timedelta(days=DEFAULT_HISTORY_DAYS - 1)

    def _context(self, source, provider):
        currency, timezone, name = provider.context()
        try:
            ZoneInfo(str(timezone))
        except (ZoneInfoNotFoundError, ValueError):
            raise SourceUnavailable("source_timezone_required") from None
        if not currency:
            raise SourceUnavailable("source_currency_required")
        if source["currency"] and (source["currency"], source["timezone"]) != (currency, timezone):
            # Never splice series with different money or day boundaries.
            raise SourceUnavailable("source_currency_or_timezone_changed")
        source.update(currency=currency, timezone=timezone, account_name=name)

    def _api_refresh(self, state, key, source, request, budget, outcome, now):
        spec = DashboardSource.model_validate({k: source[k] for k in DashboardSource.model_fields})
        if spec.route == "live_api":
            from pallas_ads.adapter_service import AdapterService

            provider = LiveProvider(self.adapter or AdapterService(self.workspace), spec)
        else:
            try:
                provider = FixtureProvider(spec)
            except (OSError, ValueError, KeyError) as error:
                raise DashboardError("Fixture could not be read as synthetic JSON.") from error
            source["fixture_sha256"] = provider.sha256
        self._context(source, provider)
        today = request.as_of or self.clock().astimezone(ZoneInfo(source["timezone"])).date()
        end = today - timedelta(days=1)  # today is still accruing; never shown as complete
        floor = self._floor(source, end)
        source["history_start"] = floor.isoformat()  # Pin the initial 90-day floor.
        try:
            for campaign, name in provider.names().items():
                if name:
                    state["campaign_names"][f"{key}|{campaign}"] = name
        except SourceUnavailable as error:
            outcome["names_unavailable"] = error.code
        used = 0

        def read(start, stop, kind):
            records, ref = provider.traffic(start, stop)
            counts = merge(
                state,
                key,
                record_rows(records, spec.account_id),
                ref=ref,
                at=now,
                period=(start.isoformat(), stop.isoformat()),
            )
            if isinstance(provider, FixtureProvider):
                from pallas_ads.dashboard_detail import retain_details

                retain_details(state, key, provider, start, stop)
            source["covered"].append([start.isoformat(), stop.isoformat()])
            outcome["windows"].append(
                {"kind": kind, "start": start.isoformat(), "end": stop.isoformat(), **counts}
            )
            for name, value in counts.items():
                outcome[name] += value

        if source["watermark"]:
            watermark = date.fromisoformat(source["watermark"])
            cursor = max(
                floor,
                min(watermark + timedelta(days=1), end - timedelta(days=request.lookback_days - 1)),
            )
            while cursor <= end and used < budget:
                stop = min(end, cursor + timedelta(days=30))
                read(cursor, stop, "incremental")
                used += 1
                source["watermark"] = max(source["watermark"], stop.isoformat())
                cursor = stop + timedelta(days=1)
        while not source["backfill_complete"] and used < budget:
            cursor = (
                date.fromisoformat(source["backfill_cursor"]) if source["backfill_cursor"] else end
            )
            if cursor < floor:
                source["backfill_complete"] = True
                break
            begin = max(floor, cursor - timedelta(days=30))
            read(begin, cursor, "backfill")
            used += 1
            if not source["watermark"]:
                source["watermark"] = cursor.isoformat()
            source["backfill_cursor"] = (begin - timedelta(days=1)).isoformat()
            source["backfill_complete"] = begin <= floor
        source["floor"] = floor.isoformat()
        source["last_success_at"] = now
        source["last_error"] = None

    def _evidence_refresh(self, state, key, source, request, ingests, outcome, now):
        for item in ingests:
            if item.data_path:
                if source["route"] != "file_import":
                    raise DashboardError("data_path requires a file_import source.")
                from pallas_ads.dashboard_data import ingest_template

                counts, period, ref = ingest_template(
                    state,
                    key,
                    source,
                    item.data_path,
                    now,
                    request.as_of,
                    DashboardStore(self.workspace, state["dashboard_id"]),
                )
                outcome["windows"].append(
                    {"kind": "template", "start": period[0], "end": period[1], "ref": ref, **counts}
                )
                for name, value in counts.items():
                    outcome[name] += value
                source["last_success_at"] = now
                source["last_error"] = None
                continue
            if item.capture_id:
                if source["route"] != "host_capture":
                    raise DashboardError("capture_id is only for host_capture sources.")
                batches, currency, timezone, observed = capture_batches(
                    self.workspace, item.capture_id, source["account_id"]
                )
                ref, authoritative = item.capture_id, True
                if timezone is not None and account_zone(timezone) is None:
                    source["timezone_limitation"] = "source_timezone_invalid"
                    timezone = None
                elif timezone is None and account_zone(source["timezone"]) is None:
                    source["timezone_limitation"] = "source_timezone_required"
                else:
                    source["timezone_limitation"] = None
                # A day is complete only once it ended in the account timezone before the read.
                cutoff = local_today(observed, timezone or source["timezone"]) - timedelta(days=1)
                batches = list(trim_unfinished(batches, cutoff.isoformat()))
            else:
                if source["route"] != "file_import":
                    raise DashboardError("dataset_id is only for file_import sources.")
                batches, currency, timezone = file_batches(self.workspace, item.dataset_id, source)
                ref, authoritative = item.dataset_id, False
            if source["currency"] and source["currency"] != currency:
                raise DashboardError("Evidence currency differs from this source.")
            if source["timezone"] and timezone and source["timezone"] != timezone:
                raise DashboardError("Evidence timezone differs from this source.")
            source["currency"] = currency
            source["timezone"] = source["timezone"] or timezone
            for (start, stop), rows, names, *excluded in batches:
                if excluded and excluded[0]:
                    outcome.setdefault("excluded_unfinished", []).append(excluded[0])
                if start > stop:
                    continue
                counts = merge(
                    state,
                    key,
                    rows,
                    ref=ref,
                    at=now,
                    period=(start, stop),
                    authoritative=authoritative,
                )
                # A traffic-only reimport cannot leave stale richer evidence on the dates it replaced.
                replaced = {r["date"] for r in rows}
                detail = state.get("drilldown", {}).get(key)
                if detail:
                    detail["rows"] = [
                        r
                        for r in detail["rows"]
                        if not start <= r["date"] <= stop
                        or (not authoritative and r["date"] not in replaced)
                    ]
                if authoritative:
                    # File rows are observations only: their min/max span is not complete coverage.
                    source["covered"].append([start, stop])
                outcome["windows"].append(
                    {"kind": "ingest", "start": start, "end": stop, "ref": ref, **counts}
                )
                for name, value in counts.items():
                    outcome[name] += value
                for campaign, name in names.items():
                    state["campaign_names"][f"{key}|{campaign}"] = name
            source["last_success_at"] = now
            source["last_error"] = None
        if source["covered"]:
            source["watermark"] = max(b for _, b in merge_intervals(source["covered"]))
        if source["route"] == "host_capture":
            if not source["history_start"]:
                source["history_start"] = (
                    self.today_for_source(source, request) - timedelta(days=DEFAULT_HISTORY_DAYS)
                ).isoformat()
            requests = host_requests(source, request, self.today_for_source(source, request))
            source["requested_reads"] = requests
            outcome["requested_reads"] = requests

    def today_for_source(self, source, request):
        if request.as_of:
            return request.as_of
        return local_today(self.clock(), source["timezone"])


def host_requests(source, request, today):
    """Exact Meta MCP reads the host session should run next; Pallas never runs them."""
    end = today - timedelta(days=1)
    floor = (
        date.fromisoformat(source["history_start"])
        if source["history_start"]
        else end - timedelta(days=DEFAULT_HISTORY_DAYS - 1)
    )
    windows = []
    covered = merge_intervals(source["covered"])
    if source["watermark"]:
        start = max(
            floor,
            min(
                date.fromisoformat(source["watermark"]) + timedelta(days=1),
                end - timedelta(days=request.lookback_days - 1),
            ),
        )
        while start <= end and len(windows) < request.max_windows:
            stop = min(end, start + timedelta(days=30))
            windows.append((start, stop))
            start = stop + timedelta(days=1)
        cursor = date.fromisoformat(covered[0][0]) - timedelta(days=1)
    else:
        cursor = end
    while cursor >= floor and len(windows) < request.max_windows:
        begin = max(floor, cursor - timedelta(days=30))
        windows.append((begin, cursor))
        cursor = begin - timedelta(days=1)
    reads = []
    if account_zone(source["timezone"]) is None:
        # Prerequisite: Meta reports days in the account timezone; read it from the source.
        since, until = windows[0] if windows else (end, end)
        reads.append(
            {
                "source_key": f"meta:{source['account_id']}",
                "purpose": "account_timezone",
                "tool": "ads_get_ad_entities",
                "arguments": {
                    "ad_account_id": source["account_id"],
                    "level": "account",
                    "fields": ["id", "name", "timezone_name"],
                    "time_range": json.dumps(
                        {"since": since.isoformat(), "until": until.isoformat()}
                    ),
                    "time_increment": "all_days",
                    "include_additional_context": False,
                },
                "also_capture": ["ads_get_ad_accounts", "ads_get_field_context"],
            }
        )
    return reads + [
        {
            "source_key": f"meta:{source['account_id']}",
            "tool": "ads_get_ad_entities",
            "arguments": {
                "ad_account_id": source["account_id"],
                "level": "campaign",
                "fields": [
                    "id",
                    "name",
                    "amount_spent",
                    "impressions",
                    "clicks",
                    "date_start",
                    "date_stop",
                ],
                "time_range": json.dumps({"since": a.isoformat(), "until": b.isoformat()}),
                "time_increment": "1",
                "include_additional_context": False,
            },
            "also_capture": ["ads_get_ad_accounts", "ads_get_field_context"],
        }
        for a, b in windows
    ]


def capture_batches(workspace, capture_id, account_id):
    from pallas_ads.host_mcp import stage_capture
    from pallas_ads.host_metrics import currency_code, metric_value, query_groups
    from pallas_ads.host_reporting import read_capture

    try:
        capture = read_capture(workspace, capture_id)
    except (OSError, ValueError) as error:
        raise DashboardError(
            "Retained capture is missing or failed its integrity check."
        ) from error
    if capture.account_id != account_id:
        raise DashboardError("Capture account differs from this source.")
    staged = stage_capture(workspace, capture).result
    account = next((a for a in staged["accounts"] if a["ad_account_id"] == account_id), {})
    currency = currency_code(account.get("currency"))
    if not currency:
        raise DashboardError("Capture lacks ads_get_ad_accounts currency for this account.")
    metadata = {}
    for page in capture.pages:
        if page.tool == "ads_get_field_context" and not page.is_error:
            for row in page.rows():
                metadata[row["name"]] = row
    batches = []
    for group in query_groups(capture):
        args, pages = group["arguments"], group["pages"]
        if (
            group["level"] != "campaign"
            or args.get("time_increment") != "1"
            or args.get("breakdowns")
            or "time_range" not in args
        ):
            continue
        if pages[-1][1].next_cursor() or any(p.is_error for _, p in pages):
            raise DashboardError("Capture pagination is incomplete; capture every page.")
        period = json.loads(args["time_range"])
        start, stop = period["since"], period["until"]
        rows, names = [], {}
        spend_field = "amount_spent" if "amount_spent" in args["fields"] else "spend"
        for _, page in pages:
            for row in page.rows():
                campaign = row.get("id")
                day = row.get("date_start")
                if not isinstance(campaign, str) or not campaign.isdigit():
                    raise DashboardError("Campaign rows require a numeric id field.")
                if (
                    not isinstance(day, str)
                    or row.get("date_stop") != day
                    or not start <= day <= stop
                ):
                    raise DashboardError("Rows must be daily and inside the requested period.")
                values = {}
                for metric, field in (
                    ("spend", spend_field),
                    ("impressions", "impressions"),
                    ("clicks", "clicks"),
                ):
                    parsed = metric_value(field, row.get(field), metadata.get(field, {}), currency)
                    values[metric] = parsed["value"] if parsed["status"] == "provided" else None
                rows.append({"campaign_id": campaign, "date": day, **values})
                if row.get("name"):
                    names[campaign] = str(row["name"])[:200]
        batches.append(((start, stop), rows, names))
    if not batches:
        raise DashboardError(
            "Capture has no campaign-level daily query with an explicit time_range."
        )
    return batches, currency, capture_timezone(capture, account_id), capture.observed_at


def capture_periods(capture):
    """Requested periods of the campaign-level daily queries a capture can establish."""
    from pallas_ads.host_metrics import query_groups

    periods = []
    for group in query_groups(capture):
        args = group["arguments"]
        if (
            group["level"] == "campaign"
            and args.get("time_increment") == "1"
            and not args.get("breakdowns")
            and "time_range" in args
        ):
            period = json.loads(args["time_range"])
            periods.append([period["since"], period["until"]])
    return periods


def capture_timezone(capture, account_id):
    """The account timezone_name the capture itself reports; never inferred from elsewhere."""
    values = []
    for page in capture.pages:
        if page.is_error:
            continue
        if page.tool == "ads_get_ad_accounts":
            values.extend(
                row.get("timezone_name")
                for row in page.rows()
                if row.get("ad_account_id") == account_id
            )
        if page.tool == "ads_get_ad_entities" and page.entity_level == "ad_account":
            values.extend(row.get("timezone_name") for row in page.rows())
    found = {json.dumps(v) for v in values if v is not None}
    if len(found) > 1:
        raise DashboardError("Capture reports conflicting account timezones.")
    return json.loads(found.pop()) if found else None


def trim_unfinished(batches, cutoff):
    """Drop days that had not ended in the account timezone when the capture was observed.

    The retained capture keeps them; they never become dashboard rows or complete coverage.
    """
    for (start, stop), rows, names in batches:
        if stop <= cutoff:
            yield (start, stop), rows, names, None
            continue
        excluded = [max(start, next_day(cutoff)), stop]
        kept = [r for r in rows if r["date"] <= cutoff]
        yield (start, min(stop, cutoff)), kept, names, excluded


def next_day(value):
    return (date.fromisoformat(value) + timedelta(days=1)).isoformat()


def file_batches(workspace, dataset_id, source):
    from pallas_ads.file_import import ExportError, load_retained

    try:
        data = load_retained(workspace, dataset_id, "file_")
    except (ExportError, OSError, ValueError) as error:
        raise DashboardError(
            "Retained file import is missing or failed its integrity check."
        ) from error
    summary = data["summary"]
    if (
        summary["platform"] != source["platform"]
        or summary.get("account_id") != source["account_id"]
    ):
        raise DashboardError("File platform or account differs from this source.")
    rows = [
        {
            "campaign_id": r["campaign_id"],
            "date": r["date"],
            **{m: number(r.get(m)) for m in METRICS},
        }
        for r in data["rows"]
    ]
    period = (summary["period"]["start"], summary["period"]["end"])
    return (
        [(period, rows, dict(data.get("campaign_names", {})))],
        summary["currency"],
        summary["timezone"],
    )


# ---------------------------------------------------------------- presentation


def template_path():
    bundled = Path(__file__).parent / "resources/skills/pallas-dashboard/assets/dashboard.html"
    return (
        bundled
        if bundled.is_file()
        else Path(__file__).parents[2] / "skills/pallas-dashboard/assets/dashboard.html"
    )


def ratios(spend, impressions, clicks):
    return {
        "ctr": clicks / impressions if impressions else None,
        "cpc": spend / clicks if clicks else None,
        "cpm": spend / impressions * 1000 if impressions else None,
    }


def totals(rows):
    out = {}
    for m in METRICS:
        values = [number(r[m]) for r in rows]
        out[m] = sum(values, Decimal(0)) if values and None not in values else None
        out[m + "_missing"] = sum(v is None for v in values)
    spend, imp, clk = out["spend"], out["impressions"], out["clicks"]
    out.update(
        ratios(spend, imp, clk)
        if None not in (spend, imp, clk)
        else {"ctr": None, "cpc": None, "cpm": None}
    )
    return out


def short_time(value):
    """ISO timestamp -> 'YYYY-MM-DD HH:MM UTC' for display; raw value stays in status.json."""
    if not value:
        return "无"
    try:
        moment = datetime.fromisoformat(value).astimezone(UTC)
    except ValueError:
        return value
    return moment.strftime("%Y-%m-%d %H:%M UTC")


def source_status(source, end, coverage=None):
    if source["last_error"] and not source["last_success_at"]:
        return "error", "读取失败"
    if not source["watermark"] and coverage and coverage["observed_only"]:
        return "observed_only", "仅有文件观测行，日期覆盖未验证"
    if not source["watermark"]:
        return (
            ("pending", "等待宿主采集")
            if source["route"] == "host_capture"
            else ("never", "尚未读取")
        )
    lag = (end - date.fromisoformat(source["watermark"])).days
    if source["last_error"]:
        return "error", f"最近更新失败，数据截至 {source['watermark']}"
    if lag <= 0:
        return "fresh", "已更新到最新完整日期"
    return "lagging", f"落后 {lag} 天"


def html_table(headers, rows, *, numeric=(), total=None):
    """Like observation_rendering.table, but cells are already-escaped HTML."""

    def cells(row, tag="td"):
        return "".join(
            f'<{tag} class="{"number" if i in numeric else "text"}">{v}</{tag}>'
            for i, v in enumerate(row)
        )

    return (
        '<div class="table-wrap"><table><thead><tr>'
        + "".join(
            f'<th scope="col" class="{"number" if i in numeric else "text"}">{esc(h)}</th>'
            for i, h in enumerate(headers)
        )
        + "</tr></thead><tbody>"
        + "".join(f"<tr>{cells(row)}</tr>" for row in rows)
        + (f'<tr class="total">{cells(total)}</tr>' if total else "")
        + "</tbody></table></div>"
    )


def badge(platform):
    return f'<span class="badge {platform}" aria-hidden="true">{PLATFORMS[platform][0]}</span>'


def line_chart(series, start, end, currency):
    """Daily spend per platform; uncovered or unreturned days break the line (no zero-fill)."""
    days = (end - start).days + 1
    if days < 1 or not any(series.values()):
        return '<p class="small">当前窗口内没有可绘制的每日花费。</p>'
    top = max((v for s in series.values() for v in s.values()), default=Decimal(0)) or Decimal(1)
    width, height, head = 1000, 170, 10
    step = width / max(1, days - 1)

    def x(i):
        return i * step

    def y(value):
        return height - float(value / top) * (height - head)

    ticks = [top * Decimal(f) for f in ("0", "0.25", "0.5", "0.75", "1")]
    y_labels = "".join(
        f'<div style="top:{y(t) / height * 100:.2f}%">{fmt(t.quantize(Decimal(1)) if top >= 100 else t)}</div>'
        for t in ticks
    )
    parts = [
        '<path class="grid" d="' + " ".join(f"M0 {y(t):.1f} H{width}" for t in ticks[1:]) + '"/>'
    ]
    for platform, points in series.items():
        segment = []
        for i in range(days + 1):
            day = start + timedelta(days=i)
            if day in points and i < days:
                segment.append(f"{x(i):.1f} {y(points[day]):.1f}")
                continue
            if len(segment) > 1:
                parts.append(f'<path class="ln {platform}" d="M{" L".join(segment)}"/>')
            elif segment:
                parts.append(f'<path class="pt {platform}" d="M{segment[0]} h0"/>')
            segment = []
    parts.append(f'<path class="axis" d="M0 {height} H{width}"/>')
    for i in range(days):
        day = start + timedelta(days=i)
        values = "；".join(
            f"{PLATFORMS[p]} {fmt(points[day]) if day in points else '无数据'}"
            for p, points in series.items()
        )
        parts.append(
            f'<rect x="{max(0, x(i) - step / 2):.1f}" y="0" width="{step:.1f}" height="{height}">'
            f"<title>{day.isoformat()} 花费（{esc(currency)}）：{esc(values)}</title></rect>"
        )
    label_step = max(1, days // 6)
    label_days = sorted({0, days - 1, *range(0, days, label_step)})
    if len(label_days) > 2 and days - 1 - label_days[-2] < label_step / 2:
        label_days.pop(-2)
    x_labels = "".join(
        f'<div{"" if i in (0, days - 1) else ' class="mid"'} style="left:{x(i) / width * 100:.2f}%;transform:translateX('
        f'{"0" if i == 0 else "-100%" if i == days - 1 else "-50%"})">'
        f"{(start + timedelta(days=i)).isoformat()}</div>"
        for i in label_days
    )
    legend = "".join(
        f'<div class="chip"><i class="{p}"></i><b>{PLATFORMS[p]}</b>'
        f"<span>花费 {fmt(sum(points.values(), Decimal(0)))}</span></div>"
        for p, points in series.items()
    )
    label = f"每日花费（{esc(currency)}）"
    return (
        f'<div class="chart-head"><div class="chart-title">每日花费 <span>· {esc(currency)}</span></div>'
        f'<div class="legend">{legend}</div></div>'
        f'<figure><div class="chart"><div class="yaxis" aria-hidden="true">{y_labels}</div>'
        f'<div class="plot"><svg role="img" aria-label="{label}" viewBox="0 0 {width} {height}" '
        f'preserveAspectRatio="none"><title>{label}</title>{"".join(parts)}</svg></div></div>'
        f'<div class="chart" aria-hidden="true"><div></div><div class="xaxis">{x_labels}</div></div>'
        f"<figcaption>{start.isoformat()} 至 {end.isoformat()}。线条中断表示该日未读取或来源未返回数据行，不代表花费为零。</figcaption></figure>"
    )


def render(state, today):
    from pallas_ads.dashboard_view import render_interactive

    end = today - timedelta(days=1)
    sources = state["sources"]
    from pallas_ads.dashboard_data import view_data

    payload = view_data(state, today)
    rows = payload["rows"]
    coverage = {key: source_coverage(key, s, rows) for key, s in sources.items()}
    for key, value in coverage.items():
        payload["sources"][key]["observed_only"] = value["observed_only"]
    unavailable = [
        ("覆盖人数、频次", "全部来源", "当前读取不包含这些字段。"),
        ("当天数据", "全部来源", "当天仍在累积，默认排除当天。"),
    ]
    for key in sources:
        if any(
            r.get("conversions") is None or r.get("conversion_value") is None
            for r in rows
            if r["source"] == key
        ) or not any(r["source"] == key for r in rows):
            unavailable.append(
                (
                    "转化/价值（全部或部分缺失）",
                    key,
                    "缺失保留为空；跨来源聚合还需一致的事件、归因和计数口径。",
                )
            )
        for metric in METRICS:
            missing = sum(r.get(metric) is None for r in rows if r["source"] == key)
            if missing:
                unavailable.append((f"{metric}（{missing} 行）", key, "缺失不按零计算。"))
        if coverage[key]["observed_only"]:
            unavailable.append(
                (
                    "期间对比与洞察",
                    key,
                    "文件只提供观测行，未建立完整日期覆盖；缺行日期为未知，不按零计算。",
                )
            )
        if key not in state.get("drilldown", {}):
            unavailable.append(
                ("广告组、设备和素材明细", key, "尚无此粒度的已验证数据，不从 campaign 总量推算。")
            )
    for currency in {s.get("currency") for s in payload["sources"].values()}:
        selected = [s for s in payload["sources"].values() if s.get("currency") == currency]
        definitions = [s.get("conversion_definition") for s in selected]
        semantics = [
            tuple(
                d.get(k)
                for k in ("event", "attribution_window", "counting_method", "value_currency")
            )
            if d
            else None
            for d in definitions
        ]
        if len(selected) > 1 and (None in semantics or len(set(semantics)) != 1):
            unavailable.append(
                (
                    "跨来源转化/价值/CPA/CVR/ROAS 合计",
                    currency or "未知币种",
                    "事件、归因窗口或计数口径未确认一致；仍可查看单来源指标。",
                )
            )
    html_text = render_interactive(state, today, template_path().parent, payload=payload)
    rows = list(state["rows"].values())
    csv_rows = sorted(
        (
            {
                **r,
                "platform": sources[r["source"]]["platform"],
                "account_id": sources[r["source"]]["account_id"],
                "currency": sources[r["source"]]["currency"],
                "route": sources[r["source"]]["route"],
                "campaign_name": state["campaign_names"].get(f"{r['source']}|{r['campaign_id']}"),
            }
            for r in rows
        ),
        key=lambda r: (r["platform"], r["account_id"], r["date"], r["campaign_id"]),
    )
    status = {
        "dashboard_id": state["dashboard_id"],
        "evidence_mode": state["evidence_mode"],
        "latest_complete_date": end.isoformat(),
        "sources": {
            key: {
                k: s.get(k)
                for k in (
                    "platform",
                    "route",
                    "account_id",
                    "currency",
                    "timezone",
                    "timezone_limitation",
                    "watermark",
                    "floor",
                    "backfill_complete",
                    "backfill_cursor",
                    "last_success_at",
                    "last_error",
                    "requested_reads",
                )
            }
            | {
                "covered": merge_intervals(s["covered"]),
                "coverage": coverage[key],
                "freshness": source_status(s, end, coverage[key])[0],
            }
            for key, s in sources.items()
        },
        "row_count": len(rows),
        "unavailable": [{"metric": a, "scope": b, "reason": c} for a, b, c in unavailable],
    }
    return {
        "dashboard.html": html_text,
        "data.json": dump(payload),
        "rows.csv": csv_text(
            csv_rows,
            [
                "platform",
                "account_id",
                "currency",
                "route",
                "date",
                "campaign_id",
                "campaign_name",
                "spend",
                "impressions",
                "clicks",
                "revision",
                "retrieved_at",
                "ref",
            ],
        ).replace("\r\n", "\n"),
        "status.json": dump(status),
    }


def envelope(state, run, pending, directory):
    issues, missing = [], []
    if state["evidence_mode"] == "synthetic_fixture":
        issues.append(
            OperationIssue(
                code="synthetic_fixture",
                severity="warning",
                message="Synthetic fixture dashboard: invented accounts and values, not real-account testing.",
            )
        )
    for key, o in run["sources"].items():
        if o.get("error"):
            detail = f" ({o['message']})" if o.get("message") else ""
            issues.append(
                OperationIssue(
                    code="dashboard_source_failed",
                    severity="warning",
                    message=f"{key}: {o['error']}{detail}. Coverage is unchanged for that "
                    "source; rerun update after repair.",
                )
            )
    context = json.loads((directory / "status.json").read_text())
    for repair in run.get("coverage_repairs", []):
        issues.append(
            OperationIssue(
                code="coverage_repaired",
                severity="warning",
                message=f"{repair['source']}: removed coverage for "
                f"{', '.join(a if a == b else f'{a}..{b}' for a, b in repair['removed'])} "
                + (
                    "that no retained complete window supports."
                    if repair["reason"] == "file_rows_do_not_establish_complete_coverage"
                    else "that had not ended in the account timezone when captured, or whose "
                    "retained capture cannot be verified."
                )
                + " Observed rows were kept; those dates are no longer treated as complete.",
            )
        )
    for key, source in context["sources"].items():
        if source.get("timezone_limitation"):
            invalid = source["timezone_limitation"] == "source_timezone_invalid"
            issues.append(
                OperationIssue(
                    code=source["timezone_limitation"],
                    severity="warning",
                    message=f"{key}: the retained Meta evidence has "
                    f"{'an invalid' if invalid else 'no'} account timezone_name. Pallas does not "
                    "assume UTC, this computer's timezone or a currency-based zone: reads and "
                    "coverage end at the last date that has ended in every timezone, and "
                    "timezone changes cannot be detected. Run the requested account_timezone "
                    "read (or ads_get_ad_accounts with timezone_name) and stage it.",
                )
            )
        coverage = source["coverage"]
        if coverage["observed_only"]:
            observed, unknown = (
                sum((date.fromisoformat(b) - date.fromisoformat(a)).days + 1 for a, b in spans)
                for spans in (coverage["observed_only"], coverage["unknown_within_observed_span"])
            )
            issues.append(
                OperationIssue(
                    code="coverage_not_established",
                    severity="warning",
                    message=f"{key}: {observed} date(s) have rows without verified complete "
                    f"coverage and {unknown} date(s) in that span have no rows (unknown, not "
                    "zero). Period comparisons and insights are withheld for these dates; "
                    + (
                        "run the requested reads and stage a complete capture."
                        if source["route"] == "host_capture"
                        else "ingest a complete normalized data_path window to establish coverage."
                    ),
                )
            )
    if pending:
        issues.append(
            OperationIssue(
                code="host_capture_required",
                severity="info",
                message=f"{len(pending)} Meta MCP read(s) must run in the signed-in host session.",
            )
        )
        missing.append(
            MissingInput(
                field_path="ingest",
                reason="Run the requested Meta MCP reads in the host session, stage each with source_connect_or_import action=host_capture, then update with ingest capture_id.",
            )
        )
    status = "pending_user_action" if pending else "partial_result" if issues else "complete"
    summary = {
        k: {
            "windows": len(o["windows"]),
            **{n: o[n] for n in ("inserted", "restated", "unchanged", "removed")},
            "error": o.get("error"),
            # Days unfinished in the account timezone at observation; kept only in the capture.
            "excluded_unfinished": o.get("excluded_unfinished", []),
        }
        for k, o in run["sources"].items()
    }
    return OperationEnvelope(
        operation="build_report",
        status=status,
        issues=issues,
        missing_inputs=missing,
        result={
            "dashboard_id": state["dashboard_id"],
            "evidence_mode": state["evidence_mode"],
            "run": {"run_id": run["run_id"], "op": run["op"], "sources": summary},
            "conversation_context": context,
            "requested_reads": pending,
            "row_count": len(state["rows"]),
            "artifacts": {
                "html": str(directory / "dashboard.html"),
                "data": str(directory / "data.json"),
                "rows": str(directory / "rows.csv"),
                "status": str(directory / "status.json"),
                "manifest": str(directory / "manifest.json"),
            },
            "update_command": f"pallas dashboard update --dashboard {state['dashboard_id']} --workspace <workspace>",
        },
    )
