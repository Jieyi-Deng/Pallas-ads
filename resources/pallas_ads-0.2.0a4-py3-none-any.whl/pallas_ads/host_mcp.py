"""Offline staging of host-owned Meta reads; never accesses another client's credentials."""

import hashlib
import json
import os
import shlex
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import TypedDict

from pallas_ads.contracts.host_mcp import META_HOST_URL, META_READ_TOOLS, HostCapture
from pallas_ads.contracts.status import OperationEnvelope, OperationIssue

MAX_CAPTURE_BYTES = 2 * 1024 * 1024


class CursorChain(TypedDict):
    next_cursor: str | None
    seen: set[str | None]
    failed: bool
    tool: str
    scope: dict
    page_count: int
    row_count: int
    empty_page_count: int


GUARD_MATCHER = "mcp__meta_official__.*"
META_SERVER = {"type": "http", "url": META_HOST_URL}
CODEX_TEXT = (
    "Pallas pre-registered client login was verified on 2026-09-14. For a project "
    "installed with --meta-client-id, run pallas agent doctor and agent login-meta "
    "--directory PROJECT; this starts the packaged HTTPS callback and Codex login. "
    "Generic Codex dynamic registration remains blocked. "
    "Never borrow other clients' tokens."
)
# Pallas sees project files, not the host's OAuth state. The agent decides these with its tools.
HOST_CHECKS = [
    "meta_official tools absent in this session: reload/start a new session in this project, "
    "trust the project MCP server and hooks, then /mcp -> meta_official -> Authenticate.",
    "Tools present but ads_get_ad_accounts not yet successful: tools are loaded, but current "
    "authentication and account access are unverified. With the read guard loaded, call "
    "ads_get_ad_accounts and follow any host authentication prompt.",
    "ads_get_ad_accounts returned accounts: the existing host connection is usable. Do not "
    "reauthorize or run connect-meta again.",
]


def guard_executable(entry):
    """Executable of a Pallas-generated Meta read guard entry, or None for any other hook."""
    if not isinstance(entry, dict) or entry.get("matcher") != GUARD_MATCHER:
        return None
    hooks = entry.get("hooks")
    if not isinstance(hooks, list) or len(hooks) != 1 or not isinstance(hooks[0], dict):
        return None
    command = hooks[0].get("command")
    if hooks[0].get("type") != "command" or not isinstance(command, str):
        return None
    try:
        parts = shlex.split(command)
    except ValueError:
        return None
    if len(parts) != 3 or parts[1:] != ["agent", "guard-meta"]:
        return None
    return Path(parts[0]) if parts[0].endswith("/bin/pallas") else None


def _project_json(path):
    if path.is_symlink() or path.stat().st_size > 1024 * 1024:
        raise ValueError("unsupported project file")
    value = json.loads(path.read_text())
    if not isinstance(value, dict):
        raise ValueError("unsupported project file")
    return value


def meta_registration(project):
    """Observational project-scope inspection; never reads host credentials or user scope."""
    project = Path(project)
    binding_path = project / ".pallas/plugin-install.json"
    try:
        binding = _project_json(binding_path) if binding_path.is_file() else {}
    except (OSError, ValueError):
        binding = {}
    client = binding.get("client") or (
        "codex" if (project / ".codex/config.toml").is_file() else "claude"
    )
    result = {"client": client, "project": str(project), "plugin_project": bool(binding)}
    if client == "codex":
        from pallas_ads.machine_setup import read_meta

        try:
            read_meta(project)
            result["server"] = "preregistered_client_configured"
        except (OSError, KeyError, TypeError):
            result["server"] = "not_registered"
        except ValueError:
            result["server"] = "conflicting_custom"
        return result
    try:
        servers = _project_json(project / ".mcp.json").get("mcpServers", {})
        server = servers.get("meta_official") if isinstance(servers, dict) else "invalid"
        result["server"] = (
            "not_registered"
            if server is None
            else "registered"
            if server == META_SERVER
            else "conflicting_custom"
        )
    except FileNotFoundError:
        result["server"] = "not_registered"
    except (OSError, ValueError):
        result["server"] = "invalid_project_configuration"
    try:
        hooks = _project_json(project / ".claude/settings.json").get("hooks", {})
        entries = hooks.get("PreToolUse", []) if isinstance(hooks, dict) else []
        guards = [g for g in map(guard_executable, entries if isinstance(entries, list) else [])]
        guards = [g for g in guards if g is not None]
        result["read_guard"] = (
            "missing"
            if not guards
            else "installed"
            if any(g.is_file() for g in guards)
            else "stale_executable_missing"
        )
    except FileNotFoundError:
        result["read_guard"] = "missing"
    except (OSError, ValueError):
        result["read_guard"] = "invalid_project_configuration"
    return result


def host_connection_instructions(project=None):
    registration = meta_registration(project) if project is not None else {"client": "unknown"}
    setup = (
        (
            "Use the pallas-setup Skill: node <plugin>/scripts/pallas.mjs connect-meta "
            "--project "
            + shlex.quote(str(project))
            + ". It adds meta_official and the read guard, keeps "
            "other servers and hooks, and performs no authorization."
        )
        if registration.get("plugin_project")
        else (
            "This legacy project cannot add Meta in place (legacy agent setup only writes new "
            "projects, with --mode live). Migrate it to the native plugin with the pallas-setup "
            "Skill (setup --migrate keeps data), then run connect-meta."
        )
    )
    server, guard = registration.get("server"), registration.get("read_guard")
    if registration["client"] == "codex":
        state, code, next_step = (
            "codex_preregistered_route",
            "host_authorization_required",
            ("authenticate_in_host_then_read_accounts"),
        )
        message = "Check authentication in the host client's Meta MCP settings."
    elif server == "not_registered":
        state, code, next_step = "not_registered", "meta_server_not_registered", "connect_meta"
        message = "meta_official is not registered in this project. " + setup
    elif server in ("conflicting_custom", "invalid_project_configuration") or guard == (
        "invalid_project_configuration"
    ):
        state, code, next_step = (
            "configuration_conflict",
            "meta_config_conflict",
            ("review_project_configuration_manually"),
        )
        message = (
            "Existing project MCP or hook configuration differs from the supported Meta setup. "
            "Pallas will not overwrite it; the user or operator reviews .mcp.json and "
            ".claude/settings.json."
        )
    elif guard != "installed":
        state, code, next_step = "registered_guard_missing", "meta_guard_missing", "connect_meta"
        message = "meta_official is registered but the Pallas read-only guard is not active. " + (
            setup
        )
    else:
        state, code, next_step = (
            "registered_authentication_unknown",
            ("host_authorization_required"),
            "authenticate_in_host_then_read_accounts",
        )
        message = "Registered in this project. Authentication is owned by the host; check /mcp."
    return OperationEnvelope(
        operation="source_connect_or_import",
        status="pending_user_action",
        issues=[
            OperationIssue(
                code=code,
                severity="info" if code == "host_authorization_required" else "warning",
                message=message,
            )
        ],
        result={
            "authorization_owner": "host_client",
            "endpoint": META_HOST_URL,
            "server_name": "meta_official",
            "read_tools": list(META_READ_TOOLS),
            "registration": registration,
            "state": state,
            "authentication": "unknown_host_owned",
            "account_access": "unverified_until_ads_get_ad_accounts_succeeds",
            "next_step": next_step,
            "host_checks": HOST_CHECKS,
            "claude_code": (
                message
                if next_step != "authenticate_in_host_then_read_accounts"
                else "Reload and trust project MCP/hooks if prompted; use /mcp to authenticate "
                "meta_official, then ads_get_ad_accounts."
            ),
            "codex": CODEX_TEXT,
            "note": (
                "No Pallas OAuth session was created. The host owns authentication, refresh "
                "and disconnect. If its tools already work, do not reauthorize. Only project "
                "files are inspected; a user-scope registration is not visible to Pallas. "
                "Stage credential-free results with action=host_capture. "
                "Use build_report(action=host_review,capture_id=...) for a bounded HTML evidence "
                "review. Canonical outcome mapping and live performance validation remain pending."
            ),
        },
    )


def stage_capture(workspace, capture: HostCapture):
    """Retain bounded evidence and verify pagination; hashes prove integrity, not origin."""
    payload = capture.model_dump_json().encode()
    if len(payload) > MAX_CAPTURE_BYTES:
        raise ValueError("Capture too large.")
    if capture.observed_at > datetime.now(UTC) + timedelta(minutes=5):
        raise ValueError("Future observation timestamp.")
    queries: dict[str, CursorChain] = {}
    accounts, fields, calls, reasons = {}, {}, [], set()
    metadata = {}
    # Metadata can arrive after entity pages. Its position is not a coverage condition.
    for page in capture.pages:
        if page.tool == "ads_get_field_context" and not page.is_error:
            for row in page.rows():
                if not isinstance(row.get("name"), str) or not isinstance(row.get("levels"), list):
                    raise ValueError("Invalid field metadata.")
                levels = ["ad_account" if v == "account" else v for v in row["levels"]]
                if row["name"] in fields and fields[row["name"]] != levels:
                    raise ValueError("Conflicting field metadata.")
                if row["name"] in metadata and metadata[row["name"]] != row:
                    raise ValueError("Conflicting field definitions.")
                fields[row["name"]] = levels
                metadata[row["name"]] = row
    for page in capture.pages:
        args = {k: v for k, v in page.arguments.items() if k != "cursor"}
        signature = json.dumps([page.tool, args], sort_keys=True)
        previous = queries.get(signature)
        if previous is None:
            if "cursor" in page.arguments:
                raise ValueError("First page missing.")
            previous = CursorChain(
                next_cursor=None,
                seen=set(),
                failed=False,
                tool=page.tool,
                scope=args,
                page_count=0,
                row_count=0,
                empty_page_count=0,
            )
        elif (
            previous["failed"]
            or previous["next_cursor"] is None
            or page.arguments.get("cursor") != previous["next_cursor"]
        ):
            raise ValueError("Duplicate page, changed query or broken cursor chain.")
        cursor = page.next_cursor()
        if cursor is not None and cursor in previous["seen"]:
            raise ValueError("Repeated pagination cursor.")
        previous["seen"].add(cursor)
        previous.update(next_cursor=cursor, failed=page.is_error)
        queries[signature] = previous
        if page.is_error:
            reasons.add("host_source_error")
            rows = []
        else:
            rows = page.rows()
            if page.tool == "ads_get_ad_accounts":
                for row in rows:
                    identifier = row.get("ad_account_id")
                    if not isinstance(identifier, str) or not identifier.isdigit():
                        raise ValueError("Missing source account ID.")
                    if identifier in accounts:
                        raise ValueError("Duplicate source account.")
                    accounts[identifier] = {
                        k: row.get(k)
                        for k in (
                            "ad_account_id",
                            "ad_account_name",
                            "currency",
                            "timezone_name",
                            "is_ads_mcp_enabled",
                            "is_queryable",
                        )
                    }
            if page.tool == "ads_get_field_context":
                for row in rows:
                    if not isinstance(row.get("name"), str) or not isinstance(
                        row.get("levels"), list
                    ):
                        raise ValueError("Invalid field metadata.")
            if page.tool == "ads_get_ad_entities":
                if "filtering" in args:
                    definition = metadata.get("amount_spent", {})
                    if (
                        definition.get("filterable") is not True
                        or "GREATER_THAN" not in definition.get("supported_filter_operators", [])
                        or page.entity_level not in fields.get("amount_spent", [])
                    ):
                        raise ValueError("Spend filter requires matching source field metadata.")
                requested_fields = args["fields"]
                if not isinstance(requested_fields, list):
                    raise ValueError("Invalid fields.")
                for field in requested_fields:
                    if page.entity_level not in fields.get(field, []):
                        reasons.add("field_metadata_missing_or_unsupported")
                if not rows:
                    reasons.add("empty_rows_do_not_prove_zero_spend")
        previous["page_count"] += 1
        previous["row_count"] += len(rows)
        previous["empty_page_count"] += int(not rows and not page.is_error)
        calls.append(
            {
                "tool": page.tool,
                "scope": args,
                "row_count": len(rows),
                "is_error": page.is_error,
                "has_next_page": cursor is not None,
            }
        )
    pagination_complete = all(
        q["next_cursor"] is None and not q["failed"] for q in queries.values()
    )
    if not pagination_complete:
        reasons.add("host_pagination_incomplete")
    if capture.account_id and capture.account_id not in accounts:
        reasons.add("account_discovery_evidence_missing")
    digest = hashlib.sha256(payload).hexdigest()
    identifier = "host_" + digest
    root = workspace.layout.root / "host_captures"
    if root.is_symlink():
        raise ValueError("Capture directory cannot be a symlink.")
    root.mkdir(mode=0o700, exist_ok=True)
    path = root / (identifier + ".json")
    # Exclusive create and compare on replay. Never overwrite previous source evidence.
    try:
        fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    except FileExistsError:
        if path.is_symlink() or path.read_bytes() != payload:
            raise ValueError("Retained capture integrity check failed.") from None
    else:
        with os.fdopen(fd, "wb") as handle:
            handle.write(payload)
    return OperationEnvelope(
        operation="source_connect_or_import",
        status="partial_result",
        result={
            "capture_id": identifier,
            "evidence_path": str(path.resolve()),
            "content_hash": "sha256:" + digest,
            "origin_verification": "caller_asserted_not_independently_verified",
            "authorization_owner": "host_client",
            "observed_at": capture.observed_at,
            "account_id": capture.account_id,
            "accounts": list(accounts.values()),
            "calls": calls,
            "queries": [
                {
                    "tool": q["tool"],
                    "scope": q["scope"],
                    "page_count": q["page_count"],
                    "row_count": q["row_count"],
                    "empty_page_count": q["empty_page_count"],
                    "complete": q["next_cursor"] is None and not q["failed"],
                    "failed": q["failed"],
                    "continuation_required": q["next_cursor"] is not None,
                }
                for q in queries.values()
            ],
            "read_strategy": {
                "account_totals_first": True,
                "recommended_entity_page_budget": 5,
                "stop_after_consecutive_empty_pages": 2,
                "on_budget_exhausted": "retain_partial_chain_and_report_completed_accounts",
                "executor": "host_client_not_pallas",
            },
            "pagination_complete": pagination_complete,
            "canonical_data_written": False,
            "analysis_ready": False,
            "next_step": "meta_host_adapter_pending_live_validation",
        },
        issues=[
            OperationIssue(
                code=code,
                severity="warning",
                message=message,
            )
            for code, message in [
                (
                    "meta_host_adapter_pending",
                    "Evidence retained; canonical mapping and reports "
                    "are deferred until Meta test-account validation. "
                    "Do not claim an analyzed report.",
                ),
                (
                    "host_origin_unverified",
                    "The host supplied these results. Integrity hashes "
                    "cannot prove they came from Meta or establish current authorization.",
                ),
                *(
                    (code, "Preserve this limitation when interpreting the retained evidence.")
                    for code in sorted(reasons)
                ),
            ]
        ],
    )
