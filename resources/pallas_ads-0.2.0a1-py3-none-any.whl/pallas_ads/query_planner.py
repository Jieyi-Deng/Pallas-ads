"""Deterministic import-backed query resolution; no native media queries."""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from datetime import date, timedelta
from typing import Any
from zoneinfo import ZoneInfo

from pallas_ads.contracts.analysis import EvidencePolicy, PlannedSource, ResolvedQueryPlan
from pallas_ads.contracts.common import OUTCOME_METRICS
from pallas_ads.contracts.common import CanonicalDimension as D
from pallas_ads.contracts.common import CanonicalMetric as M
from pallas_ads.contracts.data import (
    CanonicalImportManifest,
    DimensionState,
    DimensionValue,
    EntityType,
    MaturityStatus,
    ObservationRevision,
    SourceSnapshot,
)
from pallas_ads.contracts.profile import CampaignScopeMode, MediaBinding, ProfileRevision
from pallas_ads.contracts.query import CanonicalQuery, DateRange
from pallas_ads.data_store import CanonicalDataRepository
from pallas_ads.local_state import WorkspaceRepository
from pallas_ads.metric_registry import DEFAULT_METRIC_REGISTRY


class AnalysisInputError(ValueError):
    def __init__(self, field_path: str, reason: str) -> None:
        super().__init__(reason)
        self.field_path = field_path
        self.reason = reason


def content_hash(payload: Any) -> str:
    encoded = json.dumps(
        payload, sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False
    ).encode("utf-8")
    return "sha256:" + hashlib.sha256(encoded).hexdigest()


def dates(period: DateRange) -> list[date]:
    return [
        period.start + timedelta(days=offset)
        for offset in range((period.end - period.start).days + 1)
    ]


def metric_components(metric: M) -> tuple[M, ...]:
    definition = DEFAULT_METRIC_REGISTRY.definition(metric)
    if definition.importable:
        return (metric,)
    assert definition.numerator_metric is not None and definition.denominator_metric is not None
    return (definition.numerator_metric, definition.denominator_metric)


def campaign_allowed(binding: MediaBinding, campaign_id: str, query: CanonicalQuery) -> bool:
    scope = binding.campaign_scope
    if scope.mode is CampaignScopeMode.INCLUDE and campaign_id not in scope.campaign_ids:
        return False
    if scope.mode is CampaignScopeMode.EXCLUDE and campaign_id in scope.campaign_ids:
        return False
    return not query.filters.campaign_ids or campaign_id in query.filters.campaign_ids


def dimension_allowed(value: DimensionValue, requested: list[str]) -> bool:
    if requested:
        return value.state is DimensionState.VALUE and value.value in requested
    return value.state is DimensionState.ALL


@dataclass
class CellState:
    records: list[ObservationRevision]
    reasons: list[str]
    snapshot: SourceSnapshot | None


@dataclass
class AnalysisContext:
    plan: ResolvedQueryPlan
    profile: ProfileRevision
    bindings: list[MediaBinding]
    manifests: dict[str, CanonicalImportManifest]
    cells: dict[tuple[str, date, M], CellState]


class QueryPlanner:
    def __init__(
        self, workspace: WorkspaceRepository, policies: dict[str, EvidencePolicy] | None = None
    ) -> None:
        self.workspace = workspace
        self.data = CanonicalDataRepository(workspace)
        self.policies = policies or {}

    def resolve(self, query: CanonicalQuery) -> AnalysisContext:
        query = CanonicalQuery.model_validate(query.model_dump(mode="json"))
        if not self.workspace.layout.database_file.is_file():
            raise AnalysisInputError("/workspace", "initialize the workspace and import data first")
        profile = self._profile(query)
        bindings = self._bindings(query, profile)
        for grain, filters in (
            (D.COUNTRY, query.filters.countries),
            (D.OS, query.filters.operating_systems),
        ):
            if len(filters) > 1:
                raise AnalysisInputError(
                    "/filters",
                    "the current dense coverage contract supports "
                    "one explicit country and OS slice per query; split this selection",
                )
            if grain in query.grain and not filters:
                raise AnalysisInputError(
                    "/filters",
                    "dimension drill-down requires explicit "
                    "country/OS filters with matching source coverage",
                )
        latest = self.data.latest_data_revision()
        revision = query.as_of_data_revision or latest
        if revision < 1 or revision > latest:
            raise AnalysisInputError(
                "/as_of_data_revision", "requested data revision is unavailable"
            )
        snapshots = self.data.source_snapshots(query.product_id, as_of_data_revision=revision)
        if query.as_of is not None:
            snapshots = [s for s in snapshots if s.observed_at <= query.as_of]
        selected_accounts = {(b.platform, b.account_id) for b in bindings}
        snapshots = [s for s in snapshots if (s.platform, s.account_id) in selected_accounts]
        if not snapshots:
            raise AnalysisInputError(
                "/platforms", "no imported source snapshots for this selection"
            )
        manifests = {}
        for snapshot in snapshots:
            manifest = self.data.source_manifest(snapshot.source_snapshot_id)
            if manifest is None:
                raise AnalysisInputError(
                    "/sources", "source manifest is missing from local storage"
                )
            manifests[snapshot.source_snapshot_id] = manifest
        rows = self.data.analysis_observations(
            query.product_id, data_revision=revision, observed_through=query.as_of
        )
        policy_version = profile.profile.comparison_policy.evidence_policy_version
        policy = self.policies.get(policy_version, EvidencePolicy(version=policy_version))
        policy = EvidencePolicy.model_validate(policy.model_dump(mode="json"))
        if policy.version != policy_version:
            raise AnalysisInputError(
                "/comparison_policy/evidence_policy_version",
                "registered evidence policy version does not match its key",
            )
        components = {part for metric in query.metrics for part in metric_components(metric)}
        if (
            set(query.metrics) & {M.MEDIA_IAP_ROAS, M.PLATFORM_ATTRIBUTED_IAP_REVENUE}
            and policy.minimum_outcome_events is not None
        ):
            components.add(M.PURCHASE_EVENT_COUNT)
        if policy.minimum_spend is not None and set(query.metrics) & OUTCOME_METRICS:
            components.add(M.SPEND)
        if set(query.reporting_time_bases) - components:
            raise AnalysisInputError(
                "/reporting_time_bases",
                "basis selection must reference a requested additive component",
            )
        cells: dict[tuple[str, date, M], CellState] = {}
        sources: list[PlannedSource] = []
        for binding in bindings:
            source_snapshots = [
                s
                for s in snapshots
                if (s.platform, s.account_id) == (binding.platform, binding.account_id)
            ]
            candidates = [
                row
                for row in rows
                if self._row_selected(row, binding, query) and row.record.metric_key in components
            ]
            source_dates = {row.record.event_date for row in candidates}
            # Explicit periods must surface absent dates, not just dates present in the rows.
            if query.period is not None:
                source_dates.update(dates(query.period))
                source_dates.update(dates(query.baseline or preceding_period(query.period)))
            mature_dates = []
            for day in sorted(source_dates):
                snapshot = next(
                    (
                        s
                        for s in reversed(source_snapshots)
                        if s.effective_period.start <= day <= s.effective_period.end
                    ),
                    None,
                )
                for metric in sorted(components):
                    selected = [
                        r
                        for r in candidates
                        if r.record.event_date == day and r.record.metric_key == metric
                    ]
                    cells[(binding.binding_id, day, metric)] = self._cell(
                        binding, query, day, metric, selected, snapshot, manifests
                    )
                states = [cells[(binding.binding_id, day, m)] for m in components]
                if all(
                    not state.reasons
                    and state.records
                    and all(
                        r.record.maturity_status is MaturityStatus.MATURE for r in state.records
                    )
                    for state in states
                ):
                    mature_dates.append(day)
            sources.append(
                PlannedSource(
                    binding_id=binding.binding_id,
                    platform=binding.platform,
                    account_id=binding.account_id,
                    snapshots=source_snapshots,
                    complete_mature_dates=mature_dates,
                    issues=[] if source_snapshots else ["source_not_imported"],
                )
            )
        if query.period is None:
            common = set.intersection(*(set(s.complete_mature_dates) for s in sources))
            end = next(
                (
                    end
                    for end in sorted(common, reverse=True)
                    if all(end - timedelta(days=offset) in common for offset in range(14))
                ),
                None,
            )
            if end is None:
                raise AnalysisInputError(
                    "/period",
                    "default comparison requires fourteen "
                    "consecutive complete mature dates across every selected "
                    "source and component; import coverage or select an explicit period",
                )
            period = DateRange(start=end - timedelta(days=6), end=end)
        else:
            period = query.period
        baseline = query.baseline or preceding_period(period)
        effective_grain = sorted(
            set(query.grain) | {D.CHANNEL, D.CAMPAIGN_TYPE, D.OPTIMIZATION_GOAL}
        )
        warnings = []
        if set(query.grain) != set(effective_grain):
            warnings.append("semantic_grain_preserved")
        if policy.calibration == "unconfigured":
            warnings.append("evidence_policy_unconfigured")
        elif policy.calibration == "synthetic":
            warnings.append("synthetic_evidence_policy")
        # Preserve the requested as_of semantics, and pin all other latest choices in the plan.
        normalized_query = query.model_copy(update={"profile_revision": profile.revision})
        if query.as_of is None:
            normalized_query.as_of_data_revision = revision
        plan = ResolvedQueryPlan(
            plan_hash="sha256:" + "0" * 64,
            query=normalized_query,
            data_revision=revision,
            profile_revision=profile.revision,
            profile_hash=profile.profile_hash,
            observed_through=query.as_of or max(s.observed_at for s in snapshots),
            period=period,
            baseline=baseline,
            effective_grain=effective_grain,
            component_metrics=sorted(components),
            sources=sources,
            evidence_policy=policy,
            warnings=warnings,
        )
        plan.plan_hash = content_hash(plan.model_dump(mode="json", exclude={"plan_hash"}))
        return AnalysisContext(plan, profile, bindings, manifests, cells)

    def _profile(self, query: CanonicalQuery) -> ProfileRevision:
        profile = (
            self.workspace.profile_revision(query.product_id, query.profile_revision)
            if query.profile_revision is not None
            else self.workspace.latest_profile_revision(query.product_id)
        )
        if query.profile_revision is None and query.as_of is not None:
            while profile is not None and profile.confirmed_at > query.as_of:
                profile = self.workspace.profile_revision(query.product_id, profile.revision - 1)
        if profile is None:
            raise AnalysisInputError(
                "/product_id", "a confirmed product profile is required at this cutoff"
            )
        if query.as_of is not None and profile.confirmed_at > query.as_of:
            raise AnalysisInputError(
                "/profile_revision", "profile revision is later than the observation cutoff"
            )
        return profile

    @staticmethod
    def _bindings(query: CanonicalQuery, profile: ProfileRevision) -> list[MediaBinding]:
        known_ids = {b.binding_id for b in profile.profile.media_bindings}
        if set(query.filters.binding_ids) - known_ids:
            raise AnalysisInputError(
                "/filters/binding_ids", "query references an unknown media binding"
            )
        if any(
            b.binding_id in query.filters.binding_ids and b.platform not in query.platforms
            for b in profile.profile.media_bindings
        ):
            raise AnalysisInputError(
                "/filters/binding_ids", "binding filters conflict with selected platforms"
            )
        bindings = [
            b
            for b in profile.profile.media_bindings
            if b.platform in query.platforms
            and (not query.filters.binding_ids or b.binding_id in query.filters.binding_ids)
        ]
        if {b.platform for b in bindings} != set(query.platforms):
            raise AnalysisInputError(
                "/platforms", "every selected platform needs a selected product binding"
            )
        for index, left in enumerate(bindings):
            for right in bindings[index + 1 :]:
                if (left.platform, left.account_id) == (
                    right.platform,
                    right.account_id,
                ) and _scopes_overlap(left, right):
                    raise AnalysisInputError(
                        "/filters/binding_ids",
                        "selected bindings have overlapping campaign scopes in one media account",
                    )
        return sorted(bindings, key=lambda b: b.binding_id)

    @staticmethod
    def _row_selected(
        row: ObservationRevision, binding: MediaBinding, query: CanonicalQuery
    ) -> bool:
        record = row.record
        return (
            (row.platform, row.account_id) == (binding.platform, binding.account_id)
            and record.entity_type is EntityType.CAMPAIGN
            and campaign_allowed(binding, record.entity_id, query)
            and (record.app_variant_id is None or record.app_variant_id in binding.app_variant_ids)
            and dimension_allowed(record.country, query.filters.countries)
            and dimension_allowed(record.os, [os.value for os in query.filters.operating_systems])
        )

    @staticmethod
    def _cell(
        binding: MediaBinding,
        query: CanonicalQuery,
        day: date,
        metric: M,
        rows: list[ObservationRevision],
        snapshot: SourceSnapshot | None,
        manifests: dict[str, CanonicalImportManifest],
    ) -> CellState:
        coverage = manifests[snapshot.source_snapshot_id].coverage if snapshot is not None else None
        basis = query.reporting_time_bases.get(metric)
        if basis is None and coverage is not None:
            basis = coverage.reporting_time_bases.get(metric)
        if basis is not None:
            rows = [r for r in rows if r.record.reporting_time_basis is basis]
        reasons = []
        if (
            snapshot is not None
            and day >= snapshot.observed_at.astimezone(ZoneInfo(snapshot.source_timezone)).date()
        ):
            reasons.append("open_reporting_day")
        if coverage is None:
            reasons.append("coverage_unverified")
        else:
            if not _scope_covered(
                binding,
                query,
                coverage.campaign_scope.mode,
                set(coverage.campaign_scope.campaign_ids),
            ):
                reasons.append("source_scope_not_covered")
            if not dimension_allowed(
                coverage.country, query.filters.countries
            ) or not dimension_allowed(
                coverage.os, [os.value for os in query.filters.operating_systems]
            ):
                reasons.append("source_scope_not_covered")
            if metric not in coverage.metrics or basis != coverage.reporting_time_bases.get(metric):
                reasons.append("incomplete_coverage")
            expected = {c for c in coverage.campaign_ids if campaign_allowed(binding, c, query)}
            if query.filters.campaign_ids:
                requested = {
                    c for c in query.filters.campaign_ids if campaign_allowed(binding, c, query)
                }
                if requested - expected:
                    reasons.append("incomplete_coverage")
            if {r.record.entity_id for r in rows} != expected:
                reasons.append("incomplete_coverage")
        counts: dict[str, int] = {}
        for row in rows:
            counts[row.record.entity_id] = counts.get(row.record.entity_id, 0) + 1
        if any(count != 1 for count in counts.values()):
            reasons.append("ambiguous_series")
        if not rows:
            reasons.append("missing_component")
        return CellState(rows, sorted(set(reasons)), snapshot)


def preceding_period(period: DateRange) -> DateRange:
    end = period.start - timedelta(days=1)
    return DateRange(start=end - (period.end - period.start), end=end)


def _scopes_overlap(left: MediaBinding, right: MediaBinding) -> bool:
    a, b = left.campaign_scope, right.campaign_scope
    if a.mode is CampaignScopeMode.INCLUDE:
        return any(
            c in b.campaign_ids
            if b.mode is CampaignScopeMode.INCLUDE
            else c not in b.campaign_ids
            if b.mode is CampaignScopeMode.EXCLUDE
            else True
            for c in a.campaign_ids
        )
    if b.mode is CampaignScopeMode.INCLUDE:
        return _scopes_overlap(right, left)
    return True


def _scope_covered(
    binding: MediaBinding,
    query: CanonicalQuery,
    coverage_mode: CampaignScopeMode,
    coverage_ids: set[str],
) -> bool:
    if coverage_mode is CampaignScopeMode.ALL:
        return True
    requested = (
        set(query.filters.campaign_ids)
        if query.filters.campaign_ids
        else set(binding.campaign_scope.campaign_ids)
        if binding.campaign_scope.mode is CampaignScopeMode.INCLUDE
        else None
    )
    if requested is not None:
        requested = {c for c in requested if campaign_allowed(binding, c, query)}
        return (
            requested <= coverage_ids
            if coverage_mode is CampaignScopeMode.INCLUDE
            else not requested & coverage_ids
        )
    return (
        coverage_mode is CampaignScopeMode.EXCLUDE
        and binding.campaign_scope.mode is CampaignScopeMode.EXCLUDE
        and coverage_ids <= set(binding.campaign_scope.campaign_ids)
    )
