"""Load operator-provided loopback certificates without modifying system trust."""

from __future__ import annotations

import ssl
from pathlib import Path


def load_callback_tls(certificate: Path, key_file: Path) -> ssl.SSLContext:
    """The browser must trust this certificate and its SAN must match the callback host.

    Neither certificate paths nor key contents belong in public connection contracts.
    No CA installation, insecure verification bypass or external tunnel is performed.
    """
    try:
        context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        context.minimum_version = ssl.TLSVersion.TLSv1_2
        # Supply a callback so encrypted keys fail safely rather than prompting in OpenSSL.
        context.load_cert_chain(certificate, key_file, password=lambda: "")
        return context
    except (OSError, ValueError, ssl.SSLError):
        raise ValueError(
            "Cannot load callback TLS certificate/key; check local PEM files."
        ) from None
