"""Versioned, closed read-only recipes. No caller-supplied endpoints or native query text."""

from __future__ import annotations

import json
from typing import cast

from pallas_ads.contracts.adapter import AdapterManifest, QueryMode
from pallas_ads.contracts.common import MediaPlatform
from pallas_ads.contracts.query import DateRange
from pallas_ads.contracts.source import SourceQueryPlan, SourceReadRequest
from pallas_ads.oauth_provider import API_VERSIONS, META_ROOT, TIKTOK_ROOT
from pallas_ads.query_planner import content_hash

SOURCE_REFERENCES = {
    "meta": [
        "https://developers.facebook.com/docs/marketing-api/insights/",
        "https://github.com/facebook/facebook-python-business-sdk/blob/main/facebook_business/adobjects/adaccount.py",
        "https://github.com/facebook/facebook-python-business-sdk/blob/main/facebook_business/apiconfig.py",
    ],
    "tiktok": [
        "https://business-api.tiktok.com/portal/docs?id=1740302848100353",
        "https://github.com/tiktok/tiktok-business-api-sdk/blob/main/python_sdk/business_api_client/api/reporting_api.py",
        "https://business-api.tiktok.com/portal/docs?id=1738373164380162",
    ],
    "google": [
        "https://developers.google.com/google-ads/api/rest/auth",
        "https://developers.google.com/google-ads/api/rest/common/search",
        "https://developers.google.com/google-ads/api/docs/release-notes",
    ],
}


def adapter_manifest(platform: MediaPlatform | str) -> AdapterManifest:
    platform = MediaPlatform(platform)
    fields = {
        "spend": "metrics.cost_micros" if platform == "google" else "spend",
        "impressions": "metrics.impressions" if platform == "google" else "impressions",
        "clicks": "metrics.clicks" if platform == "google" else "clicks",
    }
    return AdapterManifest.model_validate(
        {
            "manifest_id": f"adapter_{platform}_experimental",
            "platform": platform,
            "adapter_version": "0.1.0",
            "api_version": API_VERSIONS[platform],
            "capability": {
                "capability_id": f"cap_{platform}_experimental",
                "platform": platform,
                "adapter_version": "0.1.0",
                "api_version": API_VERSIONS[platform],
                "query_modes": [
                    m for m in QueryMode if platform == "google" or m != QueryMode.ACCOUNT_HIERARCHY
                ],
                "metrics": list(fields),
                "dimensions": ["channel", "campaign", "event_date"],
                "supports_pagination": True,
                "supports_empty_accounts": True,
            },
            "native_fields": [
                {"field_name": value, "value_type": "decimal", "nullable": True}
                for value in fields.values()
            ],
            "metric_mappings": [
                {
                    "canonical_metric": key,
                    "native_fields": [value],
                    "query_mode": "traffic_performance",
                    "semantic_version": "1.0.0",
                }
                for key, value in fields.items()
            ],
            # No invented maturity/lookback default. Conversion discovery isn't a canonical mapping.
            "official_source_references": SOURCE_REFERENCES[platform],
        }
    )


def plan_read(request: SourceReadRequest) -> SourceQueryPlan:
    request = SourceReadRequest.model_validate(request.model_dump(mode="json"))
    platform, mode, account = request.platform, request.mode, request.account_id
    parameters, body = {}, None
    required = []
    method = "GET"
    performance = mode in (QueryMode.TRAFFIC_PERFORMANCE, QueryMode.CONVERSION_PERFORMANCE)
    period = request.period
    if platform == "meta":
        parameters = {"limit": 100}
        if mode == QueryMode.CAPABILITY_PROBE:
            endpoint = META_ROOT + "/me/adaccounts"
            parameters["fields"] = "account_id,name,currency,timezone_name,account_status"
            required = ["account_id"]
        elif mode == QueryMode.ACCOUNT_CONTEXT:
            endpoint = META_ROOT + f"/act_{account}"
            parameters = {"fields": "account_id,name,currency,timezone_name,account_status"}
            required = ["account_id", "currency", "timezone_name"]
        elif mode == QueryMode.ENTITY_CONFIGURATION:
            endpoint = META_ROOT + f"/act_{account}/campaigns"
            parameters["fields"] = (
                "id,name,status,effective_status,objective,daily_budget,lifetime_budget,updated_time"
            )
            required = ["id", "objective", "status"]
        else:
            assert period is not None or request.query_lifetime
            endpoint = META_ROOT + f"/act_{account}/insights"
            fields = (
                "account_id,campaign_id,date_start,date_stop,"
                "account_currency,spend,impressions,clicks"
            )
            if mode == QueryMode.CONVERSION_PERFORMANCE:
                fields = "account_id,campaign_id,date_start,date_stop,actions,action_values"
            parameters.update(
                fields=fields,
                level="campaign",
                time_increment=1,
                **(
                    {"date_preset": "maximum"}
                    if request.query_lifetime
                    else {
                        "time_range": json.dumps(
                            {
                                "since": str(cast(DateRange, period).start),
                                "until": str(cast(DateRange, period).end),
                            }
                        )
                    }
                ),
            )
            if mode == QueryMode.CONVERSION_PERFORMANCE:
                parameters["action_report_time"] = "impression"
                parameters["use_unified_attribution_setting"] = "true"
            required = ["account_id", "campaign_id", "date_start"]
        if request.campaign_ids:
            parameters["filtering"] = json.dumps(
                [
                    {
                        "field": "campaign.id" if performance else "id",
                        "operator": "IN",
                        "value": request.campaign_ids,
                    }
                ]
            )
    elif platform == "tiktok":
        parameters = {"advertiser_id": account, "page": 1, "page_size": 100}
        if mode == QueryMode.CAPABILITY_PROBE:
            endpoint = TIKTOK_ROOT + "/oauth2/advertiser/get/"
            parameters = {}  # app_id/secret injected only in the private transport boundary.
            required = ["advertiser_id"]
        elif mode == QueryMode.ACCOUNT_CONTEXT:
            endpoint = TIKTOK_ROOT + "/advertiser/info/"
            parameters = {
                "advertiser_ids": json.dumps([account]),
                "fields": json.dumps(["advertiser_id", "name", "currency", "timezone", "status"]),
            }
            required = ["advertiser_id", "currency", "timezone"]
        elif mode == QueryMode.ENTITY_CONFIGURATION:
            endpoint = TIKTOK_ROOT + "/campaign/get/"
            parameters["fields"] = json.dumps(
                [
                    "campaign_id",
                    "campaign_name",
                    "objective_type",
                    "operation_status",
                    "budget",
                    "budget_mode",
                    "modify_time",
                ]
            )
            required = ["campaign_id", "objective_type"]
        else:
            assert period is not None or request.query_lifetime
            endpoint = TIKTOK_ROOT + "/report/integrated/get/"
            parameters.update(
                report_type="BASIC",
                data_level="AUCTION_CAMPAIGN",
                dimensions=json.dumps(["campaign_id", "stat_time_day"]),
                metrics=json.dumps(
                    ["spend", "impressions", "clicks"]
                    if mode == QueryMode.TRAFFIC_PERFORMANCE
                    else ["conversion", "total_purchase", "total_purchase_value"]
                ),
                **(
                    {"query_lifetime": True}
                    if request.query_lifetime
                    else {
                        "start_date": str(cast(DateRange, period).start),
                        "end_date": str(cast(DateRange, period).end),
                    }
                ),
            )
            required = ["dimensions.campaign_id", "dimensions.stat_time_day", "metrics"]
        if request.campaign_ids:
            parameters["filtering"] = json.dumps(
                [
                    {
                        "field_name": "campaign_ids",
                        "filter_type": "IN",
                        "filter_value": json.dumps(request.campaign_ids),
                    }
                ]
                if performance
                else {"campaign_ids": request.campaign_ids}
            )
    else:
        root = "https://googleads.googleapis.com/v25"
        if mode == QueryMode.CAPABILITY_PROBE:
            endpoint = root + "/customers:listAccessibleCustomers"
            required = ["resourceNames"]
        else:
            endpoint = root + f"/customers/{account}/googleAds:search"
            method = "POST"
            where = ""
            if mode == QueryMode.ACCOUNT_CONTEXT:
                selection = (
                    "customer.id, customer.descriptive_name, customer.currency_code, "
                    "customer.time_zone, customer.manager, customer.test_account"
                )
                resource, required = (
                    "customer",
                    ["customer.id", "customer.currencyCode", "customer.timeZone"],
                )
            elif mode == QueryMode.ACCOUNT_HIERARCHY:
                selection = (
                    "customer_client.id, customer_client.descriptive_name, "
                    "customer_client.currency_code, customer_client.time_zone, "
                    "customer_client.manager, customer_client.test_account, "
                    "customer_client.level, customer_client.status"
                )
                resource, required = (
                    "customer_client",
                    ["customerClient.id", "customerClient.manager"],
                )
                where = " WHERE customer_client.level <= 1"
            elif mode == QueryMode.ENTITY_CONFIGURATION:
                selection = (
                    "campaign.id, campaign.name, campaign.status, "
                    "campaign.advertising_channel_type, "
                    "campaign.advertising_channel_sub_type, "
                    "campaign.bidding_strategy_type, campaign_budget.amount_micros, "
                    "campaign_budget.period"
                )
                resource, required = (
                    "campaign",
                    ["campaign.id", "campaign.status", "campaign.advertisingChannelType"],
                )
            else:
                assert period is not None or request.query_lifetime
                resource = "campaign"
                selection = (
                    "campaign.id, segments.date, metrics.cost_micros, "
                    "metrics.impressions, metrics.clicks"
                )
                if mode == QueryMode.CONVERSION_PERFORMANCE:
                    selection = (
                        "campaign.id, segments.date, segments.conversion_action, "
                        "metrics.conversions, metrics.conversions_value"
                    )
                where = (
                    f" WHERE segments.date BETWEEN '{cast(DateRange, period).start}' "
                    f"AND '{cast(DateRange, period).end}'"
                )
                required = ["campaign.id", "segments.date", "metrics"]
            if request.campaign_ids:
                where += (
                    (" AND " if where else " WHERE ")
                    + "campaign.id IN ("
                    + ",".join(request.campaign_ids)
                    + ")"
                )
            body = {"query": f"SELECT {selection} FROM {resource}{where}"}
    if performance and platform in ("meta", "tiktok"):
        if platform == "tiktok":
            dimensions = (
                ["campaign_id"] if request.query_lifetime else ["campaign_id", "stat_time_day"]
            )
            if request.report_level == "adgroup":
                parameters["data_level"] = "AUCTION_ADGROUP"
                dimensions = ["adgroup_id", "stat_time_day"]
            if request.audience_dimension:
                parameters["report_type"] = "AUDIENCE"
                dimensions.append(
                    {"age": "age", "gender": "gender", "country": "country_code"}[
                        request.audience_dimension
                    ]
                )
            parameters["dimensions"] = json.dumps(dimensions)
            required = ["dimensions." + d for d in dimensions] + ["metrics"]
        else:
            if request.report_level == "adgroup":
                parameters["level"] = "adset"
                parameters["fields"] = str(parameters["fields"]) + ",adset_id"
                required.append("adset_id")
            if request.audience_dimension:
                parameters["breakdowns"] = request.audience_dimension
                required.append(request.audience_dimension)
    if performance and platform == "google" and request.audience_dimension:
        resource, field = {
            "age": ("age_range_view", "ad_group_criterion.age_range.type"),
            "gender": ("gender_view", "ad_group_criterion.gender.type"),
            "country": ("user_location_view", "user_location_view.country_criterion_id"),
        }[request.audience_dimension]
        assert period is not None
        body = {
            "query": (
                f"SELECT campaign.id, segments.date, {field}, metrics.cost_micros, "
                f"metrics.impressions, metrics.clicks FROM {resource} "
                f"WHERE segments.date BETWEEN '{period.start}' AND '{period.end}'"
            )
        }
    if request.context_kind:
        from pallas_ads.context_plans import context_recipe

        endpoint, parameters, body, required = context_recipe(request, endpoint)
    values = {
        "request": request,
        "api_version": API_VERSIONS[platform],
        "method": method,
        "endpoint": endpoint,
        "parameters": parameters,
        "body": body,
        "required_fields": required,
    }
    plan = SourceQueryPlan.model_validate({"plan_id": "native_plan_" + "0" * 64, **values})
    plan.plan_id = (
        "native_plan_" + content_hash(plan.model_dump(mode="json", exclude={"plan_id"}))[7:]
    )
    return plan
