"""CLI commands for the shared runtime. Arguments contain paths, never credential values."""

from __future__ import annotations

import json
import time
from pathlib import Path
from typing import Annotated

import typer

from pallas_ads.callback_tls import load_callback_tls
from pallas_ads.config import Settings
from pallas_ads.local_state import WorkspaceRepository
from pallas_ads.mcp_server import MAX_MESSAGE_BYTES, catalog, serve
from pallas_ads.operations import Runtime, needs

WorkspaceOption = Annotated[Path | None, typer.Option("--workspace", help="Local workspace root.")]
InputOption = Annotated[
    Path | None, typer.Option("--input", help="Typed request JSON file; otherwise stdin.")
]


def root(path):
    return path if path is not None else Settings.from_environment().data_dir


def emit(response):
    typer.echo(response.model_dump_json())


def execute(operation, workspace, input_path):
    runtime = Runtime(root(workspace))
    try:
        if input_path is None:
            import sys

            raw = sys.stdin.buffer.read(MAX_MESSAGE_BYTES + 1)
        else:
            with input_path.open("rb") as handle:
                raw = handle.read(MAX_MESSAGE_BYTES + 1)
        if len(raw) > MAX_MESSAGE_BYTES:
            raise ValueError
        arguments = json.loads(raw)
        # Short-lived commands cannot keep callback sessions alive. Use source connect or MCP.
        if (
            operation == "source_connect_or_import"
            and arguments.get("action") == "connect"
            and not (arguments.get("platform") == "meta" and arguments.get("config") is None)
        ):
            response = needs(
                operation,
                (
                    "Use pallas source connect --input FILE or the persistent "
                    "MCP server for browser authorization."
                ),
            )
        else:
            response = runtime.invoke(operation, arguments)
    except (ValueError, OSError, AttributeError, RecursionError):
        response = needs(operation, "Provide a valid bounded JSON request file or stdin.")
    finally:
        runtime.close()
    emit(response)
    raise typer.Exit(
        {"complete": 0, "partial_result": 2, "pending_user_action": 3}.get(response.status, 1)
    )


def register(app):
    @app.command("demo")
    def demo(output_dir: Annotated[Path, typer.Option("--output-dir")]):
        """Run a bundled synthetic profile/import/compare/monitor/report loop offline."""
        from pallas_ads.demo import run_demo

        try:
            typer.echo(json.dumps(run_demo(output_dir), ensure_ascii=False))
        except (ValueError, OSError):
            typer.echo("Demo needs a new or empty writable directory.", err=True)
            raise typer.Exit(1) from None

    providers = typer.Typer(help="Operator-only provider configuration.")
    app.add_typer(providers, name="providers")

    @providers.command("configure")
    def configure_providers(
        input_path: Annotated[Path, typer.Option("--input")], workspace: WorkspaceOption = None
    ):
        from pallas_ads.provider_setup import install_setup

        try:
            repository = WorkspaceRepository(root(workspace))
            repository.load_manifest()
            destination = install_setup(repository, input_path)
            typer.echo(json.dumps({"status": "complete", "path": str(destination)}))
        except (ValueError, OSError):
            typer.echo(
                "Invalid or existing operator setup. Use credential references only.", err=True
            )
            raise typer.Exit(1) from None

    @providers.command("google-desktop")
    def configure_google_desktop(
        input_path: Annotated[Path, typer.Option("--input")],
        workspace: WorkspaceOption = None,
        user_default: bool = False,
    ):
        """Operator: import Desktop OAuth once; users only authorize and select accounts."""
        from pallas_ads.provider_setup import import_google_desktop, user_setup_path

        if user_default and workspace is not None:
            typer.echo("Choose --user-default or --workspace, not both.", err=True)
            raise typer.Exit(1)
        try:
            if user_default:
                destination = user_setup_path()
            else:
                repository = WorkspaceRepository(root(workspace))
                repository.load_manifest()
                destination = repository.layout.root / "settings/providers.json"
            import_google_desktop(input_path, destination)
            typer.echo(json.dumps({"status": "complete", "platform": "google"}))
        except Exception:
            typer.echo(
                "Google setup unavailable. Operator: check Desktop client file, "
                "existing configuration and OS keychain. No credentials are shown.",
                err=True,
            )
            raise typer.Exit(1) from None

    workspace_app = typer.Typer(help="Initialize local state.")
    app.add_typer(workspace_app, name="workspace")

    @workspace_app.command("init")
    def initialize(workspace: WorkspaceOption = None, workspace_id: str = "workspace_local"):
        repository = WorkspaceRepository(root(workspace))
        try:
            if repository.layout.workspace_file.exists() and workspace_id == "workspace_local":
                workspace_id = repository.load_manifest().workspace_id
            response = repository.bootstrap(workspace_id)
        except (ValueError, OSError):
            response = needs(
                "workspace_bootstrap", "Invalid workspace identity or unavailable local path."
            )
        emit(response)
        if response.status != "complete":
            raise typer.Exit(1)

    @app.command("call")
    def call(operation: str, workspace: WorkspaceOption = None, input_path: InputOption = None):
        """Invoke a catalog operation with typed JSON from stdin or a local file."""
        execute(operation, workspace, input_path)

    @app.command("operations")
    def operations():
        """Print the closed tool catalog and complete input schemas."""
        typer.echo(json.dumps({"tools": catalog()}, ensure_ascii=False))

    for group_name, commands in {
        "profile": {"update": "profile_create_or_update", "context": "profile_get_context"},
        "source": {"manage": "source_connect_or_import", "status": "source_status"},
        "monitor": {"run": "run_monitors"},
        "report": {"build": "build_report"},
    }.items():
        group = typer.Typer(help=f"{group_name.title()} operations using typed request JSON.")
        app.add_typer(group, name=group_name)
        for command_name, operation in commands.items():
            group.command(command_name)(_command(operation))
        if group_name == "source":
            group.command("connect")(connect)
    app.command("compare")(_command("compare_acquisition"))
    app.command("sync")(_command("sync_media_data"))
    mcp = typer.Typer(help="Local MCP stdio server.")
    app.add_typer(mcp, name="mcp")
    mcp.command("serve")(mcp_serve)


def _command(operation):
    def command(workspace: WorkspaceOption = None, input_path: InputOption = None):
        execute(operation, workspace, input_path)

    return command


def tls_context(certificate, tls_key):
    if (certificate is None) != (tls_key is None):
        raise ValueError
    return load_callback_tls(certificate, tls_key) if certificate else None


def mcp_serve(
    workspace: WorkspaceOption = None, certificate: Path | None = None, tls_key: Path | None = None
):
    """Serve JSON-RPC on stdio; keep OAuth sessions alive until the client exits."""
    try:
        context = tls_context(certificate, tls_key)
    except ValueError:
        typer.echo("Cannot load local callback TLS configuration.", err=True)
        raise typer.Exit(1) from None
    serve(Runtime(root(workspace), callback_tls=context))


def connect(
    input_path: Annotated[Path, typer.Option("--input")],
    workspace: WorkspaceOption = None,
    certificate: Path | None = None,
    tls_key: Path | None = None,
):
    """Start browser authorization and remain alive for its callback; Ctrl-C cancels."""
    runtime = None
    try:
        context = tls_context(certificate, tls_key)
        runtime = Runtime(root(workspace), callback_tls=context)
        with input_path.open("rb") as handle:
            raw = handle.read(MAX_MESSAGE_BYTES + 1)
        if len(raw) > MAX_MESSAGE_BYTES:
            raise ValueError
        request = json.loads(raw)
        if request.get("action") != "connect":
            raise ValueError
        response = runtime.invoke("source_connect_or_import", request)
        emit(response)
        if (
            isinstance(response.result, dict)
            and response.result.get("authorization_owner") == "host_client"
        ):
            raise typer.Exit(3)
        while response.status == "pending_user_action":
            time.sleep(0.25)
            response = runtime.auth.status(response.result.session_id)
        if response.operation == "source_auth_status":
            emit(response)
        if response.result is None or getattr(response.result, "state", None) != "connected":
            raise typer.Exit(1)
    except (ValueError, OSError, AttributeError, RecursionError):
        emit(needs("source_connect_or_import", "Invalid local authorization configuration."))
        raise typer.Exit(1) from None
    except KeyboardInterrupt:
        typer.echo("Authorization cancelled.", err=True)
        raise typer.Exit(130) from None
    finally:
        if runtime:
            runtime.close()
