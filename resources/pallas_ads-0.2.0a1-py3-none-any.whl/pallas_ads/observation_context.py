"""Resolve product and optimization evidence without interpreting campaign names."""

import re
from urllib.parse import parse_qs, urlsplit

from pallas_ads.adapter_service import _get


def store_identity(value):
    if not isinstance(value, str):
        return None
    try:
        parsed = urlsplit(value)
    except ValueError:
        return None
    if parsed.scheme != "https" or parsed.username or parsed.password:
        return None
    if parsed.hostname == "play.google.com" and parsed.path == "/store/apps/details":
        return parse_qs(parsed.query).get("id", [None])[0]
    if parsed.hostname == "apps.apple.com":
        match = re.search(r"/id([0-9]+)(?:/|$)", parsed.path)
        return match[1] if match else None
    return None


def resolve_context(workspace, connection, reads):
    platform = connection.config.platform
    account = connection.selected_account_id or connection.config.mcp_advertiser_id
    profiles = []
    for identifier in workspace.load_manifest().profile_ids:
        revision = workspace.latest_profile_revision(identifier)
        if revision:
            profiles.append(revision.profile)
    configurations, goals, creatives, google_aux, apps = [], [], [], [], []
    for read in reads:
        if read.plan.request.mode != "entity_configuration":
            continue
        kind = read.plan.request.context_kind
        for i, row in enumerate(read.records):
            metadata = row.metadata
            entry = {
                "entity_id": row.entity_id,
                "source_ref": f"adapter-read://{read.read_id}/records/{i}",
                "observed_at": read.observed_at.isoformat(),
                "complete_read": read.pagination_complete,
                "campaign_id": str(
                    _get(metadata, "campaign.id")
                    or metadata.get("campaign_id")
                    or (row.entity_id if kind is None else "")
                ),
                "native": metadata,
            }
            if kind == "optimization":
                if platform == "google":
                    goal, event = (
                        None,
                        _get(metadata, "campaign.selectiveOptimization.conversionActions"),
                    )
                    bid = _get(metadata, "campaign.biddingStrategyType")
                else:
                    goal = metadata.get("optimization_goal")
                    event = (
                        metadata.get("optimization_event")
                        if platform == "tiktok"
                        else _get(metadata, "promoted_object.custom_event_type")
                    )
                    bid = metadata.get("bid_type", metadata.get("bid_strategy"))
                evaluation = {
                    "CLICK": "CPC / CTR",
                    "LINK_CLICKS": "CPC / destination-click semantics",
                    "REACH": "reach / frequency / CPM",
                    "IMPRESSION": "CPM",
                    "IMPRESSIONS": "CPM",
                    "INSTALL": "verified installs / CPI",
                    "APP_INSTALLS": "verified installs / CPI",
                    "CONVERT": "verified optimization-event volume / CPA",
                    "OFFSITE_CONVERSIONS": "verified optimization-event volume / CPA",
                    "VALUE": "verified attributed value / ROAS",
                    "LANDING_PAGE_VIEWS": "landing-page views / cost per view",
                }.get(goal, "verify goal/event mapping before outcome evaluation")
                goals.append(
                    {
                        **entry,
                        "optimization_goal": goal,
                        "optimization_event": event,
                        "bid_strategy": bid,
                        "evaluation_metrics": evaluation,
                        "effective_period": None,
                        "historical_goal_verified": False,
                        "targeting": {
                            k: metadata[k]
                            for k in (
                                "age_groups",
                                "gender",
                                "location_ids",
                                "operating_systems",
                                "interest_category_ids",
                                "targeting",
                            )
                            if metadata.get(k) is not None
                        },
                        "status": "current_snapshot" if goal or bid else "unresolved",
                    }
                )
            elif kind == "apps":
                apps.append(entry)
            elif kind == "creative":
                creatives.append(entry)
            elif kind and kind.startswith("google_"):
                google_aux.append({**entry, "resource": kind})
            else:
                configurations.append(entry)
    if platform == "google":
        resolve_google_events(goals, google_aux)
    products = []
    for campaign in configurations:
        identifier = campaign["campaign_id"]
        matched, identities = [], set()
        related = [e for e in creatives if e["campaign_id"] == identifier]
        for e in related:
            m = e["native"]
            urls = [m.get("landing_page_url")]
            urls += _get(m, "adGroupAd.ad.finalUrls") or []
            link = _get(m, "creative.object_story_spec.link_data.link")
            urls.append(link)
            identities.update(x for u in urls if (x := store_identity(u)))
        related_goals = [g for g in goals if g["campaign_id"] == identifier]
        app_ids = {g["native"].get("app_id") for g in related_goals}
        app_evidence = [
            a for a in apps if a["native"].get("app_id") in app_ids and a["complete_read"]
        ]
        for app in app_evidence:
            identity = store_identity(app["native"].get("download_url"))
            if identity:
                identities.add(identity)
        for profile in profiles:
            bindings = [
                b
                for b in profile.media_bindings
                if b.platform == platform
                and b.account_id == account
                and (
                    b.campaign_scope.mode == "all"
                    or b.campaign_scope.mode == "include"
                    and identifier in b.campaign_scope.campaign_ids
                    or b.campaign_scope.mode == "exclude"
                    and identifier not in b.campaign_scope.campaign_ids
                )
            ]
            if bindings:
                stores = {
                    v.store_identifier
                    for v in profile.app_variants
                    if any(v.app_variant_id in b.app_variant_ids for b in bindings)
                }
                if not identities or identities <= stores:
                    matched.append(
                        {
                            "product_id": profile.profile_id,
                            "product_name": profile.product_name,
                            "monetization_model": profile.monetization_model,
                            "business_kpi": profile.kpi.model_dump(mode="json"),
                            "evidence": "api_store_identity_and_confirmed_binding"
                            if identities
                            else "user_confirmed_binding_only",
                        }
                    )
        status = (
            "resolved"
            if len(matched) == 1
            else "conflict"
            if len(matched) > 1 or identities
            else "unresolved"
        )
        if not matched and identities and not profiles:
            status = "identified_unbound"
        products.append(
            {
                "campaign_id": identifier,
                "status": status,
                "matches": matched,
                "store_identities": sorted(identities),
                "source_refs": [campaign["source_ref"]]
                + [e["source_ref"] for e in related + app_evidence],
                "api_app_evidence": app_evidence,
                "campaign_name_used_for_identity": False,
            }
        )
    return {
        "campaign_configuration": configurations,
        "optimization_context": goals,
        "google_goal_evidence": google_aux,
        "creative_context": creatives,
        "app_directory": apps,
        "product_resolution": products,
        "rules": [
            "current_configuration_is_not_historical_configuration",
            "targeting_is_not_delivered_audience",
            "native_app_id_is_not_automatically_store_id",
            "conversion_action_directory_is_not_selected_bidding_events",
        ],
    }


def resolve_google_events(goals, auxiliary):
    """Effective current event selection, keeping custom-goal and app overrides explicit."""
    actions = {
        e["native"]["conversionAction"]["resourceName"]: e
        for e in auxiliary
        if e["resource"] == "google_actions" and _get(e["native"], "conversionAction.resourceName")
    }
    configs = {e["campaign_id"]: e for e in auxiliary if e["resource"] == "google_goal_config"}
    customs = {
        e["native"]["customConversionGoal"]["resourceName"]: e
        for e in auxiliary
        if e["resource"] == "google_custom_goals"
        and _get(e["native"], "customConversionGoal.resourceName")
    }
    for goal in goals:
        campaign = goal["campaign_id"]
        config = configs.get(campaign)
        selected, refs, selection = None, [], "unresolved"
        override = goal["optimization_event"]
        custom = (
            _get(config["native"], "conversionGoalCampaignConfig.customConversionGoal")
            if config
            else None
        )
        if override:
            selected, selection = override, "app_selective_optimization"
        elif custom:
            e = customs.get(custom)
            if (
                e
                and e["complete_read"]
                and _get(e["native"], "customConversionGoal.status") == "ENABLED"
            ):
                selected = _get(e["native"], "customConversionGoal.conversionActions")
                refs.append(e["source_ref"])
                selection = "custom_goal_includes_secondary_actions"
        elif config and config["complete_read"]:
            categories = [
                e
                for e in auxiliary
                if e["resource"] == "google_goals"
                and e["campaign_id"] == campaign
                and e["complete_read"]
                and _get(e["native"], "campaignConversionGoal.biddable") is True
            ]
            if categories:
                selected = []
                selection = "effective_campaign_goals_and_primary_actions"
                refs.extend(e["source_ref"] for e in categories)
                for name, e in actions.items():
                    a = e["native"]["conversionAction"]
                    if (
                        e["complete_read"]
                        and a.get("status") == "ENABLED"
                        and a.get("primaryForGoal") is True
                        and any(
                            a.get("category")
                            == _get(g["native"], "campaignConversionGoal.category")
                            and a.get("origin")
                            == _get(g["native"], "campaignConversionGoal.origin")
                            for g in categories
                        )
                    ):
                        selected.append(name)
        events = []
        for identifier in selected or []:
            e = actions.get(identifier)
            events.append(
                {
                    "resource_name": identifier,
                    "metadata": e["native"]["conversionAction"] if e else None,
                    "source_ref": e["source_ref"] if e else None,
                }
            )
        goal.update(
            optimization_event=events,
            event_selection=selection,
            event_selection_source_refs=refs + ([config["source_ref"]] if config else []),
        )
        bid = goal["bid_strategy"]
        if bid in ("MAXIMIZE_CONVERSIONS", "TARGET_CPA"):
            goal["optimization_goal"] = "CONVERSIONS"
            goal["evaluation_metrics"] = "Selected-event volume / CPA; retain event separation"
        elif bid in ("MAXIMIZE_CONVERSION_VALUE", "TARGET_ROAS"):
            goal["optimization_goal"] = "CONVERSION_VALUE"
            goal["evaluation_metrics"] = (
                "Selected-event attributed value / ROAS; verify revenue semantics"
            )
        elif bid in ("TARGET_SPEND", "MANUAL_CPC"):
            goal["optimization_goal"] = "CLICKS_OR_MANUAL_BID"
            goal["evaluation_metrics"] = (
                "CPC / CTR; manual bidding is not an explicit business outcome"
            )
        goal["event_mapping_complete"] = bool(events) and all(
            e["metadata"] is not None for e in events
        )
