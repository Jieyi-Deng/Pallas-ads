"""Credential values stay in memory or explicitly selected OS/environment providers."""

from __future__ import annotations

import json
import os
import sys
from typing import Protocol

from pydantic import AwareDatetime, BaseModel, ConfigDict, SecretStr

from pallas_ads.contracts.credentials import CredentialProvider, CredentialRef


class CredentialError(ValueError):
    pass


class TokenBundle(BaseModel):
    """Private memory/keychain payload. Never use in public envelopes or files."""

    model_config = ConfigDict(extra="ignore", hide_input_in_errors=True)
    access_token: SecretStr
    refresh_token: SecretStr | None = None
    expires_in: int | None = None
    refresh_expires_at: AwareDatetime | None = None

    def __repr__(self) -> str:
        return "TokenBundle(<redacted>)"

    def keychain_payload(self) -> str:
        return json.dumps(
            {
                "access_token": self.access_token.get_secret_value(),
                "refresh_token": self.refresh_token.get_secret_value()
                if self.refresh_token
                else None,
                "expires_in": self.expires_in,
                "refresh_expires_at": self.refresh_expires_at.isoformat()
                if self.refresh_expires_at
                else None,
            }
        )


class SecretBackend(Protocol):
    def get_password(self, service: str, username: str) -> str | None: ...
    def set_password(self, service: str, username: str, password: str) -> None: ...
    def delete_password(self, service: str, username: str) -> None: ...


class CredentialStore:
    def __init__(self, *, backend: SecretBackend | None = None) -> None:
        self._backend = backend

    def _secure_backend(self) -> SecretBackend:
        if self._backend is not None:
            return self._backend
        # Select an OS backend explicitly; never accept keyrings.alt plaintext or config plugins.
        try:
            if sys.platform == "darwin":
                from keyring.backends.macOS import Keyring
            elif sys.platform.startswith("linux"):
                from keyring.backends.SecretService import Keyring
            else:
                raise CredentialError("OS keychain unavailable; use an environment reference")
            backend = Keyring()
            if backend.priority <= 0:
                raise CredentialError("OS keychain unavailable")
            self._backend = backend
            return backend
        except Exception:
            raise CredentialError("OS keychain unavailable; use an environment reference") from None

    def read(self, ref: CredentialRef) -> str:
        try:
            value = (
                os.environ.get(ref.locator)
                if ref.provider == CredentialProvider.ENVIRONMENT
                else self._secure_backend().get_password("pallas-ads", ref.locator)
            )
            if not value or len(value) > 65536 or "\r" in value or "\n" in value:
                raise CredentialError("credential unavailable or invalid")
            return value
        except Exception:
            raise CredentialError("credential unavailable or invalid") from None

    def tokens(self, ref: CredentialRef) -> TokenBundle:
        value = self.read(ref)
        try:
            bundle = (
                TokenBundle.model_validate_json(value)
                if value.startswith("{")
                else TokenBundle(access_token=SecretStr(value))
            )
            for secret in (bundle.access_token, bundle.refresh_token):
                if secret is not None:
                    text = secret.get_secret_value()
                    if (
                        not text
                        or len(text) > 32768
                        or any(ord(c) < 32 or ord(c) == 127 for c in text)
                    ):
                        raise ValueError
            return bundle
        except Exception:
            raise CredentialError("credential payload invalid") from None

    def write(self, ref: CredentialRef, bundle: TokenBundle) -> None:
        if ref.provider != CredentialProvider.OS_KEYCHAIN:
            raise CredentialError("environment credentials are read-only")
        try:
            self._secure_backend().set_password(
                "pallas-ads", ref.locator, bundle.keychain_payload()
            )
        except Exception:
            raise CredentialError("could not save OS credential") from None

    def delete(self, ref: CredentialRef) -> None:
        if ref.provider != CredentialProvider.OS_KEYCHAIN:
            raise CredentialError("environment credentials are user-managed")
        try:
            self._secure_backend().delete_password("pallas-ads", ref.locator)
        except Exception:
            raise CredentialError("could not remove OS credential") from None
