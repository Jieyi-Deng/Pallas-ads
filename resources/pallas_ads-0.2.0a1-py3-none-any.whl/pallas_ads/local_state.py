"""DuckDB-backed local workspace state for profiles and credential references."""

from __future__ import annotations

import json
import tempfile
from datetime import UTC, datetime
from enum import StrEnum
from pathlib import Path
from typing import Self

import duckdb
import yaml
from pydantic import AwareDatetime, BaseModel, Field, model_validator

from pallas_ads.contracts.base import VersionedContract
from pallas_ads.contracts.credentials import CredentialRef
from pallas_ads.contracts.profile import ProfileDraftValues, ProfileRevision
from pallas_ads.contracts.status import MissingInput, OperationEnvelope, OperationStatus
from pallas_ads.contracts.workspace import WorkspaceManifest, WorkspaceState
from pallas_ads.workspace import WorkspaceLayout

LOCAL_SCHEMA_VERSION = 3

_SCHEMA_MIGRATIONS = (
    (1, "week2_profile_local_state"),
    (2, "week3_canonical_import_metrics"),
    (3, "week5_monitoring"),
)

_SCHEMA_STATEMENTS = (
    """
    CREATE TABLE IF NOT EXISTS schema_migrations (
        version INTEGER PRIMARY KEY,
        name VARCHAR NOT NULL,
        applied_at TIMESTAMPTZ NOT NULL
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS workspace_metadata (
        workspace_id VARCHAR PRIMARY KEY,
        schema_version VARCHAR NOT NULL,
        created_at TIMESTAMPTZ NOT NULL
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS profile_pending_changes (
        draft_id VARCHAR PRIMARY KEY,
        profile_id VARCHAR NOT NULL,
        base_revision INTEGER NOT NULL,
        content_hash VARCHAR NOT NULL,
        change_kind VARCHAR NOT NULL,
        state VARCHAR NOT NULL,
        values_json VARCHAR NOT NULL,
        confirmation_summary VARCHAR,
        created_at TIMESTAMPTZ NOT NULL,
        confirmed_revision INTEGER
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS profile_revisions (
        profile_id VARCHAR NOT NULL,
        revision INTEGER NOT NULL,
        schema_version VARCHAR NOT NULL,
        profile_hash VARCHAR NOT NULL,
        confirmed_draft_id VARCHAR NOT NULL UNIQUE,
        confirmed_content_hash VARCHAR NOT NULL,
        confirmed_at TIMESTAMPTZ NOT NULL,
        profile_json VARCHAR NOT NULL,
        PRIMARY KEY (profile_id, revision)
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS credential_refs (
        credential_id VARCHAR PRIMARY KEY,
        schema_version VARCHAR NOT NULL,
        provider VARCHAR NOT NULL,
        locator VARCHAR NOT NULL,
        platform VARCHAR,
        label VARCHAR,
        created_at TIMESTAMPTZ NOT NULL
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS data_revisions (
        data_revision BIGINT PRIMARY KEY,
        source_snapshot_id VARCHAR NOT NULL UNIQUE,
        created_at TIMESTAMPTZ NOT NULL
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS source_snapshots (
        source_snapshot_id VARCHAR PRIMARY KEY,
        package_id VARCHAR NOT NULL UNIQUE,
        data_revision BIGINT NOT NULL UNIQUE,
        product_id VARCHAR NOT NULL,
        platform VARCHAR NOT NULL,
        account_id VARCHAR NOT NULL,
        observed_at TIMESTAMPTZ NOT NULL,
        content_hash VARCHAR NOT NULL,
        snapshot_json VARCHAR NOT NULL,
        manifest_json VARCHAR NOT NULL
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS entity_snapshots (
        entity_snapshot_id VARCHAR PRIMARY KEY,
        entity_key VARCHAR NOT NULL,
        revision INTEGER NOT NULL,
        data_revision BIGINT NOT NULL,
        source_snapshot_id VARCHAR NOT NULL,
        product_id VARCHAR NOT NULL,
        platform VARCHAR NOT NULL,
        account_id VARCHAR NOT NULL,
        entity_type VARCHAR NOT NULL,
        entity_id VARCHAR NOT NULL,
        observed_at TIMESTAMPTZ NOT NULL,
        payload_hash VARCHAR NOT NULL,
        snapshot_json VARCHAR NOT NULL,
        UNIQUE (entity_key, revision)
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS observation_revisions (
        observation_id VARCHAR PRIMARY KEY,
        observation_key VARCHAR NOT NULL,
        revision INTEGER NOT NULL,
        data_revision BIGINT NOT NULL,
        source_snapshot_id VARCHAR NOT NULL,
        product_id VARCHAR NOT NULL,
        platform VARCHAR NOT NULL,
        account_id VARCHAR NOT NULL,
        entity_type VARCHAR NOT NULL,
        entity_id VARCHAR NOT NULL,
        event_date DATE NOT NULL,
        metric_key VARCHAR NOT NULL,
        metric_semantic_version VARCHAR NOT NULL,
        maturity_status VARCHAR NOT NULL,
        observed_at TIMESTAMPTZ NOT NULL,
        payload_hash VARCHAR NOT NULL,
        observation_json VARCHAR NOT NULL,
        UNIQUE (observation_key, revision)
    )
    """,
    """
    CREATE OR REPLACE VIEW current_entity_snapshots AS
    SELECT * EXCLUDE (current_rank)
    FROM (
        SELECT *, row_number() OVER (
            PARTITION BY entity_key ORDER BY revision DESC, data_revision DESC
        ) AS current_rank
        FROM entity_snapshots
    )
    WHERE current_rank = 1
    """,
    """
    CREATE OR REPLACE VIEW current_observations AS
    SELECT * EXCLUDE (current_rank)
    FROM (
        SELECT *, row_number() OVER (
            PARTITION BY observation_key ORDER BY revision DESC, data_revision DESC
        ) AS current_rank
        FROM observation_revisions
    )
    WHERE current_rank = 1
    """,
)


class ProfileChangeKind(StrEnum):
    CREATE = "create"
    PATCH = "patch"


class PendingChangeState(StrEnum):
    INCOMPLETE = "incomplete"
    READY = "ready"
    CONFIRMED = "confirmed"


class PendingProfileChange(VersionedContract):
    draft_id: str = Field(pattern=r"^draft_[a-z0-9][a-z0-9_-]*$")
    profile_id: str = Field(pattern=r"^prod_[a-z0-9][a-z0-9_-]*$")
    base_revision: int = Field(ge=0)
    content_hash: str = Field(pattern=r"^sha256:[a-f0-9]{64}$")
    change_kind: ProfileChangeKind
    state: PendingChangeState
    values: ProfileDraftValues
    confirmation_summary: str | None = Field(default=None, min_length=1)
    created_at: AwareDatetime
    confirmed_revision: int | None = Field(default=None, ge=1)

    @model_validator(mode="after")
    def validate_state(self) -> Self:
        if self.state is PendingChangeState.INCOMPLETE:
            if self.confirmation_summary is not None or self.confirmed_revision is not None:
                raise ValueError("incomplete profile changes cannot contain confirmation data")
        elif self.state is PendingChangeState.READY:
            if self.confirmation_summary is None:
                raise ValueError("ready profile changes require a confirmation summary")
            if self.confirmed_revision is not None:
                raise ValueError("ready profile changes cannot contain a confirmed revision")
        elif self.confirmation_summary is None or self.confirmed_revision is None:
            raise ValueError("confirmed profile changes require a summary and revision")
        return self


class LocalStateError(RuntimeError):
    """Raised when persisted local state violates an invariant."""


def _canonical_json(value: BaseModel) -> str:
    return json.dumps(
        value.model_dump(mode="json"),
        ensure_ascii=False,
        separators=(",", ":"),
        sort_keys=True,
    )


def _utc_from_epoch_us(value: int) -> datetime:
    return datetime.fromtimestamp(value / 1_000_000, tz=UTC)


def _atomic_write_yaml(path: Path, payload: dict[str, object]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary_path: Path | None = None
    try:
        with tempfile.NamedTemporaryFile(
            mode="w",
            encoding="utf-8",
            dir=path.parent,
            prefix=f".{path.name}.",
            suffix=".tmp",
            delete=False,
        ) as handle:
            yaml.safe_dump(
                payload,
                handle,
                allow_unicode=True,
                default_flow_style=False,
                sort_keys=False,
            )
            temporary_path = Path(handle.name)
        temporary_path.replace(path)
    finally:
        if temporary_path is not None and temporary_path.exists():
            temporary_path.unlink()


class WorkspaceRepository:
    """Persistence boundary for one local Pallas workspace."""

    def __init__(self, root: Path) -> None:
        self.layout = WorkspaceLayout(root.expanduser().resolve())

    def bootstrap(
        self,
        workspace_id: str,
        *,
        created_at: datetime | None = None,
    ) -> OperationEnvelope[WorkspaceState]:
        now = created_at or datetime.now(UTC)
        created_now = not self.layout.workspace_file.exists()
        for directory in (
            self.layout.root,
            self.layout.profiles_dir,
            self.layout.source_manifests_dir,
            self.layout.adapter_manifests_dir,
            self.layout.database_file.parent,
            self.layout.raw_data_dir,
            self.layout.reports_dir,
            self.layout.logs_dir,
        ):
            directory.mkdir(parents=True, exist_ok=True)

        if created_now:
            manifest = WorkspaceManifest(workspace_id=workspace_id, created_at=now)
            self._write_manifest(manifest)
        else:
            manifest = self.load_manifest()
            if manifest.workspace_id != workspace_id:
                return OperationEnvelope[WorkspaceState](
                    operation="workspace_bootstrap",
                    status=OperationStatus.NEEDS_INPUT,
                    missing_inputs=[
                        MissingInput(
                            field_path="/workspace_id",
                            reason=(
                                f"workspace already belongs to {manifest.workspace_id}; "
                                "use the existing ID"
                            ),
                            expected_type="existing workspace ID",
                        )
                    ],
                )

        self._initialize_database(manifest)
        return OperationEnvelope[WorkspaceState](
            operation="workspace_bootstrap",
            status=OperationStatus.COMPLETE,
            result=WorkspaceState(
                workspace_id=manifest.workspace_id,
                root=str(self.layout.root),
                database_file=str(self.layout.database_file),
                initialized_at=manifest.created_at,
                created_now=created_now,
            ),
        )

    def load_manifest(self) -> WorkspaceManifest:
        payload = yaml.safe_load(self.layout.workspace_file.read_text(encoding="utf-8"))
        if not isinstance(payload, dict):
            raise LocalStateError("workspace manifest must contain a mapping")
        return WorkspaceManifest.model_validate(payload)

    def save_pending_change(self, change: PendingProfileChange) -> None:
        existing = self.get_pending_change(change.draft_id)
        if existing is not None and existing != change:
            raise LocalStateError(
                f"draft ID already exists with different content: {change.draft_id}"
            )
        with duckdb.connect(str(self.layout.database_file)) as connection:
            connection.execute(
                """
                INSERT OR IGNORE INTO profile_pending_changes VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                [
                    change.draft_id,
                    change.profile_id,
                    change.base_revision,
                    change.content_hash,
                    change.change_kind.value,
                    change.state.value,
                    _canonical_json(change.values),
                    change.confirmation_summary,
                    change.created_at,
                    change.confirmed_revision,
                ],
            )

    def get_pending_change(self, draft_id: str) -> PendingProfileChange | None:
        with duckdb.connect(str(self.layout.database_file), read_only=True) as connection:
            row = connection.execute(
                """
                SELECT profile_id, base_revision, content_hash, change_kind, state, values_json,
                       confirmation_summary, epoch_us(created_at), confirmed_revision
                FROM profile_pending_changes WHERE draft_id = ?
                """,
                [draft_id],
            ).fetchone()
        if row is None:
            return None
        return PendingProfileChange(
            draft_id=draft_id,
            profile_id=row[0],
            base_revision=row[1],
            content_hash=row[2],
            change_kind=row[3],
            state=row[4],
            values=ProfileDraftValues.model_validate_json(row[5]),
            confirmation_summary=row[6],
            created_at=_utc_from_epoch_us(row[7]),
            confirmed_revision=row[8],
        )

    def latest_profile_revision(self, profile_id: str) -> ProfileRevision | None:
        with duckdb.connect(str(self.layout.database_file), read_only=True) as connection:
            row = connection.execute(
                """
                SELECT profile_json FROM profile_revisions
                WHERE profile_id = ? ORDER BY revision DESC LIMIT 1
                """,
                [profile_id],
            ).fetchone()
        if row is None:
            return None
        return ProfileRevision.model_validate_json(row[0])

    def profile_revision(self, profile_id: str, revision: int) -> ProfileRevision | None:
        with duckdb.connect(str(self.layout.database_file), read_only=True) as connection:
            row = connection.execute(
                """
                SELECT profile_json FROM profile_revisions
                WHERE profile_id = ? AND revision = ?
                """,
                [profile_id, revision],
            ).fetchone()
        if row is None:
            return None
        return ProfileRevision.model_validate_json(row[0])

    def revision_for_draft(self, draft_id: str) -> ProfileRevision | None:
        with duckdb.connect(str(self.layout.database_file), read_only=True) as connection:
            row = connection.execute(
                "SELECT profile_json FROM profile_revisions WHERE confirmed_draft_id = ?",
                [draft_id],
            ).fetchone()
        if row is None:
            return None
        return ProfileRevision.model_validate_json(row[0])

    def save_profile_revision(self, revision: ProfileRevision) -> None:
        existing = self.revision_for_draft(revision.confirmed_draft_id)
        if existing is not None:
            if existing != revision:
                raise LocalStateError("confirmed draft already points to a different revision")
            return

        pending = self.get_pending_change(revision.confirmed_draft_id)
        if pending is None or pending.state is not PendingChangeState.READY:
            raise LocalStateError("profile revision requires a ready pending change")
        if (
            pending.profile_id != revision.profile_id
            or pending.content_hash != revision.confirmed_content_hash
            or pending.base_revision + 1 != revision.revision
        ):
            raise LocalStateError("profile revision does not match its pending change")

        serialized_revision = _canonical_json(revision)
        with duckdb.connect(str(self.layout.database_file)) as connection:
            connection.execute("BEGIN TRANSACTION")
            try:
                connection.execute(
                    """
                    INSERT INTO profile_revisions VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    [
                        revision.profile_id,
                        revision.revision,
                        revision.schema_version,
                        revision.profile_hash,
                        revision.confirmed_draft_id,
                        revision.confirmed_content_hash,
                        revision.confirmed_at,
                        serialized_revision,
                    ],
                )
                connection.execute(
                    """
                    UPDATE profile_pending_changes
                    SET state = ?, confirmed_revision = ?
                    WHERE draft_id = ?
                    """,
                    [
                        PendingChangeState.CONFIRMED.value,
                        revision.revision,
                        revision.confirmed_draft_id,
                    ],
                )
                connection.execute("COMMIT")
            except Exception:
                connection.execute("ROLLBACK")
                raise

        _atomic_write_yaml(
            self.layout.profile_file(revision.profile_id),
            revision.model_dump(mode="json", exclude_none=True),
        )
        manifest = self.load_manifest()
        if revision.profile_id not in manifest.profile_ids:
            self._write_manifest(
                WorkspaceManifest(
                    workspace_id=manifest.workspace_id,
                    created_at=manifest.created_at,
                    profile_ids=sorted([*manifest.profile_ids, revision.profile_id]),
                    credential_ref_ids=manifest.credential_ref_ids,
                )
            )

    def save_credential_ref(self, credential: CredentialRef) -> None:
        existing = self.get_credential_ref(credential.credential_id)
        if existing is not None and existing != credential:
            raise LocalStateError(
                f"credential reference ID already exists: {credential.credential_id}"
            )
        if existing is None:
            with duckdb.connect(str(self.layout.database_file)) as connection:
                connection.execute(
                    """
                    INSERT INTO credential_refs VALUES (?, ?, ?, ?, ?, ?, ?)
                    """,
                    [
                        credential.credential_id,
                        credential.schema_version,
                        credential.provider.value,
                        credential.locator,
                        credential.platform.value if credential.platform is not None else None,
                        credential.label,
                        credential.created_at,
                    ],
                )
        manifest = self.load_manifest()
        if credential.credential_id not in manifest.credential_ref_ids:
            self._write_manifest(
                WorkspaceManifest(
                    workspace_id=manifest.workspace_id,
                    created_at=manifest.created_at,
                    profile_ids=manifest.profile_ids,
                    credential_ref_ids=sorted(
                        [*manifest.credential_ref_ids, credential.credential_id]
                    ),
                )
            )

    def get_credential_ref(self, credential_id: str) -> CredentialRef | None:
        with duckdb.connect(str(self.layout.database_file), read_only=True) as connection:
            row = connection.execute(
                """
                SELECT schema_version, provider, locator, platform, label,
                       epoch_us(created_at)
                FROM credential_refs WHERE credential_id = ?
                """,
                [credential_id],
            ).fetchone()
        if row is None:
            return None
        return CredentialRef(
            schema_version=row[0],
            credential_id=credential_id,
            provider=row[1],
            locator=row[2],
            platform=row[3],
            label=row[4],
            created_at=_utc_from_epoch_us(row[5]),
        )

    def _initialize_database(self, manifest: WorkspaceManifest) -> None:
        from pallas_ads.monitor_store import MONITOR_SCHEMA_STATEMENTS

        with duckdb.connect(str(self.layout.database_file)) as connection:
            for statement in (*_SCHEMA_STATEMENTS, *MONITOR_SCHEMA_STATEMENTS):
                connection.execute(statement)
            existing_workspace = connection.execute(
                "SELECT workspace_id FROM workspace_metadata LIMIT 1"
            ).fetchone()
            if existing_workspace is not None and existing_workspace[0] != manifest.workspace_id:
                raise LocalStateError(
                    "workspace manifest ID does not match the initialized database"
                )
            for version, name in _SCHEMA_MIGRATIONS:
                connection.execute(
                    "INSERT OR IGNORE INTO schema_migrations VALUES (?, ?, ?)",
                    [version, name, datetime.now(UTC)],
                )
            connection.execute(
                "INSERT OR IGNORE INTO workspace_metadata VALUES (?, ?, ?)",
                [manifest.workspace_id, manifest.schema_version, manifest.created_at],
            )

    def _write_manifest(self, manifest: WorkspaceManifest) -> None:
        _atomic_write_yaml(
            self.layout.workspace_file,
            manifest.model_dump(mode="json"),
        )
