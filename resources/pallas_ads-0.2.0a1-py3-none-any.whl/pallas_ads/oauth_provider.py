"""Provider-specific OAuth recipes; private token payloads never become public contracts."""

from __future__ import annotations

import base64
import hashlib
from datetime import UTC, datetime
from urllib.parse import urlencode

from pallas_ads.contracts.source import SourceConnectionConfig
from pallas_ads.credential_store import CredentialError, CredentialStore, TokenBundle
from pallas_ads.source_transport import SourceHTTPError, Transport

API_VERSIONS = {"meta": "v26.0", "tiktok": "v1.3", "google": "v25"}
META_ROOT = "https://graph.facebook.com/v26.0"
TIKTOK_ROOT = "https://business-api.tiktok.com/open_api/v1.3"


class OAuthProvider:
    def __init__(
        self, transport: Transport, credentials: CredentialStore, *, clock=lambda: datetime.now(UTC)
    ) -> None:
        self.transport, self.credentials = transport, credentials
        self.clock = clock

    def authorization_url(self, config, redirect_uri: str, state: str, verifier: str) -> str:
        if config.transport == "official_mcp":
            return self._mcp(config).authorization_url(config, redirect_uri, state, verifier)
        if not config.client_id:
            raise CredentialError("developer app client ID required")
        params = {"client_id": config.client_id, "redirect_uri": redirect_uri, "state": state}
        if config.platform == "google":
            endpoint = "https://accounts.google.com/o/oauth2/v2/auth"
            params.update(
                response_type="code",
                scope="https://www.googleapis.com/auth/adwords",
                access_type="offline",
                prompt="consent",
                code_challenge_method="S256",
                code_challenge=base64.urlsafe_b64encode(hashlib.sha256(verifier.encode()).digest())
                .decode()
                .rstrip("="),
            )
        elif config.platform == "meta":
            endpoint = "https://www.facebook.com/v26.0/dialog/oauth"
            params.update(response_type="code", override_default_response_type="true")
            if config.meta_config_id:
                params["config_id"] = config.meta_config_id
            else:
                params["scope"] = "ads_read"
        else:
            endpoint = "https://business-api.tiktok.com/portal/auth"
            params["app_id"] = params.pop("client_id")
        return endpoint + "?" + urlencode(params)

    def _app_value(self, config: SourceConnectionConfig) -> str:
        if config.transport == "official_mcp":
            return ""  # Public client: DCR + PKCE, never a developer app secret.
        if config.app_credential_ref is None:
            raise CredentialError("developer app credential reference required")
        return self.credentials.read(config.app_credential_ref)

    def _google_or_operator_secret(self, config):
        # Explicit operator/keychain configuration wins. Never send a bundled secret for a
        # different client's persisted connection (e.g. after an app-identity change).
        if config.app_credential_ref:
            return self._app_value(config)
        if config.platform == "google":
            from pallas_ads.google_application import bundled_secret

            return bundled_secret(config.client_id)
        return None

    def exchange(self, config, code: str, redirect_uri: str, verifier: str) -> TokenBundle:
        if config.transport == "official_mcp":
            return self._mcp(config).exchange(config, code, redirect_uri, verifier)
        if config.platform == "tiktok":
            response = self.transport.request(
                "POST",
                TIKTOK_ROOT + "/oauth2/access_token/",
                headers={},
                body={
                    "app_id": config.client_id,
                    "secret": self._app_value(config),
                    "auth_code": code,
                },
            )
        else:
            body = {"client_id": config.client_id, "code": code, "redirect_uri": redirect_uri}
            secret = self._google_or_operator_secret(config)
            if secret is not None:
                body["client_secret"] = secret
            if config.platform == "google":
                body.update(grant_type="authorization_code", code_verifier=verifier)
                endpoint = "https://oauth2.googleapis.com/token"
            else:
                self._app_value(config)  # Meta's confidential app flow requires its secret.
                endpoint = META_ROOT + "/oauth/access_token"
            response = self.transport.request("POST", endpoint, headers={}, body=body, form=True)
        return self._tokens(config, response)

    @staticmethod
    def _tokens(config, response) -> TokenBundle:
        try:
            payload = response.payload
            if response.status != 200 or not isinstance(payload, dict) or "error" in payload:
                raise ValueError
            if config.platform == "tiktok":
                if payload.get("code") != 0:
                    raise ValueError
                payload = payload["data"]
            tokens = TokenBundle.model_validate(payload)
            if not tokens.access_token.get_secret_value() or (
                tokens.expires_in is not None and tokens.expires_in <= 0
            ):
                raise ValueError
            return tokens
        except Exception:
            raise CredentialError("authorization exchange failed; authorize again") from None

    def refresh(self, config, previous: TokenBundle) -> TokenBundle:
        if config.transport == "official_mcp":
            return self._mcp(config).refresh(config, previous)
        if config.platform != "google" or previous.refresh_token is None:
            raise CredentialError("this credential requires a new authorization")
        body = {
            "client_id": config.client_id,
            "grant_type": "refresh_token",
            "refresh_token": previous.refresh_token.get_secret_value(),
        }
        secret = self._google_or_operator_secret(config)
        if secret is not None:
            body["client_secret"] = secret
        response = self.transport.request(
            "POST",
            "https://oauth2.googleapis.com/token",
            headers={},
            body=body,
            form=True,
        )
        tokens = self._tokens(config, response)
        if tokens.refresh_token is None:
            tokens.refresh_token = previous.refresh_token
        return tokens

    def revoke(self, config, tokens: TokenBundle) -> bool:
        if config.transport == "official_mcp":
            return self._mcp(config).revoke(config, tokens)
        try:
            value = tokens.access_token.get_secret_value()
            if config.platform == "google":
                if tokens.refresh_token:
                    value = tokens.refresh_token.get_secret_value()
                response = self.transport.request(
                    "POST",
                    "https://oauth2.googleapis.com/revoke",
                    headers={},
                    body={"token": value},
                    form=True,
                )
                return response.status == 200
            if config.platform == "meta":
                response = self.transport.request(
                    "DELETE",
                    META_ROOT + "/me/permissions",
                    headers={"Authorization": "Bearer " + value},
                )
                return response.status == 200 and response.payload.get("success") is True
            response = self.transport.request(
                "POST",
                TIKTOK_ROOT + "/oauth2/revoke_token/",
                headers={"Access-Token": value},
                body={"app_id": config.client_id, "secret": self._app_value(config)},
            )
            return response.status == 200 and response.payload.get("code") == 0
        except (SourceHTTPError, CredentialError, ValueError, AttributeError):
            return False

    def _mcp(self, config):
        if config.platform == "meta":
            from pallas_ads.meta_mcp_auth import MetaMCPOAuth

            return MetaMCPOAuth(self.transport)
        from pallas_ads.tiktok_mcp_auth import TikTokMCPOAuth

        return TikTokMCPOAuth(self.transport, clock=self.clock)
