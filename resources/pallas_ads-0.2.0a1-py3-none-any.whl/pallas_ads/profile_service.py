"""Deterministic product-profile draft, patch and confirmation workflow."""

from __future__ import annotations

import hashlib
import json
from collections import Counter
from collections.abc import Mapping, Sequence
from datetime import UTC, datetime
from typing import Any

from pydantic import JsonValue

from pallas_ads.contracts.profile import (
    FieldProvenance,
    PatchOperation,
    ProductProfile,
    ProfileDraft,
    ProfileDraftReview,
    ProfileDraftValues,
    ProfilePatch,
    ProfilePatchItem,
    ProfileRevision,
    SourceFact,
)
from pallas_ads.contracts.status import MissingInput, OperationEnvelope, OperationStatus
from pallas_ads.local_state import (
    PendingChangeState,
    PendingProfileChange,
    ProfileChangeKind,
    WorkspaceRepository,
)


def _content_hash(payload: object) -> str:
    rendered = json.dumps(
        payload,
        ensure_ascii=False,
        separators=(",", ":"),
        sort_keys=True,
    ).encode()
    return f"sha256:{hashlib.sha256(rendered).hexdigest()}"


def build_profile_draft(
    values: ProfileDraftValues,
    *,
    draft_id: str,
    base_revision: int = 0,
    created_at: datetime | None = None,
) -> ProfileDraft:
    """Create a draft whose hash covers its full confirmation payload."""

    timestamp = created_at or datetime.now(UTC)
    hash_payload = {
        "schema_version": "1.0",
        "draft_id": draft_id,
        "base_revision": base_revision,
        "created_at": timestamp.isoformat(),
        "values": values.model_dump(mode="json"),
    }
    return ProfileDraft(
        draft_id=draft_id,
        base_revision=base_revision,
        content_hash=_content_hash(hash_payload),
        created_at=timestamp,
        values=values,
    )


def build_profile_patch(
    *,
    draft_id: str,
    profile_id: str,
    base_revision: int,
    changes: list[ProfilePatchItem],
    field_provenance: list[FieldProvenance],
    created_at: datetime | None = None,
) -> ProfilePatch:
    """Create a patch whose hash covers changes and their provenance."""

    timestamp = created_at or datetime.now(UTC)
    hash_payload = {
        "schema_version": "1.0",
        "draft_id": draft_id,
        "profile_id": profile_id,
        "base_revision": base_revision,
        "changes": [change.model_dump(mode="json") for change in changes],
        "field_provenance": [item.model_dump(mode="json") for item in field_provenance],
        "created_at": timestamp.isoformat(),
    }
    return ProfilePatch(
        draft_id=draft_id,
        profile_id=profile_id,
        base_revision=base_revision,
        content_hash=_content_hash(hash_payload),
        changes=changes,
        field_provenance=field_provenance,
        created_at=timestamp,
    )


def _draft_hash_is_valid(draft: ProfileDraft) -> bool:
    expected = build_profile_draft(
        draft.values,
        draft_id=draft.draft_id,
        base_revision=draft.base_revision,
        created_at=draft.created_at,
    )
    return expected.content_hash == draft.content_hash


def _patch_hash_is_valid(patch: ProfilePatch) -> bool:
    expected = build_profile_patch(
        draft_id=patch.draft_id,
        profile_id=patch.profile_id,
        base_revision=patch.base_revision,
        changes=patch.changes,
        field_provenance=patch.field_provenance,
        created_at=patch.created_at,
    )
    return expected.content_hash == patch.content_hash


def _required_provenance_paths(values: ProfileDraftValues) -> set[str]:
    paths: set[str] = set()
    for field_name in (
        "product_name",
        "monetization_model",
        "kpi",
        "comparison_policy",
    ):
        if getattr(values, field_name) is not None:
            paths.add(f"/{field_name}")
    paths.update(
        f"/app_variants/{variant.app_variant_id}/store_identifier"
        for variant in values.app_variants
    )
    paths.update(
        f"/media_bindings/{binding.binding_id}/account_id" for binding in values.media_bindings
    )
    return paths


def _missing_profile_inputs(values: ProfileDraftValues) -> list[MissingInput]:
    missing: list[MissingInput] = []
    required_values = (
        ("/product_name", values.product_name, "product name"),
        ("/monetization_model", values.monetization_model, "monetization model"),
        ("/app_variants", values.app_variants, "at least one app variant"),
        ("/media_bindings", values.media_bindings, "at least one media binding"),
        ("/kpi", values.kpi, "primary KPI and business event"),
        ("/comparison_policy", values.comparison_policy, "comparison policy"),
    )
    for field_path, value, expectation in required_values:
        if value is None or value == []:
            missing.append(
                MissingInput(
                    field_path=field_path,
                    reason=f"confirmed profiles require {expectation}",
                )
            )

    provenance_paths = {item.field_path for item in values.field_provenance}
    for field_path in sorted(_required_provenance_paths(values) - provenance_paths):
        missing.append(
            MissingInput(
                field_path=f"/field_provenance{field_path}",
                reason=f"required field {field_path} needs explicit provenance",
                expected_type="FieldProvenance",
            )
        )
    return missing


def _source_fact_text(value: SourceFact | None) -> str:
    if value is None:
        return "待媒体 API 或导入事实确认"
    return f"{value.value}（来源：{_origin_label(value.provenance.origin.value)}）"


def _platform_label(value: str) -> str:
    return {"meta": "Meta", "tiktok": "TikTok", "google": "Google"}.get(value, value)


def _origin_label(value: str) -> str:
    return {
        "user": "用户提供",
        "api": "媒体 API",
        "import": "导入数据",
        "system": "Pallas 系统",
    }.get(value, value)


def _metric_label(value: str) -> str:
    return {
        "spend": "花费",
        "impressions": "展示",
        "clicks": "点击",
        "ctr": "点击率",
        "cpm": "千次展示成本",
        "cpc": "单次点击成本",
        "installs": "安装",
        "cpi": "单次安装成本",
        "optimization_event_count": "优化事件",
        "cpa_optimization_event": "优化事件 CPA",
        "purchase_event_count": "购买事件",
        "cpa_purchase_event": "购买事件 CPA",
        "platform_attributed_iap_revenue": "媒体侧应用内购买收入",
        "media_iap_roas": "媒体侧应用内购买 ROAS",
    }.get(value, value)


def _field_label(path: str) -> str:
    fixed_labels = {
        "/product_name": "产品名称",
        "/monetization_model": "变现模式",
        "/kpi": "KPI 设置",
        "/comparison_policy": "比较政策",
    }
    if path in fixed_labels:
        return fixed_labels[path]
    parts = path.split("/")
    if len(parts) == 4 and parts[1] == "app_variants" and parts[3] == "store_identifier":
        return f"App {parts[2]} 的商店标识"
    if len(parts) == 4 and parts[1] == "media_bindings" and parts[3] == "account_id":
        return f"媒体绑定 {parts[2]} 的账户"
    segment_labels = {
        "product_name": "产品名称",
        "monetization_model": "变现模式",
        "app_variants": "App 列表",
        "media_bindings": "媒体绑定",
        "kpi": "KPI 设置",
        "comparison_policy": "比较政策",
        "store_identifier": "商店标识",
        "display_name": "显示名称",
        "account_id": "账户 ID",
        "campaign_scope": "Campaign 范围",
        "credential_ref_id": "凭据引用",
        "business_event_key": "业务事件",
        "primary_metric": "主指标",
        "visible_metrics": "可见指标",
    }
    labels = []
    for part in parts[1:]:
        if part.isdigit():
            labels.append(f"第 {int(part) + 1} 项")
        else:
            labels.append(segment_labels.get(part, part))
    return " / ".join(labels)


def _profile_field_label(path: str, values: ProfileDraftValues) -> str:
    parts = path.split("/")
    if len(parts) == 4 and parts[1] == "app_variants":
        variant = next(
            (item for item in values.app_variants if item.app_variant_id == parts[2]),
            None,
        )
        if variant is not None:
            os_label = {"ios": "iOS", "android": "Android"}.get(variant.os.value, variant.os.value)
            return f"{os_label} App 的{_field_label(f'/{parts[3]}')}"
    if len(parts) == 4 and parts[1] == "media_bindings":
        binding = next(
            (item for item in values.media_bindings if item.binding_id == parts[2]),
            None,
        )
        if binding is not None:
            return f"{_platform_label(binding.platform.value)} 账户的{_field_label(f'/{parts[3]}')}"
    return _field_label(path)


def _render_provenance_summary(
    provenance_items: Sequence[FieldProvenance],
    *,
    values: ProfileDraftValues | None = None,
) -> list[str]:
    grouped: dict[str, list[str]] = {}
    for provenance in sorted(provenance_items, key=lambda item: item.field_path):
        label = (
            _profile_field_label(provenance.field_path, values)
            if values is not None
            else _field_label(provenance.field_path)
        )
        grouped.setdefault(provenance.origin.value, []).append(label)
    order = ("user", "api", "import", "system")
    return [
        f"- {_origin_label(origin)}：{'、'.join(grouped[origin])}"
        for origin in order
        if origin in grouped
    ]


def render_profile_confirmation(draft: ProfileDraft) -> str:
    """Render a complete, stable Chinese confirmation without YAML or JSON."""

    values = draft.values
    assert values.product_name is not None
    assert values.monetization_model is not None
    assert values.kpi is not None
    assert values.comparison_policy is not None

    lines = [
        "请确认以下产品档案：",
        f"产品：{values.product_name}（档案 ID：{values.profile_id}）",
        "变现模式："
        + {
            "in_app_purchase": "应用内购买",
            "hybrid": "混合变现",
            "ad_supported": "广告变现",
            "subscription": "订阅",
            "other": "其他",
        }.get(values.monetization_model.value, values.monetization_model.value),
        "App 版本：",
    ]
    os_counts = Counter(variant.os.value for variant in values.app_variants)
    variant_labels: dict[str, str] = {}
    for variant in sorted(values.app_variants, key=lambda item: item.app_variant_id):
        display_name = f"，显示名称 {variant.display_name}" if variant.display_name else ""
        operating_system = {"ios": "iOS", "android": "Android"}.get(
            variant.os.value, variant.os.value
        )
        variant_labels[variant.app_variant_id] = operating_system
        if os_counts[variant.os.value] > 1:
            variant_labels[variant.app_variant_id] = (
                variant.display_name or variant.store_identifier
            )
        lines.append(f"- {operating_system}：商店标识 {variant.store_identifier}{display_name}")

    lines.append("媒体绑定：")
    for binding in sorted(values.media_bindings, key=lambda item: item.binding_id):
        variants = "、".join(
            variant_labels[variant_id] for variant_id in sorted(binding.app_variant_ids)
        )
        if binding.campaign_scope.mode.value == "all":
            campaign_scope = "全部 Campaign"
        else:
            campaign_ids = "、".join(sorted(binding.campaign_scope.campaign_ids))
            campaign_scope = f"{binding.campaign_scope.mode.value}：{campaign_ids}"
        credential_text = "已配置凭据引用" if binding.credential_ref_id else "尚未配置凭据"
        lines.append(
            f"- {_platform_label(binding.platform.value)} / {binding.account_id}：App {variants}；"
            f"范围 {campaign_scope}；币种 {_source_fact_text(binding.account_currency)}；"
            f"时区 {_source_fact_text(binding.account_timezone)}；凭证 {credential_text}"
        )

    metrics = "、".join(
        f"{_metric_label(metric.value)}（{metric.value}）" for metric in values.kpi.visible_metrics
    )
    lines.extend(
        [
            "KPI：",
            f"- 主指标：{_metric_label(values.kpi.primary_metric.value)}"
            f"（{values.kpi.primary_metric.value}）",
            f"- 业务事件：{values.kpi.business_event_key}",
            f"- 默认关注指标：{metrics}",
            "比较政策：",
        ]
    )
    attribution = values.comparison_policy.requested_attribution
    if attribution is None:
        lines.append("- 严格 outcome 比较的归因政策尚未指定")
    else:
        lines.append(
            f"- 请求归因：点击 {attribution.click_window_days} 天，展示 "
            f"{attribution.view_window_days} 天，事件 {attribution.event_key}"
        )
    if values.comparison_policy.currency_conversions:
        for conversion in values.comparison_policy.currency_conversions:
            lines.append(
                f"- 汇率：{conversion.source_currency} 到 {conversion.target_currency}，"
                f"数值 {conversion.rate}，方向 {conversion.direction.value}，"
                f"生效日 {conversion.effective_date.isoformat()}，"
                f"有效至 {(conversion.valid_through or conversion.effective_date).isoformat()}"
            )
    else:
        lines.append("- 未保存跨币种换算")
    lines.extend(
        [
            "- 保留媒体账户原始时区",
            f"- 证据政策版本：{values.comparison_policy.evidence_policy_version}",
            "字段来源：",
        ]
    )
    lines.extend(_render_provenance_summary(values.field_provenance, values=values))
    lines.append("如以上信息无误，请确认创建产品档案。")
    return "\n".join(lines)


def _decode_pointer_token(token: str) -> str:
    return token.replace("~1", "/").replace("~0", "~")


def _container_and_key(document: object, path: str) -> tuple[object, str]:
    tokens = [_decode_pointer_token(token) for token in path.split("/")[1:]]
    if not tokens:
        raise ValueError("profile patch path cannot target the document root")
    current = document
    for token in tokens[:-1]:
        if isinstance(current, dict):
            if token not in current:
                raise ValueError(f"profile patch path does not exist: {path}")
            current = current[token]
        elif isinstance(current, list):
            try:
                index = int(token)
            except (IndexError, ValueError) as error:
                raise ValueError(f"invalid list position in profile patch path: {path}") from error
            if index < 0:
                raise ValueError(f"invalid list position in profile patch path: {path}")
            try:
                current = current[index]
            except IndexError as error:
                raise ValueError(f"invalid list position in profile patch path: {path}") from error
        else:
            raise ValueError(f"profile patch path traverses a scalar value: {path}")
    return current, tokens[-1]


def _apply_patch_item(document: dict[str, Any], item: ProfilePatchItem) -> None:
    container, key = _container_and_key(document, item.path)
    if isinstance(container, dict):
        exists = key in container
        if item.operation is PatchOperation.REPLACE and not exists:
            raise ValueError(f"replace path does not exist: {item.path}")
        if item.operation is PatchOperation.REMOVE:
            if not exists:
                raise ValueError(f"remove path does not exist: {item.path}")
            del container[key]
        else:
            container[key] = item.value
        return
    if isinstance(container, list):
        if key == "-" and item.operation is PatchOperation.ADD:
            container.append(item.value)
            return
        try:
            index = int(key)
        except ValueError as error:
            raise ValueError(f"invalid list position in profile patch path: {item.path}") from error
        if index < 0:
            raise ValueError(f"invalid list position in profile patch path: {item.path}")
        if item.operation is PatchOperation.ADD:
            if index < 0 or index > len(container):
                raise ValueError(f"add position is outside the list: {item.path}")
            container.insert(index, item.value)
        elif item.operation is PatchOperation.REPLACE:
            try:
                container[index] = item.value
            except IndexError as error:
                raise ValueError(f"replace position is outside the list: {item.path}") from error
        else:
            try:
                del container[index]
            except IndexError as error:
                raise ValueError(f"remove position is outside the list: {item.path}") from error
        return
    raise ValueError(f"profile patch path parent is not a collection: {item.path}")


def _human_value(value: JsonValue) -> str:
    if value is None:
        return "未设置"
    if isinstance(value, bool):
        return "是" if value else "否"
    if isinstance(value, Mapping):
        return "；".join(
            f"{_field_label(f'/{key}')}为 {_human_value(child)}" for key, child in value.items()
        )
    if isinstance(value, Sequence) and not isinstance(value, str):
        return "、".join(_human_value(child) for child in value) or "空列表"
    return str(value)


def render_patch_confirmation(patch: ProfilePatch) -> str:
    lines = ["请确认以下产品档案变更："]
    for item in patch.changes:
        operation = {
            "add": "新增",
            "replace": "修改",
            "remove": "移除",
        }[item.operation.value]
        line = f"- {_field_label(item.path)}：{operation}"
        if item.operation is not PatchOperation.REMOVE:
            line += f"，新值 {_human_value(item.value)}"
        lines.append(line)
    lines.append("字段来源：")
    lines.extend(_render_provenance_summary(patch.field_provenance))
    lines.append("如以上变更无误，请确认更新产品档案。")
    return "\n".join(lines)


class ProfileService:
    def __init__(self, repository: WorkspaceRepository) -> None:
        self.repository = repository

    def prepare_draft(self, draft: ProfileDraft) -> OperationEnvelope[ProfileDraftReview]:
        if not _draft_hash_is_valid(draft):
            return self._invalid_hash_review(
                draft.draft_id,
                draft.values.profile_id,
                draft.content_hash,
                draft.base_revision,
            )
        latest = self.repository.latest_profile_revision(draft.values.profile_id)
        if (latest is None and draft.base_revision != 0) or (
            latest is not None and latest.revision != draft.base_revision
        ):
            return self._stale_revision_review(
                draft.draft_id,
                draft.values.profile_id,
                draft.content_hash,
                draft.base_revision,
            )

        missing_inputs = _missing_profile_inputs(draft.values)
        summary = None if missing_inputs else render_profile_confirmation(draft)
        state = PendingChangeState.INCOMPLETE if missing_inputs else PendingChangeState.READY
        self.repository.save_pending_change(
            PendingProfileChange(
                draft_id=draft.draft_id,
                profile_id=draft.values.profile_id,
                base_revision=draft.base_revision,
                content_hash=draft.content_hash,
                change_kind=ProfileChangeKind.CREATE,
                state=state,
                values=draft.values,
                confirmation_summary=summary,
                created_at=draft.created_at,
            )
        )
        review = ProfileDraftReview(
            draft_id=draft.draft_id,
            profile_id=draft.values.profile_id,
            content_hash=draft.content_hash,
            base_revision=draft.base_revision,
            ready_for_confirmation=not missing_inputs,
            confirmation_summary=summary,
        )
        if missing_inputs:
            return OperationEnvelope[ProfileDraftReview](
                operation="profile_prepare",
                status=OperationStatus.NEEDS_INPUT,
                result=review,
                missing_inputs=missing_inputs,
            )
        return OperationEnvelope[ProfileDraftReview](
            operation="profile_prepare",
            status=OperationStatus.COMPLETE,
            result=review,
        )

    def prepare_patch(self, patch: ProfilePatch) -> OperationEnvelope[ProfileDraftReview]:
        if not _patch_hash_is_valid(patch):
            return self._invalid_hash_review(
                patch.draft_id,
                patch.profile_id,
                patch.content_hash,
                patch.base_revision,
            )
        current = self.repository.latest_profile_revision(patch.profile_id)
        if current is None or current.revision != patch.base_revision:
            return self._stale_revision_review(
                patch.draft_id,
                patch.profile_id,
                patch.content_hash,
                patch.base_revision,
            )

        changed_paths = {item.path for item in patch.changes}
        provenance_paths = {item.field_path for item in patch.field_provenance}
        missing_provenance = sorted(changed_paths - provenance_paths)
        unexpected_provenance = sorted(provenance_paths - changed_paths)
        if missing_provenance or unexpected_provenance:
            return OperationEnvelope[ProfileDraftReview](
                operation="profile_prepare",
                status=OperationStatus.NEEDS_INPUT,
                result=ProfileDraftReview(
                    draft_id=patch.draft_id,
                    profile_id=patch.profile_id,
                    content_hash=patch.content_hash,
                    base_revision=patch.base_revision,
                    ready_for_confirmation=False,
                ),
                missing_inputs=(
                    [
                        MissingInput(
                            field_path=f"/field_provenance{path}",
                            reason=f"changed field {path} needs explicit provenance",
                            expected_type="FieldProvenance",
                        )
                        for path in missing_provenance
                    ]
                    + [
                        MissingInput(
                            field_path=f"/field_provenance{path}",
                            reason=(
                                f"provenance for unchanged field {path} must be removed "
                                "from this patch"
                            ),
                        )
                        for path in unexpected_provenance
                    ]
                ),
            )

        document = current.profile.model_dump(
            mode="json",
            exclude={"schema_version", "confirmation_revision", "confirmed_at"},
        )
        for item in patch.changes:
            try:
                _apply_patch_item(document, item)
            except ValueError as error:
                return OperationEnvelope[ProfileDraftReview](
                    operation="profile_prepare",
                    status=OperationStatus.NEEDS_INPUT,
                    result=ProfileDraftReview(
                        draft_id=patch.draft_id,
                        profile_id=patch.profile_id,
                        content_hash=patch.content_hash,
                        base_revision=patch.base_revision,
                        ready_for_confirmation=False,
                    ),
                    missing_inputs=[MissingInput(field_path=item.path, reason=str(error))],
                )

        provenance_by_path = {item.field_path: item for item in current.profile.field_provenance}
        provenance_by_path.update({item.field_path: item for item in patch.field_provenance})
        document["field_provenance"] = [
            item.model_dump(mode="json")
            for item in sorted(provenance_by_path.values(), key=lambda item: item.field_path)
        ]
        values = ProfileDraftValues.model_validate(document)
        missing_inputs = _missing_profile_inputs(values)
        if missing_inputs:
            return OperationEnvelope[ProfileDraftReview](
                operation="profile_prepare",
                status=OperationStatus.NEEDS_INPUT,
                result=ProfileDraftReview(
                    draft_id=patch.draft_id,
                    profile_id=patch.profile_id,
                    content_hash=patch.content_hash,
                    base_revision=patch.base_revision,
                    ready_for_confirmation=False,
                ),
                missing_inputs=missing_inputs,
            )

        summary = render_patch_confirmation(patch)
        self.repository.save_pending_change(
            PendingProfileChange(
                draft_id=patch.draft_id,
                profile_id=patch.profile_id,
                base_revision=patch.base_revision,
                content_hash=patch.content_hash,
                change_kind=ProfileChangeKind.PATCH,
                state=PendingChangeState.READY,
                values=values,
                confirmation_summary=summary,
                created_at=patch.created_at,
            )
        )
        return OperationEnvelope[ProfileDraftReview](
            operation="profile_prepare",
            status=OperationStatus.COMPLETE,
            result=ProfileDraftReview(
                draft_id=patch.draft_id,
                profile_id=patch.profile_id,
                content_hash=patch.content_hash,
                base_revision=patch.base_revision,
                ready_for_confirmation=True,
                confirmation_summary=summary,
            ),
        )

    def get_confirmation_review(self, draft_id: str) -> OperationEnvelope[ProfileDraftReview]:
        """Return a pending summary only while its base revision is still current."""

        pending = self.repository.get_pending_change(draft_id)
        if pending is None:
            return OperationEnvelope[ProfileDraftReview](
                operation="profile_confirmation_review",
                status=OperationStatus.NEEDS_INPUT,
                missing_inputs=[
                    MissingInput(
                        field_path="/draft_id",
                        reason="no pending profile change exists for this internal draft ID",
                    )
                ],
            )
        if pending.state is PendingChangeState.INCOMPLETE:
            return OperationEnvelope[ProfileDraftReview](
                operation="profile_confirmation_review",
                status=OperationStatus.NEEDS_INPUT,
                result=ProfileDraftReview(
                    draft_id=pending.draft_id,
                    profile_id=pending.profile_id,
                    content_hash=pending.content_hash,
                    base_revision=pending.base_revision,
                    ready_for_confirmation=False,
                ),
                missing_inputs=_missing_profile_inputs(pending.values),
            )
        if pending.state is PendingChangeState.CONFIRMED:
            return OperationEnvelope[ProfileDraftReview](
                operation="profile_confirmation_review",
                status=OperationStatus.NEEDS_INPUT,
                missing_inputs=[
                    MissingInput(
                        field_path="/draft_id",
                        reason="this profile change has already been confirmed",
                    )
                ],
            )

        latest = self.repository.latest_profile_revision(pending.profile_id)
        if (latest is None and pending.base_revision != 0) or (
            latest is not None and latest.revision != pending.base_revision
        ):
            return OperationEnvelope[ProfileDraftReview](
                operation="profile_confirmation_review",
                status=OperationStatus.NEEDS_INPUT,
                missing_inputs=[
                    MissingInput(
                        field_path="/base_revision",
                        reason=(
                            "a newer profile revision exists; generate a new confirmation summary"
                        ),
                    )
                ],
            )

        return OperationEnvelope[ProfileDraftReview](
            operation="profile_confirmation_review",
            status=OperationStatus.COMPLETE,
            result=ProfileDraftReview(
                draft_id=pending.draft_id,
                profile_id=pending.profile_id,
                content_hash=pending.content_hash,
                base_revision=pending.base_revision,
                ready_for_confirmation=True,
                confirmation_summary=pending.confirmation_summary,
            ),
        )

    def confirm(
        self,
        draft_id: str,
        content_hash: str,
        *,
        confirmed_at: datetime | None = None,
    ) -> OperationEnvelope[ProfileRevision]:
        existing_revision = self.repository.revision_for_draft(draft_id)
        if existing_revision is not None:
            if existing_revision.confirmed_content_hash != content_hash:
                return self._confirmation_hash_mismatch(draft_id)
            return OperationEnvelope[ProfileRevision](
                operation="profile_confirm",
                status=OperationStatus.COMPLETE,
                result=existing_revision,
            )

        pending = self.repository.get_pending_change(draft_id)
        if pending is None:
            return OperationEnvelope[ProfileRevision](
                operation="profile_confirm",
                status=OperationStatus.NEEDS_INPUT,
                missing_inputs=[
                    MissingInput(
                        field_path="/draft_id",
                        reason="no pending profile change exists for this draft ID",
                    )
                ],
            )
        if pending.content_hash != content_hash:
            return self._confirmation_hash_mismatch(draft_id)
        if pending.state is not PendingChangeState.READY:
            return OperationEnvelope[ProfileRevision](
                operation="profile_confirm",
                status=OperationStatus.NEEDS_INPUT,
                missing_inputs=_missing_profile_inputs(pending.values),
            )

        latest = self.repository.latest_profile_revision(pending.profile_id)
        if (latest is None and pending.base_revision != 0) or (
            latest is not None and latest.revision != pending.base_revision
        ):
            return OperationEnvelope[ProfileRevision](
                operation="profile_confirm",
                status=OperationStatus.NEEDS_INPUT,
                missing_inputs=[
                    MissingInput(
                        field_path="/base_revision",
                        reason="profile changed after this confirmation summary was generated",
                    )
                ],
            )

        timestamp = confirmed_at or datetime.now(UTC)
        revision_number = pending.base_revision + 1
        profile = ProductProfile(
            **pending.values.model_dump(mode="python"),
            confirmation_revision=revision_number,
            confirmed_at=timestamp,
        )
        profile_hash = _content_hash(profile.model_dump(mode="json"))
        revision = ProfileRevision(
            profile_id=pending.profile_id,
            revision=revision_number,
            profile_hash=profile_hash,
            confirmed_draft_id=pending.draft_id,
            confirmed_content_hash=pending.content_hash,
            confirmed_at=timestamp,
            profile=profile,
        )
        self.repository.save_profile_revision(revision)
        return OperationEnvelope[ProfileRevision](
            operation="profile_confirm",
            status=OperationStatus.COMPLETE,
            result=revision,
        )

    @staticmethod
    def _invalid_hash_review(
        draft_id: str,
        profile_id: str,
        content_hash: str,
        base_revision: int,
    ) -> OperationEnvelope[ProfileDraftReview]:
        return OperationEnvelope[ProfileDraftReview](
            operation="profile_prepare",
            status=OperationStatus.NEEDS_INPUT,
            result=ProfileDraftReview(
                draft_id=draft_id,
                profile_id=profile_id,
                content_hash=content_hash,
                base_revision=base_revision,
                ready_for_confirmation=False,
            ),
            missing_inputs=[
                MissingInput(
                    field_path="/content_hash",
                    reason="content hash does not match the draft payload",
                )
            ],
        )

    @staticmethod
    def _stale_revision_review(
        draft_id: str,
        profile_id: str,
        content_hash: str,
        base_revision: int,
    ) -> OperationEnvelope[ProfileDraftReview]:
        return OperationEnvelope[ProfileDraftReview](
            operation="profile_prepare",
            status=OperationStatus.NEEDS_INPUT,
            result=ProfileDraftReview(
                draft_id=draft_id,
                profile_id=profile_id,
                content_hash=content_hash,
                base_revision=base_revision,
                ready_for_confirmation=False,
            ),
            missing_inputs=[
                MissingInput(
                    field_path="/base_revision",
                    reason="draft base revision does not match current profile state",
                )
            ],
        )

    @staticmethod
    def _confirmation_hash_mismatch(
        draft_id: str,
    ) -> OperationEnvelope[ProfileRevision]:
        return OperationEnvelope[ProfileRevision](
            operation="profile_confirm",
            status=OperationStatus.NEEDS_INPUT,
            missing_inputs=[
                MissingInput(
                    field_path="/content_hash",
                    reason=f"content hash does not match pending draft {draft_id}",
                )
            ],
        )
