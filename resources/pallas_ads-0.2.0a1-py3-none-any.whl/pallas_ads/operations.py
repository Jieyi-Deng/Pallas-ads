"""Closed, typed operation surface shared by CLI and the local MCP server."""

from __future__ import annotations

import json
from pathlib import Path
from uuid import uuid4

import duckdb
from pydantic import ValidationError

from pallas_ads.analysis_service import AnalysisService
from pallas_ads.auth_service import AuthService
from pallas_ads.canonical_import import CanonicalImportService
from pallas_ads.compare_service import ComparisonService
from pallas_ads.contracts.base import ContractModel
from pallas_ads.contracts.operations import (
    AuthRequest,
    ContextRequest,
    MonitorRequest,
    ProfileRequest,
    ReportRequest,
    SourceRequest,
    SourceStatusRequest,
)
from pallas_ads.contracts.query import CanonicalQuery
from pallas_ads.contracts.status import MissingInput, OperationEnvelope
from pallas_ads.contracts.sync import SyncRequest
from pallas_ads.local_state import LocalStateError, WorkspaceRepository
from pallas_ads.monitor_service import MonitorService
from pallas_ads.onboarding_service import OnboardingService
from pallas_ads.onboarding_service import needs as onboarding_needs
from pallas_ads.profile_service import ProfileService, build_profile_draft
from pallas_ads.report_service import ReportService


def needs(operation: str, reason: str):
    return OperationEnvelope(
        operation=operation,
        status="needs_input",
        missing_inputs=[MissingInput(field_path="/request", reason=reason)],
    )


def complete(operation: str, result):
    return OperationEnvelope(operation=operation, status="complete", result=result)


class Runtime:
    """One workspace and one process-lifetime OAuth service; no native query escape hatch."""

    def __init__(self, root: Path, *, auth=None, adapter=None, callback_tls=None):
        self.workspace = WorkspaceRepository(root)
        self.auth = auth or AuthService(self.workspace)
        self.adapter = adapter
        self.callback_tls = callback_tls

    def close(self):
        self.auth.close()

    def invoke(self, name: str, arguments: object):
        try:
            model = OPERATION_MODELS.get(name)
            if model is None:
                return needs("runtime_operation", "Unknown operation; use the published catalog.")
            request = model.model_validate(arguments)
            if not self.workspace.layout.workspace_file.is_file():
                return needs(name, "Initialize the selected workspace with pallas workspace init.")
            # Validate persisted metadata before dispatch; never echo exception payloads.
            self.workspace.load_manifest()
            response = self._dispatch(name, request)
            # Stable operation names across all transports, preserving every issue/status.
            return response.model_copy(update={"operation": name})
        except ValidationError as error:
            # Never echo inputs, exception context or source-provided dictionary keys.
            known = set(OPERATION_MODELS.get(name, ContractModel).model_fields)
            return OperationEnvelope(
                operation=name,
                status="needs_input",
                missing_inputs=[
                    MissingInput(
                        field_path="/" + str(e["loc"][0])
                        if e["loc"] and e["loc"][0] in known
                        else "/request",
                        reason="Use level=account/ad_account, campaign, adset or ad."
                        if e["type"] == "host_entity_level"
                        else "Request validation failed: "
                        + e["type"]
                        + ". Consult this field's published schema.",
                    )
                    for e in error.errors(
                        include_input=False, include_context=False, include_url=False
                    )[:20]
                ],
            )
        except (
            ValueError,
            OSError,
            LocalStateError,
            duckdb.Error,
            RecursionError,
            KeyError,
            StopIteration,
        ):
            return needs(
                name,
                "Invalid request or unavailable local state; inspect the schema and workspace.",
            )

    def _dispatch(self, name, request):
        if name == "profile_create_or_update":
            service = ProfileService(self.workspace)
            if request.action == "draft" and request.values is not None:
                draft = build_profile_draft(
                    request.values,
                    draft_id=request.draft_id or "draft_" + uuid4().hex,
                )
                return service.prepare_draft(draft)
            if request.action == "patch" and request.patch is not None:
                return service.prepare_patch(request.patch)
            if request.action == "review" and request.draft_id:
                return service.get_confirmation_review(request.draft_id)
            if (
                request.action == "confirm"
                and request.draft_id
                and request.content_hash
                and request.user_confirmed
            ):
                return service.confirm(request.draft_id, request.content_hash)
            return needs(
                name,
                (
                    "Supply the fields for this action; confirmation requires "
                    "user approval of the exact summary."
                ),
            )
        if name == "profile_get_context":
            manifest = self.workspace.load_manifest()
            identifier = request.product_id
            if identifier is None and len(manifest.profile_ids) == 1:
                identifier = manifest.profile_ids[0]
            if identifier is None:
                products = []
                for product_id in manifest.profile_ids:
                    revision = self.workspace.latest_profile_revision(product_id)
                    if revision is not None:
                        products.append(
                            {
                                "product_id": product_id,
                                "product_name": revision.profile.product_name,
                            }
                        )
                return OperationEnvelope(
                    operation=name,
                    status="needs_input",
                    result={"products": products},
                    missing_inputs=[
                        MissingInput(
                            field_path="/product_id",
                            reason="Choose a displayed product name, or create a profile first.",
                        )
                    ],
                )
            revision = self.workspace.latest_profile_revision(identifier)
            return (
                complete(name, revision)
                if revision
                else needs(name, "Confirmed profile not found.")
            )
        if name == "source_connect_or_import":
            if request.action in ("file_preview", "file_import"):
                from pallas_ads.file_import import ExportError, stage_file

                if any(
                    (
                        request.package_path,
                        request.capture,
                        request.capture_id,
                        request.config,
                        request.connection_id,
                        request.credential_ref,
                        request.platform,
                        request.period,
                    )
                ):
                    return needs(
                        name,
                        "Use file_path, import_options and confirmation fields only.",
                    )
                try:
                    return stage_file(self.workspace, request)
                except ExportError as error:
                    return needs(name, str(error))
            if any(
                (
                    request.file_path,
                    request.import_options,
                    request.review_hash,
                    request.user_confirmed,
                )
            ):
                return needs(name, "File inputs require file_preview or file_import.")
            if request.action in ("host_capture", "host_inspect"):
                from pallas_ads.contracts.host_mcp import HostCapture
                from pallas_ads.host_mcp import MAX_CAPTURE_BYTES, stage_capture

                capture = request.capture
                if request.action == "host_inspect":
                    if not request.capture_id or capture is not None or request.package_path:
                        return needs(name, "Supply only the retained capture_id for host_inspect.")
                    path = (
                        self.workspace.layout.root
                        / "host_captures"
                        / (request.capture_id + ".json")
                    )
                elif request.package_path and capture is None:
                    path = Path(request.package_path)
                elif capture is not None and not request.package_path:
                    path = None
                else:
                    return needs(name, "Supply capture or package_path, not both.")
                if path is not None:
                    with path.open("rb") as handle:
                        raw = handle.read(MAX_CAPTURE_BYTES + 1)
                    if len(raw) > MAX_CAPTURE_BYTES:
                        raise ValueError("Capture too large.")
                    if request.action == "host_inspect":
                        import hashlib

                        if "host_" + hashlib.sha256(raw).hexdigest() != request.capture_id:
                            raise ValueError("Capture integrity mismatch.")
                    capture = HostCapture.model_validate(json.loads(raw))
                return stage_capture(self.workspace, capture)
            if request.action == "import" and request.package_path:
                return CanonicalImportService(self.workspace).import_package(
                    Path(request.package_path)
                )
            service = OnboardingService(self.workspace, adapter=self.adapter)
            if request.action == "options":
                return service.options()
            if request.action in ("discover", "select", "inspect"):
                if not request.connection_id or (
                    request.action == "select" and not request.choice_id
                ):
                    return needs(name, "Supply a connection and a discovered choice for selection.")
                return getattr(service, request.action)(request)
            if request.action == "connect":
                if request.platform == "meta" and request.config is None:
                    from pallas_ads.host_mcp import host_connection_instructions

                    return host_connection_instructions()
                try:
                    config = service.connect_config(request)
                except ValueError:
                    return onboarding_needs(
                        "operator_setup_required",
                        (
                            "Provider setup is unavailable. Ask the operator to configure it; "
                            "do not ask the user for developer tokens or app secrets."
                        ),
                    )
                if config.transport == "official_mcp":
                    prepared = self.auth.prepare_mcp(config)
                    if prepared.result is None:
                        return prepared
                    config = prepared.result
                return self.auth.start(
                    config,
                    open_browser=request.open_browser,
                    callback_tls=self.callback_tls
                    if (config.registered_redirect_uri or "").startswith("https://")
                    else None,
                )
            if request.action == "attach" and request.config and request.credential_ref:
                return self.auth.attach(request.config, request.credential_ref)
            if request.action in ("refresh", "disconnect") and request.connection_id:
                return getattr(self.auth, request.action)(request.connection_id)
            return needs(name, "Supply the configuration, reference or package for this action.")
        if name == "source_auth_status":
            return getattr(self.auth, request.action)(request.session_id)
        if name == "source_status":
            return self.auth.connection(request.connection_id)
        if name == "sync_media_data":
            from pallas_ads.sync_service import SyncService

            return SyncService(self.workspace, adapter=self.adapter).sync(request)
        if name in ("compare_acquisition", "validate_comparability"):
            # Validation includes the actual semantic matrix and sufficiency, not only planning.
            return ComparisonService(self.workspace).compare(request)
        if name == "run_monitors":
            service = MonitorService(self.workspace)
            if request.action == "run" and request.definition:
                return service.run(
                    request.definition,
                    data_revision=request.data_revision,
                    baseline_data_revision=request.baseline_data_revision,
                    evaluated_at=request.evaluated_at,
                )
            if request.action == "record_health" and request.observation:
                return service.record_health(request.observation)
            if (
                request.action == "transition"
                and request.event_id
                and request.action_id
                and request.state
                and request.reason
                and request.evaluated_at
                and request.data_revision
            ):
                return service.transition(
                    request.event_id,
                    action_id=request.action_id,
                    state=request.state,
                    reason=request.reason,
                    at=request.evaluated_at,
                    data_revision=request.data_revision,
                )
            return needs(
                name, "Supply the monitor definition, health observation or transition fields."
            )
        if name == "build_report":
            if request.action == "file_review":
                from pallas_ads.file_import import ExportError, file_report

                if not request.dataset_id or any(
                    (
                        request.capture_id,
                        request.context_capture_ids,
                        request.connection_id,
                        request.period,
                        request.packet_id,
                        request.product_id,
                        request.draft,
                        request.report_id,
                        request.monitor_run_ids,
                        request.history_before,
                    )
                ):
                    return needs(
                        name,
                        "Use only dataset_id for file_review; review the entire retained snapshot.",
                    )
                try:
                    return file_report(self.workspace, request.dataset_id)
                except ExportError as error:
                    return needs(name, str(error))
            if request.dataset_id:
                return needs(name, "dataset_id requires action=file_review.")
            if request.action == "host_review":
                from pallas_ads.host_reporting import build_host_report

                if not request.capture_id or any(
                    (
                        request.connection_id,
                        request.period,
                        request.packet_id,
                        request.product_id,
                        request.draft,
                        request.report_id,
                        request.monitor_run_ids,
                    )
                ):
                    return needs(name, "Use only capture_id for a retained host evidence review.")
                return build_host_report(
                    self.workspace, request.capture_id, request.context_capture_ids
                )
            if request.context_capture_ids:
                return needs(name, "context_capture_ids requires action=host_review.")
            if request.capture_id:
                return needs(name, "capture_id requires action=host_review.")
            if request.action == "analyze" and request.connection_id:
                from pallas_ads.observation_service import ObservationService

                return ObservationService(self.workspace, adapter=self.adapter).analyze(request)
            if request.action == "load" and request.product_id and request.report_id:
                return ReportService(self.workspace).load(request.product_id, request.report_id)
            if request.packet_id:
                if request.action == "prepare":
                    return AnalysisService(self.workspace).prepare(
                        request.packet_id, monitor_run_ids=request.monitor_run_ids
                    )
                if request.action == "build":
                    return ReportService(self.workspace).build(
                        request.packet_id,
                        monitor_run_ids=request.monitor_run_ids,
                        draft=request.draft,
                    )
            return needs(name, "Supply retained packet or report identifiers.")
        raise ValueError("unknown operation")


OPERATION_MODELS: dict[str, type[ContractModel]] = {
    "profile_create_or_update": ProfileRequest,
    "profile_get_context": ContextRequest,
    "source_connect_or_import": SourceRequest,
    "source_auth_status": AuthRequest,
    "source_status": SourceStatusRequest,
    "sync_media_data": SyncRequest,
    "compare_acquisition": CanonicalQuery,
    "run_monitors": MonitorRequest,
    "validate_comparability": CanonicalQuery,
    "build_report": ReportRequest,
}
