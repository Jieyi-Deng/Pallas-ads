"""Official MCP account client and shared pinned protocol boundary."""

from __future__ import annotations

import json
from uuid import uuid4

from pallas_ads.contracts.source import SourceQueryPlan, SourceReadResult
from pallas_ads.contracts.status import OperationEnvelope, OperationIssue
from pallas_ads.query_planner import content_hash
from pallas_ads.source_redaction import redact
from pallas_ads.source_transport import SourceHTTPError
from pallas_ads.tiktok_mcp_auth import MCP_RESOURCE

TOOL = "advertiser_info_get"
FIELDS = ("advertiser_id", "name", "status", "currency", "timezone")
PROTOCOL_VERSIONS = ("2025-11-25", "2025-06-18", "2025-03-26", "2024-11-05")


class TikTokMCPClient:
    def __init__(self, transport, access_token, *, advertiser_id):
        if advertiser_id is not None and (
            not isinstance(advertiser_id, str)
            or not advertiser_id.isascii()
            or not advertiser_id.isdigit()
            or len(advertiser_id) > 32
        ):
            raise SourceHTTPError("mcp_read_scope_not_allowed")
        self.transport, self._access_token = transport, access_token
        self._advertiser_id = advertiser_id
        self._session = None
        self.protocol_version = None
        self._identifier = 0
        self.tool_schema_hash = None
        self.tool_discovery_pages = 0

    def _rpc(self, method, params, *, notification=False):
        # Restrict both MCP methods and tools even if future callers bypass read_account.
        if method not in ("initialize", "notifications/initialized", "tools/list", "tools/call"):
            raise SourceHTTPError("mcp_method_not_allowed")
        if method == "tools/call" and not self._allowed_call(params):
            raise SourceHTTPError("mcp_tool_not_allowed")
        self._identifier += 1
        body = {"jsonrpc": "2.0", "method": method, "params": params}
        if not notification:
            body["id"] = self._identifier
        headers = {
            "Authorization": "Bearer " + self._access_token,
            "Accept": "application/json, text/event-stream",
        }
        if self.protocol_version:
            headers["MCP-Protocol-Version"] = self.protocol_version
        if self._session:
            headers["Mcp-Session-Id"] = self._session
        response = self.transport.request("POST", MCP_RESOURCE, headers=headers, body=body)
        if response.status in (401, 403):
            raise SourceHTTPError("authentication_or_permission_failed")
        if response.status == 429 or response.status >= 500:
            raise SourceHTTPError("provider_temporarily_unavailable", retriable=True)
        if notification:
            if response.status not in (200, 202, 204):
                raise SourceHTTPError("mcp_notification_failed")
            return {}
        payload = response.payload
        if (
            response.status != 200
            or not isinstance(payload, dict)
            or payload.get("jsonrpc") != "2.0"
            or type(payload.get("id")) is not int
            or payload["id"] != self._identifier
        ):
            raise SourceHTTPError("mcp_response_invalid")
        if "error" in payload:
            error = payload["error"]
            # TikTok documents stateless tools/list + tools/call directly. Only an explicit
            # JSON-RPC method-not-found response permits that compatibility path.
            if method == "initialize" and isinstance(error, dict) and error.get("code") == -32601:
                return None
            raise SourceHTTPError("mcp_remote_error")
        result = payload.get("result")
        if not isinstance(result, dict):
            raise SourceHTTPError("mcp_response_invalid")
        session = next(
            (v for k, v in response.headers.items() if k.lower() == "mcp-session-id"), None
        )
        if session is not None:
            if (
                (method != "initialize" and session != self._session)
                or not isinstance(session, str)
                or not 1 <= len(session) <= 512
                or any(ord(c) < 33 or ord(c) > 126 for c in session)
            ):
                raise SourceHTTPError("mcp_session_invalid")
            self._session = session
        return result

    def _allowed_call(self, params):
        return self._advertiser_id is not None and params == {
            "name": TOOL,
            "arguments": {"advertiser_ids": [self._advertiser_id], "fields": list(FIELDS)},
        }

    def _initialize(self):
        result = self._rpc(
            "initialize",
            {
                "protocolVersion": PROTOCOL_VERSIONS[0],
                "capabilities": {},
                "clientInfo": {"name": "pallas-ads", "version": "0.1.0"},
            },
        )
        if result is None:
            return
        if (
            result.get("protocolVersion") not in PROTOCOL_VERSIONS
            or not isinstance(result.get("capabilities"), dict)
            or not isinstance(result["capabilities"].get("tools"), dict)
        ):
            raise SourceHTTPError("mcp_protocol_unsupported")
        self.protocol_version = result["protocolVersion"]
        self._rpc("notifications/initialized", {}, notification=True)

    @staticmethod
    def _check_tool(tool):
        schema = tool.get("inputSchema", {})
        properties = schema.get("properties", {})
        required = schema.get("required", [])
        ids = properties.get("advertiser_ids", {})
        fields = properties.get("fields", {})
        if (
            schema.get("type") != "object"
            or not isinstance(required, list)
            or not set(required).issubset({"advertiser_ids", "fields"})
            or ids.get("type") != "array"
            or ids.get("items", {}).get("type") != "string"
            or fields.get("type") != "array"
            or fields.get("items", {}).get("type") != "string"
            or not set(FIELDS).issubset(fields.get("items", {}).get("enum", FIELDS))
            or tool.get("annotations", {}).get("readOnlyHint") is False
        ):
            raise SourceHTTPError("mcp_tool_schema_changed")

    def read_account(self):
        try:
            return self._read_account()
        except SourceHTTPError:
            raise
        except (ValueError, TypeError, AttributeError, KeyError):
            raise SourceHTTPError("mcp_response_invalid") from None

    def _read_account(self):
        advertiser_id = self._advertiser_id
        if advertiser_id is None:
            raise SourceHTTPError("mcp_account_selection_required")
        self._initialize()
        cursor, seen = None, set()
        for _ in range(10):
            result = self._rpc("tools/list", {"cursor": cursor} if cursor else {})
            self.tool_discovery_pages += 1
            tools = result.get("tools")
            if (
                not isinstance(tools, list)
                or len(tools) > 1000
                or any(not isinstance(tool, dict) for tool in tools)
            ):
                raise SourceHTTPError("mcp_tools_invalid")
            matches = [tool for tool in tools if tool.get("name") == TOOL]
            if len(matches) > 1:
                raise SourceHTTPError("mcp_tool_ambiguous")
            if matches:
                self._check_tool(matches[0])
                self.tool_schema_hash = content_hash(matches[0]["inputSchema"])
                break
            cursor = result.get("nextCursor")
            if not cursor:
                raise SourceHTTPError("mcp_account_tool_unavailable")
            if not isinstance(cursor, str) or len(cursor) > 2048 or cursor in seen:
                raise SourceHTTPError("mcp_tool_pagination_invalid")
            seen.add(cursor)
        else:
            raise SourceHTTPError("mcp_tool_page_limit")
        result = self._rpc(
            "tools/call",
            {
                "name": TOOL,
                "arguments": {"advertiser_ids": [advertiser_id], "fields": list(FIELDS)},
            },
        )
        if result.get("isError", False) is not False:
            raise SourceHTTPError("mcp_tool_failed")
        if "structuredContent" in result:
            payload = result["structuredContent"]
        else:
            content = result.get("content")
            if (
                not isinstance(content, list)
                or len(content) != 1
                or not isinstance(content[0], dict)
                or (content[0].get("type") != "text" or not isinstance(content[0].get("text"), str))
            ):
                raise SourceHTTPError("mcp_tool_result_invalid")
            try:
                payload = json.loads(content[0]["text"])
            except ValueError:
                raise SourceHTTPError("mcp_tool_result_invalid") from None
        if (
            not isinstance(payload, dict)
            or type(payload.get("code")) is not int
            or not 0 <= payload["code"] <= 2147483647
        ):
            raise SourceHTTPError("mcp_tool_result_invalid")
        if payload["code"] != 0:
            # 40001 is not unique to missing advertisers. Classify only the exact observed
            # message for our selected account; never echo remote text (which may contain secrets).
            if payload["code"] == 40001 and payload.get("message") == (
                f"The advertiser {advertiser_id} doesn't exist or has been deleted."
            ):
                raise SourceHTTPError("mcp_advertiser_not_found")
            raise SourceHTTPError(f"mcp_provider_error_{payload['code']}")
        rows = payload.get("data", {}).get("list")
        if not isinstance(rows, list) or len(rows) != 1 or not isinstance(rows[0], dict):
            raise SourceHTTPError("missing_account_context")
        row = rows[0]
        if row.get("advertiser_id") != advertiser_id:
            raise SourceHTTPError("response_scope_mismatch")
        if any(
            not isinstance(row.get(key), str) or not 1 <= len(row[key]) <= 512 for key in FIELDS
        ):
            raise SourceHTTPError("response_schema_changed")
        # Never retain unexpected fields (emails, balances, contact details, tool instructions).
        return {key: row[key] for key in FIELDS}


def read_mcp_account(service, connection, request, tokens):
    """Called under AdapterService's connection lock; ordinary retention/pruning still applies."""
    from pallas_ads.adapter_service import _record

    if (
        request.platform != "tiktok"
        or request.mode != "account_context"
        or request.account_id != connection.config.mcp_advertiser_id
    ):
        raise SourceHTTPError("mcp_read_scope_not_allowed")
    body = {
        "name": TOOL,
        "arguments": {
            "advertiser_ids": [request.account_id],
            "fields": list(FIELDS),
        },
    }
    plan = SourceQueryPlan(
        plan_id="mcp_plan_"
        + content_hash(
            {"request": request.model_dump(mode="json"), "body": body, "resource": MCP_RESOURCE}
        ).removeprefix("sha256:"),
        transport="official_mcp",
        request=request,
        api_version="v1.3",
        method="POST",
        endpoint=MCP_RESOURCE,
        parameters={},
        body=body,
        required_fields=list(FIELDS),
    )
    client = TikTokMCPClient(
        service.transport, tokens.access_token.get_secret_value(), advertiser_id=request.account_id
    )
    row = client.read_account()
    secrets = tuple(
        value.get_secret_value() for value in (tokens.access_token, tokens.refresh_token) if value
    )
    if client._session:
        secrets += (client._session,)
    row = redact(row, secrets)
    record = _record(plan, row)
    result = SourceReadResult(
        read_id="read_" + uuid4().hex,
        plan=plan,
        observed_at=service.clock(),
        records=[record],
        pages_received=1,
        pagination_complete=True,
        warnings=record.warnings,
    )
    if service.raw_retention_days:
        result.artifact_path = service._retain(
            result,
            [
                {
                    "transport": "official_mcp",
                    "protocol_version": client.protocol_version,
                    "stateless_compatibility": client.protocol_version is None,
                    "tool_schema_hash": client.tool_schema_hash,
                    "tool_discovery_pages": client.tool_discovery_pages,
                    "code": 0,
                    "data": {"list": [row]},
                }
            ],
        )
    return OperationEnvelope(
        operation="source_read",
        status="partial_result" if record.warnings else "complete",
        result=result,
        issues=[
            OperationIssue(
                code="source_fields_incomplete",
                message="Some returned account fields are missing or unverified.",
            )
        ]
        if record.warnings
        else [],
    )
