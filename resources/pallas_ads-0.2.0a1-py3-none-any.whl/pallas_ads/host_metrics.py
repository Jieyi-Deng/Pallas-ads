"""Descriptive Meta metrics scoped to retained queries; never canonical attribution."""

import json
import re
from collections import OrderedDict
from decimal import Decimal

from pallas_ads.observation_rendering import esc, fmt, number, table

LABELS = {
    "spend": "花费",
    "amount_spent": "花费",
    "impressions": "展示",
    "clicks": "点击（全部）",
    "omni_purchase": "媒体归因购买",
    "omni_purchase_values": "媒体归因购买价值",
    "cost_per_omni_purchase": "媒体返回的每次购买成本",
    "purchase_roas": "媒体返回的购买 ROAS",
}
MONEY = {"spend", "amount_spent", "omni_purchase_values", "cost_per_omni_purchase"}
DECIMAL_TEXT = r"[+-]?(?:\d{1,3}(?:,\d{3})+|\d+)(?:\.\d+)?"
ISO_MONEY = re.compile(
    rf"(?:(US\$|CA\$|AU\$|HK\$|CN¥|\$|€|£|¥)\s*)?({DECIMAL_TEXT})\s+([A-Z]{{3}})"
)
PREFIX_CURRENCIES = {
    "US$": "USD",
    "CA$": "CAD",
    "AU$": "AUD",
    "HK$": "HKD",
    "CN¥": "CNY",
    "€": "EUR",
    "£": "GBP",
}


def currency_code(value):
    return value if isinstance(value, str) and re.fullmatch(r"[A-Z]{3}", value) else None


def metric_value(field, value, metadata, currency):
    """Accept explicit ISO display amounts; ambiguous/localized strings stay unparsed."""
    result = {"value": None, "unit": None, "status": "missing", "source_field": field}
    if value is None:
        return result
    result["status"] = "unverified"
    parsed = number(value)
    result["display_value"] = parsed
    if field in MONEY:
        unit = None
        match = ISO_MONEY.fullmatch(value.strip()) if isinstance(value, str) else None
        if match:
            prefix, amount, unit = match.groups()
            if prefix in PREFIX_CURRENCIES and PREFIX_CURRENCIES[prefix] != unit:
                return result
            if currency and unit != currency:
                result["status"] = "currency_conflict"
                return result
            parsed = number(amount.replace(",", ""))
        elif currency and (
            metadata.get("unit") in (currency, "account_currency")
            or metadata.get("type") == "CURRENCY"
            or "account currency" in str(metadata.get("description", "")).lower()
        ):
            unit = currency
        if not unit:
            return result
    else:
        unit = "倍" if field == "purchase_roas" else "次"
        if parsed is None and isinstance(value, str) and re.fullmatch(DECIMAL_TEXT, value):
            parsed = number(value.replace(",", ""))
    if parsed is not None and parsed >= 0:
        result.update(value=parsed, unit=unit, status="provided")
    return result


def query_groups(capture):
    groups = OrderedDict()
    for index, page in enumerate(capture.pages):
        if page.tool != "ads_get_ad_entities":
            continue
        args = {k: v for k, v in page.arguments.items() if k != "cursor"}
        key = json.dumps(args, sort_keys=True)
        if key not in groups:
            groups[key] = {"arguments": args, "level": page.entity_level, "pages": []}
        groups[key]["pages"].append((index, page))
    return list(groups.values())


def summarize(capture, account_currency):
    metadata = {}
    for page in capture.pages:
        if page.tool == "ads_get_field_context" and not page.is_error:
            for row in page.rows():
                previous = metadata.get(row["name"])
                # Conflicting metadata is not a license to select the convenient unit.
                metadata[row["name"]] = row if previous is None or previous == row else {}
    summaries = []
    for ordinal, group in enumerate(query_groups(capture), 1):
        pages = group["pages"]
        args = group["arguments"]
        scope = json.loads(args["time_range"]) if "time_range" in args else None
        complete = not pages[-1][1].next_cursor() and not any(p.is_error for _, p in pages)
        rows = []
        for page_index, page in pages:
            if page.is_error:
                continue
            for row_index, row in enumerate(page.rows()):
                metrics = {
                    f: metric_value(f, row.get(f), metadata.get(f, {}), account_currency)
                    for f in args["fields"]
                    if f in LABELS
                }
                # Ratios only within the exact same source row and source currency.
                spend_field = "amount_spent" if "amount_spent" in metrics else "spend"
                spend = metrics.get(spend_field, {}).get("value")
                for label, numerator, denominator, scale, unit in (
                    ("ctr", "clicks", "impressions", 100, "%"),
                    ("cpc", None, "clicks", 1, account_currency),
                    ("cpm", None, "impressions", 1000, account_currency),
                ):
                    n = metrics.get(numerator, {}).get("value") if numerator else spend
                    d = metrics.get(denominator, {}).get("value")
                    if n is not None and d is not None and d > 0 and unit:
                        metrics[label] = {
                            "value": n / d * scale,
                            "unit": unit,
                            "status": "derived",
                            "source_field": [numerator or spend_field, denominator],
                        }
                rows.append(
                    {
                        "entity": row.get("name") or row.get("id") or "未提供名称",
                        "date_start": row.get("date_start"),
                        "date_stop": row.get("date_stop"),
                        "timezone_name": row.get("timezone_name"),
                        "metrics": metrics,
                        "evidence_pointer": (
                            f"/pages/{page_index}/structured_content/ad_entities/{row_index}"
                        ),
                    }
                )
        summaries.append(
            {
                "query": ordinal,
                "level": group["level"],
                "period": scope,
                "time_increment": args["time_increment"],
                "breakdowns": args.get("breakdowns", []),
                "filtering": args.get("filtering", []),
                "complete": complete,
                "page_count": len(pages),
                "empty_page_count": sum(not p.rows() for _, p in pages if not p.is_error),
                "rows": rows,
                "row_count": len(rows),
            }
        )
    return summaries


def render_summaries(summaries):
    """Human labels and bounded query-scoped tables; no mixed-grain totals."""
    output = []
    findings = []
    labels = {
        **LABELS,
        "ctr": "点击率（计算）",
        "cpc": "点击成本（计算）",
        "cpm": "千次展示成本（计算）",
    }
    for summary in summaries[:12]:
        scope = summary["period"]
        period = f"{scope['since']} 至 {scope['until']}" if scope else "媒体最大可查询范围"
        level = {"ad_account": "账户", "campaign": "广告系列", "adset": "广告组", "ad": "广告"}[
            summary["level"]
        ]
        state = "分页完整" if summary["complete"] else "分页未完成或读取失败"
        output.append(
            f"<article><h3>{esc(level)} · {esc(period)}</h3><p>{state}；"
            f"已返回 {summary['row_count']} 行，读取 {summary['page_count']} 页。"
            "分页完整不等于日期覆盖或归因口径已经核实。</p>"
        )
        if summary["breakdowns"]:
            output.append("<p>本查询带有分组维度；保留独立行，不当作账户总额。</p>")
        timezones = sorted(
            {r["timezone_name"] for r in summary["rows"] if isinstance(r.get("timezone_name"), str)}
        )
        if timezones:
            output.append(
                "<p>来源时区：" + esc("、".join(timezones)) + "；保留原值，不推定历史时区设置。</p>"
            )
        if summary["filtering"]:
            output.append(
                "<p>本查询仅筛选花费大于零的实体，未包含全部实体，不将此范围当作完整账户清单。</p>"
            )
        if not summary["rows"]:
            output.append("<p>本查询没有返回数据，不能解释为零花费。</p></article>")
            continue
        rows = summary["rows"]
        if summary["level"] != "ad_account":
            rows = sorted(
                rows,
                key=lambda r: (
                    r["metrics"].get("amount_spent", r["metrics"].get("spend", {})).get("value")
                    or Decimal(0)
                ),
                reverse=True,
            )
        preview = []
        for row in rows[:10]:
            row_period = (
                f"{row['date_start']} 至 {row['date_stop']}"
                if row["date_start"] and row["date_stop"]
                else "返回行未单列日期"
            )
            for field, metric in row["metrics"].items():
                status = {
                    "missing": "来源未提供，不能当作零",
                    "unverified": "数值或单位未核实",
                    "currency_conflict": "币种与账户不一致",
                    "provided": "媒体返回",
                    "derived": "同行数据计算",
                }[metric["status"]]
                preview.append(
                    [
                        row["entity"],
                        row_period,
                        labels[field],
                        fmt(
                            metric["value"]
                            if metric["value"] is not None
                            else metric.get("display_value")
                        ),
                        metric["unit"] or "单位未核实",
                        status,
                    ]
                )
        if summary["level"] == "ad_account" and len(rows) == 1 and not summary["breakdowns"]:
            output.append(
                '<dl class="metrics">'
                + "".join(
                    '<div class="metric"><dt>'
                    + esc(item[2])
                    + "</dt><dd>"
                    + esc(item[3])
                    + '</dd><div class="unit">'
                    + esc(item[4])
                    + " · "
                    + esc(item[5])
                    + "</div></div>"
                    for item in preview
                )
                + "</dl>"
            )
        else:
            output.append(
                table(["对象", "行期间", "指标", "数值", "单位", "说明"], preview, numeric=(3,))
            )
        if len(rows) > 10:
            output.append(
                "<p>仅展示前 10 行；实体按已返回花费排序，完整数据见附件。"
                "不代表未返回实体的全局排名。</p>"
            )
        output.append("</article>")
        if scope and scope["since"] == scope["until"]:
            findings.append("单日快照没有独立参照期，不能据此判断成本上升或下降。")
        if any(m["status"] == "missing" for r in rows for m in r["metrics"].values()):
            findings.append("部分指标来源未提供；保留缺失，不把未返回购买解释为零购买。")
        if any(f in r["metrics"] for r in rows for f in ("omni_purchase", "purchase_roas")):
            findings.append(
                "购买与 ROAS 是 Meta 归因结果；没有已确认的归因窗口和业务目标，"
                "不能判定目标达成、财务盈利或跨媒体优劣。"
            )
        if not summary["complete"]:
            findings.append("已有结果可先审阅；未完成查询独立保留，不阻塞其他账户的基础报告。")
    if len(summaries) > 12:
        output.append("<p>正文展示前 12 个查询，所有查询及范围保存在分析附件；未跨查询相加。</p>")
    return "".join(output), list(dict.fromkeys(findings))
