# ruff: noqa: E501
"""Human-readable review of retained Meta host evidence, without invented normalization."""

import hashlib
import os
from datetime import date, timedelta
from decimal import Decimal
from string import Template
from typing import TypedDict
from uuid import uuid4

from pallas_ads.contracts.host_mcp import HostCapture
from pallas_ads.contracts.source import SourceRecord
from pallas_ads.contracts.status import OperationEnvelope, OperationIssue
from pallas_ads.host_mcp import MAX_CAPTURE_BYTES, stage_capture
from pallas_ads.host_metrics import currency_code, render_summaries, summarize
from pallas_ads.observation_diagnostics import diagnose
from pallas_ads.observation_rendering import dump, esc, fmt, table, template_path, trend


class DailySpend(TypedDict):
    date: str
    spend: Decimal


def read_capture(workspace, identifier):
    path = workspace.layout.root / "host_captures" / (identifier + ".json")
    if path.is_symlink():
        raise ValueError("Capture cannot be a symlink.")
    with path.open("rb") as handle:
        raw = handle.read(MAX_CAPTURE_BYTES + 1)
    if len(raw) > MAX_CAPTURE_BYTES or "host_" + hashlib.sha256(raw).hexdigest() != identifier:
        raise ValueError("Capture integrity mismatch.")
    return HostCapture.model_validate_json(raw)


def display(value):
    if value is None:
        return "未提供"
    if isinstance(value, bool):
        return "是" if value else "否"
    if isinstance(value, (dict, list)):
        return "结构化明细见本地证据文件"
    if isinstance(value, (int, float, Decimal)):
        return fmt(value)
    return str(value)[:300]


def review_capture(workspace, identifier, context_ids):
    capture = read_capture(workspace, identifier)
    pages = []
    sources = []
    for context_id in dict.fromkeys(context_ids):
        context = read_capture(workspace, context_id)
        if context.host != capture.host or context.account_id not in (None, capture.account_id):
            raise ValueError("Context host/account mismatch.")
        if abs(context.observed_at - capture.observed_at) > timedelta(hours=24):
            raise ValueError("Context must be from the same 24-hour observation window.")
        if any(p.tool == "ads_get_ad_entities" for p in context.pages):
            raise ValueError("Context references may only contain discovery and field metadata.")
        sources.append({"capture_id": context_id, "observed_at": context.observed_at.isoformat()})
        pages.extend(context.pages)
    pages.extend(capture.pages)
    # Exact replay pages are harmless; conflicting metadata must still be rejected.
    unique = {p.model_dump_json(): p for p in pages if p.tool != "ads_get_ad_entities"}
    ordered = [*unique.values(), *(p for p in pages if p.tool == "ads_get_ad_entities")]
    combined = HostCapture.model_validate({**capture.model_dump(), "pages": ordered})
    return combined, sources


def build_host_report(workspace, identifier, context_ids=()):
    capture, context_sources = review_capture(workspace, identifier, context_ids)
    reviewed = stage_capture(workspace, capture)
    result = reviewed.result
    account = next((a for a in result["accounts"] if a["ad_account_id"] == capture.account_id), {})
    currency = currency_code(account.get("currency"))
    pages = [p for p in capture.pages if p.tool == "ads_get_ad_entities"]
    summaries = summarize(capture, currency)
    metric_sections, findings = render_summaries(summaries)
    overview = (
        '<div class="notice">本报告基于客户端交付的 Meta 官方 MCP 读取结果。'
        "Pallas 验证留存完整性，不能独立证明来源、当前登录状态或完整历史覆盖。"
        "这不是跨媒体标准化效果报告。</div>"
        + table(
            ["账户", "币种", "采集时间"],
            [
                [
                    account.get("ad_account_name") or "未确认",
                    currency or "未确认",
                    capture.observed_at.isoformat(),
                ]
            ],
        )
    )
    goals = []
    goal_labels = {
        "optimization_goal": "优化目标",
        "objective": "投放目标",
        "promoted_object": "推广对象",
        "targeting": "配置受众（非实际触达人群）",
    }
    for page in pages:
        if page.is_error:
            continue
        for row in page.rows()[:10]:
            for field, label in goal_labels.items():
                if field in page.arguments["fields"] and field in row:
                    goals.append(
                        [
                            row.get("name") or row.get("id") or "未提供名称",
                            label,
                            display(row[field]),
                        ]
                    )
    overview += metric_sections
    overview += (
        "<p>各查询可能重叠，不跨页、跨层级直接相加。空结果不证明花费为零。"
        "金额按明确的币种和字段信息解释；无法确认的值保留为单位未核实。</p>"
    )
    changes = "<p>缺少经过口径确认的可比时间序列时，不输出异常幅度、原因归因或因果结论。</p>"
    # Only a complete, single-query daily account spend series has an unambiguous grain here.
    account_queries = [q for q in summaries if q["level"] == "ad_account"]
    daily: list[DailySpend] = []
    traffic = None
    if currency and len(account_queries) == 1:
        query = account_queries[0]
        if query["complete"] and query["time_increment"] == "1" and not query["breakdowns"]:
            for row in query["rows"]:
                metric = row["metrics"].get("amount_spent", row["metrics"].get("spend", {}))
                start, end = row["date_start"], row["date_stop"]
                spend = metric.get("value")
                try:
                    day = date.fromisoformat(start)
                except (TypeError, ValueError):
                    daily = []
                    break
                if start != end or spend is None or metric.get("unit") != currency:
                    daily = []
                    break
                scope = query["period"]
                if scope and not date.fromisoformat(scope["since"]) <= day <= date.fromisoformat(
                    scope["until"]
                ):
                    daily = []
                    break
                daily.append({"date": day.isoformat(), "spend": spend})
    days = [d["date"] for d in daily]
    if daily and len(set(days)) == len(days):
        daily.sort(key=lambda d: d["date"])
        changes = trend(daily, currency).replace("evidence/daily.csv", "evidence.json")
        changes += "<p>图中仅展示来源明确提供的每日花费；缺失日期不填零。优化目标、人群、素材和归因窗口未核实前，不能把花费波动解释为效果变化。</p>"
        continuous = all(
            date.fromisoformat(b["date"]) - date.fromisoformat(a["date"]) == timedelta(days=1)
            for a, b in zip(daily, daily[1:], strict=False)
        )
        # Reuse the same calculation engine as Google/TikTok, without creating a connection
        # or writing a canonical observation. Account rows are not campaign observations.
        query = account_queries[0]
        records = [
            SourceRecord(
                account_id=capture.account_id,
                entity_id=capture.account_id,
                event_date=date.fromisoformat(row["date_start"]),
                values={
                    "spend": row["metrics"]
                    .get("amount_spent", row["metrics"].get("spend", {}))
                    .get("value"),
                    "impressions": row["metrics"].get("impressions", {}).get("value"),
                    "clicks": row["metrics"].get("clicks", {}).get("value"),
                },
            )
            for row in query["rows"]
        ]
        diagnostics = diagnose(records)
        change = diagnostics["change"] if continuous else None
        if change:
            change.pop("campaign_contributions", None)
        traffic = {
            "totals": diagnostics["totals"],
            "daily": diagnostics["daily"],
            "change": change,
            "scope": "single_complete_daily_account_query",
            "date_coverage_continuous": continuous,
            "causality": "not_established",
        }
        if change and change["components"]:
            changes += "<h3>点击成本的变化与算术拆解</h3>"
            changes += (
                f"<p>前段 {esc(' 至 '.join(change['baseline']))}，后段 "
                f"{esc(' 至 '.join(change['comparison']))}；等长日历区间比较，"
                "奇数跨度的中间一天不进入两段。</p>"
            )
            changes += table(
                ["指标", "前段", "后段", "单位"],
                [
                    [
                        label,
                        fmt(change["before"][key], percent=key == "ctr"),
                        fmt(change["after"][key], percent=key == "ctr"),
                        unit,
                    ]
                    for key, label, unit in (
                        ("cpc", "点击成本", currency),
                        ("cpm", "千次展示成本", currency),
                        ("ctr", "点击率", "%"),
                    )
                ],
                numeric=(1, 2),
            )
            changes += (
                "<p>"
                + "；".join(
                    f"{esc(c['factor'])} 的变化对 CPC 差额贡献 "
                    f"{fmt(c['cpc_delta'], signed=True)} {esc(currency)}"
                    for c in change["components"]
                )
                + "。这解释算术贡献，不能证明竞价竞争、素材疲劳或受众变化。</p>"
            )
        if continuous and len(daily) >= 4 and len(daily) % 2 == 0:
            half = len(daily) // 2
            before = sum((d["spend"] for d in daily[:half]), Decimal(0))
            after = sum((d["spend"] for d in daily[half:]), Decimal(0))
            changes += (
                f"<p>等长前后两段（各 {half} 天）的花费分别为 {fmt(before)} {esc(currency)} 和 "
                f"{fmt(after)} {esc(currency)}，差额 {fmt(after - before)} {esc(currency)}。"
                "这是描述性比较，不构成统计异常判断或原因证明。</p>"
            )
    changes += "<h3>媒体返回的目标与受众线索</h3>"
    changes += (
        table(["实体", "字段", "来源值"], goals[:20])
        if goals
        else "<p>未取得可验证的优化目标和受众配置，需继续通过媒体字段接口读取，不能从 Campaign 名称推断。</p>"
    )
    if findings:
        changes += (
            "<h3>本次数据支持的判断</h3><ul>"
            + "".join("<li>" + esc(f) + "</li>" for f in findings)
            + "</ul>"
        )
    recommendations = (
        "<ul><li>先确认账户与实际推广产品的对应关系；名称只作线索。</li>"
        "<li>按广告组优化目标和优化事件拆分评价，获取归因窗口、实际受众及结果指标后再判断效率。</li>"
        "<li>将来源错误、分页不完整、空数据与零花费分开记录；不要用浏览器抓数代替失败的 API。</li>"
        "<li>补齐上述证据前，不推荐提高预算、重启投放，也不做跨渠道 ROAS 排名。</li></ul>"
    )
    if not result["pagination_complete"]:
        recommendations = (
            '<div class="notice">本次读取有错误或未完成分页，不能作为完整账户分析。</div>'
            + recommendations
        )
    if context_sources:
        overview += "<p>账户与字段信息由同宿主、24 小时内的留存记录补充；各自采集时间见分析附件。上下文补充不证明历史设置一致。</p>"
    document = Template(template_path().read_text()).substitute(
        title="Meta 账户数据核查报告",
        subtitle="账户事实、数据变化与尚需验证的分析条件",
        overview=overview,
        changes=changes,
        recommendations=recommendations,
        evidence_links='<div class="evidence-links"><a href="evidence.json">完整来源证据</a><a href="analysis.json">指标、范围与判断依据</a><a href="manifest.json">文件完整性记录</a></div>',
    )
    root = workspace.layout.reports_dir / ("host_review_" + uuid4().hex)
    root.mkdir(mode=0o700, parents=True)
    for filename, content in (
        ("report.html", document),
        ("evidence.json", capture.model_dump_json(indent=2)),
        (
            "analysis.json",
            dump(
                {
                    "report_kind": "host_evidence_review",
                    "renderer_version": "host-2.0.0",
                    "primary_capture_id": identifier,
                    "context_sources": context_sources,
                    "observed_at": capture.observed_at.isoformat(),
                    "traffic_diagnostics": traffic,
                    "queries": summaries,
                    "source_issues": [issue.model_dump(mode="json") for issue in reviewed.issues],
                    "evidence_pointer_convention": "JSON path after decoding the ad_entities JSON string in each retained page",
                    "findings": findings,
                    "canonical_data_written": False,
                    "origin_verification": "caller_asserted_not_independently_verified",
                }
            ),
        ),
    ):
        fd = os.open(root / filename, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        with os.fdopen(fd, "w") as handle:
            handle.write(content)
    manifest = {
        "renderer_version": "host-2.0.0",
        "template": "pallas-analysis/assets/report.html",
        "template_sha256": hashlib.sha256(template_path().read_bytes()).hexdigest(),
        "files": {
            name: hashlib.sha256((root / name).read_bytes()).hexdigest()
            for name in ("report.html", "evidence.json", "analysis.json")
        },
    }
    fd = os.open(root / "manifest.json", os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, "w") as handle:
        handle.write(dump(manifest))
    return OperationEnvelope(
        operation="build_report",
        status="partial_result",
        result={
            "html_path": str((root / "report.html").resolve()),
            "capture_id": identifier,
            "context_sources": context_sources,
            "analysis_path": str((root / "analysis.json").resolve()),
            "manifest_path": str((root / "manifest.json").resolve()),
            "report_kind": "host_evidence_review",
            "canonical_data_written": False,
            "performance_validated": False,
            "pagination_complete": result["pagination_complete"],
        },
        issues=[
            OperationIssue(
                code="host_report_limited",
                severity="warning",
                message="Evidence review only; no canonical outcome mapping, causal diagnosis or live reconciliation.",
            )
        ],
    )
