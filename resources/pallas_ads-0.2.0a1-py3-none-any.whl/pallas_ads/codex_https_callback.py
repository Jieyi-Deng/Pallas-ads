"""Loopback-only HTTPS callback forwarder for a pre-registered Codex OAuth client.

No tokens, logs, tunnels, trust-store changes or advertising requests. Codex remains responsible
for OAuth state, PKCE, issuer validation and token storage. Run only during the login process.
"""

from __future__ import annotations

import argparse
import http.client
import re
import ssl
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlsplit


def make_server(callback_url: str, upstream_port: int, certificate: Path, tls_key: Path):
    parsed = urlsplit(callback_url)
    if (
        parsed.scheme != "https"
        or parsed.hostname != "localhost"
        or parsed.username is not None
        or parsed.password is not None
        or parsed.query
        or parsed.fragment
        or not re.fullmatch(r"/callback/[A-Za-z0-9_-]{12}", parsed.path)
        or parsed.port is None
        or not 1024 <= parsed.port <= 65535
        or not 1024 <= upstream_port <= 65535
        or parsed.port == upstream_port
    ):
        raise ValueError("Use an explicit localhost HTTPS port and Codex-specific callback path.")
    context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    context.minimum_version = ssl.TLSVersion.TLSv1_2
    context.load_cert_chain(certificate, tls_key, password=lambda: "")

    class Handler(BaseHTTPRequestHandler):
        def log_message(self, format, *args):
            pass  # Never log an authorization code, state or callback URL query.

        def reply(self, status, message):
            body = message.encode()
            self.send_response(status)
            self.send_header("Content-Type", "text/plain; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            self.send_header("Referrer-Policy", "no-referrer")
            self.send_header(
                "Content-Security-Policy", "default-src 'none'; frame-ancestors 'none'"
            )
            self.end_headers()
            self.wfile.write(body)

        def do_GET(self):
            if len(self.path) > 16384 or self.headers.get_all("Host") != [parsed.netloc]:
                self.reply(400, "Invalid local callback request.")
                return
            target = urlsplit(self.path)
            if target.scheme or target.netloc or target.path != parsed.path or target.fragment:
                self.reply(404, "Unknown callback path.")
                return
            try:
                query = parse_qs(target.query, keep_blank_values=True, max_num_fields=16)
            except ValueError:
                self.reply(400, "Invalid callback query.")
                return
            if (
                any(len(v) != 1 or not v[0] for v in query.values())
                or "state" not in query
                or ("code" in query) == ("error" in query)
                or self.headers.get("Transfer-Encoding")
                or self.headers.get("Content-Length", "0") != "0"
            ):
                self.reply(400, "Invalid callback parameters.")
                return
            # Fixed destination, no proxy environment, cookies, authorization headers or redirects.
            connection = http.client.HTTPConnection("127.0.0.1", upstream_port, timeout=5)
            try:
                connection.request("GET", self.path)
                response = connection.getresponse()
                status = response.status
            except (OSError, http.client.HTTPException):
                self.reply(502, "Codex login listener is unavailable. Start login and try again.")
                return
            finally:
                connection.close()
            if status == 200:
                self.reply(200, "Callback forwarded. Check Codex for the authorization result.")
            else:
                self.reply(400, "Codex did not accept this callback. Check its login result.")

        def do_POST(self):
            self.reply(405, "Only the OAuth GET callback is supported.")

    class Server(ThreadingHTTPServer):
        daemon_threads = True

        def get_request(self):
            connection, address = super().get_request()
            connection.settimeout(5)
            # Perform TLS handshakes in request threads; a stalled peer cannot block accept().
            try:
                return context.wrap_socket(
                    connection, server_side=True, do_handshake_on_connect=False
                ), address
            except Exception:
                connection.close()
                raise

        def handle_error(self, request, client_address):
            pass  # No traceback containing request material.

    return Server(("127.0.0.1", parsed.port), Handler)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--callback-url", required=True)
    parser.add_argument("--upstream-port", required=True, type=int)
    parser.add_argument("--certificate", required=True, type=Path)
    parser.add_argument("--tls-key", required=True, type=Path)
    args = parser.parse_args()
    try:
        with make_server(
            args.callback_url, args.upstream_port, args.certificate, args.tls_key
        ) as server:
            print("Local HTTPS callback forwarder ready; no request logging.", flush=True)
            server.serve_forever()
    except KeyboardInterrupt:
        pass
    except (OSError, ValueError):
        parser.exit(
            1, "Cannot start local callback forwarder. Check ports and certificate files.\n"
        )


if __name__ == "__main__":
    main()
