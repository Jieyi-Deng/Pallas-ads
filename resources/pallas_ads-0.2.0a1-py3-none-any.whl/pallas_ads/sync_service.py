"""Conservative native traffic → canonical import bridge; no synthetic maturity defaults."""

from __future__ import annotations

import hashlib
import json
import tempfile
from pathlib import Path

from pallas_ads.adapter_service import AdapterService, _get
from pallas_ads.canonical_import import CanonicalImportService
from pallas_ads.contracts.data import CanonicalImportManifest, NativeReadLineage
from pallas_ads.contracts.source import SourceReadRequest
from pallas_ads.contracts.status import MissingInput, OperationEnvelope, OperationIssue
from pallas_ads.contracts.sync import SyncRequest, SyncResult
from pallas_ads.metric_registry import MetricRegistry
from pallas_ads.query_planner import content_hash
from pallas_ads.source_state import SourceStateStore


class SyncService:
    def __init__(self, workspace, *, adapter=None):
        self.workspace = workspace
        self.adapter = adapter or AdapterService(workspace)

    def sync(self, request: SyncRequest):
        reads = []
        warnings = [
            "experimental_adapter",
            "maturity_and_dense_coverage_unverified",
            "canonical_outcomes_unmapped",
            "current_configuration_only",
        ]
        try:
            request = SyncRequest.model_validate(request.model_dump(mode="json"))
            profile = self.workspace.latest_profile_revision(request.product_id)
            if profile is None:
                raise ValueError
            binding = next(
                b for b in profile.profile.media_bindings if b.binding_id == request.binding_id
            )
            connection = SourceStateStore(self.workspace.layout.root).load(request.connection_id)
            if (
                connection is None
                or connection.state != "connected"
                or connection.config.platform != binding.platform
                or (
                    connection.selected_account_id is not None
                    and connection.selected_account_id != binding.account_id
                )
                or (
                    connection.config.transport == "official_mcp"
                    and connection.config.mcp_advertiser_id != binding.account_id
                )
            ):
                raise ValueError
            if (request.period.end - request.period.start).days > 30:
                raise ValueError
            # Preserve the confirmed all/include scope; never widen an exclude request.
            if binding.campaign_scope.mode == "exclude":
                return self._needs(
                    "Native sync supports confirmed all/include campaign scopes; "
                    "use canonical import for exclude scopes."
                )
            campaign_ids = binding.campaign_scope.campaign_ids
            if any(not c.isascii() or not c.isdigit() for c in campaign_ids):
                raise ValueError
            for mode in ("account_context", "entity_configuration", "traffic_performance"):
                response = self.adapter.read(
                    request.connection_id,
                    SourceReadRequest(
                        platform=binding.platform,
                        mode=mode,
                        account_id=binding.account_id,
                        campaign_ids=[] if mode == "account_context" else campaign_ids,
                        period=request.period if mode == "traffic_performance" else None,
                        max_pages=request.max_pages,
                    ),
                )
                if response.result is not None:
                    reads.append(response.result)
                if response.status not in ("complete", "partial_result") or response.result is None:
                    return OperationEnvelope(
                        operation="sync_media_data",
                        status=response.status,
                        result=SyncResult(reads=reads, warnings=warnings) if reads else None,
                        issues=response.issues,
                        missing_inputs=response.missing_inputs,
                    )
                if not response.result.pagination_complete:
                    return self._partial(
                        reads, None, warnings + ["incomplete_pagination_no_import"]
                    )
            if len(reads[0].records) != 1:
                raise ValueError
            context = reads[0].records[0].metadata
            currency, timezone = context.get("account_currency"), context.get("source_timezone")
            if not isinstance(currency, str) or not isinstance(timezone, str):
                raise ValueError
            if request.include_native_conversions:
                if binding.platform != "tiktok":
                    warnings.append("native_conversion_diagnostics_tiktok_only")
                else:
                    diagnostic = self.adapter.read(
                        request.connection_id,
                        SourceReadRequest(
                            platform=binding.platform,
                            mode="conversion_performance",
                            account_id=binding.account_id,
                            campaign_ids=campaign_ids,
                            period=request.period,
                            max_pages=request.max_pages,
                        ),
                    )
                    if diagnostic.result is not None:
                        reads.append(diagnostic.result)
                    if diagnostic.result is None or not diagnostic.result.pagination_complete:
                        warnings.append("native_conversion_diagnostics_incomplete")
                    warnings.extend(issue.code for issue in diagnostic.issues)
            from pallas_ads.source_analysis import analyze_traffic

            analysis = analyze_traffic(reads[2], currency, timezone)
            # CanonicalImportService also validates confirmed account facts before persistence.
            package_result = self._import(request, binding, reads, currency, timezone)
            if package_result.result is None:
                return OperationEnvelope(
                    operation="sync_media_data",
                    status="needs_input",
                    result=SyncResult(reads=reads, warnings=warnings),
                    missing_inputs=package_result.missing_inputs,
                )
            return self._partial(reads, package_result.result, warnings, analysis)
        except (ValueError, OSError, StopIteration):
            return self._needs(
                "Check confirmed binding, source connection, numeric "
                "campaign scope, account facts and the maximum 31-day window."
            )

    def _import(self, request, binding, reads, currency, timezone):
        platform = binding.platform.value
        missing = {"state": "missing"}
        na = {"state": "not_applicable"}
        entities = [
            dict(
                entity_type="account",
                entity_id=binding.account_id,
                campaign_type=na,
                optimization_goal=na,
                status="unknown",
            )
        ]
        campaign_context = {}
        for record in reads[1].records:
            row = record.metadata
            status = _get(
                row,
                {"meta": "status", "tiktok": "operation_status", "google": "campaign.status"}[
                    platform
                ],
            )
            objective = _get(
                row,
                {
                    "meta": "objective",
                    "tiktok": "objective_type",
                    "google": "campaign.advertisingChannelType",
                }[platform],
            )
            fields = dict(
                entity_type="campaign",
                entity_id=record.entity_id,
                campaign_type=missing,
                optimization_goal=missing,
            )
            campaign_context[record.entity_id] = fields
            entities.append(
                dict(
                    **fields,
                    status=str(status or "unknown"),
                    objective_native=str(objective) if objective else None,
                )
            )
        observations = []
        metrics = MetricRegistry()
        for record in reads[2].records:
            if record.entity_id not in campaign_context:
                raise ValueError("traffic lacks campaign context")
            for key, value in record.values.items():
                if key not in ("spend", "impressions", "clicks") or value is None:
                    continue
                definition = metrics.definition(key)
                observations.append(
                    dict(
                        **campaign_context[record.entity_id],
                        event_date=record.event_date.isoformat(),
                        reporting_time_basis="delivery_date",
                        country={"state": "all"},
                        # Fixed traffic queries aggregate across OS without OS filters.
                        # Mark that grain explicitly so canonical unfiltered queries select it.
                        os={"state": "all"},
                        metric_key=key,
                        metric_semantic_version=definition.semantic_version,
                        value=str(value),
                        unit=definition.unit.value,
                        currency=currency,
                        source_timezone=timezone,
                        maturity_status="provisional",
                    )
                )
        identity = content_hash([r.model_dump(mode="json") for r in reads]).split(":")[1]
        with tempfile.TemporaryDirectory(prefix="pallas-sync-") as directory:
            root = Path(directory)
            files = []
            for role, payload in [("entities", entities), ("observations", observations)]:
                raw = json.dumps(payload, ensure_ascii=False, sort_keys=True).encode()
                (root / f"{role}.json").write_bytes(raw)
                files.append(
                    dict(
                        role=role,
                        path=f"{role}.json",
                        format="json",
                        content_sha256="sha256:" + hashlib.sha256(raw).hexdigest(),
                    )
                )
            manifest = CanonicalImportManifest(
                package_id="import_native_" + identity,
                source_snapshot_id="snapshot_native_" + identity,
                product_id=request.product_id,
                platform=binding.platform,
                account_id=binding.account_id,
                account_currency=currency,
                source_timezone=timezone,
                observed_at=max(r.observed_at for r in reads),
                effective_period=request.period,
                files=files,
                native_lineage=[self._lineage(r) for r in reads],
                maturity_policies=[
                    dict(
                        canonical_metric=key,
                        metric_semantic_version=metrics.definition(key).semantic_version,
                        reporting_time_basis="delivery_date",
                        policy_version="native-unverified-1.0.0",
                        maturity_verified=False,
                        provisional_days=0,
                        refresh_lookback_days=0,
                    )
                    for key in ("spend", "impressions", "clicks")
                ],
            )
            (root / "manifest.json").write_text(manifest.model_dump_json(indent=2))
            return CanonicalImportService(self.workspace).import_package(root)

    def _lineage(self, read):
        # Do not retain native response records beyond raw retention in canonical manifests.
        path = self.workspace.layout.raw_data_dir / "adapter_reads" / read.read_id / "evidence.json"
        payload = json.loads(path.read_text())
        digest = payload.pop("content_hash", None)
        if content_hash(payload) != digest:
            raise ValueError("corrupt source evidence")
        expected = read.model_dump(mode="json")
        expected["artifact_path"] = None
        if payload["result"] != expected:
            raise ValueError("source evidence does not match the normalized read")
        return NativeReadLineage(
            read_id=read.read_id, plan=read.plan, observed_at=read.observed_at, content_hash=digest
        )

    @staticmethod
    def _needs(reason):
        return OperationEnvelope(
            operation="sync_media_data",
            status="needs_input",
            missing_inputs=[MissingInput(field_path="/sync", reason=reason)],
        )

    @staticmethod
    def _partial(reads, imported, warnings, analysis=None):
        return OperationEnvelope(
            operation="sync_media_data",
            status="partial_result",
            result=SyncResult(
                reads=reads, imported=imported, warnings=warnings, traffic_analysis=analysis
            ),
            issues=[
                OperationIssue(
                    code="native_semantics_unverified",
                    severity="warning",
                    message=(
                        "Only available traffic components are retained "
                        "provisionally; coverage, outcomes and strict rankings are "
                        "unavailable."
                    ),
                )
            ],
        )
