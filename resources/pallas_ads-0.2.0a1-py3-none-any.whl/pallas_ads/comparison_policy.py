"""Pure, conservative comparison eligibility and metric-specific claim boundaries.

Arithmetic is not eligibility. Semantic blockers take precedence over evidence-volume
checks, and neither a comparable cell nor a point estimate establishes a causal winner.
"""

from __future__ import annotations

import hashlib
import json
from decimal import Decimal
from typing import Literal

from pallas_ads.contracts.analysis import EvidencePolicy, MetricAggregate
from pallas_ads.contracts.common import (
    OUTCOME_METRICS,
    TRAFFIC_METRICS,
    CanonicalMetric,
    ComparisonStatus,
    ReportingTimeBasis,
)
from pallas_ads.contracts.evidence import AllowedClaim, ComparisonCell, ProhibitedClaim
from pallas_ads.contracts.metrics import MetricInterpretationWarning, MetricUnit
from pallas_ads.contracts.profile import ProductProfile
from pallas_ads.metric_registry import DEFAULT_METRIC_REGISTRY

_UNVERIFIED_GOALS = frozenset(
    {"unknown", "missing", "unmapped", "all", "not_requested", "not_supported", "not_applicable"}
)
_QUALIFYING_WARNINGS = frozenset(
    {
        MetricInterpretationWarning.ZERO_SPEND_WITH_OUTCOMES.value,
        MetricInterpretationWarning.POSITIVE_SPEND_WITH_ZERO_OUTCOME.value,
        MetricInterpretationWarning.BOTH_COMPONENTS_ZERO.value,
    }
)
_EVENT_METRICS = {
    CanonicalMetric.INSTALLS: CanonicalMetric.INSTALLS,
    CanonicalMetric.CPI: CanonicalMetric.INSTALLS,
    CanonicalMetric.PURCHASE_EVENT_COUNT: CanonicalMetric.PURCHASE_EVENT_COUNT,
    CanonicalMetric.CPA_PURCHASE_EVENT: CanonicalMetric.PURCHASE_EVENT_COUNT,
    CanonicalMetric.OPTIMIZATION_EVENT_COUNT: CanonicalMetric.OPTIMIZATION_EVENT_COUNT,
    CanonicalMetric.CPA_OPTIMIZATION_EVENT: CanonicalMetric.OPTIMIZATION_EVENT_COUNT,
    CanonicalMetric.PLATFORM_ATTRIBUTED_IAP_REVENUE: CanonicalMetric.PURCHASE_EVENT_COUNT,
    CanonicalMetric.MEDIA_IAP_ROAS: CanonicalMetric.PURCHASE_EVENT_COUNT,
}


def _stable_id(prefix: str, payload: object) -> str:
    encoded = json.dumps(payload, sort_keys=True, separators=(",", ":"), default=str).encode()
    return f"{prefix}_{hashlib.sha256(encoded).hexdigest()[:24]}"


def _verified_goal(aggregate: MetricAggregate) -> str | None:
    goals = set(aggregate.optimization_goals)
    if len(goals) != 1:
        return None
    goal = next(iter(goals))
    normalized = goal.strip().lower()
    if not normalized or normalized.split(":", 1)[0] in _UNVERIFIED_GOALS:
        return None
    return goal


def _required_components(metric: CanonicalMetric) -> set[CanonicalMetric]:
    definition = DEFAULT_METRIC_REGISTRY.definition(metric)
    return {
        component
        for component in (definition.numerator_metric, definition.denominator_metric)
        if component is not None
    } or {metric}


def _display_unit(aggregate: MetricAggregate) -> str:
    unit = aggregate.computation.unit
    currency = aggregate.currency or "unknown currency"
    if unit is MetricUnit.CURRENCY:
        return currency
    if unit is MetricUnit.CURRENCY_PER_ACTION:
        return f"{currency}/action"
    if unit is MetricUnit.CURRENCY_PER_THOUSAND:
        return f"{currency}/1000 impressions"
    return unit.value


def _time_basis_reasons(left: MetricAggregate, right: MetricAggregate) -> set[str]:
    required = _required_components(left.metric)
    reasons: set[str] = set()
    resolved: list[dict[CanonicalMetric, ReportingTimeBasis]] = []
    for aggregate in (left, right):
        bases: dict[CanonicalMetric, ReportingTimeBasis] = {}
        for component in required:
            choices = set(aggregate.reporting_time_bases.get(component, []))
            if not choices or choices & {ReportingTimeBasis.UNKNOWN, ReportingTimeBasis.MIXED}:
                reasons.add("unknown_reporting_time_basis")
            elif len(choices) != 1:
                reasons.add("conflicting_reporting_time_bases")
            else:
                bases[component] = next(iter(choices))
        if len(bases) != len(required):
            continue
        if left.metric in OUTCOME_METRICS:
            for component, basis in bases.items():
                if component is CanonicalMetric.SPEND:
                    if basis not in {
                        ReportingTimeBasis.DELIVERY_DATE,
                        ReportingTimeBasis.AD_INTERACTION_DATE,
                    }:
                        reasons.add("period_flow_not_cohort")
                elif basis is not ReportingTimeBasis.AD_INTERACTION_DATE:
                    reasons.add("period_flow_not_cohort")
        elif len(set(bases.values())) != 1:
            reasons.add("reporting_time_basis_mismatch")
        resolved.append(bases)
    if len(resolved) == 2:
        for component in required:
            if resolved[0][component] == resolved[1][component]:
                continue
            # These two spend labels both describe source delivery/interaction costs;
            # their outcome date must independently be verified as interaction-date.
            if (
                left.metric in OUTCOME_METRICS
                and component is CanonicalMetric.SPEND
                and {resolved[0][component], resolved[1][component]}
                <= {
                    ReportingTimeBasis.DELIVERY_DATE,
                    ReportingTimeBasis.AD_INTERACTION_DATE,
                }
            ):
                continue
            reasons.add("reporting_time_basis_mismatch")
    return reasons


def _attribution_reasons(
    left: MetricAggregate, right: MetricAggregate, profile: ProductProfile
) -> set[str]:
    reasons: set[str] = set()
    specs = []
    for aggregate in (left, right):
        signatures = {
            (spec.event_key, spec.click_window_days, spec.view_window_days)
            for spec in aggregate.attribution_specs
        }
        if not signatures:
            reasons.add("missing_effective_attribution")
        elif len(signatures) != 1:
            reasons.add("conflicting_effective_attribution")
        else:
            specs.append(next(iter(signatures)))
    if len(specs) == 2:
        if specs[0][0] != specs[1][0]:
            reasons.add("canonical_event_mismatch")
        if specs[0][1:] != specs[1][1:]:
            reasons.add("effective_attribution_mismatch")
    requested = profile.comparison_policy.requested_attribution
    if requested is None:
        reasons.add("missing_requested_attribution")
    else:
        expected = (requested.event_key, requested.click_window_days, requested.view_window_days)
        if any(spec != expected for spec in specs):
            reasons.add("requested_attribution_mismatch")
    return reasons


def _sufficiency_reasons(
    left: MetricAggregate, right: MetricAggregate, policy: EvidencePolicy
) -> set[str]:
    if left.metric not in OUTCOME_METRICS:
        return set()
    reasons = set(left.evidence_sufficiency_reasons) | set(right.evidence_sufficiency_reasons)
    if policy.calibration == "unconfigured" or policy.minimum_outcome_events is None:
        return reasons | {"evidence_policy_unconfigured"}
    event_metric = _EVENT_METRICS[left.metric]
    for aggregate in (left, right):
        count = aggregate.components.get(event_metric)
        if count is None:
            reasons.add("missing_sufficiency_event_count")
        elif count < policy.minimum_outcome_events:
            reasons.add("below_minimum_outcome_events")
        if policy.minimum_spend is not None:
            spend = aggregate.components.get(CanonicalMetric.SPEND)
            currencies = set(aggregate.component_currencies.get(CanonicalMetric.SPEND, []))
            if policy.minimum_spend_currency is None:
                reasons.add("missing_minimum_spend_currency")
            if not currencies:
                reasons.add("missing_sufficiency_spend_currency")
            elif policy.minimum_spend_currency is not None and currencies != {
                policy.minimum_spend_currency
            }:
                reasons.add("sufficiency_spend_currency_mismatch")
            if spend is None:
                reasons.add("missing_sufficiency_spend")
            elif (
                policy.minimum_spend_currency is not None
                and currencies == {policy.minimum_spend_currency}
                and spend < policy.minimum_spend
            ):
                reasons.add("below_minimum_spend")
    return reasons


def compare_aggregates(
    left: MetricAggregate,
    right: MetricAggregate,
    *,
    profile: ProductProfile,
    policy: EvidencePolicy,
    evidence_refs: list[str],
    comparison_type: Literal["cross_source", "period_change"] = "cross_source",
) -> ComparisonCell:
    """Compare the same metric; for period changes, left is current and right baseline.

    Aggregation owns scope coverage, currency conversion, and source-policy validation.
    Its reasons are fail-closed unless they are explicit arithmetic qualifications.
    """

    if left.metric is not right.metric:
        raise ValueError("comparisons require the same canonical metric")
    if comparison_type not in {"cross_source", "period_change"}:
        raise ValueError("unsupported comparison type")
    blockers: set[str] = set()
    qualifications: set[str] = set()
    if comparison_type == "cross_source":
        if left.period != right.period:
            blockers.add("comparison_period_mismatch")
    else:
        if left.scope_key != right.scope_key:
            blockers.add("period_change_scope_mismatch")
        if (
            left.window != "current"
            or right.window != "baseline"
            or right.period.end >= left.period.start
            or right.period.end - right.period.start != left.period.end - left.period.start
        ):
            blockers.add("invalid_period_change_windows")
    for aggregate in (left, right):
        all_reasons = set(aggregate.reasons) | {
            warning.value for warning in aggregate.computation.interpretation_warnings
        }
        qualifications.update(all_reasons & _QUALIFYING_WARNINGS)
        blockers.update(all_reasons - _QUALIFYING_WARNINGS)
        if not aggregate.complete:
            blockers.add("incomplete_source_coverage")
        if aggregate.computation.metric_key is not aggregate.metric:
            blockers.add("metric_computation_mismatch")
        if aggregate.computation.value is None:
            null_reason = aggregate.computation.null_reason
            blockers.add(f"null_metric:{null_reason.value if null_reason else 'unknown'}")
        if aggregate.provisional:
            qualifications.add("provisional_data")
        if not aggregate.source_timezones:
            blockers.add("missing_source_timezone")
    if left.computation.semantic_version != right.computation.semantic_version:
        blockers.add("metric_semantic_version_mismatch")
    if left.computation.unit is not right.computation.unit:
        blockers.add("metric_unit_mismatch")

    left_goal, right_goal = _verified_goal(left), _verified_goal(right)
    goals_compatible = left_goal is not None and left_goal == right_goal
    if not goals_compatible and left.metric not in TRAFFIC_METRICS:
        blockers.add(
            "unverified_optimization_goal"
            if left_goal is None or right_goal is None
            else "incompatible_optimization_goals"
        )
    blockers.update(_time_basis_reasons(left, right))
    if left.metric in OUTCOME_METRICS:
        blockers.update(_attribution_reasons(left, right, profile))
    monetary = (
        left.computation.unit
        in {
            MetricUnit.CURRENCY,
            MetricUnit.CURRENCY_PER_ACTION,
            MetricUnit.CURRENCY_PER_THOUSAND,
        }
        or left.metric is CanonicalMetric.MEDIA_IAP_ROAS
    )
    if monetary:
        if left.currency is None or right.currency is None:
            blockers.add("missing_effective_currency")
        elif left.currency != right.currency:
            blockers.add("currency_mismatch")
    timezones = set(left.source_timezones) | set(right.source_timezones)
    if len(timezones) > 1:
        qualifications.add("source_timezone_boundary_mismatch")

    insufficiency = _sufficiency_reasons(left, right, policy)
    if blockers:
        status = ComparisonStatus.NOT_COMPARABLE
        reasons = blockers | qualifications
    elif insufficiency:
        status = ComparisonStatus.INSUFFICIENT_EVIDENCE
        reasons = insufficiency | qualifications
    elif qualifications:
        status = ComparisonStatus.DIRECTIONALLY_COMPARABLE
        reasons = qualifications
    else:
        status = ComparisonStatus.STRICTLY_COMPARABLE
        reasons = set()

    delta_absolute: Decimal | None = None
    delta_relative: Decimal | None = None
    if comparison_type == "period_change" and not blockers:
        assert left.computation.value is not None and right.computation.value is not None
        delta_absolute = left.computation.value - right.computation.value
        if right.computation.value != 0:
            delta_relative = delta_absolute / right.computation.value
    values = {
        "metric": left.metric,
        "comparison_type": comparison_type,
        "left_scope": left.scope_key,
        "right_scope": right.scope_key,
        "left_value": None if left.computation.value is None else str(left.computation.value),
        "right_value": None if right.computation.value is None else str(right.computation.value),
        "status": status,
        "reasons": sorted(reasons),
        "optimization_goals_compatible": goals_compatible,
        "evidence_refs": sorted(set(evidence_refs)),
        "delta_absolute": delta_absolute,
        "delta_relative": delta_relative,
        "left_unit": _display_unit(left),
        "right_unit": _display_unit(right),
        "evidence_policy_version": policy.version,
        "evidence_policy_calibration": policy.calibration,
    }
    return ComparisonCell(comparison_id=_stable_id("cmp", values), **values)


def claims_for_comparisons(
    cells: list[ComparisonCell],
) -> tuple[list[AllowedClaim], list[ProhibitedClaim]]:
    """Only measured, qualified, metric-specific comparisons may become claims."""

    allowed: list[AllowedClaim] = []
    prohibited = [
        ProhibitedClaim(
            statement="Declare an overall channel winner.",
            reason="A metric-specific comparison cannot establish overall channel performance.",
        ),
        ProhibitedClaim(
            statement="Claim causation or statistical significance from these point estimates.",
            reason="No causal identification or statistical significance test has been performed.",
        ),
    ]
    for cell in cells:
        strict = cell.status is ComparisonStatus.STRICTLY_COMPARABLE
        directional_traffic = (
            cell.status is ComparisonStatus.DIRECTIONALLY_COMPARABLE
            and cell.metric in TRAFFIC_METRICS
        )
        if strict or directional_traffic:
            qualification = (
                "Under the verified comparison conditions"
                if strict
                else f"Directionally only ({', '.join(cell.reasons)})"
            )
            if cell.evidence_policy_calibration == "synthetic":
                qualification += "; sufficiency uses a synthetic, not live-validated policy"
            left_scope, right_scope = cell.left_scope, cell.right_scope
            if cell.comparison_type == "period_change":
                left_scope += " (current period)"
                right_scope += " (baseline period)"
            statement = (
                f"{qualification}: {left_scope} measured {cell.metric.value} "
                f"{cell.left_value} {cell.left_unit or ''}; "
                f"{right_scope} measured {cell.right_value} {cell.right_unit or ''}. "
                "This is not an overall winner or causal conclusion."
            )
            allowed.append(
                AllowedClaim(
                    claim_id=_stable_id("claim", [cell.comparison_id, statement]),
                    statement=statement,
                    evidence_refs=cell.evidence_refs,
                )
            )
        if not strict:
            prohibited.append(
                ProhibitedClaim(
                    statement=(
                        f"Declare a definitive {cell.metric.value} winner between "
                        f"{cell.left_scope} and {cell.right_scope}."
                    ),
                    reason=f"{cell.status.value}: {', '.join(cell.reasons)}",
                )
            )
    return allowed, prohibited
