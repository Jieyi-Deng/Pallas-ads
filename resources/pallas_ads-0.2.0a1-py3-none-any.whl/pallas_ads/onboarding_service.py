"""Account-first discovery, explicit selection and source inspection without a product profile."""

from __future__ import annotations

import json
import os
import re
from datetime import UTC, datetime, timedelta
from uuid import uuid4

from pallas_ads.adapter_service import AdapterService, _get
from pallas_ads.contracts.source import SourceConnectionConfig, SourceReadRequest
from pallas_ads.contracts.status import MissingInput, OperationEnvelope, OperationIssue
from pallas_ads.provider_setup import load_setup
from pallas_ads.query_planner import content_hash
from pallas_ads.source_state import SourceStateStore


def needs(code, message):
    return OperationEnvelope(
        operation="source_connect_or_import",
        status="needs_input",
        missing_inputs=[MissingInput(field_path="/source", reason=message)],
        issues=[OperationIssue(code=code, message=message)],
    )


class OnboardingService:
    def __init__(self, workspace, *, adapter=None, clock=lambda: datetime.now(UTC)):
        self.workspace = workspace
        self.store = SourceStateStore(workspace.layout.root)
        self.adapter = adapter or AdapterService(workspace)
        self.clock = clock

    def options(self):
        templates = {c.platform: c for c in load_setup(self.workspace).connections}
        connections = []
        if self.store.root.is_dir():
            for path in sorted(self.store.root.glob("connection_*.json")):
                if not re.fullmatch(r"connection_[a-z0-9][a-z0-9_-]*", path.stem):
                    continue
                c = self.store.load(path.stem)
                if c:
                    connections.append(
                        {
                            "connection_id": c.config.connection_id,
                            "platform": c.config.platform,
                            "state": c.state,
                            "selected_account_id": c.selected_account_id
                            or c.config.mcp_advertiser_id,
                        }
                    )
        return OperationEnvelope(
            operation="source_connect_or_import",
            status="complete",
            result={
                "providers": [
                    {
                        "platform": p,
                        "setup_status": "host_client_managed"
                        if p == "meta"
                        else "configured"
                        if p in templates or p == "tiktok"
                        else "operator_setup_required",
                    }
                    for p in ("meta", "google", "tiktok")
                ],
                "connections": connections,
                "meta_host": {
                    "endpoint": "https://mcp.facebook.com/ads",
                    "authorization_owner": "host_client",
                    "host_status": "unknown_use_host_mcp_settings",
                    "claude_code_auth": "verified_2026_09_14",
                    "codex_auth": "preregistered_client_supported_dcr_blocked_2026_09_14",
                    "analysis": "pending_test_account_adapter_validation",
                },
                "next_step": "connect_then_discover_accounts",
                "note": (
                    "Configured is not authorization or live permission validation. "
                    "Developer setup belongs to the operator."
                ),
            },
        )

    def connect_config(self, request):
        if request.config is not None:
            return request.config  # Existing explicit operator/canary path remains supported.
        platform = request.platform
        identifier = request.connection_id or "connection_" + uuid4().hex
        template = next(
            (c for c in load_setup(self.workspace).connections if c.platform == platform), None
        )
        if template is None and platform == "tiktok":
            template = SourceConnectionConfig(
                connection_id=identifier,
                platform="tiktok",
                transport="official_mcp",
                registered_redirect_uri="http://127.0.0.1:8767/callback",
            )
        if template is None:
            raise ValueError("operator_setup_required")
        return SourceConnectionConfig.model_validate(
            {**template.model_dump(mode="json"), "connection_id": identifier}
        )

    def _connection(self, identifier):
        if not identifier:
            raise ValueError("connection required")
        c = self.store.load(identifier)
        if c is None or c.state != "connected":
            raise ValueError("connection unavailable")
        return c

    def _read(
        self, c, mode, *, account=None, manager=None, period=None, max_pages=20, discovery=False
    ):
        return self.adapter.read(
            c.config.connection_id,
            SourceReadRequest(
                platform=c.config.platform,
                mode=mode,
                account_id=account,
                period=period,
                max_pages=max_pages,
                manager_account_id=manager,
                ignore_configured_manager=discovery and c.config.platform == "google",
            ),
        )

    def discover(self, request):
        c = self._connection(request.connection_id)
        reads, issues, choices = [], [], {}
        missing_inputs = []
        platform = c.config.platform.value

        def read(mode, account=None, manager=None):
            response = self._read(
                c,
                mode,
                account=account,
                manager=manager,
                max_pages=request.max_pages,
                discovery=True,
            )
            issues.extend(response.issues)
            missing_inputs.extend(response.missing_inputs)
            if response.result:
                reads.append(response.result)
                if not response.result.pagination_complete:
                    issues.append(
                        OperationIssue(
                            code="account_discovery_incomplete",
                            message="Account discovery incomplete.",
                        )
                    )
                return response.result
            issues.append(
                OperationIssue(
                    code="account_discovery_unavailable",
                    message="Unable to read account discovery.",
                )
            )
            return None

        def add(account, metadata, read_result, index, manager=None, google_client=False):
            if not isinstance(account, str) or not re.fullmatch(r"[0-9]{1,32}", account):
                raise ValueError("invalid discovered account")
            row = metadata
            if platform == "google":
                row = metadata.get("customerClient" if google_client else "customer", {})
                name, is_manager, test = (
                    row.get("descriptiveName"),
                    row.get("manager"),
                    row.get("testAccount"),
                )
                if type(is_manager) is not bool:
                    raise ValueError("account manager status missing")
            else:
                name, is_manager, test = row.get("name"), False, None
            if name is not None and (not isinstance(name, str) or len(name) > 512):
                raise ValueError("invalid account name")
            # Prefer the first verified route; never confuse token-owner MCC with access routing.
            if account not in choices:
                if len(choices) >= request.max_accounts:
                    issues.append(
                        OperationIssue(
                            code="account_limit_reached",
                            message="Discovery reached the configured account limit.",
                        )
                    )
                    return
                choice = {
                    "account_id": account,
                    "name": name,
                    "platform": platform,
                    "manager": is_manager,
                    "test_account": test,
                    "manager_account_id": manager,
                    "source_ref": f"adapter-read://{read_result.read_id}/records/{index}",
                }
                choice["choice_id"] = (
                    "choice_"
                    + content_hash(
                        {**choice, "revision": c.revision, "connection": request.connection_id}
                    )[7:31]
                )
                choices[account] = choice

        initial = read("capability_probe")
        if initial:
            roots = initial.records[: request.max_accounts]
            if len(initial.records) > len(roots):
                issues.append(
                    OperationIssue(
                        code="account_limit_reached",
                        message="Accessible account list exceeds limit.",
                    )
                )
            queue = []
            for index, row in enumerate(roots):
                if platform != "google":
                    add(row.account_id, row.metadata, initial, index)
                    continue
                context = read("account_context", row.account_id)
                if not context or len(context.records) != 1:
                    continue
                add(row.account_id, context.records[0].metadata, context, 0)
                if choices.get(row.account_id, {}).get("manager"):
                    queue.append((row.account_id, row.account_id))
            visited = set()
            while queue and len(visited) < request.max_accounts:
                account, route = queue.pop(0)
                if account in visited:
                    continue
                visited.add(account)
                hierarchy = read("account_hierarchy", account, route)
                if not hierarchy:
                    continue
                for index, row in enumerate(hierarchy.records):
                    add(row.account_id, row.metadata, hierarchy, index, route, True)
                    if (
                        _get(row.metadata, "customerClient.manager") is True
                        and row.account_id not in visited
                    ):
                        if len(queue) < request.max_accounts:
                            queue.append((row.account_id, route))
                        else:
                            issues.append(
                                OperationIssue(
                                    code="account_limit_reached",
                                    message="Manager traversal truncated.",
                                )
                            )
            if queue:
                issues.append(
                    OperationIssue(
                        code="account_limit_reached", message="Manager traversal truncated."
                    )
                )
        payload = {
            "connection_id": request.connection_id,
            "connection_revision": c.revision,
            "created_at": self.clock().isoformat(),
            "choices": list(choices.values()),
            "read_ids": [r.read_id for r in reads],
        }
        payload["content_hash"] = content_hash(payload)
        fd = self.store.lock(request.connection_id)
        try:
            current = self._connection(request.connection_id)
            if current.revision != c.revision:
                raise ValueError("connection changed during discovery")
            self.store._write(
                self.store._path(request.connection_id).with_suffix(".accounts.json"),
                json.dumps(payload, sort_keys=True),
            )
        finally:
            self.store.unlock(fd)
        return OperationEnvelope(
            operation="source_connect_or_import",
            status="partial_result" if issues else "complete",
            result={
                **payload,
                "reads": reads,
                "next_step": "select_account_by_name"
                if choices
                else "repair_account_discovery_no_browser_fallback",
            },
            issues=issues,
            missing_inputs=missing_inputs,
        )

    def select(self, request):
        fd = self.store.lock(request.connection_id)
        try:
            c = self._connection(request.connection_id)
            path = self.store._path(request.connection_id).with_suffix(".accounts.json")
            handle = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
            with os.fdopen(handle) as file:
                payload = json.loads(file.read(1_000_001))
            digest = payload.pop("content_hash")
            if content_hash(payload) != digest or payload["connection_id"] != request.connection_id:
                raise ValueError("invalid discovery receipt")
            if payload["connection_revision"] != c.revision:
                raise ValueError("stale discovery receipt")
            observed = datetime.fromisoformat(payload["created_at"])
            if (
                observed.tzinfo is None
                or not self.clock() - timedelta(hours=24) <= observed <= self.clock()
            ):
                raise ValueError("expired discovery receipt")
            choice = next(x for x in payload["choices"] if x["choice_id"] == request.choice_id)
            if choice["manager"]:
                return needs(
                    "select_advertising_account",
                    "Select an advertising account, not a manager account.",
                )
            c.selected_account_id = choice["account_id"]
            if c.config.transport == "official_mcp":
                c.config.mcp_advertiser_id = choice["account_id"]
            if c.config.platform == "google":
                c.config.login_customer_id = choice["manager_account_id"]
            c.revision += 1
            c.updated_at = self.clock()
            self.store.save(c)
            return OperationEnvelope(
                operation="source_connect_or_import",
                status="complete",
                result={
                    "connection_id": request.connection_id,
                    "account": choice,
                    "next_step": "inspect_before_profile",
                },
            )
        finally:
            self.store.unlock(fd)

    def inspect(self, request):
        if request.period and (request.period.end - request.period.start).days > 30:
            from pallas_ads.contracts.operations import ReportRequest
            from pallas_ads.observation_service import ObservationService

            return ObservationService(
                self.workspace, adapter=self.adapter, clock=self.clock
            ).analyze(
                ReportRequest(
                    action="analyze",
                    connection_id=request.connection_id,
                    period=request.period,
                    max_pages=request.max_pages,
                )
            )
        c = self._connection(request.connection_id)
        account = c.selected_account_id or c.config.mcp_advertiser_id
        if not account:
            return needs(
                "account_selection_required", "Discover accounts and choose one by name first."
            )
        reads, issues, facts, candidates = [], [], [], []
        modes = ["account_context", "entity_configuration"]
        if request.period:
            modes.append("traffic_performance")
        for mode in modes:
            response = self._read(
                c,
                mode,
                account=account,
                period=request.period if mode == "traffic_performance" else None,
                max_pages=request.max_pages,
            )
            issues.extend(response.issues)
            if response.result:
                reads.append(response.result)
            if not response.result or not response.result.pagination_complete:
                return OperationEnvelope(
                    operation="source_connect_or_import",
                    status="partial_result",
                    result={
                        "reads": reads,
                        "facts": facts,
                        "product_candidates": candidates,
                        "next_step": "repair_source_read_no_browser_fallback",
                    },
                    issues=issues
                    or [
                        OperationIssue(
                            code="source_read_incomplete", message="Source inspection incomplete."
                        )
                    ],
                )
            for index, row in enumerate(response.result.records):
                ref = f"adapter-read://{response.result.read_id}/records/{index}"
                if mode == "account_context":
                    for key in ("account_currency", "source_timezone"):
                        if row.metadata.get(key) is not None:
                            facts.append(
                                {
                                    "field": key,
                                    "value": row.metadata[key],
                                    "origin": "api",
                                    "source_ref": ref,
                                }
                            )
                    facts.append(
                        {
                            "field": "account_id",
                            "value": row.account_id,
                            "origin": "api",
                            "source_ref": ref,
                        }
                    )
                if mode == "entity_configuration":
                    name = (
                        _get(row.metadata, "campaign.name")
                        if c.config.platform == "google"
                        else row.metadata.get("campaign_name", row.metadata.get("name"))
                    )
                    app_id = row.metadata.get("app_id")
                    candidates.append(
                        {
                            "campaign_id": row.entity_id,
                            "campaign_name": name,
                            "app_id": app_id,
                            "source_ref": ref,
                            "identity_verified": False,
                        }
                    )
        if self._connection(request.connection_id).revision != c.revision:
            raise ValueError("connection changed during inspection")
        result = {
            "account_id": account,
            "reads": reads,
            "facts": facts,
            "product_candidates": candidates,
            "next_step": "ask_only_missing_or_ambiguous_product_facts_then_review",
            "missing_product_facts": [
                "confirmed_product_identity",
                "business_model",
                "business_goals",
            ],
            "canonical_imported": False,
        }
        if request.period:
            from pallas_ads.source_analysis import analyze_traffic

            currency = next((f["value"] for f in facts if f["field"] == "account_currency"), None)
            timezone = next((f["value"] for f in facts if f["field"] == "source_timezone"), None)
            if currency and timezone:
                result["traffic_analysis"] = analyze_traffic(reads[-1], currency, timezone)
        from pallas_ads.contracts.source import SourceReadRequest
        from pallas_ads.observation_context import resolve_context

        context_reads = list(reads)
        kinds = ["optimization", "creative"] + (["apps"] if c.config.platform == "tiktok" else [])
        for kind in kinds if candidates else []:
            response = self.adapter.read(
                request.connection_id,
                SourceReadRequest(
                    platform=c.config.platform,
                    mode="entity_configuration",
                    account_id=account,
                    context_kind=kind,
                    max_pages=request.max_pages,
                ),
            )
            issues.extend(response.issues)
            if response.result:
                context_reads.append(response.result)
        resolution = resolve_context(self.workspace, c, context_reads)
        result["context"] = resolution
        resolved_by_campaign = {p["campaign_id"]: p for p in resolution["product_resolution"]}
        for candidate in candidates:
            identity = resolved_by_campaign.get(candidate["campaign_id"], {})
            candidate["identity_status"] = identity.get("status", "unresolved")
            candidate["identity_verified"] = any(
                m["evidence"] == "api_store_identity_and_confirmed_binding"
                for m in identity.get("matches", [])
            )
        unresolved = [p for p in resolution["product_resolution"] if p["status"] != "resolved"]
        result["missing_product_facts"] = (
            ["confirm_unresolved_product_or_business_facts"]
            if unresolved or not resolution["product_resolution"]
            else []
        )
        if not unresolved and resolution["product_resolution"]:
            result["next_step"] = "use_resolved_context_or_analyze"
        if unresolved or not resolution["product_resolution"]:
            issues.append(
                OperationIssue(
                    code="product_context_requires_confirmation",
                    severity="warning",
                    message=(
                        "API identity checks completed; confirm only unresolved "
                        "identities or business facts."
                    ),
                )
            )
        if self._connection(request.connection_id).revision != c.revision:
            raise ValueError("connection changed during context resolution")
        return OperationEnvelope(
            operation="source_connect_or_import",
            status="partial_result" if issues else "complete",
            result=result,
            issues=issues,
        )
