"""Validated, content-addressed and offline report packages with no-overwrite publication."""

from __future__ import annotations

import hashlib
import json
import os
import re
import shutil
import stat
import tempfile
from datetime import UTC, datetime
from pathlib import Path

from pallas_ads.analysis_service import AnalysisService, validate_contract, validate_draft
from pallas_ads.briefing import build_document
from pallas_ads.contracts.delivery import (
    AgentAnalysisContract,
    AgentAnalysisDraft,
    BriefingDocument,
    ReportManifest,
    ReportResult,
)
from pallas_ads.contracts.status import MissingInput, OperationEnvelope, OperationIssue
from pallas_ads.evidence_store import EvidenceStoreError
from pallas_ads.local_state import WorkspaceRepository
from pallas_ads.query_planner import content_hash
from pallas_ads.report_rendering import render_html, render_markdown

RENDERER_VERSION = "1.0.0"
ARTIFACT_NAMES = frozenset(
    {
        "evidence.json",
        "analysis_contract.json",
        "analysis.json",
        "briefing.json",
        "report.md",
        "report.html",
        "chat.md",
    }
)


class ReportStoreError(ValueError):
    """An incomplete, corrupt or conflicting report must be inspected, never overwritten."""


def _json(model) -> bytes:
    return (
        json.dumps(model.model_dump(mode="json"), ensure_ascii=False, indent=2, sort_keys=True)
        + "\n"
    ).encode("utf-8")


def _hash(value: bytes) -> str:
    return "sha256:" + hashlib.sha256(value).hexdigest()


def _report_id(contract: AgentAnalysisContract, draft: AgentAnalysisDraft) -> str:
    return (
        "report_"
        + content_hash([contract.contract_id, draft.model_dump(mode="json"), RENDERER_VERSION])[7:]
    )


def _read(path: Path) -> bytes:
    descriptor = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    with os.fdopen(descriptor, "rb") as handle:
        if not stat.S_ISREG(os.fstat(handle.fileno()).st_mode):
            raise ReportStoreError("report artifact must be a regular file")
        return handle.read()


class ReportService:
    def __init__(self, workspace: WorkspaceRepository) -> None:
        self.workspace = workspace
        self.analysis = AnalysisService(workspace)

    def build(
        self,
        packet_id: str,
        *,
        monitor_run_ids: list[str] | None = None,
        draft: AgentAnalysisDraft | None = None,
    ) -> OperationEnvelope[ReportResult]:
        prepared = self.analysis.prepare(packet_id, monitor_run_ids=monitor_run_ids)
        if prepared.result is None:
            return OperationEnvelope(
                operation="build_report",
                status="needs_input",
                missing_inputs=prepared.missing_inputs,
            )
        try:
            contract = prepared.result
            if draft is None:
                draft = AgentAnalysisDraft(
                    contract_id=contract.contract_id,
                    check_ids=[o.option_id for o in contract.options if o.kind == "check"],
                )
            else:
                draft = AgentAnalysisDraft.model_validate(draft.model_dump(mode="json"))
            validate_draft(contract, draft)
            document = build_document(contract, draft)
            report_id = _report_id(contract, draft)
            packet = contract.evidence.comparison.packet
            target = self._directory(packet.scope.product_id, report_id)
            if target.exists() or target.is_symlink():
                return self.load(packet.scope.product_id, report_id)
            target.parent.mkdir(parents=True, exist_ok=True)
            lock = target.parent / f".{report_id}.lock"
            # Cooperating writers use an exclusive directory; a crash leaves an explicit lock,
            # never permission to overwrite a partially published report.
            lock.mkdir()
            temporary: Path | None = None
            try:
                if target.exists() or target.is_symlink():
                    return self.load(packet.scope.product_id, report_id)
                temporary = Path(tempfile.mkdtemp(prefix=".report-", dir=target.parent))
                markdown = render_markdown(document).encode("utf-8")
                artifacts = {
                    "evidence.json": _json(contract.evidence),
                    "analysis_contract.json": _json(contract),
                    "analysis.json": _json(draft),
                    "briefing.json": _json(document),
                    "report.md": markdown,
                    "chat.md": markdown,
                    "report.html": render_html(document).encode("utf-8"),
                }
                manifest = ReportManifest(
                    report_id=report_id,
                    product_id=packet.scope.product_id,
                    contract_id=contract.contract_id,
                    packet_id=packet.packet_id,
                    monitor_run_ids=[r.run_id for r in contract.evidence.monitor_runs],
                    profile_revision=contract.evidence.comparison.plan.profile_revision,
                    data_revision=contract.evidence.comparison.plan.data_revision,
                    created_at=datetime.now(UTC),
                    status=document.status,
                    artifact_hashes={name: _hash(value) for name, value in artifacts.items()},
                )
                for name, value in {**artifacts, "manifest.json": _json(manifest)}.items():
                    with (temporary / name).open("xb") as handle:
                        handle.write(value)
                        handle.flush()
                        os.fsync(handle.fileno())
                os.rename(temporary, target)
                temporary = None
            finally:
                if temporary is not None:
                    shutil.rmtree(temporary)
                lock.rmdir()
            return self.load(packet.scope.product_id, report_id)
        except (ValueError, OSError, EvidenceStoreError):
            return _needs("build_report")

    def _directory(self, product_id: str, report_id: str) -> Path:
        if (
            re.fullmatch(r"prod_[a-z0-9][a-z0-9_-]*", product_id) is None
            or re.fullmatch(r"report_[a-f0-9]{64}", report_id) is None
        ):
            raise ReportStoreError("invalid report identifier")
        root = self.workspace.layout.reports_dir
        if root.is_symlink() or (root / product_id).is_symlink():
            raise ReportStoreError("report directories cannot be symbolic links")
        return root / product_id / report_id

    def load(self, product_id: str, report_id: str) -> OperationEnvelope[ReportResult]:
        """Replay a portable package without reading the current profile, data or event state."""
        try:
            directory = self._directory(product_id, report_id)
            if directory.is_symlink() or not directory.is_dir():
                raise ReportStoreError("report directory unavailable")
            manifest = ReportManifest.model_validate_json(_read(directory / "manifest.json"))
            if set(manifest.artifact_hashes) != ARTIFACT_NAMES:
                raise ReportStoreError("report file inventory mismatch")
            artifacts = {name: _read(directory / name) for name in ARTIFACT_NAMES}
            if any(
                _hash(value) != manifest.artifact_hashes[name] for name, value in artifacts.items()
            ):
                raise ReportStoreError("report artifact hash mismatch")
            contract = AgentAnalysisContract.model_validate_json(
                artifacts["analysis_contract.json"]
            )
            draft = AgentAnalysisDraft.model_validate_json(artifacts["analysis.json"])
            document = BriefingDocument.model_validate_json(artifacts["briefing.json"])
            validate_contract(contract)
            validate_draft(contract, draft)
            plan = contract.evidence.comparison.plan
            packet = contract.evidence.comparison.packet
            if (
                manifest.report_id != report_id
                or _report_id(contract, draft) != report_id
                or manifest.product_id != product_id
                or packet.scope.product_id != product_id
                or manifest.contract_id != contract.contract_id
                or manifest.packet_id != packet.packet_id
                or manifest.profile_revision != plan.profile_revision
                or manifest.data_revision != plan.data_revision
                or manifest.monitor_run_ids != [r.run_id for r in contract.evidence.monitor_runs]
                or manifest.status != document.status
            ):
                raise ReportStoreError("report manifest linkage mismatch")
            if artifacts["evidence.json"] != _json(contract.evidence) or document != build_document(
                contract, draft
            ):
                raise ReportStoreError("report evidence or canonical document mismatch")
            if (
                artifacts["report.md"] != render_markdown(document).encode("utf-8")
                or artifacts["chat.md"] != artifacts["report.md"]
                or artifacts["report.html"] != render_html(document).encode("utf-8")
            ):
                raise ReportStoreError("rendered report differs from its canonical document")
            result = ReportResult(manifest=manifest, directory=str(directory))
            return OperationEnvelope(
                operation="build_report",
                status=manifest.status,
                result=result,
                issues=[
                    OperationIssue(
                        code="partial_briefing",
                        severity="warning",
                        message="The report retains missing or unknown scopes; "
                        "qualified evidence is available.",
                    )
                ]
                if manifest.status == "partial_result"
                else [],
            )
        except (ValueError, OSError, EvidenceStoreError):
            return _needs("load_report")


def _needs(operation: str) -> OperationEnvelope[ReportResult]:
    return OperationEnvelope(
        operation=operation,
        status="needs_input",
        missing_inputs=[
            MissingInput(
                field_path="/report",
                reason="Report inputs or immutable storage could not be validated. "
                "Inspect evidence, analysis references and local report files "
                "without overwriting history.",
            )
        ],
    )
