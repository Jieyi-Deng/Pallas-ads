"""Immutable, content-checked local persistence for resolved analysis evidence."""

from __future__ import annotations

import hashlib
import json
import os
import re
import stat
import tempfile
from pathlib import Path
from typing import Any

from pydantic import Field

from pallas_ads.contracts.analysis import ResolvedQueryPlan
from pallas_ads.contracts.base import ContractModel
from pallas_ads.contracts.evidence import EvidencePacket


class EvidenceStoreError(RuntimeError):
    """An evidence artifact is invalid, corrupted, or conflicts with durable history."""


class _EvidenceArtifact(ContractModel):
    plan: ResolvedQueryPlan
    packet: EvidencePacket
    content_hash: str = Field(pattern=r"^sha256:[a-f0-9]{64}$")


def _canonical_json(value: dict[str, Any]) -> str:
    return json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    )


def _content_hash(payload: dict[str, Any]) -> str:
    return "sha256:" + hashlib.sha256(_canonical_json(payload).encode("utf-8")).hexdigest()


def _validate_linkage(plan: ResolvedQueryPlan, packet: EvidencePacket) -> None:
    if _content_hash(plan.model_dump(mode="json", exclude={"plan_hash"})) != plan.plan_hash:
        raise EvidenceStoreError("resolved query plan content hash does not match")
    if packet.lineage.query_plan_hashes != [plan.plan_hash]:
        raise EvidenceStoreError("packet must reference exactly its resolved query plan")
    if packet.lineage.data_revision != plan.data_revision:
        raise EvidenceStoreError("packet and plan data revisions do not match")
    if packet.lineage.profile_revision != plan.profile_revision:
        raise EvidenceStoreError("packet and plan profile revisions do not match")
    if packet.lineage.profile_hash != plan.profile_hash:
        raise EvidenceStoreError("packet and plan profile hashes do not match")
    if packet.lineage.query_id != plan.query.query_id:
        raise EvidenceStoreError("packet and plan query IDs do not match")
    if packet.scope.product_id != plan.query.product_id:
        raise EvidenceStoreError("packet and plan products do not match")
    if set(packet.scope.platforms) != set(plan.query.platforms):
        raise EvidenceStoreError("packet and plan selected platforms do not match")
    if packet.scope.period != plan.period or packet.scope.baseline != plan.baseline:
        raise EvidenceStoreError("packet and plan resolved date ranges do not match")


class EvidenceStore:
    """Store one validated plan/packet envelope per immutable packet identifier.

    A temporary file is fully written before its hard link is published. An existing
    artifact is never overwritten, including during concurrent identical saves.
    """

    def __init__(self, root: Path) -> None:
        self.root = Path(root)

    def save(self, plan: ResolvedQueryPlan, packet: EvidencePacket) -> Path:
        # Round-trip validates nested values even if callers mutated model lists/dicts.
        try:
            plan_copy = ResolvedQueryPlan.model_validate(plan.model_dump(mode="json"))
            packet_copy = EvidencePacket.model_validate(packet.model_dump(mode="json"))
        except (ValueError, TypeError) as error:
            raise EvidenceStoreError("plan or packet contract validation failed") from error
        _validate_linkage(plan_copy, packet_copy)
        path = self._artifact_path(packet_copy.packet_id)
        payload = {
            "plan": plan_copy.model_dump(mode="json"),
            "packet": packet_copy.model_dump(mode="json"),
        }
        artifact = _EvidenceArtifact(
            plan=plan_copy,
            packet=packet_copy,
            content_hash=_content_hash(payload),
        )
        serialized = _canonical_json(artifact.model_dump(mode="json")) + "\n"
        temporary_path: Path | None = None
        try:
            self.root.mkdir(parents=True, exist_ok=True)
            descriptor, temporary_name = tempfile.mkstemp(
                prefix=".evidence-", suffix=".tmp", dir=self.root
            )
            temporary_path = Path(temporary_name)
            with os.fdopen(descriptor, "w", encoding="utf-8") as temporary:
                temporary.write(serialized)
                temporary.flush()
                os.fsync(temporary.fileno())
            try:
                os.link(temporary_path, path, follow_symlinks=False)
            except FileExistsError:
                existing = self._read_artifact(packet_copy.packet_id)
                if existing != artifact:
                    raise EvidenceStoreError(
                        "packet ID already exists with different content; history was not changed"
                    ) from None
            return path
        except OSError as error:
            raise EvidenceStoreError("could not publish immutable evidence artifact") from error
        finally:
            if temporary_path is not None:
                temporary_path.unlink(missing_ok=True)

    def load(self, packet_id: str) -> tuple[ResolvedQueryPlan, EvidencePacket]:
        """Read and validate durable content, returning fresh model instances each time."""

        artifact = self._read_artifact(packet_id)
        return artifact.plan, artifact.packet

    def _artifact_path(self, packet_id: str) -> Path:
        if re.fullmatch(r"evidence_[a-z0-9][a-z0-9_-]*", packet_id) is None:
            raise EvidenceStoreError("invalid evidence packet identifier")
        return self.root / f"{packet_id}.json"

    def _read_artifact(self, packet_id: str) -> _EvidenceArtifact:
        path = self._artifact_path(packet_id)
        try:
            # Do not follow a replaced artifact into an unrelated local file.
            descriptor = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
            with os.fdopen(descriptor, "r", encoding="utf-8") as source:
                if not stat.S_ISREG(os.fstat(source.fileno()).st_mode):
                    raise EvidenceStoreError("evidence artifact must be a regular file")
                raw = json.load(source)
            artifact = _EvidenceArtifact.model_validate(raw)
        except (OSError, UnicodeError, ValueError) as error:
            raise EvidenceStoreError("evidence artifact is unavailable or invalid") from error
        if artifact.packet.packet_id != packet_id:
            raise EvidenceStoreError("evidence artifact packet identifier does not match its path")
        payload = artifact.model_dump(mode="json", exclude={"content_hash"})
        if _content_hash(payload) != artifact.content_hash:
            raise EvidenceStoreError("evidence artifact content hash does not match")
        _validate_linkage(artifact.plan, artifact.packet)
        return artifact
