"""Closed TikTok campaign/daily reporting over the official, pinned MCP transport.

Tool schemas are checked at discovery, never used to select arbitrary tools or arguments.
No successful public-doc lookup or synthetic fixture is a live capability certification.
"""

from __future__ import annotations

import json
import re
from uuid import uuid4

from pallas_ads.adapter_plans import plan_read
from pallas_ads.adapter_service import _pages, _record
from pallas_ads.contracts.source import SourceReadRequest, SourceReadResult
from pallas_ads.contracts.status import OperationEnvelope, OperationIssue
from pallas_ads.query_planner import content_hash
from pallas_ads.source_redaction import redact
from pallas_ads.source_transport import SourceHTTPError
from pallas_ads.tiktok_mcp_auth import MCP_RESOURCE
from pallas_ads.tiktok_mcp_client import TikTokMCPClient, read_mcp_account

MODES = {
    "capability_probe": "auth_advertiser_get",
    "entity_configuration": "campaign_get",
    "traffic_performance": "report_integrated_get",
    "conversion_performance": "report_integrated_get",
}


def report_plan(request):
    request = SourceReadRequest.model_validate(request.model_dump(mode="json"))
    if request.platform != "tiktok" or request.mode not in MODES:
        raise SourceHTTPError("mcp_read_scope_not_allowed")
    native = plan_read(request)
    arguments = dict(native.parameters)
    # Native GET serializes containers; MCP accepts typed JSON containers.
    for key in ("fields", "dimensions", "metrics", "filtering"):
        if key in arguments:
            value = arguments[key]
            assert isinstance(value, str)
            arguments[key] = json.loads(value)
    if request.mode == "entity_configuration" and not request.context_kind:
        fields = arguments["fields"]
        assert isinstance(fields, list)
        arguments["fields"] = fields + ["app_id", "app_promotion_type", "sales_destination"]
    if request.period or request.query_lifetime:
        arguments["service_type"] = "AUCTION"
    name = {"optimization": "adgroup_get", "creative": "ad_get", "apps": "app_list_get"}.get(
        request.context_kind, MODES[request.mode]
    )
    body = {"name": name, "arguments": arguments}
    return native.model_copy(
        update=dict(
            plan_id="mcp_plan_"
            + content_hash(
                {"request": request.model_dump(mode="json"), "body": body, "resource": MCP_RESOURCE}
            ).removeprefix("sha256:"),
            transport="official_mcp",
            method="POST",
            endpoint=MCP_RESOURCE,
            parameters={},
            body=body,
        )
    )


def _accepts(schema, value):
    """Conservative schema compatibility for the fixed request, including nullable types."""
    if not isinstance(schema, dict):
        return False
    if "anyOf" in schema:
        return any(_accepts(s, value) for s in schema["anyOf"])
    kind = schema.get("type")
    expected = (
        "object"
        if isinstance(value, dict)
        else "array"
        if isinstance(value, list)
        else "string"
        if isinstance(value, str)
        else "boolean"
        if type(value) is bool
        else "integer"
        if type(value) is int
        else None
    )
    # JSON Schema number includes integer values. Keep outgoing page numbers integral.
    if expected == "integer" and (kind == "number" or isinstance(kind, list) and "number" in kind):
        kind = "integer"
    if expected is None or (kind != expected and not isinstance(kind, list)):
        return False
    if isinstance(kind, list) and expected not in kind:
        return False
    if "enum" in schema and value not in schema["enum"]:
        return False
    if "const" in schema and value != schema["const"]:
        return False
    if expected == "array":
        return all(_accepts(schema.get("items", {}), item) for item in value)
    if expected == "object":
        properties, required = schema.get("properties", {}), schema.get("required", [])
        if not isinstance(properties, dict) or not isinstance(required, list):
            return False
        if not set(required).issubset(value):
            return False
        return all(
            _accepts(properties[k], v)
            if k in properties
            else schema.get("additionalProperties", True) is True
            for k, v in value.items()
        )
    if expected == "integer":
        return schema.get("minimum", value) <= value <= schema.get("maximum", value)
    return True


class TikTokReportClient(TikTokMCPClient):
    def __init__(self, transport, access_token, *, request):
        self.plan = report_plan(request)
        self._call_spec = json.dumps(self.plan.body, sort_keys=True)
        super().__init__(transport, access_token, advertiser_id=self.plan.request.account_id)
        self._page = 1

    def _allowed_call(self, params):
        expected = json.loads(self._call_spec)
        if (
            self.plan.request.mode != "capability_probe"
            and self.plan.request.context_kind != "apps"
        ):
            expected = {**expected, "arguments": {**expected["arguments"], "page": self._page}}
        # JSON comparison distinguishes true from 1, unlike Python dict equality.
        return json.dumps(params, sort_keys=True) == json.dumps(expected, sort_keys=True)

    def discover(self):
        self._initialize()
        cursor, seen = None, set()
        for _ in range(10):
            result = self._rpc("tools/list", {"cursor": cursor} if cursor else {})
            self.tool_discovery_pages += 1
            catalog = result.get("tools")
            if (
                not isinstance(catalog, list)
                or len(catalog) > 1000
                or any(not isinstance(t, dict) for t in catalog)
            ):
                raise SourceHTTPError("mcp_tools_invalid")
            matches = [t for t in catalog if t.get("name") == self.plan.body["name"]]
            if len(matches) > 1:
                raise SourceHTTPError("mcp_tool_ambiguous")
            if matches:
                tool = matches[0]
                schema = tool.get("inputSchema", {})
                self.tool_schema_hash = content_hash(schema)
                if (
                    tool.get("annotations", {}).get("readOnlyHint") is False
                    or not set(self.plan.body["arguments"]).issubset(schema.get("properties", {}))
                    or not _accepts(schema, self.plan.body["arguments"])
                ):
                    raise SourceHTTPError("mcp_tool_schema_changed")
                self._schema = schema
                self.tool_schema_hash = content_hash(schema)
                return
            cursor = result.get("nextCursor")
            if not cursor:
                raise SourceHTTPError("mcp_report_tool_unavailable")
            if not isinstance(cursor, str) or len(cursor) > 2048 or cursor in seen:
                raise SourceHTTPError("mcp_tool_pagination_invalid")
            seen.add(cursor)
        raise SourceHTTPError("mcp_tool_page_limit")

    def read_page(self, page):
        if type(page) is not int or not 1 <= page <= self.plan.request.max_pages:
            raise SourceHTTPError("mcp_read_scope_not_allowed")
        self._page = page
        body = json.loads(self._call_spec)
        if (
            self.plan.request.mode != "capability_probe"
            and self.plan.request.context_kind != "apps"
        ):
            body["arguments"]["page"] = page
        if not _accepts(self._schema, body["arguments"]):
            raise SourceHTTPError("mcp_tool_schema_changed")
        result = self._rpc("tools/call", body)
        if result.get("isError", False) is not False:
            raise SourceHTTPError("mcp_tool_failed")
        payload = result.get("structuredContent")
        if payload is None:
            content = result.get("content")
            if (
                not isinstance(content, list)
                or len(content) != 1
                or not isinstance(content[0], dict)
                or content[0].get("type") != "text"
            ):
                raise SourceHTTPError("mcp_tool_result_invalid")
            payload = json.loads(content[0]["text"])
        if (
            not isinstance(payload, dict)
            or type(payload.get("code")) is not int
            or not 0 <= payload["code"] <= 2147483647
        ):
            raise SourceHTTPError("mcp_tool_result_invalid")
        if payload["code"]:
            raise SourceHTTPError(f"mcp_provider_error_{payload['code']}")
        if self.plan.request.context_kind == "apps":
            data = payload.get("data", {})
            rows = data.get("apps") if isinstance(data, dict) else None
            if (
                not isinstance(rows, list)
                or len(rows) > 10000
                or data.get("page_info")
                or data.get("next_cursor")
            ):
                raise SourceHTTPError("response_schema_changed")
            clean = []
            for row in rows:
                if not isinstance(row, dict) or row.get("advertiser_id") != self._advertiser_id:
                    raise SourceHTTPError("response_scope_mismatch")
                clean.append(
                    {
                        k: row.get(k)
                        for k in (
                            "advertiser_id",
                            "app_id",
                            "app_platform_id",
                            "app_name",
                            "download_url",
                            "package_name",
                            "platform",
                        )
                    }
                )
            return {
                "code": 0,
                "data": {"list": clean, "page_info": {"page": 1, "total_page": 1}},
            }, None
        if self.plan.request.mode == "capability_probe":
            data = payload.get("data", {})
            rows = data.get("list") if isinstance(data, dict) else None
            if not isinstance(rows, list) or len(rows) > 10000:
                raise SourceHTTPError("response_schema_changed")
            if data.get("page_info") or data.get("next_cursor"):
                raise SourceHTTPError("mcp_discovery_pagination_unsupported")
            clean = []
            for row in rows:
                if not isinstance(row, dict) or not isinstance(row.get("advertiser_id"), str):
                    raise SourceHTTPError("response_schema_changed")
                if not re.fullmatch(r"[0-9]{1,32}", row["advertiser_id"]):
                    raise SourceHTTPError("response_schema_changed")
                name = row.get("advertiser_name", row.get("name"))
                if name is not None and (not isinstance(name, str) or len(name) > 512):
                    raise SourceHTTPError("response_schema_changed")
                clean.append({"advertiser_id": row["advertiser_id"], "name": name})
            return {
                "code": 0,
                "data": {"list": clean, "page_info": {"page": 1, "total_page": 1}},
            }, None
        rows, cursor = _pages("tiktok", self.plan.request.mode, payload)
        info = payload["data"]["page_info"]
        if (
            type(info.get("page")) is not int
            or info["page"] != page
            or type(info.get("total_page")) is not int
            or len(rows) > 100
            or (info["total_page"] == 0 and rows)
        ):
            raise SourceHTTPError("pagination_schema_changed")
        # Retain only requested fields; never descriptions, contact details or instructions.
        clean = []
        for row in rows:
            if "advertiser_id" in row and str(row["advertiser_id"]) != self._advertiser_id:
                raise SourceHTTPError("response_scope_mismatch")
            if self.plan.request.period or self.plan.request.query_lifetime:
                if not isinstance(row.get("dimensions"), dict) or not isinstance(
                    row.get("metrics"), dict
                ):
                    raise SourceHTTPError("response_schema_changed")
                dimensions = row["dimensions"]
                if set(dimensions) != set(body["arguments"]["dimensions"]):
                    raise SourceHTTPError("response_grain_mismatch")
                if not self.plan.request.query_lifetime and (
                    not isinstance(dimensions.get("stat_time_day"), str)
                    or not re.fullmatch(
                        r"[0-9]{4}-[0-9]{2}-[0-9]{2}( 00:00:00)?", dimensions["stat_time_day"]
                    )
                ):
                    raise SourceHTTPError("response_date_invalid")
                clean.append(
                    {
                        "dimensions": {
                            k: row["dimensions"].get(k) for k in body["arguments"]["dimensions"]
                        },
                        "metrics": {k: row["metrics"].get(k) for k in body["arguments"]["metrics"]},
                    }
                )
            else:
                clean.append({k: row.get(k) for k in body["arguments"]["fields"]})
        return {
            "code": 0,
            "data": {"list": clean, "page_info": {"page": page, "total_page": info["total_page"]}},
        }, cursor


def read_mcp(service, connection, request, tokens):
    if request.mode != "capability_probe" and (
        not connection.config.mcp_advertiser_id
        or request.account_id != connection.config.mcp_advertiser_id
    ):
        raise SourceHTTPError("mcp_read_scope_not_allowed")
    if request.mode == "account_context":
        return read_mcp_account(service, connection, request, tokens)
    client = TikTokReportClient(
        service.transport, tokens.access_token.get_secret_value(), request=request
    )
    pages, records, issues, seen = [], [], [], set()
    complete = False
    total_pages = None
    secrets = tuple(v.get_secret_value() for v in (tokens.access_token, tokens.refresh_token) if v)
    try:
        client.discover()
        for page in range(1, request.max_pages + 1):
            payload, cursor = client.read_page(page)
            reported_total = payload["data"]["page_info"]["total_page"]
            if total_pages is not None and reported_total != total_pages:
                raise SourceHTTPError("pagination_changed_during_read")
            total_pages = reported_total
            payload = redact(payload, secrets + ((client._session,) if client._session else ()))
            pages.append(
                {
                    **payload,
                    "transport": "official_mcp",
                    "protocol_version": client.protocol_version,
                    "stateless_compatibility": client.protocol_version is None,
                    "tool_schema_hash": client.tool_schema_hash,
                    "tool_discovery_pages": client.tool_discovery_pages,
                }
            )
            # Any invalid or repeated row prevents a canonical import of this read.
            for row in payload["data"]["list"]:
                record = _record(client.plan, row)
                key = (
                    record.account_id,
                    record.entity_id,
                    record.event_date,
                    record.metadata.get("audience_segment"),
                )
                if key in seen:
                    raise SourceHTTPError("duplicate_source_scope")
                seen.add(key)
                records.append(record)
            if cursor is None:
                complete = True
                break
        if not complete:
            raise SourceHTTPError("page_limit_reached")
    except (ValueError, TypeError, AttributeError, KeyError) as error:
        issues.append(
            OperationIssue(
                code=error.code if isinstance(error, SourceHTTPError) else "mcp_response_invalid",
                message="TikTok MCP read incomplete; inspect source scope and tool compatibility.",
                retriable=isinstance(error, SourceHTTPError) and error.retriable,
            )
        )
    if issues and not pages:
        # Retain diagnostic metadata even when schema validation stops before tools/call.
        # This is not a report page and must not increment pages_received.
        diagnostic = {
            "transport": "official_mcp",
            "tool_schema_hash": client.tool_schema_hash,
            "error_codes": [i.code for i in issues],
            "kind": "pre_call_diagnostic",
        }
    else:
        diagnostic = None
    warnings = sorted({w for r in records for w in r.warnings} | {i.code for i in issues})
    if warnings:
        issues.append(
            OperationIssue(
                code="source_semantics_unverified",
                severity="warning",
                message="Source fields, goals, maturity or conversion semantics are unverified.",
            )
        )
    result = SourceReadResult(
        read_id="read_" + uuid4().hex,
        plan=client.plan,
        observed_at=service.clock(),
        records=records,
        pages_received=len(pages),
        pagination_complete=complete,
        warnings=warnings,
    )
    if service.raw_retention_days:
        result.artifact_path = service._retain(result, pages + ([diagnostic] if diagnostic else []))
    return OperationEnvelope(
        operation="source_read",
        status="partial_result" if issues or warnings else "complete",
        result=result,
        issues=issues,
    )
