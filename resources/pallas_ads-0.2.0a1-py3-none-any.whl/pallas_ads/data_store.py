"""DuckDB persistence for source, entity, observation, and data revisions."""

from __future__ import annotations

import hashlib
import json
from datetime import UTC, datetime, timedelta
from decimal import Decimal
from typing import Any

import duckdb
from pydantic import BaseModel

from pallas_ads.contracts.common import MediaPlatform, ReportingTimeBasis
from pallas_ads.contracts.data import (
    CanonicalEntityRecord,
    CanonicalImportManifest,
    CanonicalImportResult,
    CanonicalObservationRecord,
    EntitySnapshot,
    ObservationRevision,
    SourceSnapshot,
)
from pallas_ads.local_state import WorkspaceRepository


class CanonicalDataError(RuntimeError):
    """Raised when persisted canonical data would violate revision identity."""


def _validate_read_cutoff(as_of_data_revision: int | None, as_of: datetime | None) -> None:
    if as_of_data_revision is not None and as_of is not None:
        raise ValueError("select either as_of_data_revision or as_of, not both")
    if as_of_data_revision is not None and (
        isinstance(as_of_data_revision, bool)
        or not isinstance(as_of_data_revision, int)
        or as_of_data_revision < 0
    ):
        raise ValueError("as_of_data_revision must be a nonnegative integer")
    if as_of is not None and (as_of.tzinfo is None or as_of.utcoffset() is None):
        raise ValueError("as_of must be a timezone-aware datetime")


def _json_default(value: object) -> str:
    if isinstance(value, Decimal):
        return str(value)
    raise TypeError(f"unsupported canonical JSON value: {type(value).__name__}")


def _canonical_json(value: BaseModel | dict[str, Any]) -> str:
    payload = value.model_dump(mode="json") if isinstance(value, BaseModel) else value
    return json.dumps(
        payload,
        ensure_ascii=False,
        separators=(",", ":"),
        sort_keys=True,
        default=_json_default,
    )


def _hash_payload(value: BaseModel | dict[str, Any]) -> str:
    if (
        isinstance(value, CanonicalObservationRecord)
        and value.reporting_time_basis is ReportingTimeBasis.UNKNOWN
    ):
        # Preserve the identity/content hash of pre-refinement, explicitly unverified data.
        value = value.model_dump(mode="json", exclude={"reporting_time_basis"})
    if isinstance(value, CanonicalEntityRecord) and value.objective_native is None:
        # Preserve pre-Week-5 entity hashes when objective evidence was not supplied.
        value = value.model_dump(mode="json", exclude={"objective_native"})
    digest = hashlib.sha256(_canonical_json(value).encode("utf-8")).hexdigest()
    return f"sha256:{digest}"


def _observation_key(
    product_id: str,
    platform: MediaPlatform,
    account_id: str,
    record: CanonicalObservationRecord,
) -> str:
    identity = {
        "product_id": product_id,
        "platform": platform.value,
        "account_id": account_id,
        "entity_type": record.entity_type.value,
        "entity_id": record.entity_id,
        "app_variant_id": record.app_variant_id,
        "event_date": record.event_date.isoformat(),
        "country": record.country.model_dump(mode="json"),
        "os": record.os.model_dump(mode="json"),
        "campaign_type_native": record.campaign_type_native,
        "campaign_type": record.campaign_type.model_dump(mode="json"),
        "optimization_goal_native": record.optimization_goal_native,
        "optimization_goal": record.optimization_goal.model_dump(mode="json"),
        "attribution_spec": (
            record.attribution_spec.model_dump(mode="json")
            if record.attribution_spec is not None
            else None
        ),
        "metric_key": record.metric_key.value,
        "metric_semantic_version": record.metric_semantic_version,
        "currency": record.currency,
        "source_timezone": record.source_timezone,
    }
    if record.reporting_time_basis is not ReportingTimeBasis.UNKNOWN:
        identity["reporting_time_basis"] = record.reporting_time_basis.value
    return f"observation_{_hash_payload(identity).removeprefix('sha256:')[:32]}"


class CanonicalDataRepository:
    """Append-only revision storage over an initialized workspace repository."""

    def __init__(self, workspace: WorkspaceRepository) -> None:
        self.workspace = workspace

    def source_snapshot(self, source_snapshot_id: str) -> SourceSnapshot | None:
        with duckdb.connect(str(self.workspace.layout.database_file), read_only=True) as connection:
            row = connection.execute(
                "SELECT snapshot_json FROM source_snapshots WHERE source_snapshot_id = ?",
                [source_snapshot_id],
            ).fetchone()
        return SourceSnapshot.model_validate_json(row[0]) if row is not None else None

    def entity_snapshot(self, entity_snapshot_id: str) -> EntitySnapshot | None:
        """Read an immutable entity revision for an evidence-backed report export."""
        with duckdb.connect(str(self.workspace.layout.database_file), read_only=True) as connection:
            row = connection.execute(
                "SELECT snapshot_json FROM entity_snapshots WHERE entity_snapshot_id = ?",
                [entity_snapshot_id],
            ).fetchone()
        return EntitySnapshot.model_validate_json(row[0]) if row is not None else None

    def latest_data_revision(self) -> int:
        with duckdb.connect(str(self.workspace.layout.database_file), read_only=True) as connection:
            row = connection.execute(
                "SELECT coalesce(max(data_revision), 0) FROM data_revisions"
            ).fetchone()
        assert row is not None
        return int(row[0])

    def source_snapshots(
        self,
        product_id: str,
        *,
        as_of_data_revision: int | None = None,
        as_of: datetime | None = None,
    ) -> list[SourceSnapshot]:
        _validate_read_cutoff(as_of_data_revision, as_of)
        parameters: list[object] = [product_id]
        clause = "product_id = ?"
        if as_of_data_revision is not None:
            clause += " AND data_revision <= ?"
            parameters.append(as_of_data_revision)
        elif as_of is not None:
            clause += " AND observed_at <= ?"
            parameters.append(as_of)
        with duckdb.connect(str(self.workspace.layout.database_file), read_only=True) as connection:
            rows = connection.execute(
                f"SELECT snapshot_json FROM source_snapshots WHERE {clause} ORDER BY data_revision",
                parameters,
            ).fetchall()
        return [SourceSnapshot.model_validate_json(row[0]) for row in rows]

    def source_manifest(self, source_snapshot_id: str) -> CanonicalImportManifest | None:
        with duckdb.connect(str(self.workspace.layout.database_file), read_only=True) as connection:
            row = connection.execute(
                "SELECT manifest_json FROM source_snapshots WHERE source_snapshot_id = ?",
                [source_snapshot_id],
            ).fetchone()
        return CanonicalImportManifest.model_validate_json(row[0]) if row is not None else None

    def latest_source_observed_at(
        self,
        product_id: str,
        platform: MediaPlatform,
        account_id: str,
    ) -> datetime | None:
        with duckdb.connect(str(self.workspace.layout.database_file), read_only=True) as connection:
            row = connection.execute(
                """
                SELECT epoch_us(max(observed_at)) FROM source_snapshots
                WHERE product_id = ? AND platform = ? AND account_id = ?
                """,
                [product_id, platform.value, account_id],
            ).fetchone()
        if row is None or row[0] is None:
            return None
        return datetime.fromtimestamp(row[0] / 1_000_000, tz=UTC)

    def persist_import(
        self,
        manifest: CanonicalImportManifest,
        *,
        content_hash: str,
        response_field_inventory: list[str],
        raw_path: str,
        entities: list[CanonicalEntityRecord],
        observations: list[CanonicalObservationRecord],
    ) -> CanonicalImportResult:
        manifest_json = _canonical_json(manifest)
        database_file = str(self.workspace.layout.database_file)
        with duckdb.connect(database_file) as connection:
            connection.execute("BEGIN TRANSACTION")
            try:
                existing = connection.execute(
                    """
                    SELECT snapshot_json, manifest_json, content_hash
                    FROM source_snapshots WHERE source_snapshot_id = ? OR package_id = ?
                    """,
                    [manifest.source_snapshot_id, manifest.package_id],
                ).fetchone()
                if existing is not None:
                    snapshot = SourceSnapshot.model_validate_json(existing[0])
                    if (
                        CanonicalImportManifest.model_validate_json(existing[1]) != manifest
                        or existing[2] != content_hash
                    ):
                        raise CanonicalDataError(
                            "source snapshot or package ID already exists with different content"
                        )
                    connection.execute("ROLLBACK")
                    return self._result(
                        connection,
                        snapshot,
                        snapshot_reused=True,
                        entity_revisions_created=0,
                        observation_revisions_created=0,
                    )

                revision_row = connection.execute(
                    "SELECT coalesce(max(data_revision), 0) + 1 FROM data_revisions"
                ).fetchone()
                assert revision_row is not None
                data_revision = int(revision_row[0])
                snapshot = SourceSnapshot(
                    source_snapshot_id=manifest.source_snapshot_id,
                    package_id=manifest.package_id,
                    data_revision=data_revision,
                    product_id=manifest.product_id,
                    platform=manifest.platform,
                    account_id=manifest.account_id,
                    account_currency=manifest.account_currency,
                    source_timezone=manifest.source_timezone,
                    import_format_version=manifest.import_format_version,
                    effective_period=manifest.effective_period,
                    observed_at=manifest.observed_at,
                    content_hash=content_hash,
                    response_field_inventory=response_field_inventory,
                    raw_path=raw_path,
                    retention_deadline=manifest.observed_at
                    + timedelta(days=manifest.raw_retention_days),
                )
                connection.execute(
                    "INSERT INTO data_revisions VALUES (?, ?, ?)",
                    [data_revision, manifest.source_snapshot_id, manifest.observed_at],
                )
                connection.execute(
                    "INSERT INTO source_snapshots VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                    [
                        snapshot.source_snapshot_id,
                        snapshot.package_id,
                        snapshot.data_revision,
                        snapshot.product_id,
                        snapshot.platform.value,
                        snapshot.account_id,
                        snapshot.observed_at,
                        snapshot.content_hash,
                        _canonical_json(snapshot),
                        manifest_json,
                    ],
                )
                entity_count = self._persist_entities(connection, snapshot, entities)
                observation_count = self._persist_observations(
                    connection,
                    snapshot,
                    observations,
                )
                result = self._result(
                    connection,
                    snapshot,
                    snapshot_reused=False,
                    entity_revisions_created=entity_count,
                    observation_revisions_created=observation_count,
                )
                connection.execute("COMMIT")
                return result
            except Exception:
                connection.execute("ROLLBACK")
                raise

    def current_entities(
        self,
        product_id: str,
        *,
        platform: MediaPlatform | None = None,
        as_of_data_revision: int | None = None,
        as_of: datetime | None = None,
    ) -> list[EntitySnapshot]:
        _validate_read_cutoff(as_of_data_revision, as_of)
        parameters: list[object] = [product_id]
        clauses = ["product_id = ?"]
        if platform is not None:
            clauses.append("platform = ?")
            parameters.append(platform.value)
        revision_clause = ""
        source_table = "entity_snapshots"
        if as_of_data_revision is not None:
            revision_clause = " AND data_revision <= ?"
            parameters.append(as_of_data_revision)
        elif as_of is not None:
            revision_clause = " AND observed_at <= ?"
            parameters.append(as_of)
        sql = f"""
            SELECT snapshot_json FROM (
                SELECT *, row_number() OVER (
                    PARTITION BY entity_key ORDER BY revision DESC, data_revision DESC
                ) AS current_rank
                FROM {source_table}
                WHERE {" AND ".join(clauses)}{revision_clause}
            ) WHERE current_rank = 1
            ORDER BY platform, account_id, entity_type, entity_id
        """
        with duckdb.connect(str(self.workspace.layout.database_file), read_only=True) as connection:
            rows = connection.execute(sql, parameters).fetchall()
        return [EntitySnapshot.model_validate_json(row[0]) for row in rows]

    def current_observations(
        self,
        product_id: str,
        *,
        platform: MediaPlatform | None = None,
        as_of_data_revision: int | None = None,
        as_of: datetime | None = None,
    ) -> list[ObservationRevision]:
        _validate_read_cutoff(as_of_data_revision, as_of)
        parameters: list[object] = [product_id]
        clauses = ["product_id = ?"]
        if platform is not None:
            clauses.append("platform = ?")
            parameters.append(platform.value)
        revision_clause = ""
        if as_of_data_revision is not None:
            revision_clause = " AND data_revision <= ?"
            parameters.append(as_of_data_revision)
        elif as_of is not None:
            revision_clause = " AND observed_at <= ?"
            parameters.append(as_of)
        sql = f"""
            SELECT observation_json FROM (
                SELECT *, row_number() OVER (
                    PARTITION BY observation_key ORDER BY revision DESC, data_revision DESC
                ) AS current_rank
                FROM observation_revisions
                WHERE {" AND ".join(clauses)}{revision_clause}
            ) WHERE current_rank = 1
            ORDER BY platform, account_id, event_date, entity_id, metric_key
        """
        with duckdb.connect(str(self.workspace.layout.database_file), read_only=True) as connection:
            rows = connection.execute(sql, parameters).fetchall()
        return [ObservationRevision.model_validate_json(row[0]) for row in rows]

    def analysis_observations(
        self,
        product_id: str,
        *,
        data_revision: int,
        observed_through: datetime | None = None,
    ) -> list[ObservationRevision]:
        """Read a pinned revision, optionally intersected with an observation cutoff.

        Both constraints apply before choosing each fact's latest revision. A
        later import with an old observed_at can never alter a pinned analysis.
        """
        _validate_read_cutoff(data_revision, None)
        _validate_read_cutoff(None, observed_through)
        parameters: list[object] = [product_id, data_revision]
        cutoff = ""
        if observed_through is not None:
            cutoff = " AND observed_at <= ?"
            parameters.append(observed_through)
        with duckdb.connect(str(self.workspace.layout.database_file), read_only=True) as connection:
            rows = connection.execute(
                f"""
                SELECT observation_json FROM (
                    SELECT *, row_number() OVER (
                        PARTITION BY observation_key ORDER BY revision DESC, data_revision DESC
                    ) AS current_rank
                    FROM observation_revisions
                    WHERE product_id = ? AND data_revision <= ?{cutoff}
                ) WHERE current_rank = 1
                ORDER BY platform, account_id, event_date, entity_id, metric_key
                """,
                parameters,
            ).fetchall()
        return [ObservationRevision.model_validate_json(row[0]) for row in rows]

    @staticmethod
    def _persist_entities(
        connection: duckdb.DuckDBPyConnection,
        snapshot: SourceSnapshot,
        records: list[CanonicalEntityRecord],
    ) -> int:
        created = 0
        for record in records:
            key = _entity_key_from_snapshot(snapshot, record)
            payload_hash = _hash_payload(record)
            latest = connection.execute(
                """
                SELECT revision, payload_hash FROM entity_snapshots
                WHERE entity_key = ? ORDER BY revision DESC LIMIT 1
                """,
                [key],
            ).fetchone()
            if latest is not None and latest[1] == payload_hash:
                continue
            revision = 1 if latest is None else int(latest[0]) + 1
            entity_snapshot = EntitySnapshot(
                entity_snapshot_id=f"entity_snapshot_{key.removeprefix('entity_')[:16]}_r{revision}",
                entity_key=key,
                revision=revision,
                data_revision=snapshot.data_revision,
                source_snapshot_id=snapshot.source_snapshot_id,
                product_id=snapshot.product_id,
                platform=snapshot.platform,
                account_id=snapshot.account_id,
                observed_at=snapshot.observed_at,
                record=record,
            )
            connection.execute(
                "INSERT INTO entity_snapshots VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                [
                    entity_snapshot.entity_snapshot_id,
                    entity_snapshot.entity_key,
                    entity_snapshot.revision,
                    entity_snapshot.data_revision,
                    entity_snapshot.source_snapshot_id,
                    entity_snapshot.product_id,
                    entity_snapshot.platform.value,
                    entity_snapshot.account_id,
                    record.entity_type.value,
                    record.entity_id,
                    entity_snapshot.observed_at,
                    payload_hash,
                    _canonical_json(entity_snapshot),
                ],
            )
            created += 1
        return created

    @staticmethod
    def _persist_observations(
        connection: duckdb.DuckDBPyConnection,
        snapshot: SourceSnapshot,
        records: list[CanonicalObservationRecord],
    ) -> int:
        created = 0
        for record in records:
            key = _observation_key_from_snapshot(snapshot, record)
            payload_hash = _hash_payload(record)
            latest = connection.execute(
                """
                SELECT revision, payload_hash FROM observation_revisions
                WHERE observation_key = ? ORDER BY revision DESC LIMIT 1
                """,
                [key],
            ).fetchone()
            if latest is not None and latest[1] == payload_hash:
                continue
            revision = 1 if latest is None else int(latest[0]) + 1
            observation = ObservationRevision(
                observation_id=(f"observation_{key.removeprefix('observation_')[:16]}_r{revision}"),
                observation_key=key,
                revision=revision,
                data_revision=snapshot.data_revision,
                source_snapshot_id=snapshot.source_snapshot_id,
                product_id=snapshot.product_id,
                platform=snapshot.platform,
                account_id=snapshot.account_id,
                observed_at=snapshot.observed_at,
                record=record,
            )
            connection.execute(
                """
                INSERT INTO observation_revisions
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                [
                    observation.observation_id,
                    observation.observation_key,
                    observation.revision,
                    observation.data_revision,
                    observation.source_snapshot_id,
                    observation.product_id,
                    observation.platform.value,
                    observation.account_id,
                    record.entity_type.value,
                    record.entity_id,
                    record.event_date,
                    record.metric_key.value,
                    record.metric_semantic_version,
                    record.maturity_status.value,
                    observation.observed_at,
                    payload_hash,
                    _canonical_json(observation),
                ],
            )
            created += 1
        return created

    @staticmethod
    def _result(
        connection: duckdb.DuckDBPyConnection,
        snapshot: SourceSnapshot,
        *,
        snapshot_reused: bool,
        entity_revisions_created: int,
        observation_revisions_created: int,
    ) -> CanonicalImportResult:
        entity_count_row = connection.execute(
            """
            SELECT count(*) FROM current_entity_snapshots
            WHERE product_id = ? AND platform = ? AND account_id = ?
            """,
            [snapshot.product_id, snapshot.platform.value, snapshot.account_id],
        ).fetchone()
        observation_count_row = connection.execute(
            """
            SELECT count(*) FROM current_observations
            WHERE product_id = ? AND platform = ? AND account_id = ?
            """,
            [snapshot.product_id, snapshot.platform.value, snapshot.account_id],
        ).fetchone()
        assert entity_count_row is not None and observation_count_row is not None
        return CanonicalImportResult(
            package_id=snapshot.package_id,
            source_snapshot_id=snapshot.source_snapshot_id,
            platform=snapshot.platform,
            data_revision=snapshot.data_revision,
            snapshot_reused=snapshot_reused,
            entity_revisions_created=entity_revisions_created,
            observation_revisions_created=observation_revisions_created,
            current_entity_count=int(entity_count_row[0]),
            current_observation_count=int(observation_count_row[0]),
        )


def _entity_key_from_snapshot(
    snapshot: SourceSnapshot,
    record: CanonicalEntityRecord,
) -> str:
    identity = {
        "product_id": snapshot.product_id,
        "platform": snapshot.platform.value,
        "account_id": snapshot.account_id,
        "entity_type": record.entity_type.value,
        "entity_id": record.entity_id,
    }
    return f"entity_{_hash_payload(identity).removeprefix('sha256:')[:32]}"


def _observation_key_from_snapshot(
    snapshot: SourceSnapshot,
    record: CanonicalObservationRecord,
) -> str:
    return _observation_key(
        snapshot.product_id,
        snapshot.platform,
        snapshot.account_id,
        record,
    )
