# ruff: noqa: E501
"""Deterministic descriptive diagnostics. Contributions are arithmetic, never causal effects."""

from collections import defaultdict
from decimal import Decimal
from statistics import median

D = Decimal


def totals(rows):
    result = {}
    for key in ("spend", "impressions", "clicks"):
        values = [r.values.get(key) for r in rows]
        result[key] = sum(values, D(0)) if values and all(v is not None for v in values) else None
    for name, numerator, denominator, factor in (
        ("ctr", "clicks", "impressions", 1),
        ("cpc", "spend", "clicks", 1),
        ("cpm", "spend", "impressions", 1000),
    ):
        n, d = result[numerator], result[denominator]
        result[name] = n / d * factor if n is not None and d is not None and d > 0 else None
    return result


def groups(rows, key):
    result = defaultdict(list)
    for row in rows:
        result[key(row)].append(row)
    return dict(sorted(result.items()))


def diagnose(rows, comparison_period=None):
    daily = [{"date": str(k), **totals(v)} for k, v in groups(rows, lambda r: r.event_date).items()]
    campaigns = [
        {"campaign_id": k, **totals(v)} for k, v in groups(rows, lambda r: r.entity_id).items()
    ]
    insights = []
    overall = totals(rows)
    if overall["spend"] and all(c["spend"] is not None for c in campaigns):
        leading = max(campaigns, key=lambda c: c["spend"])
        share = leading["spend"] / overall["spend"]
        insights.append(
            {
                "kind": "observation",
                "title": "花费集中度",
                "evidence": ["campaigns", "totals"],
                "detail": f"Campaign {leading['campaign_id']} 占已获取花费的 {share:.1%}。总体变化可能由少数系列主导。",
                "next_check": "先检查主要系列的优化事件、投放配置和分日变化；集中不等于低效。",
            }
        )
    change = None
    # Compare equal calendar windows inside the retrieved interval; odd middle day is excluded.
    if rows:
        first, last = min(r.event_date for r in rows), max(r.event_date for r in rows)
        if comparison_period is not None:
            first, last = comparison_period.start, comparison_period.end
        days = (last - first).days + 1
        if days >= 2:
            from datetime import timedelta

            half = days // 2
            a = [r for r in rows if first <= r.event_date < first + timedelta(days=half)]
            b = [r for r in rows if last - timedelta(days=half) < r.event_date <= last]
            before, after = totals(a), totals(b)
            change = {
                "method": "equal_calendar_halves_observed_rows",
                "window_days": half,
                "baseline": [str(first), str(first + timedelta(days=half - 1))],
                "comparison": [str(last - timedelta(days=half - 1)), str(last)],
                "before": before,
                "after": after,
                "components": [],
                "campaign_contributions": [],
            }
            if all(
                x is not None and x > 0
                for x in (before["ctr"], after["ctr"], before["cpm"], after["cpm"])
            ):
                # Symmetric two-factor/Shapley decomposition of CPC = CPM / (1000 * CTR).
                p0, p1, r0, r1 = before["cpm"], after["cpm"], before["ctr"], after["ctr"]
                price = (p1 - p0) * (1 / r0 + 1 / r1) / 2000
                response = (1 / r1 - 1 / r0) * (p0 + p1) / 2000
                change["components"] = [
                    {"factor": "CPM", "cpc_delta": price},
                    {"factor": "CTR", "cpc_delta": response},
                ]
                insights.append(
                    {
                        "kind": "arithmetic_contribution",
                        "title": "CPC 波动拆解",
                        "evidence": ["change"],
                        "detail": f"两段等长区间的 CPC 从 {before['cpc']:.4f} 变为 {after['cpc']:.4f}；CPM 变化贡献 {price:+.4f}，CTR 变化贡献 {response:+.4f}。",
                        "next_check": "这是恒等式拆解。竞价竞争、素材疲劳或受众变化需另行验证；不能由 CPM/CTR 直接认定。",
                    }
                )
            ga, gb = groups(a, lambda r: r.entity_id), groups(b, lambda r: r.entity_id)
            if all(x is not None and x > 0 for x in (before["clicks"], after["clicks"])):
                for campaign in sorted(set(ga) | set(gb)):
                    ta, tb = totals(ga.get(campaign, [])), totals(gb.get(campaign, []))
                    item = {
                        "campaign_id": campaign,
                        "status": "common"
                        if campaign in ga and campaign in gb
                        else "entry_or_exit_observed",
                    }
                    if (
                        all(x is not None and x > 0 for x in (ta["clicks"], tb["clicks"]))
                        and ta["cpc"] is not None
                        and tb["cpc"] is not None
                    ):
                        w0, w1 = ta["clicks"] / before["clicks"], tb["clicks"] / after["clicks"]
                        item.update(
                            within_cpc=(ta["cpc"] - tb["cpc"]) * -(w0 + w1) / 2,
                            mix_cpc=(w1 - w0) * (ta["cpc"] + tb["cpc"]) / 2,
                        )
                    else:
                        item["contribution"] = (
                            "unresolved: missing/zero-click stratum; no invented counterfactual"
                        )
                    change["campaign_contributions"].append(item)
    anomalies = []
    values: list[Decimal] = [D(str(d["spend"])) for d in daily if d["spend"] is not None]
    if len(values) >= 14:
        center = median(values)
        mad = median([abs(v - center) for v in values])
        if mad > 0:
            for day in daily:
                if (
                    day["spend"] is not None
                    and abs(D(str(day["spend"])) - center) > 3 * D("1.4826") * mad
                ):
                    anomalies.append(
                        {
                            "date": day["date"],
                            "spend": day["spend"],
                            "method": "3_scaled_MAD_observed_days",
                            "causality": "unassessed",
                        }
                    )
    if anomalies:
        insights.append(
            {
                "kind": "screening",
                "title": "需复核的花费异常日",
                "evidence": ["anomalies"],
                "detail": f"有 {len(anomalies)} 个已观测日期偏离中位数超过 3 倍校正 MAD。此筛查未校正星期效应或多重比较。",
                "next_check": "核对预算、暂停记录、数据延迟和受众构成；不称为统计显著或已确认异常原因。",
            }
        )
    return {
        "totals": overall,
        "daily": daily,
        "campaigns": campaigns,
        "change": change,
        "anomalies": anomalies,
        "insights": insights,
    }


def context_insights(context, audience, diagnostics):
    """Contextual interpretation with explicit evidence gaps and bounded next checks."""
    insights = []
    goals = context["optimization_context"]
    values = sorted({g["optimization_goal"] for g in goals if g["optimization_goal"]})
    if values:
        insights.append(
            {
                "kind": "observation",
                "title": "先按实际优化目标判断表现",
                "evidence": ["context.optimization_context"],
                "detail": f"已读到 {len(goals)} 个投放单元的当前配置，优化目标包括 {', '.join(values)}。"
                + (
                    "存在多种目标，不能按一个 CPA 或 ROAS 混排。"
                    if len(values) > 1
                    else "报告按该目标列出应核验的成效指标。"
                ),
                "next_check": "先将历史事件口径与对应投放单元核对；当前配置不能证明历史未变。点击成本只描述流量效率。",
            }
        )
    for p in context["product_resolution"]:
        if p["status"] != "resolved":
            continue
        for match in p["matches"]:
            kpi = match["business_kpi"]["primary_metric"]
            campaign_goals = {
                g["optimization_goal"] for g in goals if g["campaign_id"] == p["campaign_id"]
            }
            if campaign_goals & {"INSTALL", "APP_INSTALLS", "CLICK", "LINK_CLICKS"} and (
                "roas" in kpi or "purchase" in kpi
            ):
                insights.append(
                    {
                        "kind": "hypothesis",
                        "title": "优化目标与业务成效存在距离",
                        "evidence": ["context.product_resolution", "context.optimization_context"],
                        "detail": f"Campaign {p['campaign_id']} 的当前目标是 {', '.join(sorted(campaign_goals))}，而已确认产品的业务 KPI 是 {kpi}。低点击/安装成本不能直接证明付费质量。",
                        "next_check": "先核验购买事件回传及同龄获客 cohort 收入；若重启投放，以对应业务事件质量作为实验护栏，不直接扩量。",
                    }
                )
    for a in audience:
        segments = a["segments"]
        eligible = [
            s
            for s in segments
            if s["spend"] is not None
            and s["clicks"] is not None
            and s["clicks"] >= 30
            and s["cpc"] is not None
        ]
        if len(eligible) < 2:
            continue
        high, low = max(eligible, key=lambda s: s["cpc"]), min(eligible, key=lambda s: s["cpc"])
        if high["cpc"] == low["cpc"]:
            continue
        insights.append(
            {
                "kind": "observation",
                "title": f"{a['dimension']} 人群流量成本差异",
                "evidence": ["delivered_audience", a["read_id"]],
                "detail": f"在 {a['period']['start']} 至 {a['period']['end']}，{high['segment']} 的 CPC 为 {high['cpc']:.4f}，{low['segment']} 为 {low['cpc']:.4f}。只展示至少 30 次点击的分组；这不是显著性阈值。",
                "next_check": "按相同产品和优化事件检查转化质量、受众重叠与投放结构；不能据此称某年龄/性别/地区更优，也不能将定向设置当作实投分布。",
            }
        )
    experiments = []
    if diagnostics["daily"]:
        for value in values or ["unresolved"]:
            examples = [g for g in goals if g["optimization_goal"] == value]
            metric = (
                examples[0]["evaluation_metrics"]
                if examples
                else "Resolve optimization goal/event first"
            )
            experiments.append(
                {
                    "optimization_goal": value,
                    "primary_measure": metric,
                    "hypothesis": "核验产品/事件后，一次只改变一个素材或受众因素，检验成本与下游质量的权衡。",
                    "controls": "同产品、同目标事件、同归因窗口、同投放期间；随机拆分或平台实验优先。",
                    "guardrails": "先约定可接受成本/质量、预算与观察期；等待转化成熟，不按单日波动停启。",
                    "status": "proposal_only_no_ad_changes",
                }
            )
    return insights, experiments
