"""Discovery-only contract for curated advertising-agent conversation cases."""

from __future__ import annotations

from datetime import datetime
from enum import StrEnum
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, JsonValue, model_validator


class StrictModel(BaseModel):
    """Reject unknown fields so extraction mistakes fail early."""

    model_config = ConfigDict(extra="forbid")


class ExtractorMode(StrEnum):
    MANUAL = "manual"
    AUTOMATED = "automated"
    HYBRID = "hybrid"


class Platform(StrEnum):
    META = "meta"
    GOOGLE = "google"
    TIKTOK = "tiktok"
    OTHER = "other"
    UNKNOWN = "unknown"


class Relevance(StrEnum):
    CORE_MONITORING = "core_monitoring"
    ADJACENT = "adjacent"
    OUT_OF_SCOPE = "out_of_scope"


class IntentFamily(StrEnum):
    MONITOR = "monitor"
    DIAGNOSE = "diagnose"
    REPORT = "report"
    EXPLAIN_METRIC = "explain_metric"
    RETRIEVE_DATA = "retrieve_data"
    PLAN_ACTION = "plan_action"
    EXECUTE_ACTION = "execute_action"
    CREATE_AD = "create_ad"
    CREATIVE_ANALYSIS = "creative_analysis"
    OTHER = "other"


class EntityLevel(StrEnum):
    ACCOUNT = "account"
    CAMPAIGN = "campaign"
    AD_SET = "ad_set"
    AD = "ad"
    CREATIVE = "creative"
    MIXED = "mixed"
    UNKNOWN = "unknown"


class EvidenceKind(StrEnum):
    METRIC = "metric"
    DIMENSION = "dimension"
    CONFIGURATION = "configuration"
    CHANGE = "change"
    EVENT = "event"
    TOOL_RESULT = "tool_result"
    USER_STATEMENT = "user_statement"
    OTHER = "other"


class EvidenceOrigin(StrEnum):
    USER_MESSAGE = "user_message"
    AGENT_MESSAGE = "agent_message"
    TOOL_CALL = "tool_call"
    TOOL_RESULT = "tool_result"
    REVIEWER_DERIVED = "reviewer_derived"


class DataTransformation(StrEnum):
    OBSERVED = "observed"
    NORMALIZED = "normalized"
    PERTURBED = "perturbed"
    SYNTHETIC = "synthetic"


class ToolStatus(StrEnum):
    SUCCEEDED = "succeeded"
    FAILED = "failed"
    PARTIAL = "partial"
    UNKNOWN = "unknown"


class UserResponse(StrEnum):
    ACCEPTED = "accepted"
    PARTIALLY_ACCEPTED = "partially_accepted"
    REJECTED = "rejected"
    CLARIFIED = "clarified"
    NO_FEEDBACK = "no_feedback"
    UNKNOWN = "unknown"


class ActionStatus(StrEnum):
    NONE = "none"
    PLANNED = "planned"
    EXECUTED = "executed"
    ROLLED_BACK = "rolled_back"
    UNKNOWN = "unknown"


class EvaluationMethod(StrEnum):
    UNVERIFIED = "unverified"
    OBSERVATIONAL = "observational"
    CONTROLLED = "controlled"


class GroundTruthStatus(StrEnum):
    UNREVIEWED = "unreviewed"
    PARTIAL = "partial"
    REVIEWED = "reviewed"


class FailureMode(StrEnum):
    UNSUPPORTED_CONCLUSION = "unsupported_conclusion"
    INSUFFICIENT_EVIDENCE = "insufficient_evidence"
    WRONG_METRIC_SEMANTICS = "wrong_metric_semantics"
    API_MISUSE = "api_misuse"
    HALLUCINATED_FIELD = "hallucinated_field"
    UNSAFE_ACTION = "unsafe_action"
    EXCESSIVE_COST = "excessive_cost"
    INCOMPLETE_ANSWER = "incomplete_answer"
    OTHER = "other"


class SourceReference(StrictModel):
    source_system: str = Field(min_length=1)
    conversation_id_hash: str = Field(min_length=12)
    turn_start: int = Field(ge=0)
    turn_end: int = Field(ge=0)
    occurred_at: datetime | None = None
    language: str = Field(default="zh-CN", min_length=2)
    extractor_mode: ExtractorMode

    @model_validator(mode="after")
    def validate_turn_range(self) -> SourceReference:
        if self.turn_end < self.turn_start:
            raise ValueError("turn_end must be greater than or equal to turn_start")
        return self


class TaskDefinition(StrictModel):
    platform: Platform
    relevance: Relevance
    intent_family: IntentFamily
    intent_detail: str = Field(min_length=1)
    entity_levels: list[EntityLevel] = Field(min_length=1)
    campaign_objective: str | None = None


class UserNeed(StrictModel):
    request_summary: str = Field(min_length=1)
    desired_outcome: str = Field(min_length=1)
    constraints: list[str] = Field(default_factory=list)
    sanitized_excerpt: str | None = None


class TimeRange(StrictModel):
    start: datetime | None = None
    end: datetime | None = None
    description: str | None = None

    @model_validator(mode="after")
    def validate_time_range(self) -> TimeRange:
        if self.start is not None and self.end is not None and self.end < self.start:
            raise ValueError("end must be greater than or equal to start")
        return self


class EvidenceItem(StrictModel):
    evidence_id: str = Field(pattern=r"^ev_[a-z0-9][a-z0-9_-]*$")
    kind: EvidenceKind
    name: str = Field(min_length=1)
    value: JsonValue = None
    unit: str | None = None
    entity_ref: str | None = None
    time_range: TimeRange | None = None
    origin: EvidenceOrigin
    transformation: DataTransformation
    notes: str | None = None


class ToolTrace(StrictModel):
    trace_id: str = Field(pattern=r"^tool_[a-z0-9][a-z0-9_-]*$")
    tool_name: str = Field(min_length=1)
    operation: str = Field(min_length=1)
    input_fields: list[str] = Field(default_factory=list)
    output_fields: list[str] = Field(default_factory=list)
    status: ToolStatus
    error_code: str | None = None
    error_summary: str | None = None
    latency_ms: int | None = Field(default=None, ge=0)


class Hypothesis(StrictModel):
    hypothesis_id: str = Field(pattern=r"^hyp_[a-z0-9][a-z0-9_-]*$")
    statement: str = Field(min_length=1)
    evidence_refs: list[str] = Field(default_factory=list)
    confidence: float | None = Field(default=None, ge=0, le=1)


class ActionRecommendation(StrictModel):
    action_id: str = Field(pattern=r"^action_[a-z0-9][a-z0-9_-]*$")
    action_type: str = Field(min_length=1)
    target: str = Field(min_length=1)
    rationale: str = Field(min_length=1)
    parameters: dict[str, JsonValue] = Field(default_factory=dict)
    requires_approval: bool = True


class AgentAnswer(StrictModel):
    answer_summary: str = Field(min_length=1)
    hypotheses: list[Hypothesis] = Field(default_factory=list)
    recommended_actions: list[ActionRecommendation] = Field(default_factory=list)


class CaseOutcome(StrictModel):
    user_response: UserResponse
    action_status: ActionStatus
    result_summary: str | None = None
    evaluation_method: EvaluationMethod = EvaluationMethod.UNVERIFIED


class QualityReview(StrictModel):
    ground_truth_status: GroundTruthStatus
    usefulness_score: int | None = Field(default=None, ge=1, le=5)
    failure_modes: list[FailureMode] = Field(default_factory=list)
    missing_information: list[str] = Field(default_factory=list)
    expected_evidence: list[str] = Field(default_factory=list)
    expected_reasoning_checks: list[str] = Field(default_factory=list)
    expected_actions: list[str] = Field(default_factory=list)
    reviewer_notes: str | None = None


class PrivacyReview(StrictModel):
    pii_removed: bool
    credentials_removed: bool
    identifiers_pseudonymized: bool
    business_values_transformed: bool
    raw_text_included: Literal[False] = False


class ConversationCase(StrictModel):
    """One decision-relevant task segment extracted from a conversation."""

    schema_version: Literal["1.0"] = "1.0"
    case_id: str = Field(pattern=r"^case_[a-z0-9][a-z0-9_-]*$")
    source: SourceReference
    task: TaskDefinition
    user_need: UserNeed
    evidence: list[EvidenceItem] = Field(default_factory=list)
    tool_traces: list[ToolTrace] = Field(default_factory=list)
    agent_answer: AgentAnswer
    outcome: CaseOutcome
    review: QualityReview
    privacy: PrivacyReview
    tags: list[str] = Field(default_factory=list)

    @model_validator(mode="after")
    def validate_references(self) -> ConversationCase:
        evidence_ids = [item.evidence_id for item in self.evidence]
        if len(evidence_ids) != len(set(evidence_ids)):
            raise ValueError("evidence_id values must be unique within a case")

        known_evidence = set(evidence_ids)
        referenced_evidence = {
            reference
            for hypothesis in self.agent_answer.hypotheses
            for reference in hypothesis.evidence_refs
        }
        unknown_references = sorted(referenced_evidence - known_evidence)
        if unknown_references:
            raise ValueError(f"unknown evidence references: {unknown_references}")

        action_ids = [action.action_id for action in self.agent_answer.recommended_actions]
        if len(action_ids) != len(set(action_ids)):
            raise ValueError("action_id values must be unique within a case")
        return self
