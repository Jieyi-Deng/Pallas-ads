"""Legacy conversation-research contracts, isolated from the runtime."""

from pallas_ads.research.conversation.models import ConversationCase

__all__ = ["ConversationCase"]
