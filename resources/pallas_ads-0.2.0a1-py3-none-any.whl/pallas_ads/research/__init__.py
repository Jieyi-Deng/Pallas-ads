"""Research and evaluation assets that are not runtime contracts."""
