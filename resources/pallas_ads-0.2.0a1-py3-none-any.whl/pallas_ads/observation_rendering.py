# ruff: noqa: E501
"""Human-facing three-part observation report, rendered from the shared Skill template."""

from __future__ import annotations

import csv
import hashlib
import html
import io
import json
import os
import unicodedata
from datetime import date, timedelta
from decimal import Decimal, InvalidOperation, localcontext
from pathlib import Path
from string import Template
from uuid import uuid4

RENDERER_VERSION = "2.2.1"
METRICS = {
    "spend": "花费",
    "impressions": "展示",
    "clicks": "点击",
    "ctr": "点击率",
    "cpc": "平均点击成本",
    "cpm": "千次展示成本",
}
GOALS = {
    "INSTALL": "安装",
    "APP_INSTALLS": "安装",
    "CLICK": "点击",
    "LINK_CLICKS": "链接点击",
    "CONVERT": "转化事件",
    "OFFSITE_CONVERSIONS": "站外转化",
    "CONVERSIONS": "转化事件",
    "VALUE": "转化价值",
    "CONVERSION_VALUE": "转化价值",
    "REACH": "覆盖人数",
    "IMPRESSION": "展示",
    "IMPRESSIONS": "展示",
    "LANDING_PAGE_VIEWS": "落地页浏览",
}
DIMENSIONS = {"age": "年龄", "gender": "性别", "country": "地区"}


def encode(value):
    if isinstance(value, Decimal):
        return str(value)
    if isinstance(value, date):
        return value.isoformat()
    if hasattr(value, "model_dump"):
        return value.model_dump(mode="json")
    raise TypeError("unsupported report value")


def dump(value):
    return json.dumps(value, default=encode, ensure_ascii=False, sort_keys=True, indent=2)


def esc(value):
    return html.escape(str(value), quote=True)


def number(value):
    if value is None or isinstance(value, bool):
        return None
    try:
        v = Decimal(str(value))
        return v if v.is_finite() else None
    except InvalidOperation:
        return None


def fmt(value, *, percent=False, signed=False):
    v = number(value)
    if v is None:
        return "未提供"
    with localcontext() as ctx:
        ctx.prec = max(38, len(v.as_tuple().digits) + abs(v.as_tuple().exponent) + 8)
        v = v * 100 if percent else v
        v = v.quantize(Decimal("0.01"))
    if not v:
        v = abs(v)
    precision = 0 if v == v.to_integral_value() else 2
    return format(v, ("+" if signed else "") + f",.{precision}f") + ("%" if percent else "")


def template_path():
    bundled = Path(__file__).parent / "resources/skills/pallas-analysis/assets/report.html"
    return (
        bundled
        if bundled.is_file()
        else Path(__file__).parents[2] / "skills/pallas-analysis/assets/report.html"
    )


def table(headers, rows, *, numeric=()):
    return (
        '<div class="table-wrap"><table><thead><tr>'
        + "".join(
            f'<th scope="col" class="{"number" if i in numeric else "text"}">{esc(h)}</th>'
            for i, h in enumerate(headers)
        )
        + "</tr></thead><tbody>"
        + "".join(
            "<tr>"
            + "".join(
                f'<td class="{"number" if i in numeric else "text"}">{esc(v)}</td>'
                for i, v in enumerate(row)
            )
            + "</tr>"
            for row in rows
        )
        + "</tbody></table></div>"
    )


def period_text(period):
    if isinstance(period, dict):
        return f"{period.get('start', '未知')} 至 {period.get('end', '未知')}"
    if isinstance(period, list) and len(period) == 2:
        return f"{period[0]} 至 {period[1]}"
    return "未提供"


def campaign_names(report):
    names = {}
    for c in report["context"].get("campaign_configuration", []):
        native = c.get("native", {})
        value = (
            native.get("campaign_name")
            or native.get("name")
            or native.get("campaign", {}).get("name")
        )
        names[c["campaign_id"]] = str(value or c["campaign_id"])
    return names


def bars(items, title, *, unit="", signed=False, caption=""):
    """Zero-based bars with direct value labels; signed contributions share a zero line."""
    valid = [(str(label), number(value)) for label, value in items if number(value) is not None]
    if not valid:
        return '<p class="muted">暂无可绘制的数据。</p>'
    scale = max(abs(v) for _, v in valid) or Decimal(1)
    zero, extent = (540, 210) if signed else (340, 410)
    height = len(valid) * 42 + 54
    svg = [
        f'<text x="12" y="20" class="chart-unit">单位：{esc(unit or "未提供")}</text>',
        f'<line x1="{zero}" x2="{zero}" y1="35" y2="{height - 10}" stroke="#ccd7d6"/>',
    ]
    for i, (label, v) in enumerate(valid):
        y = 42 + i * 42
        width = float(abs(v) / scale) * extent
        x = zero - width if v < 0 else zero
        color = (
            ("#b25836" if v > 0 else "#087c83") if signed else ("#087c83" if i == 0 else "#a5bcbe")
        )
        display, width_units = "", 0
        for character in label:
            width_units += 2 if unicodedata.east_asian_width(character) in ("W", "F") else 1
            if width_units > 38:
                display += "…"
                break
            display += character
        svg.append(
            f'<text x="12" y="{y + 18}">{esc(display)}<title>{esc(label)}</title></text><rect x="{x:.4f}" y="{y}" width="{width:.4f}" height="25" fill="{color}"><title>{esc(label)}：{fmt(v, signed=signed)} {esc(unit)}</title></rect><text x="800" y="{y + 18}">{fmt(v, signed=signed)}</text>'
        )
    return f'<figure><div class="chart-scroll"><svg role="img" aria-label="{esc(title)}" viewBox="0 0 960 {height}"><title>{esc(title)}</title>{"".join(svg)}</svg></div><figcaption>{esc(caption)} 单位：{esc(unit)}。条形从零起算，数值直接标注。</figcaption></figure>'


def trend(daily, currency):
    valid = [(date.fromisoformat(r["date"]), number(r.get("spend"))) for r in daily]
    if not valid or not any(v is not None for _, v in valid):
        return '<p class="muted">未取得可用的分日花费，不能绘制趋势。</p>'
    valid.sort()
    first, last = valid[0][0], valid[-1][0]
    span = max((last - first).days, 1)
    top = max(v for _, v in valid if v is not None) or Decimal(1)
    svg = [f'<text x="135" y="20" class="chart-unit">花费（{esc(currency)}）</text>']
    for fraction in (Decimal(0), Decimal("0.5"), Decimal(1)):
        y = 248 - float(fraction) * 200
        svg.append(
            f'<line x1="135" x2="920" y1="{y:.4f}" y2="{y:.4f}" stroke="#e4ebe9"/><text x="120" y="{y + 5:.4f}" text-anchor="end">{fmt(top * fraction)}</text>'
        )
    previous = None
    for day, v in valid:
        if v is None:
            previous = None
            continue
        x = 135 + (day - first).days / span * 785
        y = 248 - float(v / top) * 200
        if previous and (day - previous[0]).days == 1:
            svg.append(
                f'<line x1="{previous[1]:.4f}" y1="{previous[2]:.4f}" x2="{x:.4f}" y2="{y:.4f}" stroke="#087c83" stroke-width="2"/>'
            )
        svg.append(
            f'<circle cx="{x:.4f}" cy="{y:.4f}" r="3" fill="#087c83"><title>{day}：{fmt(v)} {esc(currency)}</title></circle>'
        )
        previous = (day, x, y)
    # Keep a readable number of calendar-spaced ticks, including a single-day range.
    days = (last - first).days
    step = next(
        (s for s in (1, 2, 3, 7, 14, 30, 60, 90, 180, 365) if s >= days / 5),
        max(1, (days + 4) // 5),
    )
    ticks = [first + timedelta(days=n) for n in range(0, days + 1, step)]
    if ticks[-1] != last:
        if len(ticks) > 1 and (last - ticks[-1]).days < step / 2:
            ticks.pop()
        ticks.append(last)
    # Endpoint labels face inward; their occupied width exceeds half a middle label.
    # Calendar spacing alone can leave the penultimate label overlapping the end date.
    spaced = [first]
    for day in ticks[1:-1]:
        left_gap = (day - spaced[-1]).days / span * 785
        right_gap = (last - day).days / span * 785
        if left_gap >= (160 if spaced[-1] == first else 110) and right_gap >= 160:
            spaced.append(day)
    if last != first:
        spaced.append(last)
    ticks = spaced
    for day in ticks:
        x = 135 + (day - first).days / span * 785
        anchor = "start" if day == first else "end" if day == last else "middle"
        svg.append(
            f'<line x1="{x:.4f}" x2="{x:.4f}" y1="248" y2="255" stroke="#ccd7d6"/><text class="date-tick" x="{x:.4f}" y="281" text-anchor="{anchor}">{day}</text>'
        )
    return f'<figure><div class="chart-scroll"><svg viewBox="0 0 960 304" role="img" aria-label="已观测分日花费"><title>已观测分日花费</title>{"".join(svg)}</svg></div><figcaption>单位：{esc(currency)}；横轴按实际日期间距绘制。缺失日期断线，不补零。所有日期保存在<a href="evidence/daily.csv">分日明细</a>。</figcaption></figure>'


def change_summary(change):
    if not change:
        return "可比较日期不足，暂不判断前后表现变化。"
    before, after = number(change["before"].get("cpc")), number(change["after"].get("cpc"))
    if before is None or after is None:
        return "比较区间存在缺失值或零点击，平均点击成本的变化无法完整计算。"
    direction = "上升" if after > before else "下降" if after < before else "不变"
    relative = (
        f"，相对变化 {fmt((after - before) / before, percent=True, signed=True)}"
        if before
        else "，基期为零，不计算相对变化"
    )
    return f"平均点击成本从 {fmt(before)} 变为 {fmt(after)}，{direction}{relative}。"


def render(report):
    scope, d = report["scope"], report["diagnostics"]
    ctx = report["context"]
    currency = scope.get("currency") or "币种未知"
    platform = {"tiktok": "TikTok", "google": "Google Ads", "meta": "Meta Ads"}.get(
        scope["platform"], scope["platform"]
    )
    title = f"{platform} 账户投放分析"
    names = campaign_names(report)

    def label(key):
        return names.get(key, str(key))

    products = sorted(
        {
            m["product_name"]
            for p in ctx.get("product_resolution", [])
            for m in p.get("matches", [])
            if p["status"] == "resolved"
        }
    )
    goals = sorted(
        {
            GOALS.get(g.get("optimization_goal"), g.get("optimization_goal") or "未核实")
            for g in ctx.get("optimization_context", [])
        }
    )
    overview = f"<p>账户 <strong>{esc(scope['account_id'])}</strong> · {esc(currency)} · {esc(scope['timezone'])}</p>"
    overview += f"<p>已确认归属的产品：{esc('、'.join(products) or '尚待核实')}。当前读到的优化目标：{esc('、'.join(goals) or '尚待核实')}。</p>"
    windows = scope.get("windows", [])
    retrieved = scope.get("requested_period") or (
        {"start": min(w["start"] for w in windows), "end": max(w["end"] for w in windows)}
        if windows
        else None
    )
    overview += f"<p>检索/指定范围：{esc(period_text(retrieved))}；已观测产生花费：{esc(scope.get('first_observed_spend_date') or '未发现')} 至 {esc(scope.get('last_observed_spend_date') or '未发现')}。</p>"
    coverage = (
        "已读取所选文件的全部有效行；媒体账户的完整覆盖尚未核实。"
        if report.get("evidence_mode") == "user_file"
        else "已获取花费与媒体可用 Lifetime 总量按系列核对一致。"
        if scope.get("lifetime_spend_reconciled")
        else "已读完媒体最大可用范围。"
        if scope.get("provider_maximum_read_complete")
        else "已完成指定日期读取。"
        if scope.get("requested_period_read_complete")
        else "历史检索尚未完成，以下仅总结已获取的数据。"
    )
    overview += f'<p class="notice">{coverage} 当前目标配置尚未核实适用于整个历史期间；下文的点击成本不等于购买或长期回收表现。</p>'
    if report.get("evidence_mode") == "user_file":
        source = report["file_source"]
        overview += '<p class="notice">来源：用户导入文件，未连接媒体 API。账户、币种及时区按文件或用户确认解释；不是实时账户状态。</p>'
        overview += "<p>" + "；".join(esc(v) for v in report["limitations"]) + "</p>"
        if any(
            r.get("conversions") is not None or r.get("conversion_value") is not None
            for r in source["rows"]
        ):
            overview += (
                "<h3>文件中的原生转化记录</h3><p>事件："
                + esc(scope.get("conversion_event") or "未确认")
                + "；归因窗口："
                + esc(scope.get("attribution_window") or "未确认")
                + "。不把通用转化当作购买，不作跨媒体 ROAS 排名。</p>"
            )
            overview += table(
                ["系列", "日期", "转化数量", "转化价值（" + currency + "）"],
                [
                    [
                        label(r["campaign_id"]),
                        r["date"],
                        fmt(r.get("conversions")),
                        fmt(r.get("conversion_value")),
                    ]
                    for r in source["rows"][:12]
                ],
                numeric=(2, 3),
            )
            overview += (
                '<p>最多展示前十二行，全部原值和导入范围见 <a href="report.json">来源附件</a>。</p>'
            )
    unresolved = [p for p in ctx.get("product_resolution", []) if p["status"] != "resolved"]
    if unresolved:
        overview += f"<p>仍有 {fmt(len(unresolved))} 个系列的产品归属未解决，不能把这些系列自动并入某个产品结论。</p>"
    failures = [a for a in report.get("attempts", []) if not a.get("usable")]
    if failures:
        overview += f'<p class="notice">有 {fmt(len(failures))} 项读取未取得完整结果，相关人群或目标结论可能缺失。请查看<a href="evidence/notes.md">读取与口径说明</a>。</p>'
    overview += (
        '<dl class="metrics">'
        + "".join(
            f'<div class="metric"><dt>{name}</dt><dd>{fmt(d["totals"].get(key), percent=key == "ctr")}</dd><span class="unit">{esc(currency if key in ("spend", "cpc", "cpm") else "次" if key in ("clicks", "impressions") else "点击 / 展示")}</span></div>'
            for key, name in METRICS.items()
        )
        + "</dl>"
    )
    overview += '<p class="small muted">指标由已返回数据汇总；比率按汇总分子和分母计算。“未提供”不等于零。点击保留媒体原生口径。</p>'
    comparison = scope.get("diagnostic_comparison_period")
    overview += (
        f"<p>波动比较范围：{esc(period_text(comparison))}。"
        + (
            "按用户指定期间比较。"
            if scope.get("diagnostic_comparison_policy") == "explicit_period"
            else "历史分析以有花费的活动期间比较，避免停投后的零花费尾部拉偏结果。"
        )
        + "</p>"
    )
    goal_rows = []
    for g in ctx.get("optimization_context", [])[:12]:
        event = g.get("optimization_event")
        if isinstance(event, list):
            event = (
                "、".join(
                    str(e.get("metadata", {}).get("name") or e.get("resource_name") or "未核实")
                    for e in event
                    if isinstance(e, dict) and e.get("metadata")
                )
                or "事件映射未完整核实"
            )
        elif not isinstance(event, (str, int)):
            event = "未核实"
        goal_rows.append(
            [
                label(g["campaign_id"]),
                GOALS.get(g.get("optimization_goal"), g.get("optimization_goal") or "未核实"),
                str(event),
                "当前快照；历史有效期未核实",
            ]
        )
    if goal_rows:
        overview += (
            '<div class="panel"><h3>先确认在优化什么</h3>'
            + table(["广告系列", "优化目标", "优化事件", "适用时间"], goal_rows)
            + '<p class="small"><a href="evidence/context.json">完整产品、目标及来源证据</a>；此处最多展示十二个投放单元。</p></div>'
        )
    change = d.get("change")
    primary = change_summary(change)
    daily = d.get("daily", [])
    plotted = [
        r for r in daily if not comparison or comparison["start"] <= r["date"] <= comparison["end"]
    ]
    changes = '<article><span class="badge">在哪里变化 · 时间</span><h3>把变化放回实际投放期间</h3>'
    positives = [
        r for r in plotted if number(r.get("spend")) is not None and number(r.get("spend")) > 0
    ]
    if positives:
        peak = max(positives, key=lambda r: number(r["spend"]))
        changes += f"<p>图示期间的最高已观测日花费出现在 {esc(peak['date'])}，为 {fmt(peak['spend'])} {esc(currency)}。峰值本身不代表异常。</p>"
    changes += trend(plotted, currency)
    if d.get("anomalies"):
        changes += f"<p>规则筛查标记了 {fmt(len(d['anomalies']))} 个需复核日期。请先检查预算、暂停和数据延迟，不能直接称为已确认的异常原因。</p>"
    else:
        changes += '<p class="muted">当前筛查没有标记异常日，不代表不存在业务异常；日期覆盖不足或大量零值也可能限制筛查。</p>'
    changes += (
        '</article><article><span class="badge">发生了什么 · 成本与响应</span><h3>'
        + esc(primary)
        + "</h3>"
    )
    if change:
        changes += f"<p>前段：{esc(period_text(change['baseline']))}；后段：{esc(period_text(change['comparison']))}。区间等长；总跨度为奇数时，中间一天不进入两段比较。</p>"
        comparison_rows = []
        for key, name in METRICS.items():
            a, b = number(change["before"].get(key)), number(change["after"].get(key))
            delta = b - a if a is not None and b is not None else None
            delta_text = (
                fmt(delta * 100, signed=True) + " 个百分点"
                if key == "ctr" and delta is not None
                else fmt(delta, signed=True)
            )
            comparison_rows.append(
                [name, fmt(a, percent=key == "ctr"), fmt(b, percent=key == "ctr"), delta_text]
            )
        changes += table(["指标", "前段", "后段", "变化量"], comparison_rows, numeric=(1, 2, 3))
        components = change.get("components", [])
        if components:
            changes += (
                '<div class="reason"><h4>为什么会变化：已证实的算术贡献</h4><p>'
                + "；".join(
                    f"{esc('千次展示成本' if c['factor'] == 'CPM' else '点击率')}变化对平均点击成本的贡献为 {fmt(c['cpc_delta'], signed=True)} {esc(currency)}"
                    for c in components
                )
                + "。</p></div>"
            )
            changes += bars(
                [(c["factor"], c["cpc_delta"]) for c in components],
                "平均点击成本变化贡献",
                unit=f"{currency} / 点击",
                signed=True,
                caption="右侧为增加成本的贡献，左侧为降低成本的贡献。",
            )
        else:
            changes += "<p>所需分母缺失或为零，无法可靠拆解点击成本贡献。</p>"
    changes += '<div class="reason"><h4>为什么会变化：尚待验证的业务原因</h4><p>竞价环境、素材响应、预算和受众构成都可能相关。当前拆解只证明指标之间的贡献关系；要确认原因，需要同期间的配置变更、素材和分组转化证据。</p></div></article>'
    campaign_rows = sorted(
        d.get("campaigns", []), key=lambda r: number(r.get("spend")) or Decimal(0), reverse=True
    )
    total = number(d["totals"].get("spend"))
    concentration = "暂无可用的系列花费构成。"
    if campaign_rows and total and number(campaign_rows[0].get("spend")) is not None:
        leader = campaign_rows[0]
        concentration = f"{label(leader['campaign_id'])} 占已获取花费的 {fmt(number(leader['spend']) / total, percent=True)}。"
    changes += (
        '<article><span class="badge">在哪里变化 · 系列构成</span><h3>'
        + esc(concentration)
        + "</h3>"
    )
    changes += bars(
        [(label(r["campaign_id"]), r.get("spend")) for r in campaign_rows[:8]],
        "系列花费构成",
        unit=currency,
        caption="按花费降序展示，最多八个系列；完整记录见系列明细。",
    )
    contributions = (change or {}).get("campaign_contributions", [])
    if contributions:
        changes += table(
            ["广告系列", "系列内效率贡献", "点击份额变化贡献"],
            [
                [
                    label(r["campaign_id"]),
                    fmt(r.get("within_cpc"), signed=True),
                    fmt(r.get("mix_cpc"), signed=True),
                ]
                for r in contributions[:8]
            ],
            numeric=(1, 2),
        )
        changes += '<p class="small muted">贡献单位为账户币种/点击。“系列内”反映该系列自身效率变化，“份额”反映点击构成变化。进入、退出或零点击组无法完整拆解，因此这些已解析贡献不一定覆盖账户全部变化。</p>'
    changes += '<p><a href="evidence/campaigns.csv">完整系列指标</a> · <a href="evidence/diagnostics.json">完整波动计算</a></p></article>'
    for audience in report.get("delivered_audience", []):
        dim = DIMENSIONS.get(audience["dimension"], audience["dimension"])
        eligible = [
            r
            for r in audience["segments"]
            if number(r.get("clicks")) is not None
            and number(r["clicks"]) >= 30
            and number(r.get("cpc")) is not None
        ]
        eligible.sort(key=lambda r: number(r["cpc"]), reverse=True)
        changes += f'<article><span class="badge">在哪里变化 · {esc(dim)}人群</span><h3>{esc(dim)}分组的点击成本与转化质量需分开看</h3><p>实际触达数据期间：{esc(period_text(audience["period"]))}。此处是同期间的人群差异，不是人群随时间变化的证明。</p>'
        if eligible:
            high, low = eligible[0], eligible[-1]
            if len(eligible) == 1:
                changes += f"<p>只有 {esc(high['segment'])} 满足展示门槛，点击成本为 {fmt(high['cpc'])} {esc(currency)}，暂不能进行组间比较。</p>"
            else:
                changes += f"<p>{esc(high['segment'])} 的点击成本为 {fmt(high['cpc'])}，{esc(low['segment'])} 为 {fmt(low['cpc'])} {esc(currency)}。低点击成本尚不能证明更高的安装、购买或留存质量。</p>"
            changes += bars(
                [(r["segment"], r["cpc"]) for r in eligible[:8]],
                dim + "分组点击成本",
                unit=f"{currency} / 点击",
                caption=f"仅展示点击量至少 {fmt(30)} 次的分组；这是显示门槛，不是显著性检验。",
            )
        else:
            changes += "<p>没有满足展示门槛的可用分组，不生成高低表现排名。</p>"
        changes += '<p class="reason">下一步按相同产品、目标事件和归因口径核对各组转化质量，再考虑调整定向；不要把当前定向设置当作实际触达人群。</p><p><a href="evidence/audience.csv">完整人群指标及样本量</a></p></article>'
    if not report.get("delivered_audience"):
        changes += "<article><h3>人群变化暂不能判断</h3><p>尚未取得可用的实际触达人群数据，不能用定向配置或账户名称代替。</p></article>"
    findings = [
        concentration,
        primary,
        "当前优化目标为"
        + ("、".join(goals) or "未核实")
        + "；历史目标适用期与下游成效尚需核验，不能仅按点击成本判断业务成功。",
    ]
    recommendations = (
        '<div class="panel"><h3>主要发现</h3><ul class="summary-list">'
        + "".join(f"<li>{esc(f)}</li>" for f in findings)
        + "</ul></div>"
    )
    actions = [
        [
            "优先核验",
            "核对历史优化事件及回传口径",
            "让成本分母对应真实优化事件；当前配置不能回填为历史事实。",
        ],
        [
            "随后验证",
            "检查主要系列与人群的下游质量",
            "按同产品、同事件、同归因窗口对比安装、购买或同龄留存；缺失时不猜测。",
        ],
    ]
    if d.get("restart_experiments"):
        actions.append(
            [
                "再做实验",
                "一次只改变一个素材或受众因素",
                "先约定业务成功指标、质量护栏和预算；等待转化成熟后评估，不按单日波动反复停启。",
            ]
        )
    recommendations += (
        '<div class="panel"><h3>建议与验证顺序</h3>'
        + table(["顺序", "建议", "依据与验收方式"], actions)
        + "<p>以上是验证与实验建议，未修改任何广告。没有足够的转化与业务证据时，不给出确定的扩量或收益承诺。</p></div>"
    )
    links = '<div class="evidence-links"><a href="report.json">完整原始证据</a><a href="evidence/daily.csv">分日明细</a><a href="evidence/campaigns.csv">系列明细</a><a href="evidence/audience.csv">人群明细</a><a href="evidence/context.json">产品与优化目标证据</a><a href="evidence/notes.md">口径、缺失项与读取记录</a><a href="manifest.json">文件校验清单</a></div>'
    output = Template(template_path().read_text()).substitute(
        title=esc(title),
        subtitle="先看清账户与期间表现，再解释变化，最后决定下一步该验证什么。",
        overview=overview,
        changes=changes,
        recommendations=recommendations,
        evidence_links=links,
    )
    md = f"# {title}\n\n## 一、账户与期间总结\n\n账户 {scope['account_id']}；币种 {currency}；检索/指定范围 {period_text(retrieved)}。{coverage}\n\n"
    md += "\n".join(
        f"- {name}：{fmt(d['totals'].get(key), percent=key == 'ctr')}"
        for key, name in METRICS.items()
    )
    md += (
        "\n\n## 二、变化与原因拆解\n\n"
        + primary
        + "\n\n"
        + concentration
        + "\n\n算术贡献不证明业务因果，当前目标配置不代表历史配置。图表和分组证据见 [HTML 报告](report.html)。\n\n## 三、主要发现与建议\n\n"
    )
    md += "\n".join(f"- {a[1]}：{a[2]}" for a in actions)
    md += "\n\n[完整原始证据](report.json) · [口径及读取记录](evidence/notes.md)\n"
    return output, md


def csv_text(rows, fields):
    out = io.StringIO(newline="")
    writer = csv.writer(out)
    writer.writerow(fields)
    for row in rows:
        values = []
        for field in fields:
            value = row.get(field)
            cell = "" if value is None else str(value)
            # Neutralize spreadsheet formulas in source labels; exact values remain in JSON.
            if cell.startswith(("=", "+", "@", "-")) and number(cell) is None:
                cell = "'" + cell
            values.append(cell)
        writer.writerow(values)
    return out.getvalue()


def save_report(workspace, report):
    root = workspace.layout.root / "reports/observations"
    root.mkdir(parents=True, exist_ok=True)
    identifier = "observation_" + uuid4().hex
    pending, destination = root / ("." + identifier), root / identifier
    pending.mkdir(mode=0o700)
    (pending / "evidence").mkdir()
    html_text, md = render(report)
    audience = [
        {"dimension": a["dimension"], "start": a["period"]["start"], "end": a["period"]["end"], **r}
        for a in report.get("delivered_audience", [])
        for r in a["segments"]
    ]
    notes = (
        "# 口径与缺失项\n\n"
        + "\n".join("- " + s for s in report.get("limitations", []))
        + "\n\n## 检索范围与读取记录\n\n```json\n"
        + dump({"scope": report["scope"], "attempts": report.get("attempts", [])})
        + "\n```\n"
    )
    files = {
        "report.json": dump(report),
        "report.html": html_text,
        "report.md": md,
        "chat.md": md,
        "evidence/context.json": dump(report["context"]),
        "evidence/diagnostics.json": dump(report["diagnostics"]),
        "evidence/daily.csv": csv_text(report["diagnostics"]["daily"], ["date", *METRICS]),
        "evidence/campaigns.csv": csv_text(
            report["diagnostics"]["campaigns"], ["campaign_id", *METRICS]
        ),
        "evidence/audience.csv": csv_text(
            audience, ["dimension", "start", "end", "segment", *METRICS]
        ),
        "evidence/notes.md": notes,
    }
    for name, text in files.items():
        (pending / name).write_text(text, encoding="utf-8")
    manifest = {
        "renderer_version": RENDERER_VERSION,
        "template_sha256": hashlib.sha256(template_path().read_bytes()).hexdigest(),
        "report_id": identifier,
        "files": {name: hashlib.sha256(text.encode()).hexdigest() for name, text in files.items()},
    }
    (pending / "manifest.json").write_text(dump(manifest), encoding="utf-8")
    os.rename(pending, destination)
    return {
        "report_id": identifier,
        "html": str(destination / "report.html"),
        "markdown": str(destination / "report.md"),
        "data": str(destination / "report.json"),
        "manifest": str(destination / "manifest.json"),
    }
