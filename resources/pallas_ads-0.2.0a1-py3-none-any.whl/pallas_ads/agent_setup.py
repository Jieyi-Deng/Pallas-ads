"""Explicit project-local installation; no global client settings or OAuth credentials."""

import json
import os
import shlex
import shutil
import sys
import tempfile
from pathlib import Path

from pallas_ads.contracts.host_mcp import META_HOST_URL, META_READ_TOOLS
from pallas_ads.local_state import WorkspaceRepository


def skill_source():
    bundled = Path(__file__).parent / "resources/skills"
    return bundled if bundled.is_dir() else Path(__file__).parents[2] / "skills"


def setup_agent(directory: Path, client: str, *, meta_client_id: str | None = None, mode="core"):
    """Prepare a fresh working folder using this installed wheel's absolute executable."""
    if client not in ("claude", "codex"):
        raise ValueError("Unsupported client.")
    if mode not in ("core", "live"):
        raise ValueError("Choose core or live mode.")
    if meta_client_id is not None:
        from pallas_ads.machine_setup import meta_config

        meta_config(meta_client_id)
        if client != "codex":
            raise ValueError("Pre-registered configuration is for Codex only.")
    # Do not resolve Python's symlink: that would lose the active virtual environment.
    executable = Path(sys.executable).absolute().with_name("pallas")
    if not executable.is_file() or not os.access(executable, os.X_OK):
        raise ValueError("Install the Pallas wheel in this environment first.")
    if directory.is_symlink():
        raise ValueError("Choose a new directory, not a symlink.")
    directory = directory.absolute()
    if directory.exists() and (not directory.is_dir() or any(directory.iterdir())):
        raise ValueError("Choose a new or empty directory; existing settings are never replaced.")
    directory.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix=".pallas-setup-", dir=directory.parent) as temporary:
        stage = Path(temporary) / "project"
        stage.mkdir()
        workspace = directory / ".pallas"
        args = ["mcp", "serve", "--workspace", str(workspace)]
        if client == "claude":
            config = {
                "mcpServers": {
                    "pallas": {"type": "stdio", "command": str(executable), "args": args},
                    "meta_official": {"type": "http", "url": META_HOST_URL},
                },
            }
            if mode == "core":
                config["mcpServers"].pop("meta_official")
            (stage / ".mcp.json").write_text(json.dumps(config, indent=2) + "\n")
            skill_dir = stage / ".claude/skills"
            # A closed allowlist also denies future Meta tools. Reads retain normal host
            # permission prompts; never auto-approve either server's operations.
            settings = {
                "hooks": {
                    "PreToolUse": [
                        {
                            "matcher": "mcp__meta_official__.*",
                            "hooks": [
                                {
                                    "type": "command",
                                    "command": shlex.quote(str(executable)) + " agent guard-meta",
                                }
                            ],
                        }
                    ]
                }
            }
            (stage / ".claude").mkdir()
            (stage / ".claude/settings.json").write_text(json.dumps(settings, indent=2) + "\n")
        else:
            (stage / ".codex").mkdir()
            q = json.dumps  # TOML basic string escaping, not shell quoting.
            (stage / ".codex/config.toml").write_text(
                "[mcp_servers.pallas]\n"
                f"command = {q(str(executable))}\nargs = {q(args)}\n"
                "tool_timeout_sec = 180\n\n"
                "# Meta rejected Codex DCR in the 2026-09-14 live canary.\n"
                "# Leave disabled until provider/client compatibility is resolved.\n"
                "[mcp_servers.meta_official]\n"
                f"url = {q(META_HOST_URL)}\nenabled = false\n"
                f"enabled_tools = {q(list(META_READ_TOOLS))}\n"
            )
            if meta_client_id:
                config_path = stage / ".codex/config.toml"
                initial = config_path.read_text().split("# Meta rejected")[0]
                configuration = meta_config(meta_client_id)
                initial += "[mcp_servers.meta_official]\n"
                for key, value in configuration.items():
                    if key != "oauth":
                        initial += f"{key} = {json.dumps(value)}\n"
                initial += "\n[mcp_servers.meta_official.oauth]\n"
                for key, value in configuration["oauth"].items():
                    initial += f"{key} = {json.dumps(value)}\n"
                config_path.write_text(initial)
            skill_dir = stage / ".agents/skills"
        shutil.copytree(skill_source(), skill_dir)
        shutil.copytree(Path(__file__).parent / "resources/file_samples", stage / "samples")
        (stage / ".gitignore").write_text(".pallas/\n.mcp.json\n.codex/\n.claude/\n.agents/\n")
        (stage / ("CLAUDE.md" if client == "claude" else "AGENTS.md")).write_text(
            "# Pallas workspace\n\n"
            f"For Pallas work, read `{skill_dir.relative_to(stage)}/pallas-workflow/SKILL.md`.\n"
            "Use the configured pallas MCP and this folder's .pallas workspace.\n"
            "Meta authorization belongs to the host's meta_official MCP. Never read client\n"
            "credential stores or create Pallas Meta OAuth sessions as a workaround.\n"
            "Use only ads_get_ad_accounts, ads_get_field_context, ads_get_ad_entities.\n"
            "No ad writes or browser scraping. Stage host results before interpreting them.\n"
            "Meta host canonical mapping/report validation is pending a test account.\n"
        )
        (stage / "START_HERE.md").write_text(
            "# Pallas / 开始使用\n\n"
            "This folder contains a local Pallas workspace, MCP settings and bundled Skills.\n"
            "本目录已配置本地 Pallas MCP、工作区和分析 Skills，无需复制源码仓库。\n\n"
            + (
                "Open this folder in Claude Code, approve this project's MCP servers and hook,\n"
                "Run `/mcp` → `meta_official` → Authenticate, then grant browser consent.\n"
                "也可运行 `claude mcp login meta_official`。无需 Pallas App ID 或证书。\n"
                "The official host consent may request broad scopes. Pallas's project hook\n"
                "blocks all Meta tools outside its three-read allowlist; this is a host guard,\n"
                "not a server-side read-only token. Do not disable it for analysis.\n\n"
                if client == "claude"
                else "Trust this folder in Codex and start a new task. Pallas is enabled.\n"
                "Meta is disabled: on 2026-09-14 Meta rejected Codex dynamic registration with\n"
                "`invalid_client_metadata`: dynamic registration unavailable for this client.\n"
                "这是客户端兼容性阻碍，不需要填写 Pallas App ID、Token 或证书来绕过。\n"
                "Use a separate Claude Code setup for currently verified direct Meta OAuth.\n\n"
            )
            + "Try: 使用 Pallas，先检查连接并读取可访问的 Meta 账户；不要创建产品或修改广告。\n\n"
            "OAuth success is not validated ad performance. Meta canonical mapping/report testing\n"
            "awaits a test account. Host evidence can be retained with action=host_capture.\n"
            "Credentials belong to the host. Disconnect there; revoke in Meta if needed.\n"
            "Keep the installed Pallas environment in place. Moving it requires a new setup.\n"
        )
        if meta_client_id:
            command = shlex.quote(str(executable))
            project = shlex.quote(str(directory))
            (stage / "AGENTS.md").write_text(
                (stage / "AGENTS.md").read_text()
                + "\nThis project explicitly uses Pallas's pre-registered Meta client in Codex.\n"
                + "Do not follow generic DCR-blocked guidance when this configuration is present.\n"
                + f"Before first use, run `{command} agent doctor --directory {project}`.\n"
                + "Google live access optionally uses a configured release wheel.\n"
                + "Missing Google configuration does not block files or Meta.\n"
                + "If Meta certificates are missing, explain the localhost trust change\n"
                + f"and run `{command} agent prepare-meta --directory {project} "
                "--trust-local-certificate`\n"
                + "as part of user-authorized installation. System approval stays with the user.\n"
                + f"For Meta login run `{command} agent login-meta --directory {project}`.\n"
                + "This starts the callback; Codex owns tokens. Do not run bare login alone.\n"
                + "Discover accounts after consent. Login does not prove data access.\n"
            )
            (stage / "START_HERE.md").write_text(
                "# Pallas / 开始使用\n\n"
                "Open this folder in Codex and trust its project MCP configuration.\n"
                "在 Codex 打开本文件夹，允许项目 MCP；安装后开始新任务以加载工具。\n\n"
                "Tell the agent: 请检查 Pallas 安装，连接我的 Google、Meta、TikTok 广告账户。\n"
                "请先通过 API 获取账户和产品线索，无法确认的再问我，不修改广告。\n\n"
                "Google 实时连接需要另行配置的构建；Meta 使用预注册 App ID 和本机 HTTPS 回调。\n"
                "首次安装可能需要系统钥匙串/证书信任确认，媒体同意页由用户亲自确认。\n"
                "安装检查不证明外部用户资格、账户访问或真实数据正确。\n"
                "Analysis follows bundled Skills and the three-part HTML template.\n"
                "Keep this installed environment in place. Do not copy old .pallas or tokens.\n"
            )
        if mode == "core" and not meta_client_id:
            (stage / "START_HERE.md").write_text(
                "# Pallas / 开始使用\n\n"
                "在此目录打开 Codex 或 Claude Code，信任项目后开始新任务加载 Pallas。\n"
                "默认只启用本地分析，无需 OpenAI API key、Google 配置或 Meta 证书。\n\n"
                "告诉 Agent：请用 Pallas 分析这份广告 CSV/XLSX，先展示字段和口径预览，"
                "我确认后导入并生成三段式 HTML 报告。\n"
                "读取导出的 pallas-workflow 和 pallas-analysis。\n"
                "没有数据时：请预览 samples/meta_campaign_daily.csv 合成样例，确认后生成报告。\n\n"
                "实时连接按需启动：Google/TikTok 使用 Pallas 连接流程；Meta 需要宿主配置。\n"
                "媒体权限不足只影响相应连接，不阻止文件分析。保留 runtime 与 .pallas 目录。\n"
            )
        testing_guide = Path(__file__).parent / "resources/distribution/NEW_MACHINE_TESTING.md"
        if not testing_guide.is_file():
            testing_guide = Path(__file__).parents[2] / "docs/NEW_MACHINE_TESTING.md"
        shutil.copyfile(testing_guide, stage / "TESTING.md")
        instruction = stage / ("CLAUDE.md" if client == "claude" else "AGENTS.md")
        instruction.write_text(
            instruction.read_text()
            + "\nWhen asked to run acceptance tests, read TESTING.md and create a new run with\n"
            + "`pallas acceptance start`. Record each case and retain reports locally.\n"
            + "Stage only sanitized report copies for optional feedback; never collect raw client\n"
            + "logs or credentials. Pack after tester review; never automatically send files.\n"
        )
        initialized = WorkspaceRepository(stage / ".pallas").bootstrap("workspace_local")
        if initialized.status != "complete":
            raise ValueError("Workspace initialization failed.")
        # Rename publishes a fully prepared directory; never merge user settings.
        stage.rename(directory)
    return {
        "directory": str(directory),
        "workspace": str(workspace),
        "client": client,
        "mode": mode,
        "meta_authorization": "optional_not_enabled"
        if mode == "core" and not meta_client_id
        else "host_client"
        if client == "claude"
        else "host_client_preregistered"
        if meta_client_id
        else "blocked_dynamic_registration",
        "next_step": str(directory / "START_HERE.md"),
    }


def guard_meta(event):
    """Claude PreToolUse protocol; no decision means normal approval checks still apply."""
    name = event.get("tool_name") if isinstance(event, dict) else None
    if name not in {"mcp__meta_official__" + t for t in META_READ_TOOLS}:
        return {
            "hookSpecificOutput": {
                "hookEventName": "PreToolUse",
                "permissionDecision": "deny",
                "permissionDecisionReason": "Pallas Meta permits only its three read tools.",
            }
        }
    return {}


def refresh_skills(directory: Path):
    """Refresh only Pallas's two project Skills, retaining recoverable local backups."""
    from uuid import uuid4

    directory = directory.absolute()
    if any(p.is_symlink() for p in (directory, *directory.parents)):
        raise ValueError("Project path cannot contain symlinks.")
    codex, claude = directory / ".codex/config.toml", directory / ".mcp.json"
    if codex.is_file() == claude.is_file():
        raise ValueError("Choose one configured Codex or Claude project.")
    root = directory / (".agents/skills" if codex.is_file() else ".claude/skills")
    backup = directory / ".pallas/skill_backups" / ("backup_" + uuid4().hex)
    if any(p.is_symlink() for p in (root, *root.parents, *backup.parents)):
        raise ValueError("Skill/backup paths cannot contain symlinks.")
    names = ("pallas-workflow", "pallas-analysis")
    if any((root / n).is_symlink() for n in names):
        raise ValueError("Pallas skill directories cannot be symlinks.")
    backup.mkdir(parents=True, mode=0o700)
    with tempfile.TemporaryDirectory(dir=backup) as temporary:
        stage = Path(temporary)
        for name in names:
            shutil.copytree(skill_source() / name, stage / name)
        root.mkdir(parents=True, exist_ok=True)
        for name in names:
            target = root / name
            if target.exists():
                target.rename(backup / name)
            try:
                (stage / name).rename(target)
            except OSError:
                if (backup / name).exists():
                    (backup / name).rename(target)
                raise
    return {
        "updated": list(names),
        "backup": str(backup),
        "next_step": "Review custom changes in the backup and restart the Agent task.",
    }
