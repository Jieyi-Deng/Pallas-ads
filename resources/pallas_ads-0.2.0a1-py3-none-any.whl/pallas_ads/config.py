"""Local runtime configuration with no source-specific assumptions."""

from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True, slots=True)
class Settings:
    """Non-secret settings derived from the process environment."""

    data_dir: Path

    @classmethod
    def from_environment(cls) -> Settings:
        configured_data_dir = os.getenv("PALLAS_DATA_DIR")
        data_dir = Path(configured_data_dir) if configured_data_dir else Path.cwd() / ".pallas"
        return cls(data_dir=data_dir.expanduser().resolve())
