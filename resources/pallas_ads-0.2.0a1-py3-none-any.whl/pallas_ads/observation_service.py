# ruff: noqa: E501
"""Account-scoped, bounded historical acquisition and offline observation reports."""

from datetime import date, timedelta
from decimal import Decimal
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

from pallas_ads.contracts.query import DateRange
from pallas_ads.contracts.source import SourceReadRequest
from pallas_ads.contracts.status import OperationEnvelope, OperationIssue
from pallas_ads.observation_context import resolve_context
from pallas_ads.observation_diagnostics import diagnose, groups, totals
from pallas_ads.onboarding_service import OnboardingService, needs


class ObservationService(OnboardingService):
    def analyze(self, request):
        c = self._connection(request.connection_id)
        account = c.selected_account_id or c.config.mcp_advertiser_id
        if not account:
            return needs(
                "account_selection_required", "Discover and select the advertising account first."
            )
        reads, issues, missing, attempts = [], [], [], []

        def read(mode, **kwargs):
            response = self.adapter.read(
                request.connection_id,
                SourceReadRequest(
                    platform=c.config.platform,
                    mode=mode,
                    account_id=account,
                    max_pages=request.max_pages,
                    **kwargs,
                ),
            )
            issues.extend(response.issues)
            missing.extend(response.missing_inputs)
            result = response.result
            if result:
                reads.append(result)
            valid = bool(
                result is not None
                and result.pagination_complete
                and not any(i.severity == "error" for i in response.issues)
            )
            attempts.append(
                {
                    "mode": mode,
                    "options": kwargs,
                    "usable": valid,
                    "read_id": result.read_id if result else None,
                    "error_codes": [i.code for i in response.issues if i.severity == "error"],
                }
            )
            return result if valid else None

        context = read("account_context")
        if context is None or len(context.records) != 1:
            return OperationEnvelope(
                operation="build_report",
                status="partial_result",
                result={
                    "attempts": attempts,
                    "next_step": "repair_source_read_no_browser_fallback",
                },
                issues=issues
                or [
                    OperationIssue(
                        code="missing_account_context", message="Account context is unavailable."
                    )
                ],
                missing_inputs=missing,
            )
        meta = context.records[0].metadata
        currency, timezone = meta.get("account_currency"), meta.get("source_timezone")
        try:
            today = self.clock().astimezone(ZoneInfo(timezone)).date()
        except (ZoneInfoNotFoundError, TypeError, ValueError):
            return needs(
                "source_timezone_required",
                "Repair the source account timezone before selecting historical dates.",
            )
        if not currency:
            return needs(
                "source_currency_required",
                "Repair the source account currency before financial arithmetic.",
            )
        read("entity_configuration")
        read("entity_configuration", context_kind="optimization")
        read("entity_configuration", context_kind="creative")
        if c.config.platform == "tiktok":
            read("entity_configuration", context_kind="apps")
        if c.config.platform == "google":
            for kind in (
                "google_goals",
                "google_actions",
                "google_goal_config",
                "google_custom_goals",
            ):
                read("entity_configuration", context_kind=kind)

        rows, lifetime, windows = [], None, []
        lifetime_reconciled = False
        # TikTok supplies campaign Lifetime totals, not daily dates. Meta maximum is daily.
        if (
            request.period is None
            and request.history_before is None
            and c.config.platform in ("tiktok", "meta")
        ):
            lifetime = read("traffic_performance", query_lifetime=True)
            if lifetime and c.config.platform == "meta":
                rows = lifetime.records
                lifetime_reconciled = True
        stop = request.period.end if request.period else request.history_before or today
        if stop > today or request.period and request.history_before:
            return needs(
                "invalid_history_scope",
                "Use a period ending by the account's current date, or history_before, not both.",
            )
        start = request.period.start if request.period else None
        # Google daily API retention is finite; bounded lookback is never labelled Lifetime.
        floor = (
            date(max(2000, today.year - 3), today.month, min(today.day, 28))
            if c.config.platform == "google"
            else date(2000, 1, 1)
        )
        floor = max(floor, start) if start else floor
        cursor = stop
        if lifetime and c.config.platform == "tiktok" and not lifetime.records:
            lifetime_reconciled = True
        if not lifetime_reconciled:
            for _ in range(request.max_windows):
                if cursor < floor:
                    break
                begin = max(floor, cursor - timedelta(days=30))
                period = DateRange(start=begin, end=cursor)
                traffic = read("traffic_performance", period=period)
                windows.append(
                    {
                        "start": begin.isoformat(),
                        "end": cursor.isoformat(),
                        "complete": traffic is not None,
                    }
                )
                if traffic:
                    rows.extend(traffic.records)
                cursor = begin - timedelta(days=1)
                if (
                    lifetime
                    and c.config.platform == "tiktok"
                    and all(w["complete"] for w in windows)
                ):
                    expected = {r.entity_id: r.values.get("spend") for r in lifetime.records}
                    observed = {
                        key: totals(value)["spend"]
                        for key, value in groups(rows, lambda r: r.entity_id).items()
                    }
                    # Exact decimal reconciliation, per campaign: no netting across entities.
                    lifetime_reconciled = (
                        bool(expected)
                        and not (set(observed) - set(expected))
                        and all(
                            v is not None and v == observed.get(k, Decimal(0))
                            for k, v in expected.items()
                        )
                    )
                if lifetime_reconciled or start and cursor < start:
                    break
                if traffic is None:
                    cursor = period.end  # Retry this failed window; never skip a missing range.
                    break  # keep deterministic resume boundary, avoid repeated permission errors
        row_keys = [(r.account_id, r.entity_id, r.event_date) for r in rows]
        if len(row_keys) != len(set(row_keys)):
            raise ValueError("overlapping historical source rows")
        # Detailed diagnostics use the latest observed positive-spend window, not all history.
        spend_dates = sorted(
            {
                r.event_date
                for r in rows
                if r.values.get("spend") is not None and r.values["spend"] > 0
            }
        )
        native_outcomes, audience, goal_observations = [], [], []
        if spend_dates:
            end = spend_dates[-1]
            detail_period = DateRange(start=max(spend_dates[0], end - timedelta(days=30)), end=end)
            detail_traffic = (
                read("traffic_performance", period=detail_period, report_level="adgroup")
                if c.config.platform == "tiktok"
                else None
            )
            result = read(
                "conversion_performance",
                period=detail_period,
                **({"report_level": "adgroup"} if c.config.platform != "google" else {}),
            )
            if result:
                native_outcomes = [
                    {
                        "entity_id": r.entity_id,
                        "date": str(r.event_date),
                        "native": r.metadata,
                        "source_ref": f"adapter-read://{result.read_id}/records/{i}",
                    }
                    for i, r in enumerate(result.records)
                ]
            if result and detail_traffic:
                from pallas_ads.adapter_service import _decimal

                spend_by_unit = groups(detail_traffic.records, lambda r: r.entity_id)
                conversions_by_unit = groups(result.records, lambda r: r.entity_id)
                for unit, unit_rows in spend_by_unit.items():
                    traffic_values = totals(unit_rows)
                    conversion_rows = conversions_by_unit.get(unit, [])
                    values = [
                        _decimal(r.metadata.get("metrics", {}).get("conversion"))
                        for r in conversion_rows
                    ]
                    same_dates = {r.event_date for r in unit_rows} == {
                        r.event_date for r in conversion_rows
                    }
                    count = (
                        sum(values, Decimal(0))
                        if values and same_dates and all(v is not None for v in values)
                        else None
                    )
                    spend = traffic_values["spend"]
                    goal_observations.append(
                        {
                            "entity_id": unit,
                            "period": detail_period.model_dump(mode="json"),
                            "native_conversion_count": count,
                            "native_cost_per_conversion": spend / count
                            if spend is not None and count is not None and count > 0
                            else None,
                            "spend": spend,
                            "traffic_read_id": detail_traffic.read_id,
                            "conversion_read_id": result.read_id,
                            "meaning": "provider conversion metric; historical optimization-event attribution not verified",
                            "canonical_outcome": False,
                        }
                    )
            for dimension in ("age", "gender", "country"):
                result = read(
                    "traffic_performance", period=detail_period, audience_dimension=dimension
                )
                if result:
                    audience.append(
                        {
                            "dimension": dimension,
                            "period": detail_period.model_dump(mode="json"),
                            "read_id": result.read_id,
                            "segments": [
                                {"segment": k, **totals(v)}
                                for k, v in groups(
                                    result.records, lambda r: r.metadata["audience_segment"]
                                ).items()
                            ],
                        }
                    )
        resolved = resolve_context(self.workspace, c, reads)
        resolved["native_goal_observations"] = goal_observations
        # Returned performance entities missing from current configuration must remain unresolved.
        known = {p["campaign_id"] for p in resolved["product_resolution"]}
        for identifier in sorted({r.entity_id for r in rows} - known):
            resolved["product_resolution"].append(
                {
                    "campaign_id": identifier,
                    "status": "unresolved",
                    "matches": [],
                    "store_identities": [],
                    "source_refs": [],
                    "campaign_name_used_for_identity": False,
                }
            )
        if self._connection(request.connection_id).revision != c.revision:
            raise ValueError("connection changed during analysis")
        complete_requested = bool(start and cursor < start and all(w["complete"] for w in windows))
        scope = {
            "platform": str(c.config.platform),
            "account_id": account,
            "currency": currency,
            "timezone": timezone,
            "selection": "explicit_period" if start else "available_history",
            "requested_period": request.period.model_dump(mode="json") if request.period else None,
            "windows": windows,
            "first_observed_spend_date": str(spend_dates[0]) if spend_dates else None,
            "last_observed_spend_date": str(spend_dates[-1]) if spend_dates else None,
            "lifetime_spend_reconciled": lifetime_reconciled and c.config.platform == "tiktok",
            "provider_maximum_read_complete": lifetime_reconciled and c.config.platform == "meta",
            "requested_period_read_complete": complete_requested,
            "history_complete": lifetime_reconciled,
            "next_history_before": str(cursor)
            if not lifetime_reconciled and cursor >= floor and not complete_requested
            else None,
            "lookback_floor": str(floor),
            "dense_coverage_verified": False,
            "claim_scope": "observed_rows_only",
            "canonical_imported": False,
        }
        comparison_period = (
            DateRange(start=spend_dates[0], end=spend_dates[-1])
            if spend_dates and request.period is None
            else request.period
        )
        scope["diagnostic_comparison_period"] = (
            comparison_period.model_dump(mode="json") if comparison_period else None
        )
        scope["diagnostic_comparison_policy"] = (
            "explicit_period" if request.period else "observed_positive_spend_span"
        )
        diagnostics = diagnose(rows, comparison_period=comparison_period)
        from pallas_ads.observation_diagnostics import context_insights

        insights, experiments = context_insights(resolved, audience, diagnostics)
        diagnostics["insights"].extend(insights)
        from pallas_ads.contracts.observation import ObservationInsight

        diagnostics["insights"] = [
            ObservationInsight.model_validate(i).model_dump(mode="json")
            for i in diagnostics["insights"]
        ]
        diagnostics["restart_experiments"] = experiments
        limitations = [
            "Missing dates are not zero; first/last are observed positive-spend dates.",
            "Current optimization configuration is not verified for the historical period.",
            "Native conversions are not verified business outcomes; no purchase/ROAS ranking.",
            "Arithmetic drivers and observational patterns do not establish causality.",
            "Clicks retain each provider's native semantics; cross-media click efficiency is unverified.",
        ]
        if not lifetime_reconciled:
            limitations.append(
                "Lifetime is unverified; the report covers only the displayed retrieved windows."
            )
        if not audience:
            limitations.append(
                "Delivered audience data unavailable; targeting cannot substitute for delivery demographics."
            )
        report = {
            "schema_version": "2.0.0",
            "kind": "account_observation_report",
            "evidence_mode": getattr(self.adapter, "evidence_mode", "live_source_reads"),
            "created_at": self.clock().isoformat(),
            "scope": scope,
            "context": resolved,
            "diagnostics": diagnostics,
            "native_outcomes": native_outcomes,
            "delivered_audience": audience,
            "attempts": attempts,
            "limitations": limitations,
            "evidence": [r.model_dump(mode="json") for r in reads],
        }
        from pallas_ads.observation_rendering import save_report

        artifacts = save_report(self.workspace, report)
        return OperationEnvelope(
            operation="build_report",
            status="partial_result",
            result={
                "scope": scope,
                "context": resolved,
                "diagnostics": diagnostics,
                "delivered_audience": audience,
                "limitations": limitations,
                "artifacts": artifacts,
                "next_step": "explain_evidence_then_ask_only_unresolved_business_facts",
                "source_failures": [a for a in attempts if not a["usable"]],
            },
            issues=issues
            + [
                OperationIssue(
                    code="observation_report_qualified",
                    severity="warning",
                    message="Observation report preserves incomplete coverage, current-only goals and unverified outcome semantics.",
                )
            ],
            missing_inputs=missing,
        )
