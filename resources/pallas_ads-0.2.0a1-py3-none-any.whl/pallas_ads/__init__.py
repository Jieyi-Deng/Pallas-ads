"""Pallas cross-media acquisition intelligence contracts and runtime."""

__version__ = "0.2.0a1"
