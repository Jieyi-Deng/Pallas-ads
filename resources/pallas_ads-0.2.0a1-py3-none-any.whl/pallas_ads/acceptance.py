"""Local acceptance records and an explicitly reviewed, credential-screened feedback archive.

Never traverses workspace state or credential stores. Pattern screening is a backstop,
not proof that arbitrary free text is anonymous; the tester must review staged content.
"""

import hashlib
import html
import json
import posixpath
import re
import stat
import zipfile
from datetime import UTC, datetime
from html.parser import HTMLParser
from pathlib import Path
from urllib.parse import unquote, urlsplit
from uuid import uuid4

PLATFORMS = ("google", "meta", "tiktok")
CASES = (
    "installation",
    "authorization",
    "cancel_retry",
    "account_discovery",
    "account_inspection",
    "product_evidence",
    "optimization_goal",
    "history_coverage",
    "empty_data",
    "performance_analysis",
    "report_quality",
    "restart",
)
STATUSES = {"not_run", "passed", "failed", "blocked", "not_applicable"}
ALLOWED = {".md", ".json", ".html", ".css", ".js", ".svg", ".csv", ".txt"}
# Do not log matched values. Encoded text is normalized before screening.
SECRET = re.compile(
    r"-----BEGIN [^-]*(?:PRIVATE KEY|CERTIFICATE)-----"
    r"|\b(?:access[_-]?token|refresh[_-]?token|id[_-]?token|client[_-]?secret|"
    r"app[_-]?secret|api[_-]?key|developer[_-]?token|code[_-]?verifier|password|token|secret|"
    r'authorization|cookie|set-cookie)\b[\s"\']*[:=]'
    r"|\bBearer\s+[A-Za-z0-9._~+/-]+"
    r"|\b(?:ya29\.|GOCSPX-|EAA[A-Za-z0-9]{10})"
    r"|\b1//[A-Za-z0-9_-]{10}"
    r"|\beyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+"
    r"|[?&](?:code|state|token|access_token|refresh_token|client_secret|code_challenge)="
    r"|file://|/Users/|/home/|\b[A-Z]:[\\/]|data:[^\s]*;base64,",
    re.IGNORECASE,
)


def _safe_path(path):
    path = Path(path).absolute()
    if any(p.is_symlink() for p in (path, *path.parents)):
        raise ValueError("Symlinks are not allowed.")
    return path


def _write(path, text):
    with path.open("x", encoding="utf-8") as handle:
        path.chmod(0o600)
        handle.write(text)


class _ReportLinks(HTMLParser):
    def __init__(self):
        super().__init__()
        self.links = []

    def handle_starttag(self, tag, attrs):
        self.links.extend((key, value) for key, value in attrs if key in {"href", "src"} and value)


def _check_links(contents):
    for index, (name, raw) in enumerate(sorted(contents.items()), 1):
        if not name.lower().endswith((".html", ".svg")):
            continue
        parser = _ReportLinks()
        parser.feed(raw.decode("utf-8"))
        for kind, link in parser.links:
            if link.startswith("#"):
                continue
            parsed = urlsplit(link)
            if kind == "href" and parsed.scheme in {"http", "https"}:
                continue  # Public citations, still screened for secrets in the complete file.
            target = posixpath.normpath(
                posixpath.join(posixpath.dirname(name), unquote(parsed.path))
            )
            if parsed.scheme or parsed.netloc or target not in contents:
                raise ValueError(f"Missing or unsafe report attachment in staged file #{index}.")


def start(directory):
    from pallas_ads import __version__

    root = _safe_path(directory)
    root.mkdir(mode=0o700, parents=True, exist_ok=False)
    share = root / "share"
    share.mkdir(mode=0o700)
    (share / "reports").mkdir(mode=0o700)
    result = {
        "schema_version": "1.0",
        "run_id": "test_" + uuid4().hex,
        "created_at": datetime.now(UTC).isoformat(),
        "pallas_version": __version__,
        "environment": {"os": None, "client_version": None, "wheel_sha256": None},
        "accounts": {p: {"alias": p + "-account", "data_state": "unknown"} for p in PLATFORMS},
        "cases": [
            {
                "id": f"{p}.{c}",
                "status": "not_run",
                "expected": "",
                "actual": "",
                "steps": [],
                "issue": "",
                "artifacts": [],
                "retry_count": 0,
                "timing_seconds": {
                    "authorization_page": None,
                    "user_consent": None,
                    "callback_complete": None,
                    "account_discovery": None,
                },
            }
            for p in PLATFORMS
            for c in CASES
        ],
    }
    _write(share / "results.json", json.dumps(result, ensure_ascii=False, indent=2) + "\n")
    _write(
        share / "SUMMARY.md",
        "# 本轮测试总结\n\n"
        "尚未执行。请按平台总结已测事项、实际结果、阻塞、主要问题和报告清单。\n"
        "记录平台接口耗时与用户等待时间；无法测量时写未测量。\n"
        "不填写登录邮箱、账户全名、完整账户 ID、凭据或完整授权链接。\n",
    )
    _write(
        root / "LOCAL_REPORT_INDEX.md",
        "# 本机报告索引（不回传）\n\n"
        "| 用例 ID | 原始报告及附件本机路径 | 回传副本相对路径 | 未提供原因 |\n"
        "|---|---|---|---|\n\n"
        "逐份登记本轮生成的报告。原件保留在本机 .pallas 中，不移动或删除；\n"
        "回传副本仅放在 share/reports，先脱敏并修复相对附件链接。\n",
    )
    _write(
        root / "README.md",
        "# 测试留存与可选回传\n\n"
        "results.json 中每项默认 not_run；没有真实结果不得标记 passed。\n"
        "更新 share/results.json、share/SUMMARY.md 和 LOCAL_REPORT_INDEX.md。\n"
        "只将人工检查过的报告副本及必要文本附件放入 share/reports。\n"
        "不要复制整个 .pallas、客户端日志、授权配置、钥匙串、证书或安装 wheel。\n"
        "HTML 附件使用相对链接；删除账户身份和敏感落地页参数；不放截图或二进制文件。\n"
        "为避免静默泄露，不自动导入或自动修改原始报告。\n"
        "测试者审阅 share 中每个文件后，让 agent 运行：\n\n"
        "`pallas acceptance pack --directory 本目录 --reviewed`\n\n"
        "扫描命中时不会生成 ZIP；按文件编号检查排序后的清单，不打印命中的敏感值。\n"
        "扫描不能证明任意内容无秘密。ZIP 可能含投放业务数据，需测试者同意分享。\n"
        "生成 ZIP 不会发送；测试者可以选择将 feedback.zip 手动交给维护者。\n",
    )
    return {"directory": str(root), "run_id": result["run_id"], "cases": len(result["cases"])}


def pack(directory, *, reviewed=False):
    if not reviewed:
        raise ValueError("Tester review is required before packaging.")
    root = _safe_path(directory)
    share = _safe_path(root / "share")
    output = root / "feedback.zip"
    if output.exists() or output.is_symlink():
        raise ValueError("Feedback ZIP already exists; preserve it and use a new run.")
    contents = {}
    size = 0
    paths = sorted(share.rglob("*"))
    if len(paths) > 200:
        raise ValueError("Too many staged files.")
    for index, path in enumerate(paths, 1):
        _safe_path(path)
        mode = path.stat().st_mode
        if stat.S_ISDIR(mode):
            continue
        rel = path.relative_to(share).as_posix()
        if (
            not stat.S_ISREG(mode)
            or path.suffix.lower() not in ALLOWED
            or path.stat().st_size > 10 * 1024 * 1024
            or not re.fullmatch(r"[A-Za-z0-9_./-]+", rel)
            or any(part.startswith(".") for part in Path(rel).parts)
            or not (rel in {"SUMMARY.md", "results.json"} or rel.startswith("reports/"))
        ):
            raise ValueError(f"Unsupported staged file #{index}.")
        raw = path.read_bytes()
        size += len(raw)
        if size > 50 * 1024 * 1024:
            raise ValueError("Staged content exceeds limit.")
        try:
            decoded = raw.decode("utf-8")
        except UnicodeError:
            raise ValueError(f"Non-text staged file #{index}.") from None
        normalized = decoded
        for _ in range(3):
            normalized = html.unescape(unquote(normalized))
        normalized = re.sub(r"\\u([0-9a-fA-F]{4})", lambda m: chr(int(m[1], 16)), normalized)
        if "\x00" in normalized or SECRET.search(normalized):
            raise ValueError(f"Potential secret or local path in staged file #{index}.")
        contents[rel] = raw
    _check_links(contents)
    try:
        records = json.loads(contents["results.json"])
        expected = {f"{p}.{c}" for p in PLATFORMS for c in CASES}
        if (
            records["schema_version"] != "1.0"
            or not isinstance(records["run_id"], str)
            or not re.fullmatch(r"test_[0-9a-f]{32}", records["run_id"])
            or not isinstance(records["cases"], list)
            or {r["id"] for r in records["cases"]} != expected
            or len(records["cases"]) != len(expected)
        ):
            raise ValueError("Invalid test records.")
        for row in records["cases"]:
            if (
                row["status"] not in STATUSES
                or not isinstance(row["actual"], str)
                or (row["status"] != "not_run" and not row["actual"].strip())
                or not isinstance(row["artifacts"], list)
                or not all(
                    isinstance(a, str) and a in contents and a.startswith("reports/")
                    for a in row["artifacts"]
                )
            ):
                raise ValueError("Invalid test outcome.")
        if not contents["SUMMARY.md"].strip():
            raise ValueError("Missing summary.")
    except (KeyError, TypeError, ValueError):
        raise ValueError("Incomplete results, invalid status or missing report artifact.") from None
    manifest = {
        "schema_version": "1.0",
        "run_id": records["run_id"],
        "tester_reviewed": True,
        "screening": "pattern_checks_passed_not_a_guarantee",
        "automatically_sent": False,
        "files": [
            {"path": name, "sha256": hashlib.sha256(raw).hexdigest()}
            for name, raw in sorted(contents.items())
        ],
    }
    created = False
    try:
        with output.open("xb") as handle:
            created = True
            output.chmod(0o600)
            with zipfile.ZipFile(handle, "w", zipfile.ZIP_DEFLATED) as archive:
                for name, raw in sorted(contents.items()):
                    archive.writestr(name, raw)
                archive.writestr("manifest.json", json.dumps(manifest, indent=2))
    except Exception:
        if created:
            output.unlink(missing_ok=True)
        raise
    return {"archive": str(output), "file_count": len(contents), "automatically_sent": False}
