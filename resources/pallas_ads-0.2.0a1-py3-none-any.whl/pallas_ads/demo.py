"""Installed, offline synthetic engineering Alpha walkthrough through public operations."""

from __future__ import annotations

import json
import shutil
from pathlib import Path

from pallas_ads.operations import Runtime


def run_demo(root: Path):
    root = root.expanduser().resolve()
    if root.exists() and (not root.is_dir() or any(root.iterdir())):
        raise ValueError("Demo output must be new or empty.")
    resources = Path(__file__).parent / "resources" / "demo"
    root.mkdir(parents=True, exist_ok=True)
    shutil.copytree(resources, root / "inputs")
    runtime = Runtime(root / "workspace")
    try:
        runtime.workspace.bootstrap("workspace_alpha_demo")
        steps = []

        def call(name, payload):
            result = runtime.invoke(name, payload)
            if result.result is None or result.status not in ("complete", "partial_result"):
                raise ValueError(f"Demo operation failed: {name}")
            steps.append({"operation": name, "status": result.status.value})
            (root / f"{len(steps):02d}-{name}.json").write_text(result.model_dump_json(indent=2))
            return result.result

        review = call(
            "profile_create_or_update",
            {
                "action": "draft",
                "draft_id": "draft_alpha_demo",
                "values": json.loads((root / "inputs/profile.json").read_text()),
            },
        )
        (root / "profile-summary.md").write_text(review.confirmation_summary)
        # This command is explicitly a synthetic simulation, never real user profile consent.
        call(
            "profile_create_or_update",
            dict(
                action="confirm",
                draft_id=review.draft_id,
                content_hash=review.content_hash,
                user_confirmed=True,
            ),
        )
        call("profile_get_context", {})
        for platform in ("meta", "tiktok", "google"):
            call(
                "source_connect_or_import",
                dict(action="import", package_path=str(root / f"inputs/package_{platform}_v1")),
            )
        query = dict(
            query_id="query_alpha_demo",
            product_id="prod_synthetic_quest",
            platforms=["meta", "tiktok"],
            metrics=["spend", "ctr"],
        )
        packet = call("compare_acquisition", query)
        call("validate_comparability", query)
        definition = dict(
            monitor_id="monitor_alpha_demo",
            name="Synthetic spend change",
            family="delivery",
            metric="spend",
            direction="either",
            relative_threshold="0.2",
            calibration="synthetic",
            query={**query, "metrics": ["spend"]},
        )
        run = call("run_monitors", dict(definition=definition))
        call(
            "build_report",
            dict(action="prepare", packet_id=packet.packet_id, monitor_run_ids=[run.run_id]),
        )
        report = call(
            "build_report", dict(packet_id=packet.packet_id, monitor_run_ids=[run.run_id])
        )
        call(
            "build_report",
            dict(
                action="load",
                product_id="prod_synthetic_quest",
                report_id=report.manifest.report_id,
            ),
        )
        summary = dict(
            data_kind="synthetic_only_not_live_reconciliation",
            steps=steps,
            report_directory=report.directory,
            workspace=str(runtime.workspace.layout.root),
        )
        (root / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
        return summary
    finally:
        runtime.close()
