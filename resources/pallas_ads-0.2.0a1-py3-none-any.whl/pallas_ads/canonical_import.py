"""Validated import-first path for canonical Meta, TikTok, and Google packages."""

from __future__ import annotations

import csv
import hashlib
import json
import shutil
import tempfile
from collections.abc import Mapping
from datetime import timedelta
from pathlib import Path
from typing import Any
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

import yaml
from pydantic import ValidationError

from pallas_ads.contracts.common import ReportingTimeBasis
from pallas_ads.contracts.data import (
    CanonicalEntityRecord,
    CanonicalImportFile,
    CanonicalImportManifest,
    CanonicalImportResult,
    CanonicalObservationRecord,
    DimensionState,
    EntityType,
    ImportFileFormat,
    ImportFileRole,
    MaturityStatus,
)
from pallas_ads.contracts.profile import MediaBinding, ProductProfile
from pallas_ads.contracts.status import (
    IssueSeverity,
    MissingInput,
    OperationEnvelope,
    OperationIssue,
    OperationStatus,
)
from pallas_ads.data_store import CanonicalDataError, CanonicalDataRepository
from pallas_ads.local_state import LocalStateError, WorkspaceRepository
from pallas_ads.metric_registry import DEFAULT_METRIC_REGISTRY, MetricRegistry


class ImportInputError(ValueError):
    def __init__(self, field_path: str, reason: str, expected_type: str | None = None) -> None:
        super().__init__(reason)
        self.field_path = field_path
        self.reason = reason
        self.expected_type = expected_type


class CanonicalImportService:
    """Loads source-neutral files only after manifest and profile validation."""

    def __init__(
        self,
        workspace: WorkspaceRepository,
        *,
        metric_registry: MetricRegistry = DEFAULT_METRIC_REGISTRY,
    ) -> None:
        self.workspace = workspace
        self.data = CanonicalDataRepository(workspace)
        self.metrics = metric_registry

    def import_package(self, package: Path) -> OperationEnvelope[CanonicalImportResult]:
        try:
            manifest_path = _resolve_manifest_path(package)
            manifest = _load_manifest(manifest_path)
            package_root = manifest_path.parent.resolve()
            if not self.workspace.layout.workspace_file.is_file():
                raise ImportInputError(
                    "/workspace",
                    "canonical import requires an initialized Pallas workspace",
                    "a bootstrapped local workspace",
                )
            workspace_manifest = self.workspace.load_manifest()
            workspace_state = self.workspace.bootstrap(workspace_manifest.workspace_id)
            if workspace_state.status is not OperationStatus.COMPLETE:
                raise ImportInputError(
                    "/workspace",
                    "canonical import could not initialize the local data schema",
                )
            profile_revision = self.workspace.latest_profile_revision(manifest.product_id)
            if profile_revision is None:
                raise ImportInputError(
                    "/product_id",
                    "import product does not have a confirmed profile revision",
                    "confirmed product profile ID",
                )
            binding = _validate_profile_binding(profile_revision.profile, manifest)
            latest_observed_at = self.data.latest_source_observed_at(
                manifest.product_id,
                manifest.platform,
                manifest.account_id,
            )
            if latest_observed_at is not None and manifest.observed_at < latest_observed_at:
                raise ImportInputError(
                    "/observed_at",
                    "source snapshot is older than the latest imported snapshot for this account",
                    "a timestamp on or after the latest source snapshot",
                )

            loaded_files = [
                _load_import_file(package_root, file_spec) for file_spec in manifest.files
            ]
            entities = _parse_entities(loaded_files)
            observations = _parse_observations(loaded_files)
            _validate_records(
                manifest,
                binding.app_variant_ids,
                entities,
                observations,
                self.metrics,
            )
            content_hash = _package_content_hash(manifest, loaded_files)
            inventory = sorted(
                {
                    f"{loaded.spec.role.value}.{field_name}"
                    for loaded in loaded_files
                    for field_name in loaded.field_inventory
                }
            )
            raw_path, raw_created = _copy_raw_package(
                self.workspace,
                manifest_path,
                manifest,
                loaded_files,
            )
            saved_manifest_path: Path | None = None
            saved_manifest_created = False
            try:
                saved_manifest_path, saved_manifest_created = _save_source_manifest(
                    self.workspace,
                    manifest,
                )
                result = self.data.persist_import(
                    manifest,
                    content_hash=content_hash,
                    response_field_inventory=inventory,
                    raw_path=raw_path,
                    entities=entities,
                    observations=observations,
                )
            except Exception:
                if raw_created:
                    shutil.rmtree(self.workspace.layout.root / raw_path)
                if saved_manifest_created and saved_manifest_path is not None:
                    saved_manifest_path.unlink()
                raise
            return OperationEnvelope[CanonicalImportResult](
                operation="source_import",
                status=OperationStatus.COMPLETE,
                result=result,
                issues=[
                    OperationIssue(
                        code="reporting_time_basis_unverified",
                        severity=IssueSeverity.WARNING,
                        message=(
                            "Unknown or mixed report-date semantics were preserved; "
                            "strict outcome-efficiency claims require source verification."
                        ),
                        source=manifest.platform.value,
                        field_path="/files/observations/reporting_time_basis",
                    )
                ]
                if any(
                    record.reporting_time_basis
                    in {ReportingTimeBasis.UNKNOWN, ReportingTimeBasis.MIXED}
                    for record in observations
                )
                else [],
            )
        except ValidationError as error:
            return _validation_envelope(error)
        except (ImportInputError, CanonicalDataError) as error:
            missing_input = (
                MissingInput(
                    field_path=error.field_path,
                    reason=error.reason,
                    expected_type=error.expected_type,
                )
                if isinstance(error, ImportInputError)
                else MissingInput(
                    field_path="/source_snapshot_id",
                    reason=str(error),
                    expected_type="a unique snapshot and package identity",
                )
            )
            return OperationEnvelope[CanonicalImportResult](
                operation="source_import",
                status=OperationStatus.NEEDS_INPUT,
                missing_inputs=[missing_input],
            )
        except LocalStateError:
            return OperationEnvelope[CanonicalImportResult](
                operation="source_import",
                status=OperationStatus.NEEDS_INPUT,
                missing_inputs=[
                    MissingInput(
                        field_path="/workspace",
                        reason="workspace metadata and DuckDB state are inconsistent",
                    )
                ],
            )
        except OSError:
            return OperationEnvelope[CanonicalImportResult](
                operation="source_import",
                status=OperationStatus.NEEDS_INPUT,
                missing_inputs=[
                    MissingInput(
                        field_path="/workspace",
                        reason="workspace cannot retain the validated raw import package",
                        expected_type="a writable local Pallas workspace",
                    )
                ],
            )


class _LoadedImportFile:
    def __init__(
        self,
        spec: CanonicalImportFile,
        path: Path,
        records: list[dict[str, Any]],
        field_inventory: set[str],
        actual_hash: str,
    ) -> None:
        self.spec = spec
        self.path = path
        self.records = records
        self.field_inventory = field_inventory
        self.actual_hash = actual_hash


def _resolve_manifest_path(package: Path) -> Path:
    path = package.expanduser().resolve()
    if path.is_file():
        return path
    if not path.is_dir():
        raise ImportInputError("/package", "canonical import package does not exist")
    candidates = [
        path / name
        for name in ("manifest.json", "manifest.yaml", "manifest.yml")
        if (path / name).is_file()
    ]
    if len(candidates) != 1:
        raise ImportInputError(
            "/manifest",
            "package directory must contain exactly one supported manifest file",
            "manifest.json, manifest.yaml, or manifest.yml",
        )
    return candidates[0]


def _load_manifest(path: Path) -> CanonicalImportManifest:
    try:
        text = path.read_text(encoding="utf-8")
        payload = json.loads(text) if path.suffix.lower() == ".json" else yaml.safe_load(text)
    except (OSError, json.JSONDecodeError, yaml.YAMLError) as error:
        raise ImportInputError("/manifest", "manifest is not readable structured data") from error
    if not isinstance(payload, Mapping):
        raise ImportInputError("/manifest", "manifest must contain an object")
    return CanonicalImportManifest.model_validate(payload)


def _load_import_file(package_root: Path, spec: CanonicalImportFile) -> _LoadedImportFile:
    path = (package_root / spec.path).resolve()
    if not path.is_relative_to(package_root) or not path.is_file():
        raise ImportInputError(
            f"/files/{spec.path}",
            "declared import file is missing or outside the package",
        )
    try:
        content = path.read_bytes()
    except OSError as error:
        raise ImportInputError(f"/files/{spec.path}", "import file is not readable") from error
    actual_hash = f"sha256:{hashlib.sha256(content).hexdigest()}"
    if actual_hash != spec.content_sha256:
        raise ImportInputError(
            f"/files/{spec.path}/content_sha256",
            "declared content hash does not match the file",
        )

    if spec.format is ImportFileFormat.JSON:
        try:
            payload = json.loads(content)
        except json.JSONDecodeError as error:
            raise ImportInputError(f"/files/{spec.path}", "file is not valid JSON") from error
        if isinstance(payload, Mapping):
            payload = payload.get("records")
        if not isinstance(payload, list) or not all(isinstance(row, Mapping) for row in payload):
            raise ImportInputError(
                f"/files/{spec.path}",
                "JSON import files must contain a list of record objects",
            )
        records = [dict(row) for row in payload]
        inventory = {str(key) for row in records for key in row}
    else:
        try:
            decoded = content.decode("utf-8-sig")
            reader = csv.DictReader(decoded.splitlines())
            if reader.fieldnames is None:
                raise ImportInputError(f"/files/{spec.path}", "CSV file requires a header")
            records = [dict(row) for row in reader]
            inventory = set(reader.fieldnames)
        except UnicodeDecodeError as error:
            raise ImportInputError(f"/files/{spec.path}", "CSV file must be UTF-8") from error
    return _LoadedImportFile(spec, path, records, inventory, actual_hash)


def _parse_entities(loaded_files: list[_LoadedImportFile]) -> list[CanonicalEntityRecord]:
    loaded = next(item for item in loaded_files if item.spec.role is ImportFileRole.ENTITIES)
    return [
        CanonicalEntityRecord.model_validate(
            _normalize_csv_entity(row) if loaded.spec.format is ImportFileFormat.CSV else row
        )
        for row in loaded.records
    ]


def _parse_observations(
    loaded_files: list[_LoadedImportFile],
) -> list[CanonicalObservationRecord]:
    loaded = next(item for item in loaded_files if item.spec.role is ImportFileRole.OBSERVATIONS)
    return [
        CanonicalObservationRecord.model_validate(
            _normalize_csv_observation(row) if loaded.spec.format is ImportFileFormat.CSV else row
        )
        for row in loaded.records
    ]


def _normalize_csv_entity(row: dict[str, Any]) -> dict[str, Any]:
    payload = _without_blank_values(row)
    _nest_dimension(payload, "campaign_type")
    _nest_dimension(payload, "optimization_goal")
    _nest_attribution(payload)
    return payload


def _normalize_csv_observation(row: dict[str, Any]) -> dict[str, Any]:
    payload = _without_blank_values(row)
    for name in ("country", "os", "campaign_type", "optimization_goal"):
        _nest_dimension(payload, name)
    _nest_attribution(payload)
    return payload


def _without_blank_values(row: dict[str, Any]) -> dict[str, Any]:
    return {key: value for key, value in row.items() if value not in (None, "")}


def _nest_dimension(payload: dict[str, Any], name: str) -> None:
    state = payload.pop(f"{name}_state", None)
    value = payload.pop(f"{name}_value", None)
    if state is not None or value is not None:
        payload[name] = {"state": state or DimensionState.VALUE.value, "value": value}


def _nest_attribution(payload: dict[str, Any]) -> None:
    event_key = payload.pop("attribution_event_key", None)
    click_window = payload.pop("attribution_click_window_days", None)
    view_window = payload.pop("attribution_view_window_days", None)
    if event_key is not None or click_window is not None or view_window is not None:
        payload["attribution_spec"] = {
            "event_key": event_key,
            "click_window_days": click_window,
            "view_window_days": view_window,
        }


def _validate_profile_binding(
    profile: ProductProfile,
    manifest: CanonicalImportManifest,
) -> MediaBinding:
    matching = [
        binding
        for binding in profile.media_bindings
        if binding.platform is manifest.platform and binding.account_id == manifest.account_id
    ]
    if len(matching) != 1:
        raise ImportInputError(
            "/account_id",
            "manifest platform and account are not uniquely bound to the product profile",
            "a media account bound to the confirmed product profile",
        )
    binding = matching[0]
    for field_name, manifest_value in (
        ("account_currency", manifest.account_currency),
        ("account_timezone", manifest.source_timezone),
    ):
        source_fact = getattr(binding, field_name)
        if source_fact is not None and source_fact.value != manifest_value:
            raise ImportInputError(
                f"/{field_name}",
                "manifest value conflicts with the confirmed API/import account fact",
            )
    return binding


def _validate_records(
    manifest: CanonicalImportManifest,
    allowed_variant_ids: list[str],
    entities: list[CanonicalEntityRecord],
    observations: list[CanonicalObservationRecord],
    metric_registry: MetricRegistry,
) -> None:
    try:
        timezone = ZoneInfo(manifest.source_timezone)
    except (ValueError, ZoneInfoNotFoundError) as error:
        raise ImportInputError(
            "/source_timezone",
            "source timezone is not a recognized IANA timezone",
        ) from error
    observed_source_date = manifest.observed_at.astimezone(timezone).date()
    policy_by_metric = {
        (item.canonical_metric, item.metric_semantic_version, item.reporting_time_basis): item
        for item in manifest.maturity_policies
    }
    entity_ids: set[tuple[object, str]] = set()
    for index, entity in enumerate(entities):
        entity_identity = (entity.entity_type, entity.entity_id)
        if entity_identity in entity_ids:
            raise ImportInputError(
                f"/files/entities/{index}",
                "entity records must be unique by entity_type and entity_id",
            )
        entity_ids.add(entity_identity)
        if entity.app_variant_id is not None and entity.app_variant_id not in allowed_variant_ids:
            raise ImportInputError(
                f"/files/entities/{index}/app_variant_id",
                "entity references an app variant outside the media binding",
            )
        if entity.entity_type.value == "account" and entity.entity_id != manifest.account_id:
            raise ImportInputError(
                f"/files/entities/{index}/entity_id",
                "account entity ID must match the manifest account",
            )
        if entity.source_updated_at is not None and entity.source_updated_at > manifest.observed_at:
            raise ImportInputError(
                f"/files/entities/{index}/source_updated_at",
                "source_updated_at cannot be later than observed_at",
            )

    observation_identities: set[str] = set()
    for index, observation in enumerate(observations):
        if (observation.entity_type, observation.entity_id) not in entity_ids:
            raise ImportInputError(
                f"/files/observations/{index}/entity_id",
                "observation must reference an entity in the same package",
            )
        if (
            observation.app_variant_id is not None
            and observation.app_variant_id not in allowed_variant_ids
        ):
            raise ImportInputError(
                f"/files/observations/{index}/app_variant_id",
                "observation references an app variant outside the media binding",
            )
        if not (
            manifest.effective_period.start
            <= observation.event_date
            <= manifest.effective_period.end
        ):
            raise ImportInputError(
                f"/files/observations/{index}/event_date",
                "observation date is outside the manifest effective period",
            )
        if observation.event_date > observed_source_date:
            raise ImportInputError(
                f"/files/observations/{index}/event_date",
                "observation date cannot be later than the source-local observed date",
            )
        if observation.currency != manifest.account_currency:
            raise ImportInputError(
                f"/files/observations/{index}/currency",
                "observation currency must match the manifest account currency",
            )
        if observation.source_timezone != manifest.source_timezone:
            raise ImportInputError(
                f"/files/observations/{index}/source_timezone",
                "observation timezone must match the manifest source timezone",
            )
        definition = metric_registry.definition(observation.metric_key)
        if not definition.importable:
            raise ImportInputError(
                f"/files/observations/{index}/metric_key",
                "derived ratios cannot be imported; provide their additive components",
            )
        if observation.metric_semantic_version != definition.semantic_version:
            raise ImportInputError(
                f"/files/observations/{index}/metric_semantic_version",
                "metric semantic version does not match the shipped registry",
            )
        if observation.unit != definition.unit.value:
            raise ImportInputError(
                f"/files/observations/{index}/unit",
                "observation unit does not match the Metric Registry",
            )
        if definition.attribution_sensitive and observation.attribution_spec is None:
            raise ImportInputError(
                f"/files/observations/{index}/attribution_spec",
                "attribution-sensitive metric requires explicit attribution settings",
            )
        policy = policy_by_metric.get(
            (
                observation.metric_key,
                observation.metric_semantic_version,
                observation.reporting_time_basis,
            )
        )
        if policy is None:
            raise ImportInputError(
                f"/maturity_policies/{observation.metric_key.value}",
                "every imported metric and report-date basis requires versioned maturity metadata",
            )
        mature_through = observed_source_date - timedelta(days=policy.provisional_days)
        expected_maturity = (
            MaturityStatus.MATURE
            if policy.maturity_verified and observation.event_date <= mature_through
            else MaturityStatus.PROVISIONAL
        )
        if observation.maturity_status is not expected_maturity:
            raise ImportInputError(
                f"/files/observations/{index}/maturity_status",
                "maturity status conflicts with the manifest policy and source-local date",
            )
        identity_payload = observation.model_dump(
            mode="json",
            exclude={"value", "unit", "maturity_status"},
        )
        identity = json.dumps(identity_payload, sort_keys=True, separators=(",", ":"))
        if identity in observation_identities:
            raise ImportInputError(
                f"/files/observations/{index}",
                "observation facts must be unique within one package",
            )
        observation_identities.add(identity)

    _validate_coverage(manifest, entities, observations, metric_registry)


def _validate_coverage(
    manifest: CanonicalImportManifest,
    entities: list[CanonicalEntityRecord],
    observations: list[CanonicalObservationRecord],
    metric_registry: MetricRegistry,
) -> None:
    coverage = manifest.coverage
    if coverage is None:
        # Sparse legacy packages never imply unreported facts were zero.
        return
    campaign_ids = set(coverage.campaign_ids)
    entity_campaign_ids = {
        entity.entity_id for entity in entities if entity.entity_type is EntityType.CAMPAIGN
    }
    if entity_campaign_ids != campaign_ids:
        raise ImportInputError(
            "/coverage/campaign_ids",
            "coverage campaign population must exactly match campaign entities in the package",
        )
    policy_keys = {
        (policy.canonical_metric, policy.metric_semantic_version, policy.reporting_time_basis)
        for policy in manifest.maturity_policies
    }
    for metric in coverage.metrics:
        definition = metric_registry.definition(metric)
        if not definition.importable:
            raise ImportInputError(
                "/coverage/metrics", "coverage must declare only additive, importable metrics"
            )
        if (
            metric,
            definition.semantic_version,
            coverage.reporting_time_bases[metric],
        ) not in policy_keys:
            raise ImportInputError(
                "/coverage/metrics",
                "coverage metrics require versioned maturity policies, "
                "even for an empty population",
            )
    declared_metrics = set(coverage.metrics)
    # Validate memberships plus unique cells and cardinality instead of constructing
    # a potentially enormous campaign × date × metric Cartesian product.
    seen_cells: set[tuple[str, object, object]] = set()
    for index, observation in enumerate(observations):
        if observation.entity_type is not EntityType.CAMPAIGN:
            continue
        if (
            observation.entity_id not in campaign_ids
            or observation.metric_key not in declared_metrics
            or observation.country != coverage.country
            or observation.os != coverage.os
            or observation.reporting_time_basis
            != coverage.reporting_time_bases.get(observation.metric_key)
        ):
            raise ImportInputError(
                f"/files/observations/{index}",
                "campaign observation falls outside the exact declared coverage slice",
            )
        cell = (observation.entity_id, observation.event_date, observation.metric_key)
        if cell in seen_cells:
            raise ImportInputError(
                f"/files/observations/{index}",
                "coverage requires exactly one observation per campaign, date, and metric",
            )
        seen_cells.add(cell)
    day_count = (manifest.effective_period.end - manifest.effective_period.start).days + 1
    expected_count = len(campaign_ids) * day_count * len(declared_metrics)
    if len(seen_cells) != expected_count:
        raise ImportInputError(
            "/coverage",
            "complete coverage requires explicit observations, including zeros, for every "
            "declared campaign, date, and metric",
        )


def _package_content_hash(
    manifest: CanonicalImportManifest,
    loaded_files: list[_LoadedImportFile],
) -> str:
    digest = hashlib.sha256()
    manifest_payload = manifest.model_dump(mode="json")
    if not manifest.native_lineage:
        del manifest_payload["native_lineage"]
    if manifest.coverage is None:
        # Preserve hashes and idempotency for Week 3 manifests without coverage.
        del manifest_payload["coverage"]
    for policy in manifest_payload["maturity_policies"]:
        if policy["maturity_verified"]:
            del policy["maturity_verified"]
        if policy["reporting_time_basis"] == ReportingTimeBasis.UNKNOWN.value:
            del policy["reporting_time_basis"]
    digest.update(
        json.dumps(
            manifest_payload,
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
        ).encode("utf-8")
    )
    for loaded in sorted(loaded_files, key=lambda item: item.spec.path):
        digest.update(loaded.spec.path.encode("utf-8"))
        digest.update(loaded.actual_hash.encode("ascii"))
    return f"sha256:{digest.hexdigest()}"


def _copy_raw_package(
    workspace: WorkspaceRepository,
    manifest_path: Path,
    manifest: CanonicalImportManifest,
    loaded_files: list[_LoadedImportFile],
) -> tuple[str, bool]:
    target = workspace.layout.raw_data_dir / manifest.platform.value / manifest.source_snapshot_id
    relative_target = target.relative_to(workspace.layout.root).as_posix()
    if target.exists():
        try:
            copied_manifest = _load_manifest(_resolve_manifest_path(target))
        except (ImportInputError, ValidationError) as error:
            raise ImportInputError(
                "/source_snapshot_id",
                "raw snapshot directory contains an invalid manifest",
            ) from error
        if copied_manifest != manifest:
            raise ImportInputError(
                "/source_snapshot_id",
                "raw snapshot directory already exists with different manifest content",
            )
        for loaded in loaded_files:
            copied_file = target / loaded.spec.path
            if not copied_file.is_file():
                raise ImportInputError(
                    f"/files/{loaded.spec.path}",
                    "raw snapshot directory is missing a declared file",
                )
            copied_hash = f"sha256:{hashlib.sha256(copied_file.read_bytes()).hexdigest()}"
            if copied_hash != loaded.actual_hash:
                raise ImportInputError(
                    f"/files/{loaded.spec.path}",
                    "raw snapshot directory contains different file content",
                )
        return relative_target, False
    target.parent.mkdir(parents=True, exist_ok=True)
    staging = Path(tempfile.mkdtemp(prefix=f".{target.name}.", dir=target.parent))
    try:
        shutil.copy2(manifest_path, staging / manifest_path.name)
        for loaded in loaded_files:
            destination = staging / loaded.spec.path
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(loaded.path, destination)
        staging.replace(target)
    finally:
        if staging.exists():
            shutil.rmtree(staging)
    return relative_target, True


def _save_source_manifest(
    workspace: WorkspaceRepository,
    manifest: CanonicalImportManifest,
) -> tuple[Path, bool]:
    target = workspace.layout.source_manifests_dir / f"{manifest.source_snapshot_id}.json"
    content = (
        json.dumps(
            manifest.model_dump(mode="json"),
            ensure_ascii=False,
            indent=2,
            sort_keys=True,
        )
        + "\n"
    )
    if target.exists():
        saved_manifest = CanonicalImportManifest.model_validate_json(
            target.read_text(encoding="utf-8")
        )
        if saved_manifest != manifest:
            raise ImportInputError(
                "/source_snapshot_id",
                "persisted source manifest already exists with different content",
            )
        return target, False
    target.parent.mkdir(parents=True, exist_ok=True)
    temporary_path: Path | None = None
    try:
        with tempfile.NamedTemporaryFile(
            mode="w",
            encoding="utf-8",
            dir=target.parent,
            prefix=f".{target.name}.",
            suffix=".tmp",
            delete=False,
        ) as handle:
            handle.write(content)
            temporary_path = Path(handle.name)
        temporary_path.replace(target)
    finally:
        if temporary_path is not None and temporary_path.exists():
            temporary_path.unlink()
    return target, True


def _validation_envelope(
    error: ValidationError,
) -> OperationEnvelope[CanonicalImportResult]:
    missing_inputs: list[MissingInput] = []
    seen_paths: set[str] = set()
    for item in error.errors(include_input=False, include_url=False):
        path = "/" + "/".join(str(part) for part in item["loc"])
        if path in seen_paths:
            continue
        seen_paths.add(path)
        missing_inputs.append(
            MissingInput(
                field_path=path,
                reason=str(item["msg"]),
                expected_type=str(item["type"]),
            )
        )
    return OperationEnvelope[CanonicalImportResult](
        operation="source_import",
        status=OperationStatus.NEEDS_INPUT,
        missing_inputs=missing_inputs,
    )
