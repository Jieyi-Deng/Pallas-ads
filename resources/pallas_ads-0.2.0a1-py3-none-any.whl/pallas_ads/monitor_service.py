"""Import-backed monitoring; deterministic rules, no scheduler or source/LLM calls."""

from __future__ import annotations

from datetime import UTC, datetime
from decimal import Decimal
from typing import Literal, NotRequired, TypedDict

import duckdb
from pydantic import ValidationError

from pallas_ads.compare_service import ComparisonService
from pallas_ads.contracts.analysis import EvidencePolicy
from pallas_ads.contracts.base import reject_secret_material
from pallas_ads.contracts.common import ComparisonStatus
from pallas_ads.contracts.data import EntitySnapshot, EntityType
from pallas_ads.contracts.evidence import EvidencePacket
from pallas_ads.contracts.monitor import (
    MonitorDefinition,
    MonitorEvaluation,
    MonitorEvent,
    MonitorRun,
    Severity,
    SourceHealthObservation,
)
from pallas_ads.contracts.profile import MediaBinding, ProfileRevision
from pallas_ads.contracts.query import CanonicalQuery
from pallas_ads.contracts.status import (
    MissingInput,
    OperationEnvelope,
    OperationIssue,
    OperationStatus,
)
from pallas_ads.data_store import CanonicalDataRepository
from pallas_ads.local_state import WorkspaceRepository
from pallas_ads.monitor_store import MonitorRepository, MonitorStateError
from pallas_ads.query_planner import campaign_allowed, content_hash


class _EvaluationScope(TypedDict):
    scope_key: str
    period_key: str
    severity: Severity
    auto_resolve: NotRequired[bool]


class MonitorService:
    def __init__(
        self,
        workspace: WorkspaceRepository,
        *,
        evidence_policies: dict[str, EvidencePolicy] | None = None,
    ) -> None:
        self.workspace = workspace
        # Upgrade existing Week 2–4 workspaces before any monitoring table is accessed.
        workspace.bootstrap(workspace.load_manifest().workspace_id)
        self.data = CanonicalDataRepository(workspace)
        self.store = MonitorRepository(workspace)
        self.compare = ComparisonService(workspace, evidence_policies=evidence_policies)

    def record_health(
        self,
        observation: SourceHealthObservation,
    ) -> OperationEnvelope[SourceHealthObservation]:
        try:
            observation = SourceHealthObservation.model_validate(
                observation.model_dump(mode="json")
            )
            profile = self.workspace.latest_profile_revision(observation.product_id)
            if profile is None or not any(
                b.platform == observation.platform and b.account_id == observation.account_id
                for b in profile.profile.media_bindings
            ):
                raise MonitorStateError("health observation requires a confirmed source binding")
            _revision(observation.data_revision, self.data.latest_data_revision())
            self.store.save_health(observation)
            return OperationEnvelope(
                operation="record_source_health", status="complete", result=observation
            )
        except (ValueError, MonitorStateError, duckdb.Error):
            return _needs(
                "record_source_health", "health evidence is invalid or conflicts with history"
            )

    def run(
        self,
        definition: MonitorDefinition,
        *,
        data_revision: int | None = None,
        baseline_data_revision: int | None = None,
        evaluated_at: datetime | None = None,
    ) -> OperationEnvelope[MonitorRun]:
        try:
            definition = MonitorDefinition.model_validate(definition.model_dump(mode="json"))
            now = evaluated_at or datetime.now(UTC)
            if now.tzinfo is None or now.utcoffset() is None:
                raise MonitorStateError("evaluation time must be timezone-aware")
            latest = self.data.latest_data_revision()
            revision = latest if data_revision is None else data_revision
            _revision(revision, latest)
            profile = self.workspace.latest_profile_revision(definition.query.product_id)
            if profile is None:
                raise MonitorStateError("monitor requires a confirmed product profile")
            if now < profile.confirmed_at:
                raise MonitorStateError("evaluation cannot predate confirmed profile context")
            bindings = _bindings(definition.query, profile)
            if definition.family == "configuration":
                if baseline_data_revision is None:
                    raise MonitorStateError(
                        "configuration monitor requires a baseline data revision"
                    )
                _revision(baseline_data_revision, revision - 1)
            elif baseline_data_revision is not None:
                raise MonitorStateError("baseline data revision is only for configuration monitors")
            snapshots = self.data.source_snapshots(
                definition.query.product_id,
                as_of_data_revision=revision,
            )
            if any(
                s.observed_at > now
                for s in snapshots
                if any(b.platform == s.platform and b.account_id == s.account_id for b in bindings)
            ):
                raise MonitorStateError("evaluation predates selected source observations")
            packet = None
            health: list[SourceHealthObservation] = []
            warnings: list[str] = []
            if definition.family in ("delivery", "traffic", "outcome"):
                if revision == 0:
                    raise MonitorStateError("performance monitor requires imported observations")
                query = CanonicalQuery.model_validate(
                    {
                        **definition.query.model_dump(mode="json"),
                        "as_of_data_revision": revision,
                        "profile_revision": profile.revision,
                    }
                )
                response = self.compare.compare(query)
                if response.result is None:
                    return OperationEnvelope(
                        operation="run_monitors",
                        status=OperationStatus.NEEDS_INPUT,
                        missing_inputs=response.missing_inputs,
                    )
                packet = response.result
                evaluations = _performance(definition, packet)
                warnings = [warning.code for warning in packet.warnings]
            elif definition.family == "configuration":
                assert baseline_data_revision is not None
                evaluations = self._configuration(
                    definition, bindings, revision, baseline_data_revision
                )
            else:
                evaluations, health = self._health(definition, bindings, revision, now)
            self.store.save_definition(definition)
            definition_hash = content_hash(definition.model_dump(mode="json"))
            # Performance/configuration clocks do not manufacture new runs on retries.
            # Freshness and source-health decisions depend on the explicit evaluation clock.
            identity = [
                "monitor-engine-1.0.0",
                definition_hash,
                revision,
                profile.profile_hash,
                profile.revision,
                baseline_data_revision,
                packet.packet_id if packet else None,
                now.isoformat() if definition.family == "data_health" else None,
                [h.model_dump(mode="json") for h in health],
            ]
            run_id = "run_" + content_hash(identity)[7:]
            existing = self.store.get_run(run_id)
            if existing is not None:
                return _envelope(existing)
            run = MonitorRun(
                run_id=run_id,
                definition=definition,
                definition_hash=definition_hash,
                data_revision=revision,
                baseline_data_revision=baseline_data_revision,
                profile_revision=profile.revision,
                profile_hash=profile.profile_hash,
                evaluated_at=now,
                packet_id=packet.packet_id if packet else None,
                health_observations=health,
                evaluations=evaluations,
                warnings=sorted(set(warnings)),
            )
            return _envelope(self.store.publish(run))
        except MonitorStateError as error:
            return _needs("run_monitors", str(error))
        except (ValidationError, duckdb.Error, OSError):
            return _needs(
                "run_monitors", "monitor input or local storage failed validation; inspect history"
            )

    def transition(
        self,
        event_id: str,
        *,
        action_id: str,
        state: Literal["acknowledged", "resolved"],
        reason: str,
        at: datetime,
        data_revision: int,
    ) -> OperationEnvelope[MonitorEvent]:
        try:
            reject_secret_material({"action_id": action_id, "reason": reason})
            if not action_id.strip() or not reason.strip() or at.tzinfo is None:
                raise MonitorStateError("transition requires action ID, reason and aware timestamp")
            _revision(data_revision, self.data.latest_data_revision())
            result = self.store.transition(
                event_id,
                action_id=action_id,
                state=state,
                reason=reason,
                at=at,
                data_revision=data_revision,
            )
            return OperationEnvelope(
                operation="transition_monitor_event", status="complete", result=result
            )
        except (ValueError, MonitorStateError, duckdb.Error):
            return _needs(
                "transition_monitor_event", "transition is invalid or conflicts with history"
            )

    def _configuration(
        self,
        definition: MonitorDefinition,
        bindings: list[MediaBinding],
        revision: int,
        baseline_revision: int,
    ) -> list[MonitorEvaluation]:
        def selected(cutoff: int) -> dict[str, EntitySnapshot]:
            return {
                item.entity_key: item
                for item in self.data.current_entities(
                    definition.query.product_id,
                    as_of_data_revision=cutoff,
                )
                if item.record.entity_type is EntityType.CAMPAIGN
                and any(
                    b.platform == item.platform
                    and b.account_id == item.account_id
                    and item.record.app_variant_id in b.app_variant_ids
                    and campaign_allowed(b, item.record.entity_id, definition.query)
                    for b in bindings
                )
            }

        current, baseline = selected(revision), selected(baseline_revision)
        result = []
        for key in sorted(set(current) | set(baseline)):
            left, right = current.get(key), baseline.get(key)
            for field in definition.configuration_fields:
                scope = f"{key}/{field}"
                kwargs = _EvaluationScope(
                    scope_key=scope,
                    period_key=f"baseline_revision:{baseline_revision}",
                    severity=definition.severity,
                    auto_resolve=False,
                )
                if left is None or right is None:
                    result.append(
                        MonitorEvaluation(
                            **kwargs,
                            outcome="unknown",
                            reason="missing_configuration_counterpart",
                        )
                    )
                    continue
                before = right.record.model_dump(mode="json")[field]
                after = left.record.model_dump(mode="json")[field]
                unknown = (
                    before is None
                    or after is None
                    or any(
                        isinstance(value, dict) and value.get("state") != "value"
                        for value in (before, after)
                    )
                )
                result.append(
                    MonitorEvaluation(
                        **kwargs,
                        outcome="unknown"
                        if unknown
                        else ("breach" if before != after else "healthy"),
                        reason="configuration_unknown"
                        if unknown
                        else (
                            "observed_configuration_changed"
                            if before != after
                            else "configuration_unchanged"
                        ),
                        current=after,
                        baseline=before,
                        evidence_refs=[right.entity_snapshot_id, left.entity_snapshot_id],
                        source_snapshot_ids=sorted(
                            {right.source_snapshot_id, left.source_snapshot_id}
                        ),
                    )
                )
        for binding in bindings:
            if not any(
                item.platform == binding.platform and item.account_id == binding.account_id
                for item in (*current.values(), *baseline.values())
            ):
                result.append(
                    MonitorEvaluation(
                        scope_key=f"{binding.platform}/{binding.account_id}/configuration",
                        period_key=f"baseline_revision:{baseline_revision}",
                        outcome="unknown",
                        severity=definition.severity,
                        reason="no_selected_campaign_snapshots",
                        auto_resolve=False,
                    )
                )
        if not result:
            result.append(
                MonitorEvaluation(
                    scope_key="configuration",
                    period_key=f"baseline_revision:{baseline_revision}",
                    severity=definition.severity,
                    outcome="unknown",
                    reason="no_campaign_snapshots",
                    auto_resolve=False,
                )
            )
        return result

    def _health(
        self,
        definition: MonitorDefinition,
        bindings: list[MediaBinding],
        revision: int,
        now: datetime,
    ) -> tuple[list[MonitorEvaluation], list[SourceHealthObservation]]:
        snapshots = self.data.source_snapshots(
            definition.query.product_id,
            as_of_data_revision=revision,
        )
        observations = self.store.health()
        used: list[SourceHealthObservation] = []
        evaluations = []
        for platform, account in sorted({(b.platform, b.account_id) for b in bindings}):
            for check in definition.health_checks:
                kwargs = _EvaluationScope(
                    scope_key=f"{platform}/{account}/{check}",
                    period_key="source_health",
                    severity=definition.severity,
                )
                if check == "freshness":
                    available = [
                        s for s in snapshots if s.platform == platform and s.account_id == account
                    ]
                    if not available:
                        evaluations.append(
                            MonitorEvaluation(
                                **kwargs,
                                outcome="unknown",
                                reason="source_never_observed",
                            )
                        )
                        continue
                    latest = max(available, key=lambda s: (s.observed_at, s.data_revision))
                    age = (now - latest.observed_at).total_seconds()
                    assert definition.freshness_max_age_seconds is not None
                    stale = age > definition.freshness_max_age_seconds
                    evaluations.append(
                        MonitorEvaluation(
                            **kwargs,
                            outcome="breach" if stale else "healthy",
                            reason="source_stale" if stale else "source_fresh",
                            current=str(age),
                            baseline=str(definition.freshness_max_age_seconds),
                            source_snapshot_ids=[latest.source_snapshot_id],
                            evidence_refs=[latest.source_snapshot_id],
                        )
                    )
                    continue
                available = [
                    h
                    for h in observations
                    if (
                        h.product_id == definition.query.product_id
                        and h.platform == platform
                        and h.account_id == account
                        and h.check == check
                        and h.data_revision <= revision
                        and h.observed_at <= now
                    )
                ]
                if not available:
                    evaluations.append(
                        MonitorEvaluation(
                            **kwargs,
                            outcome="unknown",
                            reason="no_explicit_health_evidence",
                        )
                    )
                    continue
                latest_time = max(h.observed_at for h in available)
                candidates = [h for h in available if h.observed_at == latest_time]
                used.extend(candidates)
                statuses = {h.status for h in candidates}
                status = statuses.pop() if len(statuses) == 1 else "unknown"
                assert definition.health_max_age_seconds is not None
                expired = (now - latest_time).total_seconds() > definition.health_max_age_seconds
                if expired:
                    status = "unknown"
                evaluations.append(
                    MonitorEvaluation(
                        **kwargs,
                        outcome="healthy"
                        if status == "ok"
                        else "breach"
                        if status == "failed"
                        else "unknown",
                        reason="health_evidence_expired"
                        if expired
                        else (
                            "explicit_source_health"
                            if status != "unknown"
                            else "unknown_or_conflicting_health"
                        ),
                        current=status,
                        evidence_refs=[h.health_id for h in candidates],
                    )
                )
        return evaluations, sorted(used, key=lambda h: h.health_id)


def _bindings(query: CanonicalQuery, profile: ProfileRevision) -> list[MediaBinding]:
    bindings = [
        b
        for b in profile.profile.media_bindings
        if b.platform in query.platforms
        and (not query.filters.binding_ids or b.binding_id in query.filters.binding_ids)
    ]
    if set(query.platforms) != {b.platform for b in bindings} or (
        set(query.filters.binding_ids) - {b.binding_id for b in bindings}
    ):
        raise MonitorStateError("monitor selected source bindings are missing from the profile")
    return bindings


def _revision(value: int, maximum: int) -> None:
    if isinstance(value, bool) or not isinstance(value, int) or not 0 <= value <= maximum:
        raise MonitorStateError("data revision must exist within the available revision range")


def _performance(definition: MonitorDefinition, packet: EvidencePacket) -> list[MonitorEvaluation]:
    result = []
    facts = {f.evidence_id: f for f in packet.verified_facts}
    period_key = content_hash(packet.scope.model_dump(mode="json"))
    paired = set()
    for cell in packet.comparisons:
        if cell.comparison_type != "period_change" or cell.metric != definition.metric:
            continue
        paired.update(cell.evidence_refs)
        outcome = "unknown"
        reason = "; ".join(cell.reasons) or "comparison_not_strict"
        severity = definition.severity
        if cell.status is ComparisonStatus.STRICTLY_COMPARABLE:
            left, right = Decimal(str(cell.left_value)), Decimal(str(cell.right_value))
            if definition.direction == "stop":
                if right > 0:
                    outcome = "breach" if left == 0 else "healthy"
                    reason = "measured_delivery_stop" if left == 0 else "delivery_present"
                else:
                    reason = "zero_baseline_cannot_establish_stop"
            elif cell.delta_relative is None:
                reason = "zero_baseline_relative_change_undefined"
            else:
                delta = cell.delta_relative
                magnitude = {"increase": delta, "decrease": -delta, "either": abs(delta)}[
                    definition.direction
                ]
                assert definition.relative_threshold is not None
                breached = magnitude >= definition.relative_threshold
                outcome = "breach" if breached else "healthy"
                reason = "relative_change_threshold_breached" if breached else "within_threshold"
                if definition.critical_relative_threshold is not None and (
                    magnitude >= definition.critical_relative_threshold
                ):
                    severity = "critical"
        result.append(
            MonitorEvaluation(
                scope_key=cell.left_scope,
                period_key=period_key,
                outcome=outcome,
                severity=severity,
                reason=reason,
                current=cell.left_value,
                baseline=cell.right_value,
                delta_relative=cell.delta_relative,
                evidence_refs=[packet.packet_id, cell.comparison_id, *cell.evidence_refs],
                source_snapshot_ids=sorted(
                    {s for ref in cell.evidence_refs for s in facts[ref].source_snapshot_ids}
                ),
            )
        )
    # Preserve unknown scopes, including missing semantic counterparts and entirely empty sources.
    for fact in packet.verified_facts:
        if fact.evidence_id not in paired:
            result.append(
                MonitorEvaluation(
                    scope_key=str(fact.details.get("scope_key", fact.evidence_id)),
                    period_key=period_key,
                    outcome="unknown",
                    severity=definition.severity,
                    reason="missing_compatible_period_counterpart",
                    evidence_refs=[packet.packet_id, fact.evidence_id],
                    source_snapshot_ids=fact.source_snapshot_ids,
                )
            )
    if not result:
        result.append(
            MonitorEvaluation(
                scope_key="performance",
                period_key=period_key,
                outcome="unknown",
                severity=definition.severity,
                reason="no_evaluable_period_comparisons",
                evidence_refs=[packet.packet_id],
            )
        )
    # Unpaired baseline/current facts may refer to the same scope; one unknown is sufficient.
    unique = {(e.scope_key, e.period_key): e for e in result}
    return list(unique.values())


def _envelope(run: MonitorRun) -> OperationEnvelope[MonitorRun]:
    unknown = any(e.outcome == "unknown" for e in run.evaluations)
    return OperationEnvelope(
        operation="run_monitors",
        status="partial_result" if unknown else "complete",
        result=run,
        issues=[
            OperationIssue(
                code="monitor_evaluation_unknown",
                severity="warning",
                message="Some scopes cannot be evaluated; "
                "existing incidents are not automatically resolved.",
            )
        ]
        if unknown
        else [],
    )


def _needs(operation: str, reason: str) -> OperationEnvelope:
    return OperationEnvelope(
        operation=operation,
        status="needs_input",
        missing_inputs=[
            MissingInput(field_path="/monitor", reason=reason),
        ],
    )
