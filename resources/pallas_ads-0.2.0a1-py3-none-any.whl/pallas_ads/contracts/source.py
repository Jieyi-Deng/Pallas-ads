"""Non-secret source requests, connection state and authorization results."""

from __future__ import annotations

from datetime import date
from decimal import Decimal
from typing import Literal, Self
from urllib.parse import urlsplit

from pydantic import AwareDatetime, Field, JsonValue, model_serializer, model_validator

from pallas_ads.contracts.adapter import QueryMode
from pallas_ads.contracts.base import VersionedContract
from pallas_ads.contracts.common import MediaPlatform
from pallas_ads.contracts.credentials import CredentialRef
from pallas_ads.contracts.query import DateRange


class SourceConnectionConfig(VersionedContract):
    connection_id: str = Field(pattern=r"^connection_[a-z0-9][a-z0-9_-]*$")
    platform: MediaPlatform
    transport: Literal["native_api", "official_mcp"] = "native_api"
    mcp_advertiser_id: str | None = Field(default=None, pattern=r"^[0-9]+$", max_length=32)
    client_id: str | None = Field(default=None, pattern=r"^[A-Za-z0-9._-]+$")
    app_credential_ref: CredentialRef | None = None
    developer_credential_ref: CredentialRef | None = None
    login_customer_id: str | None = Field(default=None, pattern=r"^[0-9]+$")
    registered_redirect_uri: str | None = None
    meta_config_id: str | None = Field(default=None, pattern=r"^[0-9]+$")

    @model_validator(mode="after")
    def validate_configuration(self) -> Self:
        if self.transport == "official_mcp":
            if (
                self.platform not in (MediaPlatform.TIKTOK, MediaPlatform.META)
                or not self.registered_redirect_uri
                or self.app_credential_ref is not None
            ):
                raise ValueError("Official MCP requires a local callback, without an app secret")
            if self.platform == MediaPlatform.META and (
                not self.client_id
                or not self.client_id.isascii()
                or not self.client_id.isdigit()
                or self.meta_config_id
                or self.mcp_advertiser_id
            ):
                raise ValueError(
                    "Meta MCP requires an operator app ID, without legacy configuration"
                )
        elif self.mcp_advertiser_id is not None:
            raise ValueError("MCP advertiser scope is only valid for official MCP")
        for ref in (self.app_credential_ref, self.developer_credential_ref):
            if ref and ref.platform is not None and ref.platform != self.platform:
                raise ValueError("credential platform mismatch")
        if self.platform != MediaPlatform.GOOGLE and (
            self.developer_credential_ref or self.login_customer_id
        ):
            raise ValueError("manager/developer context is Google-specific")
        if self.meta_config_id and self.platform != MediaPlatform.META:
            raise ValueError("Business Login configuration is Meta-specific")
        if self.registered_redirect_uri:
            uri = urlsplit(self.registered_redirect_uri)
            if (
                uri.scheme not in ("http", "https")
                or uri.hostname not in ("127.0.0.1", "localhost")
                or (uri.scheme == "http" and uri.hostname != "127.0.0.1")
                or not uri.port
                or uri.port < 1024
                or uri.username
                or uri.password
                or uri.query
                or uri.fragment
                or uri.path != "/callback"
                or self.registered_redirect_uri
                != f"{uri.scheme}://{uri.hostname}:{uri.port}/callback"
            ):
                raise ValueError(
                    "callback must use an explicit local port and /callback; "
                    "localhost requires HTTPS"
                )
        return self


class SourceConnection(VersionedContract):
    config: SourceConnectionConfig
    credential_ref: CredentialRef
    state: Literal["connected", "disconnected"]
    revision: int = Field(ge=1)
    updated_at: AwareDatetime
    expires_at: AwareDatetime | None = None
    credential_owned: bool = False
    validation: Literal["unverified"] = "unverified"
    selected_account_id: str | None = Field(default=None, pattern=r"^[0-9]+$", max_length=32)


class AuthSessionResult(VersionedContract):
    session_id: str = Field(pattern=r"^auth_[a-f0-9]{32}$")
    connection_id: str
    platform: MediaPlatform
    state: Literal["pending", "exchanging", "connected", "cancelled", "expired", "failed"]
    expires_at: AwareDatetime
    authorization_url: str | None = None
    redirect_uri: str | None = None
    connection: SourceConnection | None = None


class SourceReadRequest(VersionedContract):
    platform: MediaPlatform
    mode: QueryMode
    account_id: str | None = Field(default=None, pattern=r"^[0-9]+$")
    period: DateRange | None = None
    campaign_ids: list[str] = Field(default_factory=list)
    max_pages: int = Field(default=20, ge=1, le=100)
    manager_account_id: str | None = Field(default=None, pattern=r"^[0-9]+$", max_length=32)
    ignore_configured_manager: bool = False
    query_lifetime: bool = False
    report_level: Literal["campaign", "adgroup"] = "campaign"
    audience_dimension: Literal["age", "gender", "country"] | None = None
    context_kind: (
        Literal[
            "optimization",
            "creative",
            "apps",
            "google_goals",
            "google_actions",
            "google_goal_config",
            "google_custom_goals",
        ]
        | None
    ) = None

    @model_serializer(mode="wrap")
    def serialize_compatible_request(self, handler):
        # New optional routing fields must not change retained legacy plan/manifest hashes.
        payload = handler(self)
        if self.manager_account_id is None:
            payload.pop("manager_account_id", None)
        if not self.ignore_configured_manager:
            payload.pop("ignore_configured_manager", None)
        if not self.query_lifetime:
            payload.pop("query_lifetime", None)
        if self.context_kind is None:
            payload.pop("context_kind", None)
        if self.report_level == "campaign":
            payload.pop("report_level", None)
        if self.audience_dimension is None:
            payload.pop("audience_dimension", None)
        return payload

    @model_validator(mode="after")
    def validate_scope(self) -> Self:
        if self.platform != MediaPlatform.GOOGLE and (
            self.mode == QueryMode.ACCOUNT_HIERARCHY
            or self.manager_account_id
            or self.ignore_configured_manager
        ):
            raise ValueError("hierarchy and manager routing are Google-only")
        if self.mode != QueryMode.CAPABILITY_PROBE and self.account_id is None:
            raise ValueError("account context is required outside account discovery")
        performance = self.mode in (QueryMode.TRAFFIC_PERFORMANCE, QueryMode.CONVERSION_PERFORMANCE)
        if (self.report_level != "campaign" or self.audience_dimension) and (
            not performance
            or (self.platform == "google" and self.report_level != "campaign")
            or self.query_lifetime
        ):
            raise ValueError("detailed reports require explicit TikTok or Meta performance periods")
        if self.audience_dimension and (
            self.mode != QueryMode.TRAFFIC_PERFORMANCE or self.report_level != "campaign"
        ):
            raise ValueError("audience breakdown is campaign traffic only")
        if self.campaign_ids and (self.report_level != "campaign" or self.audience_dimension):
            raise ValueError(
                "detailed diagnostics use selected-account scope without campaign filters"
            )
        if self.context_kind == "apps" and self.platform != "tiktok":
            raise ValueError("app directory recipe is TikTok-only")
        if self.context_kind and (self.mode != QueryMode.ENTITY_CONFIGURATION or self.campaign_ids):
            raise ValueError("context inspection requires unfiltered entity configuration")
        if (
            self.context_kind
            and self.context_kind.startswith("google_")
            and self.platform != "google"
        ):
            raise ValueError("Google goal resources require Google")
        if self.query_lifetime and (
            self.mode != QueryMode.TRAFFIC_PERFORMANCE
            or self.platform == "google"
            or self.period is not None
        ):
            raise ValueError("Lifetime is a period-free TikTok or Meta traffic read")
        if performance != (self.period is not None or self.query_lifetime):
            raise ValueError("only performance reads require an explicit date range")
        if self.period and (self.period.end - self.period.start).days > 30:
            raise ValueError("experimental synchronous reads are limited to 31 days")
        if len(set(self.campaign_ids)) != len(self.campaign_ids) or any(
            not value.isascii() or not value.isdigit() for value in self.campaign_ids
        ):
            raise ValueError("campaign IDs must be unique numeric identifiers")
        if self.campaign_ids and self.mode in (
            QueryMode.CAPABILITY_PROBE,
            QueryMode.ACCOUNT_CONTEXT,
            QueryMode.ACCOUNT_HIERARCHY,
        ):
            raise ValueError("campaign filtering does not apply to account reads")
        return self


class SourceQueryPlan(VersionedContract):
    plan_id: str = Field(pattern=r"^(native|mcp)_plan_[a-f0-9]{64}$")
    transport: Literal["native_api", "official_mcp"] = "native_api"
    request: SourceReadRequest
    adapter_version: Literal["0.1.0"] = "0.1.0"
    api_version: str
    method: Literal["GET", "POST"]
    endpoint: str
    parameters: dict[str, JsonValue]
    body: dict[str, JsonValue] | None = None
    required_fields: list[str]
    lifecycle: Literal["experimental"] = "experimental"


class SourceRecord(VersionedContract):
    account_id: str
    entity_id: str | None = None
    event_date: date | None = None
    values: dict[str, Decimal | None] = Field(default_factory=dict)
    metadata: dict[str, JsonValue] = Field(default_factory=dict)
    warnings: list[str] = Field(default_factory=list)


class SourceReadResult(VersionedContract):
    read_id: str = Field(pattern=r"^read_[a-f0-9]{32}$")
    plan: SourceQueryPlan
    observed_at: AwareDatetime
    records: list[SourceRecord]
    pages_received: int
    pagination_complete: bool
    warnings: list[str]
    artifact_path: str | None = None
    live_reconciled: Literal[False] = False
    coverage_verified: Literal[False] = False
