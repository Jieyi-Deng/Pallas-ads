"""Non-secret credential reference contracts."""

from __future__ import annotations

import re
from enum import StrEnum
from typing import Self

from pydantic import AwareDatetime, Field, model_validator

from pallas_ads.contracts.base import VersionedContract
from pallas_ads.contracts.common import MediaPlatform


class CredentialProvider(StrEnum):
    ENVIRONMENT = "environment"
    OS_KEYCHAIN = "os_keychain"


class CredentialRef(VersionedContract):
    """A locator for a credential whose value remains outside Pallas data."""

    credential_id: str = Field(pattern=r"^credential_[a-z0-9][a-z0-9_-]*$")
    provider: CredentialProvider
    locator: str = Field(min_length=1)
    platform: MediaPlatform | None = None
    label: str | None = Field(default=None, min_length=1)
    created_at: AwareDatetime

    @model_validator(mode="after")
    def validate_locator(self) -> Self:
        if (
            self.provider is CredentialProvider.ENVIRONMENT
            and re.fullmatch(r"[A-Z][A-Z0-9_]*", self.locator) is None
        ):
            raise ValueError("environment credential locators must be variable names")
        return self
