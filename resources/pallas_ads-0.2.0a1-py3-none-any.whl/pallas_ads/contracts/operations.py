"""Versioned requests for the closed CLI/MCP operation surface."""

from datetime import date
from typing import Annotated, Literal

from pydantic import AwareDatetime, Field

from pallas_ads.contracts.base import VersionedContract
from pallas_ads.contracts.common import MediaPlatform
from pallas_ads.contracts.credentials import CredentialRef
from pallas_ads.contracts.delivery import AgentAnalysisDraft
from pallas_ads.contracts.file_import import FileImportOptions
from pallas_ads.contracts.host_mcp import HostCapture
from pallas_ads.contracts.monitor import MonitorDefinition, SourceHealthObservation
from pallas_ads.contracts.profile import ProfileDraftValues, ProfilePatch
from pallas_ads.contracts.query import DateRange
from pallas_ads.contracts.source import SourceConnectionConfig


class ProfileRequest(VersionedContract):
    action: Literal["draft", "patch", "review", "confirm"]
    values: ProfileDraftValues | None = None
    patch: ProfilePatch | None = None
    draft_id: str | None = Field(default=None, pattern=r"^draft_[a-z0-9][a-z0-9_-]*$")
    content_hash: str | None = Field(default=None, pattern=r"^sha256:[a-f0-9]{64}$")
    user_confirmed: Literal[True] | None = None


class ContextRequest(VersionedContract):
    product_id: str | None = Field(default=None, pattern=r"^prod_[a-z0-9][a-z0-9_-]*$")


class SourceRequest(VersionedContract):
    action: Literal[
        "import",
        "connect",
        "attach",
        "refresh",
        "disconnect",
        "options",
        "discover",
        "select",
        "inspect",
        "host_capture",
        "host_inspect",
        "file_preview",
        "file_import",
    ]
    package_path: str | None = None
    file_path: str | None = None
    import_options: FileImportOptions | None = None
    review_hash: str | None = Field(default=None, pattern=r"^[a-f0-9]{64}$")
    user_confirmed: Literal[True] | None = None
    capture: HostCapture | None = None
    capture_id: str | None = Field(default=None, pattern=r"^host_[a-f0-9]{64}$")
    config: SourceConnectionConfig | None = None
    credential_ref: CredentialRef | None = None
    connection_id: str | None = Field(default=None, pattern=r"^connection_[a-z0-9][a-z0-9_-]*$")
    open_browser: bool = True
    platform: MediaPlatform | None = None
    choice_id: str | None = Field(default=None, pattern=r"^choice_[a-f0-9]{24}$")
    period: DateRange | None = None
    max_pages: int = Field(default=20, ge=1, le=100)
    max_accounts: int = Field(default=30, ge=1, le=100)


class AuthRequest(VersionedContract):
    session_id: str = Field(pattern=r"^auth_[a-f0-9]{32}$")
    action: Literal["status", "cancel"] = "status"


class SourceStatusRequest(VersionedContract):
    connection_id: str = Field(pattern=r"^connection_[a-z0-9][a-z0-9_-]*$")


class MonitorRequest(VersionedContract):
    action: Literal["run", "record_health", "transition"] = "run"
    definition: MonitorDefinition | None = None
    observation: SourceHealthObservation | None = None
    data_revision: int | None = Field(default=None, ge=1)
    baseline_data_revision: int | None = Field(default=None, ge=1)
    evaluated_at: AwareDatetime | None = None
    event_id: str | None = None
    action_id: str | None = None
    state: Literal["acknowledged", "resolved"] | None = None
    reason: str | None = None


class ReportRequest(VersionedContract):
    action: Literal["prepare", "build", "load", "analyze", "host_review", "file_review"] = "build"
    dataset_id: str | None = Field(default=None, pattern=r"^file_[a-f0-9]{64}$")
    capture_id: str | None = Field(default=None, pattern=r"^host_[a-f0-9]{64}$")
    context_capture_ids: list[Annotated[str, Field(pattern=r"^host_[a-f0-9]{64}$")]] = Field(
        default_factory=list, max_length=8
    )
    connection_id: str | None = Field(default=None, pattern=r"^connection_[a-z0-9][a-z0-9_-]*$")
    period: DateRange | None = None
    max_windows: int = Field(default=12, ge=1, le=60)
    max_pages: int = Field(default=20, ge=1, le=100)
    history_before: date | None = None
    packet_id: str | None = None
    monitor_run_ids: list[str] = Field(default_factory=list)
    draft: AgentAnalysisDraft | None = None
    product_id: str | None = None
    report_id: str | None = None
