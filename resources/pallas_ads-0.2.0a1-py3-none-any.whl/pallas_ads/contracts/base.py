"""Shared validation rules for public Pallas contracts."""

from __future__ import annotations

import re
from collections.abc import Mapping, Sequence
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, model_validator

SchemaVersion = Literal["1.0"]

# This is a denylist of field names, not a store of credential values.
_FORBIDDEN_SECRET_FIELD_NAMES = frozenset(
    {
        "access_token",
        "api_key",
        "authorization",
        "client_secret",
        "password",
        "private_key",
        "refresh_token",
        "secret",
        "token",
    }
)
_FORBIDDEN_SECRET_FIELD_SUFFIXES = (
    "_access_token",
    "_api_key",
    "_client_secret",
    "_refresh_token",
)
_FORBIDDEN_SECRET_VALUE_PATTERNS = (
    re.compile(r"^bearer\s+\S+$", re.IGNORECASE),
    re.compile(r"^sk-[A-Za-z0-9_-]{8,}$"),
    re.compile(r"^-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----"),
)


def reject_secret_material(value: Any, path: str = "$") -> None:
    """Reject credential-shaped keys and values before they enter a contract."""

    if isinstance(value, Mapping):
        for raw_key, child in value.items():
            key = str(raw_key).strip().lower().replace("-", "_")
            child_path = f"{path}.{raw_key}"
            if key in _FORBIDDEN_SECRET_FIELD_NAMES or key.endswith(
                _FORBIDDEN_SECRET_FIELD_SUFFIXES
            ):
                raise ValueError(f"secret material is not allowed at {child_path}")
            reject_secret_material(child, child_path)
        return
    if isinstance(value, Sequence) and not isinstance(value, (str, bytes, bytearray)):
        for index, child in enumerate(value):
            reject_secret_material(child, f"{path}[{index}]")
        return
    if isinstance(value, str) and any(
        pattern.search(value) for pattern in _FORBIDDEN_SECRET_VALUE_PATTERNS
    ):
        raise ValueError(f"secret-like value is not allowed at {path}")


class ContractModel(BaseModel):
    """Strict, assignment-validating and secret-safe contract base."""

    model_config = ConfigDict(
        extra="forbid",
        hide_input_in_errors=True,
        validate_assignment=True,
    )

    @model_validator(mode="before")
    @classmethod
    def reject_secrets(cls, value: Any) -> Any:
        reject_secret_material(value)
        return value


class VersionedContract(ContractModel):
    """Base for independently persisted or exchanged contracts."""

    schema_version: SchemaVersion = "1.0"
