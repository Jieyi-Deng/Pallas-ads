"""Enums shared across profile, query, adapter and evidence contracts."""

from enum import StrEnum


class MediaPlatform(StrEnum):
    META = "meta"
    TIKTOK = "tiktok"
    GOOGLE = "google"


class ReportingTimeBasis(StrEnum):
    """Meaning of the source report's date, not when Pallas fetched the data."""

    DELIVERY_DATE = "delivery_date"
    AD_INTERACTION_DATE = "ad_interaction_date"
    CONVERSION_DATE = "conversion_date"
    MIXED = "mixed"
    UNKNOWN = "unknown"


class CanonicalMetric(StrEnum):
    SPEND = "spend"
    IMPRESSIONS = "impressions"
    CPM = "cpm"
    CLICKS = "clicks"
    CTR = "ctr"
    CPC = "cpc"
    INSTALLS = "installs"
    CPI = "cpi"
    PURCHASE_EVENT_COUNT = "purchase_event_count"
    CPA_PURCHASE_EVENT = "cpa_purchase_event"
    OPTIMIZATION_EVENT_COUNT = "optimization_event_count"
    CPA_OPTIMIZATION_EVENT = "cpa_optimization_event"
    PLATFORM_ATTRIBUTED_IAP_REVENUE = "platform_attributed_iap_revenue"
    MEDIA_IAP_ROAS = "media_iap_roas"


TRAFFIC_METRICS = frozenset(
    {
        CanonicalMetric.IMPRESSIONS,
        CanonicalMetric.CPM,
        CanonicalMetric.CLICKS,
        CanonicalMetric.CTR,
        CanonicalMetric.CPC,
    }
)
OUTCOME_METRICS = frozenset(set(CanonicalMetric) - TRAFFIC_METRICS - {CanonicalMetric.SPEND})


class CanonicalDimension(StrEnum):
    CHANNEL = "channel"
    CAMPAIGN_TYPE = "campaign_type"
    OPTIMIZATION_GOAL = "optimization_goal"
    CAMPAIGN = "campaign"
    EVENT_DATE = "event_date"
    COUNTRY = "country"
    OS = "os"


class ComparisonStatus(StrEnum):
    STRICTLY_COMPARABLE = "strictly_comparable"
    DIRECTIONALLY_COMPARABLE = "directionally_comparable"
    NOT_COMPARABLE = "not_comparable"
    INSUFFICIENT_EVIDENCE = "insufficient_evidence"
