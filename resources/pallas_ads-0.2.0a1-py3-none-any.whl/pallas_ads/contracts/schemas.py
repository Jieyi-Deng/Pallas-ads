"""Deterministic JSON Schema registry for public contracts."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from pydantic import ConfigDict, JsonValue

from pallas_ads.contracts.adapter import AdapterManifest, SourceCapability
from pallas_ads.contracts.analysis import EvidencePolicy, MetricAggregate, ResolvedQueryPlan
from pallas_ads.contracts.credentials import CredentialRef
from pallas_ads.contracts.data import (
    CanonicalEntityRecord,
    CanonicalImportManifest,
    CanonicalImportResult,
    CanonicalObservationRecord,
    EntitySnapshot,
    ObservationRevision,
    SourceSnapshot,
)
from pallas_ads.contracts.delivery import (
    AgentAnalysisContract,
    AgentAnalysisDraft,
    BriefingDocument,
    ReportEvidence,
    ReportManifest,
    ReportResult,
)
from pallas_ads.contracts.evidence import EvidencePacket
from pallas_ads.contracts.host_mcp import HostCapture
from pallas_ads.contracts.metrics import MetricComputation, MetricDefinition
from pallas_ads.contracts.monitor import (
    MonitorDefinition,
    MonitorEvent,
    MonitorRun,
    SourceHealthObservation,
)
from pallas_ads.contracts.observation import ObservationInsight
from pallas_ads.contracts.operations import (
    AuthRequest,
    ContextRequest,
    MonitorRequest,
    ProfileRequest,
    ReportRequest,
    SourceRequest,
    SourceStatusRequest,
)
from pallas_ads.contracts.profile import (
    ProductProfile,
    ProfileDraft,
    ProfileDraftReview,
    ProfilePatch,
    ProfileRevision,
)
from pallas_ads.contracts.query import CanonicalQuery
from pallas_ads.contracts.source import (
    AuthSessionResult,
    SourceConnection,
    SourceConnectionConfig,
    SourceQueryPlan,
    SourceReadRequest,
    SourceReadResult,
    SourceRecord,
)
from pallas_ads.contracts.status import OperationEnvelope
from pallas_ads.contracts.sync import SyncRequest, SyncResult
from pallas_ads.contracts.workspace import WorkspaceManifest, WorkspaceState
from pallas_ads.provider_setup import ProviderSetup


class SchemaOperationEnvelope(OperationEnvelope[dict[str, JsonValue]]):
    """Concrete operation-envelope model used only for schema export."""

    model_config = ConfigDict(title="OperationEnvelope")


SCHEMA_MODELS: dict[str, type[Any]] = {
    "host_capture": HostCapture,
    "provider_setup": ProviderSetup,
    "profile_operation_request": ProfileRequest,
    "context_request": ContextRequest,
    "source_operation_request": SourceRequest,
    "auth_request": AuthRequest,
    "source_status_request": SourceStatusRequest,
    "monitor_operation_request": MonitorRequest,
    "report_operation_request": ReportRequest,
    "sync_request": SyncRequest,
    "sync_result": SyncResult,
    "auth_session_result": AuthSessionResult,
    "source_connection": SourceConnection,
    "source_connection_config": SourceConnectionConfig,
    "source_query_plan": SourceQueryPlan,
    "source_read_request": SourceReadRequest,
    "source_read_result": SourceReadResult,
    "source_record": SourceRecord,
    "agent_analysis_contract": AgentAnalysisContract,
    "agent_analysis_draft": AgentAnalysisDraft,
    "briefing_document": BriefingDocument,
    "report_evidence": ReportEvidence,
    "report_manifest": ReportManifest,
    "report_result": ReportResult,
    "observation_insight": ObservationInsight,
    "adapter_manifest": AdapterManifest,
    "canonical_entity_record": CanonicalEntityRecord,
    "canonical_import_manifest": CanonicalImportManifest,
    "canonical_import_result": CanonicalImportResult,
    "canonical_observation_record": CanonicalObservationRecord,
    "canonical_query": CanonicalQuery,
    "credential_ref": CredentialRef,
    "evidence_packet": EvidencePacket,
    "evidence_policy": EvidencePolicy,
    "entity_snapshot": EntitySnapshot,
    "metric_computation": MetricComputation,
    "metric_aggregate": MetricAggregate,
    "metric_definition": MetricDefinition,
    "monitor_definition": MonitorDefinition,
    "monitor_run": MonitorRun,
    "monitor_event": MonitorEvent,
    "source_health_observation": SourceHealthObservation,
    "observation_revision": ObservationRevision,
    "operation_envelope": SchemaOperationEnvelope,
    "product_profile": ProductProfile,
    "profile_draft": ProfileDraft,
    "profile_draft_review": ProfileDraftReview,
    "profile_patch": ProfilePatch,
    "profile_revision": ProfileRevision,
    "resolved_query_plan": ResolvedQueryPlan,
    "source_capability": SourceCapability,
    "source_snapshot": SourceSnapshot,
    "workspace_manifest": WorkspaceManifest,
    "workspace_state": WorkspaceState,
}


def schema_names() -> tuple[str, ...]:
    return tuple(sorted(SCHEMA_MODELS))


def render_schema(name: str) -> str:
    try:
        model = SCHEMA_MODELS[name]
    except KeyError as error:
        available = ", ".join(schema_names())
        raise ValueError(f"unknown schema {name!r}; available: {available}") from error
    return json.dumps(model.model_json_schema(), indent=2, ensure_ascii=False, sort_keys=True)


def export_schemas(output_dir: Path) -> list[Path]:
    output_dir.mkdir(parents=True, exist_ok=True)
    exported: list[Path] = []
    for name in schema_names():
        output = output_dir / f"{name}.schema.json"
        output.write_text(f"{render_schema(name)}\n", encoding="utf-8")
        exported.append(output)
    return exported
