"""Explicit interpretation of a single-account, campaign/day advertising export."""

from typing import Literal

from pydantic import Field

from pallas_ads.contracts.base import ContractModel
from pallas_ads.contracts.common import MediaPlatform


class FileImportOptions(ContractModel):
    platform: MediaPlatform
    account_id: str | None = Field(default=None, min_length=1, max_length=100)
    currency: str | None = Field(default=None, pattern=r"^[A-Z]{3}$")
    timezone: str | None = Field(default=None, max_length=100)
    sheet: str | None = Field(default=None, max_length=200)
    header_row: int = Field(default=1, ge=1, le=20)
    delimiter: Literal[",", ";", "\t"] = ","
    column_mapping: dict[str, str] = Field(default_factory=dict, max_length=20)
    conversion_event: str | None = Field(default=None, min_length=1, max_length=100)
    attribution_window: str | None = Field(default=None, min_length=1, max_length=200)
    reporting_time_basis: Literal[
        "delivery_date", "ad_interaction_date", "conversion_date", "unknown"
    ] = "unknown"
