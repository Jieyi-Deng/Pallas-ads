"""Operation status envelope shared by CLI and future MCP entry points."""

from __future__ import annotations

from enum import StrEnum

from pydantic import Field, model_validator

from pallas_ads.contracts.base import ContractModel, VersionedContract


class OperationStatus(StrEnum):
    COMPLETE = "complete"
    NEEDS_INPUT = "needs_input"
    PENDING_USER_ACTION = "pending_user_action"
    PARTIAL_RESULT = "partial_result"
    ADAPTER_REFRESH_REQUIRED = "adapter_refresh_required"


class IssueSeverity(StrEnum):
    INFO = "info"
    WARNING = "warning"
    ERROR = "error"


class OperationIssue(ContractModel):
    code: str = Field(min_length=1, pattern=r"^[a-z][a-z0-9_]*$")
    message: str = Field(min_length=1)
    severity: IssueSeverity = IssueSeverity.ERROR
    field_path: str | None = None
    source: str | None = None
    retriable: bool = False


class MissingInput(ContractModel):
    field_path: str = Field(min_length=1)
    reason: str = Field(min_length=1)
    expected_type: str | None = None


class OperationEnvelope[ResultT](VersionedContract):
    operation: str = Field(min_length=1, pattern=r"^[a-z][a-z0-9_]*$")
    status: OperationStatus
    result: ResultT | None = None
    issues: list[OperationIssue] = Field(default_factory=list)
    missing_inputs: list[MissingInput] = Field(default_factory=list)

    @model_validator(mode="after")
    def validate_state(self) -> OperationEnvelope[ResultT]:
        if self.status is OperationStatus.COMPLETE:
            if self.result is None:
                raise ValueError("complete operations require a result")
            if self.missing_inputs:
                raise ValueError("complete operations cannot contain missing inputs")
        elif self.status is OperationStatus.NEEDS_INPUT:
            if not self.missing_inputs:
                raise ValueError("needs_input operations require missing_inputs")
        elif not self.issues:
            raise ValueError(f"{self.status.value} operations require at least one issue")
        if self.status is OperationStatus.PARTIAL_RESULT and self.result is None:
            raise ValueError("partial_result operations require a result")
        return self
