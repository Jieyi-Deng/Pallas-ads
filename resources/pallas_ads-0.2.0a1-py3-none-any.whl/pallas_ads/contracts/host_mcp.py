"""Credential-free host MCP evidence handoff, not an OAuth or canonical-data claim."""

import json
from typing import Literal, Self

from pydantic import AwareDatetime, Field, JsonValue, model_validator
from pydantic_core import PydanticCustomError

from pallas_ads.contracts.base import ContractModel, VersionedContract, reject_secret_material
from pallas_ads.contracts.query import DateRange

META_HOST_URL = "https://mcp.facebook.com/ads"
META_READ_TOOLS = (
    "ads_get_ad_accounts",
    "ads_get_field_context",
    "ads_get_ad_entities",
)


class HostReadPage(ContractModel):
    tool: Literal["ads_get_ad_accounts", "ads_get_field_context", "ads_get_ad_entities"]
    # Deliberately omit host-only advertiser_request / client_conversation_id and headers.
    arguments: dict[str, JsonValue] = Field(default_factory=dict)
    structured_content: dict[str, JsonValue]
    is_error: bool = False

    @property
    def entity_level(self):
        """Interpret the accepted alias without rewriting retained source arguments."""
        value = self.arguments.get("level")
        return "ad_account" if value == "account" else value

    @model_validator(mode="after")
    def validate_scope(self) -> Self:
        common = {"cursor", "limit"}
        allowed = {
            "ads_get_ad_accounts": common,
            "ads_get_field_context": {"field_names"},
            "ads_get_ad_entities": common
            | {
                "ad_account_id",
                "fields",
                "level",
                "time_range",
                "date_preset",
                "time_increment",
                "breakdowns",
                "include_additional_context",
                "filtering",
            },
        }[self.tool]
        if set(self.arguments) - allowed:
            raise ValueError("Unsupported query scope; use the bounded read contract.")
        args = self.arguments
        if "cursor" in args and (not isinstance(args["cursor"], str) or not args["cursor"]):
            raise ValueError("Invalid cursor.")
        if "limit" in args and (type(args["limit"]) is not int or not 1 <= args["limit"] <= 1000):
            raise ValueError("Invalid page limit.")
        for field in ("fields", "field_names", "breakdowns"):
            value = args.get(field)
            if field in args and (
                not isinstance(value, list)
                or not value
                or not all(isinstance(v, str) and v for v in value)
            ):
                raise ValueError("Invalid field list.")
        if self.tool == "ads_get_ad_entities":
            identifier = args.get("ad_account_id")
            if (
                not isinstance(identifier, str)
                or not identifier.isascii()
                or not identifier.isdigit()
            ):
                raise ValueError("Use the selected numeric account ID.")
            if self.entity_level not in ("ad_account", "campaign", "adset", "ad"):
                raise PydanticCustomError(
                    "host_entity_level", "Use account/ad_account, campaign, adset or ad."
                )
            if not args.get("fields") or args.get("include_additional_context") is not False:
                raise ValueError("Explicit fields and raw-only response required.")
            if "filtering" in args and (
                self.entity_level == "ad_account"
                or args["filtering"]
                != [
                    {
                        "field": f"{self.entity_level}.amount_spent",
                        "operator": "GREATER_THAN",
                        "value": ["0"],
                    }
                ]
                or not isinstance(args["fields"], list)
                or "amount_spent" not in args["fields"]
            ):
                raise ValueError("Only an explicit entity amount_spent > 0 filter is supported.")
            if ("time_range" in args) == ("date_preset" in args):
                raise ValueError("Provide exactly one explicit period or maximum preset.")
            if "time_range" in args:
                if not isinstance(args["time_range"], str):
                    raise ValueError("time_range must be JSON text.")
                period = json.loads(args["time_range"])
                if not isinstance(period, dict) or set(period) != {"since", "until"}:
                    raise ValueError("Invalid period.")
                DateRange(start=period["since"], end=period["until"])
            elif args["date_preset"] not in ("maximum", "data_maximum"):
                raise ValueError("Use maximum/data_maximum or an explicit period.")
            increment = args.get("time_increment")
            if increment not in ("all_days", "monthly", *(str(v) for v in range(1, 91))):
                raise ValueError("Explicit time increment required.")
        # Official Meta currently encodes ad_entities as a JSON string. Validate the decoded
        # value as well: the generic secret guard cannot look through JSON-encoded strings.
        if "ad_entities" in self.structured_content:
            reject_secret_material(self.rows())
        if not self.is_error:
            rows = self.rows()
            reject_secret_material(rows)
            if not isinstance(rows, list) or not all(isinstance(row, dict) for row in rows):
                raise ValueError("Unsupported source response shape.")
        self.next_cursor()
        return self

    def rows(self):
        key = {
            "ads_get_ad_accounts": "ad_accounts",
            "ads_get_field_context": "fields",
            "ads_get_ad_entities": "ad_entities",
        }[self.tool]
        value = self.structured_content.get(key)
        return json.loads(value) if isinstance(value, str) else value

    def next_cursor(self):
        if self.tool == "ads_get_ad_entities":
            pagination = self.structured_content.get("pagination", {})
            if not isinstance(pagination, dict):
                raise ValueError("Invalid pagination shape.")
            value = pagination.get("next_cursor")
        else:
            value = self.structured_content.get("next_cursor")
        if value is not None and (not isinstance(value, str) or not value):
            raise ValueError("Invalid source cursor.")
        return value


class HostCapture(VersionedContract):
    platform: Literal["meta"] = "meta"
    endpoint: Literal["https://mcp.facebook.com/ads"] = META_HOST_URL
    host: Literal["codex", "claude_code", "chatgpt"]
    observed_at: AwareDatetime
    account_id: str | None = Field(default=None, pattern=r"^[0-9]+$")
    pages: list[HostReadPage] = Field(min_length=1, max_length=100)

    @model_validator(mode="after")
    def same_account(self) -> Self:
        for page in self.pages:
            if page.tool != "ads_get_ad_entities":
                continue
            if not self.account_id or page.arguments["ad_account_id"] != self.account_id:
                raise ValueError("Mixed or unspecified account scope.")
            if page.is_error:
                continue
            for row in page.rows():
                for key in ("ad_account_id", "account_id"):
                    if key in row and str(row[key]).removeprefix("act_") != self.account_id:
                        raise ValueError("Response account differs from selected account.")
                if page.entity_level == "ad_account" and row.get("id") != self.account_id:
                    raise ValueError("Response account differs from selected account.")
        return self
