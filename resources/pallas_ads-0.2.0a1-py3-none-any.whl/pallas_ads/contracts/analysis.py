"""Resolved local query plans and inspectable comparison inputs."""

from __future__ import annotations

from datetime import date
from decimal import Decimal
from typing import Literal, Self

from pydantic import AwareDatetime, Field, model_validator

from pallas_ads.contracts.base import ContractModel, VersionedContract
from pallas_ads.contracts.common import (
    CanonicalDimension,
    CanonicalMetric,
    MediaPlatform,
    ReportingTimeBasis,
)
from pallas_ads.contracts.data import AttributionSpec, SourceSnapshot
from pallas_ads.contracts.metrics import MetricComputation
from pallas_ads.contracts.profile import CurrencyConversion
from pallas_ads.contracts.query import CanonicalQuery, DateRange


class EvidencePolicy(ContractModel):
    """A versioned sufficiency policy; no uncalibrated production winner thresholds."""

    version: str = Field(min_length=1)
    calibration: Literal["unconfigured", "synthetic", "live_validated"] = "unconfigured"
    minimum_outcome_events: Decimal | None = Field(default=None, gt=0, allow_inf_nan=False)
    minimum_spend: Decimal | None = Field(default=None, gt=0, allow_inf_nan=False)
    minimum_spend_currency: str | None = Field(default=None, pattern=r"^[A-Z]{3}$")
    validation_ref: str | None = Field(default=None, min_length=1)

    @model_validator(mode="after")
    def validate_calibration(self) -> Self:
        if self.calibration == "unconfigured" and (
            self.minimum_outcome_events is not None or self.minimum_spend is not None
        ):
            raise ValueError("unconfigured policies cannot declare calibrated thresholds")
        if self.calibration != "unconfigured" and self.minimum_outcome_events is None:
            raise ValueError("configured policies require an outcome-event threshold")
        if self.calibration == "live_validated" and self.validation_ref is None:
            raise ValueError("live validated policies require validation evidence")
        if self.minimum_spend_currency is not None and self.minimum_spend is None:
            raise ValueError("spend currency requires a spend threshold")
        return self


class PlannedSource(ContractModel):
    binding_id: str
    platform: MediaPlatform
    account_id: str
    snapshots: list[SourceSnapshot] = Field(default_factory=list)
    complete_mature_dates: list[date] = Field(default_factory=list)
    issues: list[str] = Field(default_factory=list)


class ResolvedQueryPlan(VersionedContract):
    plan_hash: str = Field(pattern=r"^sha256:[a-f0-9]{64}$")
    planner_version: Literal["1.0.0"] = "1.0.0"
    query: CanonicalQuery
    data_revision: int = Field(ge=1)
    profile_revision: int = Field(ge=1)
    profile_hash: str = Field(pattern=r"^sha256:[a-f0-9]{64}$")
    observed_through: AwareDatetime
    period: DateRange
    baseline: DateRange
    effective_grain: list[CanonicalDimension]
    component_metrics: list[CanonicalMetric]
    sources: list[PlannedSource]
    evidence_policy: EvidencePolicy
    warnings: list[str] = Field(default_factory=list)


class MetricAggregate(ContractModel):
    """Arithmetic plus all gates required before interpreting it as a comparison."""

    aggregate_id: str = Field(pattern=r"^agg_[a-f0-9]{24}$")
    scope_key: str
    window: Literal["current", "baseline"]
    period: DateRange
    dimensions: dict[str, str]
    platform: MediaPlatform
    binding_ids: list[str]
    metric: CanonicalMetric
    computation: MetricComputation
    components: dict[CanonicalMetric, Decimal] = Field(default_factory=dict)
    component_currencies: dict[CanonicalMetric, list[str]] = Field(default_factory=dict)
    currency: str | None = None
    source_currencies: list[str] = Field(default_factory=list)
    source_timezones: list[str] = Field(default_factory=list)
    reporting_time_bases: dict[CanonicalMetric, list[ReportingTimeBasis]] = Field(
        default_factory=dict
    )
    optimization_goals: list[str] = Field(default_factory=list)
    attribution_specs: list[AttributionSpec] = Field(default_factory=list)
    complete: bool = False
    provisional: bool = False
    reasons: list[str] = Field(default_factory=list)
    evidence_sufficiency_reasons: list[str] = Field(default_factory=list)
    observation_ids: list[str] = Field(default_factory=list)
    source_snapshot_ids: list[str] = Field(default_factory=list)
    currency_conversions: list[CurrencyConversion] = Field(default_factory=list)
