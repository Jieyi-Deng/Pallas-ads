"""Versioned deterministic monitor inputs, evaluations and incident history."""

from __future__ import annotations

from decimal import Decimal
from typing import Literal, Self

from pydantic import AwareDatetime, Field, JsonValue, model_validator

from pallas_ads.contracts.base import ContractModel, VersionedContract
from pallas_ads.contracts.common import CanonicalMetric, MediaPlatform
from pallas_ads.contracts.query import CanonicalQuery

MonitorFamily = Literal["delivery", "traffic", "outcome", "configuration", "data_health"]
EventState = Literal["detected", "open", "acknowledged", "resolved"]
Severity = Literal["info", "warning", "critical"]
HealthCheck = Literal["freshness", "authentication", "schema", "sync"]
ConfigurationField = Literal[
    "objective_native",
    "daily_budget",
    "budget_currency",
    "status",
    "campaign_type",
    "campaign_type_native",
    "optimization_goal",
    "optimization_goal_native",
    "attribution_spec",
]


class MonitorDefinition(VersionedContract):
    monitor_id: str = Field(pattern=r"^monitor_[a-z0-9][a-z0-9_-]*$")
    version: int = Field(default=1, ge=1)
    name: str = Field(min_length=1)
    family: MonitorFamily
    query: CanonicalQuery
    metric: CanonicalMetric | None = None
    direction: Literal["increase", "decrease", "either", "stop"] = "either"
    relative_threshold: Decimal | None = Field(default=None, gt=0, allow_inf_nan=False)
    critical_relative_threshold: Decimal | None = Field(default=None, gt=0, allow_inf_nan=False)
    severity: Severity = "warning"
    calibration: Literal["user_defined", "synthetic", "live_validated"] = "user_defined"
    validation_ref: str | None = Field(default=None, min_length=1)
    configuration_fields: list[ConfigurationField] = Field(default_factory=list)
    health_checks: list[HealthCheck] = Field(default_factory=list)
    freshness_max_age_seconds: int | None = Field(default=None, gt=0)
    health_max_age_seconds: int | None = Field(default=None, gt=0)

    @model_validator(mode="after")
    def validate_rule(self) -> Self:
        if self.calibration == "live_validated" and self.validation_ref is None:
            raise ValueError("live validated monitors require validation evidence")
        families = {
            "delivery": {"spend", "impressions", "clicks"},
            "traffic": {"cpm", "ctr", "cpc"},
            "outcome": {"cpi", "cpa_purchase_event", "cpa_optimization_event", "media_iap_roas"},
        }
        if self.query.as_of is not None or self.query.as_of_data_revision is not None:
            raise ValueError("supply data revision to the run, not the monitor definition")
        if self.query.profile_revision is not None or self.query.include_provisional:
            raise ValueError("monitor definitions use current confirmed profiles and mature data")
        if "event_date" in self.query.grain:
            raise ValueError("daily baseline alignment is not supported by monitors")
        if self.family in families:
            if self.metric not in families[self.family] or self.query.metrics != [self.metric]:
                raise ValueError("performance monitor requires one family-compatible query metric")
            if self.direction == "stop":
                if self.family != "delivery" or self.relative_threshold is not None:
                    raise ValueError("stop is a delivery rule without a relative threshold")
            elif self.relative_threshold is None:
                raise ValueError("relative change rules require an explicit threshold")
            if self.critical_relative_threshold is not None and (
                self.relative_threshold is None
                or self.critical_relative_threshold <= self.relative_threshold
            ):
                raise ValueError("critical threshold must exceed the trigger threshold")
            if self.configuration_fields or self.health_checks or self.freshness_max_age_seconds:
                raise ValueError("performance rules cannot contain configuration/health settings")
        else:
            if self.query.period or self.query.baseline or self.query.reporting_time_bases:
                raise ValueError("configuration/health runs use revision/time, not report periods")
            if self.family == "data_health" and self.query.filters.campaign_ids:
                raise ValueError("source health checks are account-wide")
            if (
                self.metric is not None
                or self.relative_threshold is not None
                or (self.critical_relative_threshold is not None or self.direction != "either")
            ):
                raise ValueError("configuration/health rules cannot contain performance settings")
            if self.query.filters.countries or self.query.filters.operating_systems:
                raise ValueError(
                    "configuration/health source checks do not support country/OS slices"
                )
            if self.family == "configuration":
                if (
                    not self.configuration_fields
                    or self.health_checks
                    or self.freshness_max_age_seconds
                    or self.health_max_age_seconds
                ):
                    raise ValueError(
                        "configuration rules require only explicit configuration fields"
                    )
            elif not self.health_checks or self.configuration_fields:
                raise ValueError("health rules require explicit health checks")
            if ("freshness" in self.health_checks) != (self.freshness_max_age_seconds is not None):
                raise ValueError("freshness check requires an explicit maximum age")
        explicit_health = bool(set(self.health_checks) - {"freshness"})
        if explicit_health != (self.health_max_age_seconds is not None):
            raise ValueError("explicit health checks require a maximum evidence age")
        for values in (self.configuration_fields, self.health_checks):
            if len(values) != len(set(values)):
                raise ValueError("monitor fields/checks must be unique")
        return self


class SourceHealthObservation(VersionedContract):
    """Sanitized explicit source-boundary evidence; never inferred from imports."""

    health_id: str = Field(pattern=r"^health_[a-z0-9][a-z0-9_-]*$")
    product_id: str = Field(pattern=r"^prod_[a-z0-9][a-z0-9_-]*$")
    platform: MediaPlatform
    account_id: str = Field(min_length=1)
    check: Literal["authentication", "schema", "sync"]
    status: Literal["ok", "failed", "unknown"]
    observed_at: AwareDatetime
    data_revision: int = Field(ge=0)
    code: str = Field(pattern=r"^[a-z][a-z0-9_]*$")
    source_ref: str = Field(min_length=1)


class MonitorEvaluation(ContractModel):
    scope_key: str
    period_key: str
    outcome: Literal["breach", "healthy", "unknown"]
    severity: Severity
    reason: str
    current: JsonValue = None
    baseline: JsonValue = None
    delta_relative: Decimal | None = Field(default=None, allow_inf_nan=False)
    evidence_refs: list[str] = Field(default_factory=list)
    source_snapshot_ids: list[str] = Field(default_factory=list)
    auto_resolve: bool = True


class MonitorTransition(ContractModel):
    from_state: EventState | None
    to_state: EventState
    at: AwareDatetime
    data_revision: int = Field(ge=0)
    trigger_ref: str
    reason: str = Field(min_length=1)


class MonitorEvent(VersionedContract):
    event_id: str = Field(pattern=r"^event_[a-f0-9]{64}$")
    deduplication_key: str
    definition_hash: str
    monitor_id: str
    product_id: str
    scope_key: str
    period_key: str
    state: EventState
    severity: Severity
    first_seen_at: AwareDatetime
    last_seen_at: AwareDatetime
    last_data_revision: int = Field(ge=0)
    occurrence_count: int = Field(ge=1)
    resolution_reason: str | None = None
    latest_evaluation: MonitorEvaluation
    transitions: list[MonitorTransition] = Field(min_length=1)

    @model_validator(mode="after")
    def validate_history(self) -> Self:
        if self.last_seen_at < self.first_seen_at:
            raise ValueError("last seen cannot precede first seen")
        if self.transitions[-1].to_state != self.state:
            raise ValueError("event state must match its final transition")
        if (self.state == "resolved") != (self.resolution_reason is not None):
            raise ValueError("only resolved events require a resolution reason")
        if self.transitions[0].to_state != "detected":
            raise ValueError("incidents must begin with detection")
        if self.transitions[0].at != self.first_seen_at:
            raise ValueError("first seen must match detection time")
        if self.last_data_revision < self.transitions[-1].data_revision:
            raise ValueError("event revision cannot predate its final transition")
        previous = None
        for transition in self.transitions:
            if transition.from_state != (previous.to_state if previous else None):
                raise ValueError("event transition history must be contiguous")
            if previous and (
                transition.at < previous.at or transition.data_revision < previous.data_revision
            ):
                raise ValueError("event transition history cannot move backwards")
            previous = transition
        return self


class MonitorRun(VersionedContract):
    run_id: str = Field(pattern=r"^run_[a-f0-9]{64}$")
    definition: MonitorDefinition
    definition_hash: str
    data_revision: int = Field(ge=0)
    profile_revision: int = Field(ge=1)
    profile_hash: str
    baseline_data_revision: int | None = Field(default=None, ge=0)
    evaluated_at: AwareDatetime
    packet_id: str | None = None
    health_observations: list[SourceHealthObservation] = Field(default_factory=list)
    evaluations: list[MonitorEvaluation]
    events: list[MonitorEvent] = Field(default_factory=list)
    warnings: list[str] = Field(default_factory=list)
    prohibited_claims: list[str] = Field(
        default_factory=lambda: [
            "Do not infer causation, overall winners, or health from missing observations.",
            "Synthetic rules and evidence are not live validation or production recommendations.",
        ]
    )
