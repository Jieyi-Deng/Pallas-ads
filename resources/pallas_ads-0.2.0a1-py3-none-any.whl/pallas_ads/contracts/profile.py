"""Versioned product-profile contracts."""

from __future__ import annotations

from datetime import date
from decimal import Decimal
from enum import StrEnum
from typing import Self

from pydantic import AwareDatetime, Field, JsonValue, model_validator

from pallas_ads.contracts.base import ContractModel, VersionedContract, reject_secret_material
from pallas_ads.contracts.common import CanonicalMetric, MediaPlatform


class OperatingSystem(StrEnum):
    IOS = "ios"
    ANDROID = "android"


class MonetizationModel(StrEnum):
    IN_APP_PURCHASE = "in_app_purchase"
    HYBRID = "hybrid"
    AD_SUPPORTED = "ad_supported"
    SUBSCRIPTION = "subscription"
    OTHER = "other"


class ProvenanceOrigin(StrEnum):
    USER = "user"
    API = "api"
    IMPORT = "import"
    SYSTEM = "system"


class FieldProvenance(ContractModel):
    field_path: str = Field(pattern=r"^/(?:[^/]+/?)+$")
    origin: ProvenanceOrigin
    source_ref: str | None = Field(default=None, min_length=1)
    observed_at: AwareDatetime

    @model_validator(mode="after")
    def require_external_source_reference(self) -> Self:
        if self.origin in {ProvenanceOrigin.API, ProvenanceOrigin.IMPORT} and not self.source_ref:
            raise ValueError("api/import provenance requires a source reference")
        return self


class SourceFact(ContractModel):
    value: str = Field(min_length=1)
    provenance: FieldProvenance

    @model_validator(mode="after")
    def require_source_provenance(self) -> Self:
        if self.provenance.origin not in {ProvenanceOrigin.API, ProvenanceOrigin.IMPORT}:
            raise ValueError("source facts require api or import provenance")
        return self


class AppVariant(ContractModel):
    app_variant_id: str = Field(pattern=r"^variant_[a-z0-9][a-z0-9_-]*$")
    os: OperatingSystem
    store_identifier: str = Field(min_length=1)
    display_name: str | None = Field(default=None, min_length=1)


class CampaignScopeMode(StrEnum):
    ALL = "all"
    INCLUDE = "include"
    EXCLUDE = "exclude"


class CampaignScope(ContractModel):
    mode: CampaignScopeMode = CampaignScopeMode.ALL
    campaign_ids: list[str] = Field(default_factory=list)

    @model_validator(mode="after")
    def validate_scope(self) -> Self:
        if self.mode is CampaignScopeMode.ALL and self.campaign_ids:
            raise ValueError("all campaign scope cannot contain campaign_ids")
        if self.mode is not CampaignScopeMode.ALL and not self.campaign_ids:
            raise ValueError("include/exclude campaign scope requires campaign_ids")
        if len(self.campaign_ids) != len(set(self.campaign_ids)):
            raise ValueError("campaign_ids must be unique")
        return self


class MediaBinding(ContractModel):
    binding_id: str = Field(pattern=r"^binding_[a-z0-9][a-z0-9_-]*$")
    platform: MediaPlatform
    account_id: str = Field(min_length=1)
    app_variant_ids: list[str] = Field(min_length=1)
    campaign_scope: CampaignScope = Field(default_factory=CampaignScope)
    credential_ref_id: str | None = Field(
        default=None,
        pattern=r"^credential_[a-z0-9][a-z0-9_-]*$",
    )
    account_currency: SourceFact | None = None
    account_timezone: SourceFact | None = None

    @model_validator(mode="after")
    def validate_variant_refs(self) -> Self:
        if len(self.app_variant_ids) != len(set(self.app_variant_ids)):
            raise ValueError("app_variant_ids must be unique")
        return self


class PrimaryKpi(StrEnum):
    CPI = CanonicalMetric.CPI
    CPA_PURCHASE_EVENT = CanonicalMetric.CPA_PURCHASE_EVENT
    CPA_OPTIMIZATION_EVENT = CanonicalMetric.CPA_OPTIMIZATION_EVENT
    MEDIA_IAP_ROAS = CanonicalMetric.MEDIA_IAP_ROAS


class KpiSelection(ContractModel):
    primary_metric: PrimaryKpi = PrimaryKpi.CPA_OPTIMIZATION_EVENT
    business_event_key: str = Field(min_length=1)
    visible_metrics: list[CanonicalMetric] = Field(min_length=1)

    @model_validator(mode="after")
    def require_primary_metric_visible(self) -> Self:
        if CanonicalMetric(self.primary_metric.value) not in self.visible_metrics:
            raise ValueError("primary_metric must be included in visible_metrics")
        if len(self.visible_metrics) != len(set(self.visible_metrics)):
            raise ValueError("visible_metrics must be unique")
        return self


class AttributionRequest(ContractModel):
    click_window_days: int = Field(ge=0)
    view_window_days: int = Field(ge=0)
    event_key: str = Field(min_length=1)


class ConversionDirection(StrEnum):
    MULTIPLY_SOURCE_TO_TARGET = "multiply_source_to_target"
    DIVIDE_SOURCE_BY_RATE = "divide_source_by_rate"


class CurrencyConversion(ContractModel):
    source_currency: str = Field(pattern=r"^[A-Z]{3}$")
    target_currency: str = Field(pattern=r"^[A-Z]{3}$")
    rate: Decimal = Field(gt=0)
    direction: ConversionDirection
    effective_date: date
    valid_through: date | None = None
    binding_ids: list[str] = Field(min_length=1)

    @model_validator(mode="after")
    def validate_conversion(self) -> Self:
        if not self.rate.is_finite():
            raise ValueError("currency conversion rate must be finite")
        if self.valid_through is not None and self.valid_through < self.effective_date:
            raise ValueError("currency conversion validity cannot end before effective_date")
        if self.source_currency == self.target_currency:
            raise ValueError("currency conversion requires different currencies")
        if len(self.binding_ids) != len(set(self.binding_ids)):
            raise ValueError("currency conversion binding_ids must be unique")
        return self


class ComparisonPolicy(ContractModel):
    requested_attribution: AttributionRequest | None = None
    currency_conversions: list[CurrencyConversion] = Field(default_factory=list)
    preserve_source_timezone: bool = True
    evidence_policy_version: str = Field(min_length=1)

    @model_validator(mode="after")
    def require_source_timezone(self) -> Self:
        if not self.preserve_source_timezone:
            raise ValueError("v1 comparison policy must preserve source timezones")
        return self


class ProductProfile(VersionedContract):
    profile_id: str = Field(pattern=r"^prod_[a-z0-9][a-z0-9_-]*$")
    product_name: str = Field(min_length=1)
    monetization_model: MonetizationModel
    app_variants: list[AppVariant] = Field(min_length=1)
    media_bindings: list[MediaBinding] = Field(min_length=1)
    kpi: KpiSelection
    comparison_policy: ComparisonPolicy
    field_provenance: list[FieldProvenance] = Field(min_length=1)
    confirmation_revision: int = Field(ge=1)
    confirmed_at: AwareDatetime

    @model_validator(mode="after")
    def validate_profile_graph(self) -> Self:
        variant_ids = [variant.app_variant_id for variant in self.app_variants]
        if len(variant_ids) != len(set(variant_ids)):
            raise ValueError("app_variant_id values must be unique")

        binding_ids = [binding.binding_id for binding in self.media_bindings]
        if len(binding_ids) != len(set(binding_ids)):
            raise ValueError("binding_id values must be unique")

        unknown_variants = sorted(
            {
                variant_id
                for binding in self.media_bindings
                for variant_id in binding.app_variant_ids
                if variant_id not in variant_ids
            }
        )
        if unknown_variants:
            raise ValueError(f"media bindings reference unknown app variants: {unknown_variants}")

        unknown_bindings = sorted(
            {
                binding_id
                for conversion in self.comparison_policy.currency_conversions
                for binding_id in conversion.binding_ids
                if binding_id not in binding_ids
            }
        )
        if unknown_bindings:
            raise ValueError(f"currency conversions reference unknown bindings: {unknown_bindings}")

        provenance_paths = [item.field_path for item in self.field_provenance]
        if len(provenance_paths) != len(set(provenance_paths)):
            raise ValueError("field provenance paths must be unique")
        return self


class ProfileDraftValues(ContractModel):
    """Potentially incomplete profile values supplied by the user's agent."""

    profile_id: str = Field(pattern=r"^prod_[a-z0-9][a-z0-9_-]*$")
    product_name: str | None = Field(default=None, min_length=1)
    monetization_model: MonetizationModel | None = None
    app_variants: list[AppVariant] = Field(default_factory=list)
    media_bindings: list[MediaBinding] = Field(default_factory=list)
    kpi: KpiSelection | None = None
    comparison_policy: ComparisonPolicy | None = None
    field_provenance: list[FieldProvenance] = Field(default_factory=list)

    @model_validator(mode="after")
    def validate_partial_profile_graph(self) -> Self:
        variant_ids = [variant.app_variant_id for variant in self.app_variants]
        binding_ids = [binding.binding_id for binding in self.media_bindings]
        provenance_paths = [item.field_path for item in self.field_provenance]
        for label, values in (
            ("app_variant_id", variant_ids),
            ("binding_id", binding_ids),
            ("field provenance path", provenance_paths),
        ):
            if len(values) != len(set(values)):
                raise ValueError(f"{label} values must be unique")

        if variant_ids:
            unknown_variants = sorted(
                {
                    variant_id
                    for binding in self.media_bindings
                    for variant_id in binding.app_variant_ids
                    if variant_id not in variant_ids
                }
            )
            if unknown_variants:
                raise ValueError(
                    f"media bindings reference unknown app variants: {unknown_variants}"
                )

        if self.comparison_policy is not None:
            unknown_bindings = sorted(
                {
                    binding_id
                    for conversion in self.comparison_policy.currency_conversions
                    for binding_id in conversion.binding_ids
                    if binding_id not in binding_ids
                }
            )
            if unknown_bindings:
                raise ValueError(
                    f"currency conversions reference unknown bindings: {unknown_bindings}"
                )
        return self


class ProfileDraft(VersionedContract):
    draft_id: str = Field(pattern=r"^draft_[a-z0-9][a-z0-9_-]*$")
    base_revision: int = Field(ge=0)
    content_hash: str = Field(pattern=r"^sha256:[a-f0-9]{64}$")
    created_at: AwareDatetime
    values: ProfileDraftValues


class ProfileDraftReview(VersionedContract):
    draft_id: str = Field(pattern=r"^draft_[a-z0-9][a-z0-9_-]*$")
    profile_id: str = Field(pattern=r"^prod_[a-z0-9][a-z0-9_-]*$")
    content_hash: str = Field(pattern=r"^sha256:[a-f0-9]{64}$")
    base_revision: int = Field(ge=0)
    ready_for_confirmation: bool
    confirmation_summary: str | None = Field(default=None, min_length=1)

    @model_validator(mode="after")
    def validate_review_state(self) -> Self:
        if self.ready_for_confirmation != (self.confirmation_summary is not None):
            raise ValueError("ready_for_confirmation must match confirmation_summary availability")
        return self


class PatchOperation(StrEnum):
    ADD = "add"
    REPLACE = "replace"
    REMOVE = "remove"


class ProfilePatchItem(ContractModel):
    operation: PatchOperation
    path: str = Field(pattern=r"^/(?:[^/]+/?)+$")
    value: JsonValue = None

    @model_validator(mode="after")
    def protect_contract_identity(self) -> Self:
        path_parts = self.path.split("/")[1:]
        root = path_parts[0]
        if root in {
            "schema_version",
            "profile_id",
            "confirmation_revision",
            "confirmed_at",
            "field_provenance",
        }:
            raise ValueError(f"profile patch cannot modify immutable field: {root}")
        for path_part in path_parts:
            reject_secret_material({path_part: None}, path=f"$.path:{self.path}")
        if self.operation is PatchOperation.REMOVE and self.value is not None:
            raise ValueError("remove operations cannot contain a value")
        return self


class ProfilePatch(VersionedContract):
    draft_id: str = Field(pattern=r"^draft_[a-z0-9][a-z0-9_-]*$")
    profile_id: str = Field(pattern=r"^prod_[a-z0-9][a-z0-9_-]*$")
    base_revision: int = Field(ge=1)
    content_hash: str = Field(pattern=r"^sha256:[a-f0-9]{64}$")
    changes: list[ProfilePatchItem] = Field(min_length=1)
    field_provenance: list[FieldProvenance] = Field(default_factory=list)
    created_at: AwareDatetime

    @model_validator(mode="after")
    def validate_unique_paths(self) -> Self:
        change_paths = [item.path for item in self.changes]
        provenance_paths = [item.field_path for item in self.field_provenance]
        if len(change_paths) != len(set(change_paths)):
            raise ValueError("profile patch change paths must be unique")
        if len(provenance_paths) != len(set(provenance_paths)):
            raise ValueError("profile patch provenance paths must be unique")
        return self


class ProfileRevision(VersionedContract):
    profile_id: str = Field(pattern=r"^prod_[a-z0-9][a-z0-9_-]*$")
    revision: int = Field(ge=1)
    profile_hash: str = Field(pattern=r"^sha256:[a-f0-9]{64}$")
    confirmed_draft_id: str = Field(pattern=r"^draft_[a-z0-9][a-z0-9_-]*$")
    confirmed_content_hash: str = Field(pattern=r"^sha256:[a-f0-9]{64}$")
    confirmed_at: AwareDatetime
    profile: ProductProfile

    @model_validator(mode="after")
    def validate_revision_identity(self) -> Self:
        if self.profile.profile_id != self.profile_id:
            raise ValueError("profile_id must match the embedded profile")
        if self.profile.confirmation_revision != self.revision:
            raise ValueError("revision must match profile.confirmation_revision")
        return self
