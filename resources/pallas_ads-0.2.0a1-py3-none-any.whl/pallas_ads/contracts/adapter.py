"""Capability and manifest contracts for read-only media adapters."""

from __future__ import annotations

from enum import StrEnum
from typing import Self

from pydantic import AwareDatetime, Field, model_validator

from pallas_ads.contracts.base import ContractModel, VersionedContract
from pallas_ads.contracts.common import CanonicalDimension, CanonicalMetric, MediaPlatform


class AdapterLifecycle(StrEnum):
    EXPERIMENTAL = "experimental"
    STABLE = "stable"
    DEPRECATED = "deprecated"


class ReconciliationStatus(StrEnum):
    PASSED = "passed"
    FAILED = "failed"
    UNEXPLAINED_DIFFERENCE = "unexplained_difference"


class QueryMode(StrEnum):
    ACCOUNT_CONTEXT = "account_context"
    ACCOUNT_HIERARCHY = "account_hierarchy"
    ENTITY_CONFIGURATION = "entity_configuration"
    TRAFFIC_PERFORMANCE = "traffic_performance"
    CONVERSION_PERFORMANCE = "conversion_performance"
    CAPABILITY_PROBE = "capability_probe"


class NativeFieldDefinition(ContractModel):
    field_name: str = Field(min_length=1)
    value_type: str = Field(min_length=1)
    nullable: bool
    enum_values: list[str] = Field(default_factory=list)


class MetricMapping(ContractModel):
    canonical_metric: CanonicalMetric
    native_fields: list[str] = Field(min_length=1)
    query_mode: QueryMode
    semantic_version: str = Field(min_length=1)


class MaturityPolicy(ContractModel):
    canonical_metric: CanonicalMetric
    policy_version: str = Field(min_length=1)
    provisional_days: int = Field(ge=0)
    refresh_lookback_days: int = Field(ge=0)

    @model_validator(mode="after")
    def validate_lookback(self) -> Self:
        if self.refresh_lookback_days < self.provisional_days:
            raise ValueError("refresh lookback must cover the provisional period")
        return self


class MetricReconciliation(ContractModel):
    canonical_metric: CanonicalMetric
    status: ReconciliationStatus
    report_ref: str = Field(min_length=1)
    reconciled_at: AwareDatetime


class SourceCapability(VersionedContract):
    capability_id: str = Field(pattern=r"^cap_[a-z0-9][a-z0-9_-]*$")
    platform: MediaPlatform
    adapter_version: str = Field(pattern=r"^\d+\.\d+\.\d+$")
    api_version: str = Field(min_length=1)
    query_modes: list[QueryMode] = Field(min_length=1)
    metrics: list[CanonicalMetric] = Field(default_factory=list)
    dimensions: list[CanonicalDimension] = Field(default_factory=list)
    supports_pagination: bool
    supports_empty_accounts: bool
    observed_at: AwareDatetime | None = None

    @model_validator(mode="after")
    def validate_unique_capabilities(self) -> Self:
        for field_name in ("query_modes", "metrics", "dimensions"):
            values = getattr(self, field_name)
            if len(values) != len(set(values)):
                raise ValueError(f"{field_name} must be unique")
        return self


class AdapterManifest(VersionedContract):
    manifest_id: str = Field(pattern=r"^adapter_[a-z0-9][a-z0-9_-]*$")
    platform: MediaPlatform
    adapter_version: str = Field(pattern=r"^\d+\.\d+\.\d+$")
    api_version: str = Field(min_length=1)
    lifecycle: AdapterLifecycle = AdapterLifecycle.EXPERIMENTAL
    capability: SourceCapability
    native_fields: list[NativeFieldDefinition] = Field(default_factory=list)
    metric_mappings: list[MetricMapping] = Field(default_factory=list)
    maturity_policies: list[MaturityPolicy] = Field(default_factory=list)
    official_source_references: list[str] = Field(default_factory=list)
    last_live_validated_at: AwareDatetime | None = None
    reconciliation_evidence: list[MetricReconciliation] = Field(default_factory=list)

    @model_validator(mode="after")
    def validate_manifest(self) -> Self:
        if self.capability.platform is not self.platform:
            raise ValueError("capability platform must match manifest platform")
        if self.capability.adapter_version != self.adapter_version:
            raise ValueError("capability adapter_version must match manifest adapter_version")
        if self.capability.api_version != self.api_version:
            raise ValueError("capability api_version must match manifest api_version")
        reconciliation_metrics = [item.canonical_metric for item in self.reconciliation_evidence]
        if len(reconciliation_metrics) != len(set(reconciliation_metrics)):
            raise ValueError("reconciliation evidence must be unique per canonical metric")
        if self.lifecycle is AdapterLifecycle.STABLE:
            if self.last_live_validated_at is None or not self.capability.metrics:
                raise ValueError(
                    "stable adapters require live validation and reconciled performance metrics"
                )
            passed_metrics = {
                item.canonical_metric
                for item in self.reconciliation_evidence
                if item.status is ReconciliationStatus.PASSED
            }
            missing_reconciliation = sorted(
                metric.value for metric in set(self.capability.metrics) - passed_metrics
            )
            if missing_reconciliation:
                raise ValueError(
                    "stable adapters require passed reconciliation for every supported metric: "
                    f"{missing_reconciliation}"
                )

        field_names = [field.field_name for field in self.native_fields]
        if len(field_names) != len(set(field_names)):
            raise ValueError("native field names must be unique")

        mapping_keys = [
            (mapping.canonical_metric, mapping.query_mode) for mapping in self.metric_mappings
        ]
        if len(mapping_keys) != len(set(mapping_keys)):
            raise ValueError("metric mappings must be unique per metric and query mode")
        return self
