"""Evidence Packet and claim-boundary contracts."""

from __future__ import annotations

import re
from decimal import Decimal
from enum import StrEnum
from typing import Literal, Self

from pydantic import AwareDatetime, Field, JsonValue, model_validator

from pallas_ads.contracts.base import ContractModel, VersionedContract
from pallas_ads.contracts.common import (
    OUTCOME_METRICS,
    CanonicalMetric,
    ComparisonStatus,
    MediaPlatform,
)
from pallas_ads.contracts.query import DateRange
from pallas_ads.contracts.status import MissingInput


class EvidenceKind(StrEnum):
    METRIC = "metric"
    CONFIGURATION = "configuration"
    COMPARISON = "comparison"
    DATA_HEALTH = "data_health"


class EvidenceItem(ContractModel):
    evidence_id: str = Field(pattern=r"^ev_[a-z0-9][a-z0-9_-]*$")
    kind: EvidenceKind
    statement: str = Field(min_length=1)
    metric: CanonicalMetric | None = None
    value: JsonValue = None
    unit: str | None = None
    source_snapshot_ids: list[str] = Field(min_length=1)
    details: dict[str, JsonValue] = Field(default_factory=dict)


class ComparisonCell(ContractModel):
    comparison_id: str = Field(pattern=r"^cmp_[a-z0-9][a-z0-9_-]*$")
    metric: CanonicalMetric
    left_scope: str = Field(min_length=1)
    right_scope: str = Field(min_length=1)
    left_value: JsonValue = None
    right_value: JsonValue = None
    status: ComparisonStatus
    reasons: list[str] = Field(default_factory=list)
    optimization_goals_compatible: bool
    evidence_refs: list[str] = Field(min_length=1)
    comparison_type: Literal["cross_source", "period_change"] = "cross_source"
    left_unit: str | None = None
    right_unit: str | None = None
    delta_absolute: Decimal | None = Field(default=None, allow_inf_nan=False)
    delta_relative: Decimal | None = Field(default=None, allow_inf_nan=False)
    evidence_policy_version: str | None = None
    evidence_policy_calibration: Literal["unconfigured", "synthetic", "live_validated"] | None = (
        None
    )

    @model_validator(mode="after")
    def enforce_comparison_boundary(self) -> Self:
        if self.status is ComparisonStatus.STRICTLY_COMPARABLE and self.reasons:
            raise ValueError("strictly comparable cells cannot contain incompatibility reasons")
        if self.status is not ComparisonStatus.STRICTLY_COMPARABLE and not self.reasons:
            raise ValueError("non-strict comparison cells require reasons")
        if (
            not self.optimization_goals_compatible
            and self.metric in OUTCOME_METRICS
            and self.status is not ComparisonStatus.NOT_COMPARABLE
        ):
            raise ValueError("outcome metrics cannot compare incompatible optimization goals")
        return self


class AllowedClaim(ContractModel):
    claim_id: str = Field(pattern=r"^claim_[a-z0-9][a-z0-9_-]*$")
    statement: str = Field(min_length=1)
    evidence_refs: list[str] = Field(min_length=1)


class ProhibitedClaim(ContractModel):
    statement: str = Field(min_length=1)
    reason: str = Field(min_length=1)


class InsufficientEvidenceItem(ContractModel):
    subject: str = Field(min_length=1)
    reason: str = Field(min_length=1)
    required_evidence: list[str] = Field(default_factory=list)


class EvidenceWarning(ContractModel):
    code: str = Field(min_length=1, pattern=r"^[a-z][a-z0-9_]*$")
    message: str = Field(min_length=1)
    affected_evidence_refs: list[str] = Field(default_factory=list)


class AdapterLineage(ContractModel):
    platform: MediaPlatform
    adapter_version: str = Field(pattern=r"^\d+\.\d+\.\d+$")
    api_version: str = Field(min_length=1)


class EvidenceLineage(ContractModel):
    pallas_version: str = Field(pattern=r"^\d+\.\d+\.\d+(?:(?:a|b|rc)\d+)?$")
    profile_revision: int = Field(ge=1)
    query_id: str = Field(pattern=r"^query_[a-z0-9][a-z0-9_-]*$")
    metric_semantic_versions: dict[CanonicalMetric, str] = Field(min_length=1)
    adapters: list[AdapterLineage] = Field(default_factory=list)
    query_plan_hashes: list[str] = Field(default_factory=list)
    source_snapshot_ids: list[str] = Field(min_length=1)
    observation_revisions: dict[str, int] = Field(default_factory=dict)
    data_revision: int | None = Field(default=None, ge=1)
    profile_hash: str | None = Field(default=None, pattern=r"^sha256:[a-f0-9]{64}$")
    calculation_policy_version: str | None = None
    comparison_policy_version: str | None = None
    evidence_policy_version: str | None = None
    evidence_policy_hash: str | None = Field(default=None, pattern=r"^sha256:[a-f0-9]{64}$")
    source_content_hashes: dict[str, str] = Field(default_factory=dict)
    import_format_versions: dict[str, str] = Field(default_factory=dict)
    maturity_policy_versions: dict[str, list[str]] = Field(default_factory=dict)
    coverage_snapshot_ids: list[str] = Field(default_factory=list)

    @model_validator(mode="after")
    def validate_lineage(self) -> Self:
        invalid_hashes = [
            value
            for value in self.query_plan_hashes
            if re.fullmatch(r"sha256:[a-f0-9]{64}", value) is None
        ]
        if invalid_hashes:
            raise ValueError("query plan hashes must use sha256:<64 lowercase hex> format")
        if any(revision < 1 for revision in self.observation_revisions.values()):
            raise ValueError("observation revisions must be positive")
        return self


class EvidenceScope(ContractModel):
    product_id: str = Field(pattern=r"^prod_[a-z0-9][a-z0-9_-]*$")
    period: DateRange
    baseline: DateRange | None = None
    platforms: list[MediaPlatform] = Field(min_length=1)

    @model_validator(mode="after")
    def validate_platforms(self) -> Self:
        if len(self.platforms) != len(set(self.platforms)):
            raise ValueError("platforms must be unique")
        return self


class EvidencePacket(VersionedContract):
    packet_id: str = Field(pattern=r"^evidence_[a-z0-9][a-z0-9_-]*$")
    created_at: AwareDatetime
    scope: EvidenceScope
    verified_facts: list[EvidenceItem] = Field(default_factory=list)
    comparisons: list[ComparisonCell] = Field(default_factory=list)
    warnings: list[EvidenceWarning] = Field(default_factory=list)
    missing_inputs: list[MissingInput] = Field(default_factory=list)
    allowed_claims: list[AllowedClaim] = Field(default_factory=list)
    prohibited_claims: list[ProhibitedClaim] = Field(default_factory=list)
    insufficient_evidence: list[InsufficientEvidenceItem] = Field(default_factory=list)
    monitor_event_refs: list[str] = Field(default_factory=list)
    lineage: EvidenceLineage

    @model_validator(mode="after")
    def validate_references(self) -> Self:
        evidence_ids = [item.evidence_id for item in self.verified_facts]
        comparison_ids = [item.comparison_id for item in self.comparisons]
        claim_ids = [item.claim_id for item in self.allowed_claims]
        for label, values in (
            ("evidence_id", evidence_ids),
            ("comparison_id", comparison_ids),
            ("claim_id", claim_ids),
        ):
            if len(values) != len(set(values)):
                raise ValueError(f"{label} values must be unique")

        known_evidence = set(evidence_ids)
        references = {
            reference
            for collection in (self.comparisons, self.allowed_claims)
            for item in collection
            for reference in item.evidence_refs
        }
        references.update(
            reference for warning in self.warnings for reference in warning.affected_evidence_refs
        )
        unknown = sorted(references - known_evidence)
        if unknown:
            raise ValueError(f"unknown evidence references: {unknown}")

        lineage_snapshots = set(self.lineage.source_snapshot_ids)
        fact_snapshots = {
            snapshot_id for fact in self.verified_facts for snapshot_id in fact.source_snapshot_ids
        }
        missing_snapshots = sorted(fact_snapshots - lineage_snapshots)
        if missing_snapshots:
            raise ValueError(f"fact snapshots missing from lineage: {missing_snapshots}")
        return self
