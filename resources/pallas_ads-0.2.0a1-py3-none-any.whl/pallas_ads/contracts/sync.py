"""Profile-scoped experimental traffic synchronization contracts."""

from __future__ import annotations

from datetime import date
from typing import Literal

from pydantic import Field

from pallas_ads.contracts.base import VersionedContract
from pallas_ads.contracts.data import CanonicalImportResult
from pallas_ads.contracts.metrics import MetricComputation
from pallas_ads.contracts.query import DateRange
from pallas_ads.contracts.source import SourceReadResult


class SyncRequest(VersionedContract):
    product_id: str = Field(pattern=r"^prod_[a-z0-9][a-z0-9_-]*$")
    binding_id: str = Field(pattern=r"^binding_[a-z0-9][a-z0-9_-]*$")
    connection_id: str = Field(pattern=r"^connection_[a-z0-9][a-z0-9_-]*$")
    period: DateRange
    include_native_conversions: bool = False
    max_pages: int = Field(default=20, ge=1, le=100)


class SyncResult(VersionedContract):
    reads: list[SourceReadResult]
    imported: CanonicalImportResult | None = None
    traffic_analysis: TrafficAnalysis | None = None
    warnings: list[str]


class TrafficSlice(VersionedContract):
    """One group of returned campaign-day rows; totals never imply account completeness."""

    grain: Literal["total", "campaign", "day"]
    key: str
    observed_rows: int = Field(ge=1)
    observed_dates: list[date]
    missing_components: list[str]
    metrics: list[MetricComputation]


class TrafficAnalysis(VersionedContract):
    read_id: str
    period: DateRange
    currency: str
    source_timezone: str
    claim_scope: Literal["observed_rows_only"] = "observed_rows_only"
    maturity_verified: Literal[False] = False
    coverage_verified: Literal[False] = False
    slices: list[TrafficSlice]
    warnings: list[str]


SyncResult.model_rebuild()
