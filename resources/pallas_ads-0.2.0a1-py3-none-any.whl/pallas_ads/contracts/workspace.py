"""Local workspace contracts."""

from __future__ import annotations

from typing import Self

from pydantic import AwareDatetime, Field, model_validator

from pallas_ads.contracts.base import VersionedContract


class WorkspaceManifest(VersionedContract):
    workspace_id: str = Field(pattern=r"^workspace_[a-z0-9][a-z0-9_-]*$")
    created_at: AwareDatetime
    profile_ids: list[str] = Field(default_factory=list)
    credential_ref_ids: list[str] = Field(default_factory=list)

    @model_validator(mode="after")
    def validate_unique_references(self) -> Self:
        for label, values in (
            ("profile_ids", self.profile_ids),
            ("credential_ref_ids", self.credential_ref_ids),
        ):
            if len(values) != len(set(values)):
                raise ValueError(f"{label} must be unique")
        return self


class WorkspaceState(VersionedContract):
    workspace_id: str = Field(pattern=r"^workspace_[a-z0-9][a-z0-9_-]*$")
    root: str = Field(min_length=1)
    database_file: str = Field(min_length=1)
    initialized_at: AwareDatetime
    created_now: bool
