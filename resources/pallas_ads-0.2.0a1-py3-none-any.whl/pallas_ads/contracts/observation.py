"""Structured, qualified diagnostic insights produced from retained observations."""

from typing import Literal

from pydantic import Field

from pallas_ads.contracts.base import ContractModel


class ObservationInsight(ContractModel):
    kind: Literal["observation", "arithmetic_contribution", "screening", "hypothesis"]
    title: str = Field(min_length=1, max_length=300)
    detail: str = Field(min_length=1, max_length=4000)
    evidence: list[str] = Field(min_length=1, max_length=30)
    next_check: str = Field(min_length=1, max_length=2000)
    claim_scope: Literal["observed_rows_only"] = "observed_rows_only"
    causality: Literal["not_established"] = "not_established"
