"""Typed evidence-bound agent choices and immutable briefing artifacts."""

from __future__ import annotations

from typing import Literal, Self

from pydantic import AwareDatetime, Field, model_validator

from pallas_ads.contracts.analysis import ResolvedQueryPlan
from pallas_ads.contracts.base import ContractModel, VersionedContract
from pallas_ads.contracts.data import EntitySnapshot, SourceSnapshot
from pallas_ads.contracts.evidence import EvidencePacket
from pallas_ads.contracts.metrics import MetricDefinition
from pallas_ads.contracts.monitor import MonitorRun

SECTION_ORDER = (
    "scope",
    "facts",
    "comparisons",
    "channels",
    "monitors",
    "hypotheses",
    "unknowns",
    "methodology",
)


class RetainedEvidence(ContractModel):
    plan: ResolvedQueryPlan
    packet: EvidencePacket


class ReportEvidence(VersionedContract):
    comparison: RetainedEvidence
    monitor_runs: list[MonitorRun] = Field(default_factory=list)
    monitor_comparisons: list[RetainedEvidence] = Field(default_factory=list)
    source_snapshots: list[SourceSnapshot] = Field(default_factory=list)
    entity_snapshots: list[EntitySnapshot] = Field(default_factory=list)


class InvestigationOption(ContractModel):
    option_id: str = Field(pattern=r"^option_[a-f0-9]{24}$")
    kind: Literal["hypothesis", "check"]
    statement: str = Field(min_length=1)
    evidence_refs: list[str] = Field(min_length=1)
    verification_step: str = Field(min_length=1)


class AgentAnalysisContract(VersionedContract):
    contract_id: str = Field(pattern=r"^analysis_[a-f0-9]{64}$")
    policy_version: Literal["1.0.0"] = "1.0.0"
    product_name: str = Field(min_length=1)
    evidence: ReportEvidence
    metric_definitions: list[MetricDefinition] = Field(min_length=1)
    required_sections: list[str] = Field(default_factory=lambda: list(SECTION_ORDER))
    response_rules: list[str] = Field(min_length=1)
    options: list[InvestigationOption] = Field(default_factory=list)


class AgentAnalysisDraft(VersionedContract):
    """Choose verified claims and offered investigations; never insert arbitrary factual prose."""

    contract_id: str = Field(pattern=r"^analysis_[a-f0-9]{64}$")
    highlighted_claim_ids: list[str] = Field(default_factory=list)
    hypothesis_ids: list[str] = Field(default_factory=list)
    check_ids: list[str] = Field(default_factory=list)

    @model_validator(mode="after")
    def unique_choices(self) -> Self:
        for values in (self.highlighted_claim_ids, self.hypothesis_ids, self.check_ids):
            if len(values) != len(set(values)):
                raise ValueError("analysis choices must be unique")
        return self


class BriefingTable(ContractModel):
    title: str
    columns: list[str] = Field(min_length=1)
    rows: list[list[str]] = Field(default_factory=list)

    @model_validator(mode="after")
    def consistent_width(self) -> Self:
        if any(len(row) != len(self.columns) for row in self.rows):
            raise ValueError("table rows must match the declared columns")
        return self


class BriefingSection(ContractModel):
    section_id: str
    title: str
    paragraphs: list[str] = Field(default_factory=list)
    tables: list[BriefingTable] = Field(default_factory=list)


class BriefingDocument(VersionedContract):
    """The same plain-text document model feeds chat, Markdown and HTML."""

    contract_id: str
    title: str
    subtitle: str
    status: Literal["complete", "partial_result"]
    cards: dict[str, str]
    sections: list[BriefingSection]

    @model_validator(mode="after")
    def complete_structure(self) -> Self:
        if [section.section_id for section in self.sections] != list(SECTION_ORDER):
            raise ValueError("briefings must retain every required section in contract order")
        return self


class ReportManifest(VersionedContract):
    report_id: str = Field(pattern=r"^report_[a-f0-9]{64}$")
    product_id: str = Field(pattern=r"^prod_[a-z0-9][a-z0-9_-]*$")
    contract_id: str = Field(pattern=r"^analysis_[a-f0-9]{64}$")
    packet_id: str
    monitor_run_ids: list[str]
    profile_revision: int = Field(ge=1)
    data_revision: int = Field(ge=1)
    created_at: AwareDatetime
    renderer_version: Literal["1.0.0"] = "1.0.0"
    status: Literal["complete", "partial_result"]
    artifact_hashes: dict[str, str]


class ReportResult(VersionedContract):
    manifest: ReportManifest
    directory: str
