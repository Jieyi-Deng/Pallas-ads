"""Canonical import, snapshot, and observation contracts."""

from __future__ import annotations

from datetime import date
from decimal import Decimal
from enum import StrEnum
from pathlib import PurePosixPath
from typing import Self

from pydantic import AwareDatetime, Field, model_validator

from pallas_ads.contracts.base import ContractModel, VersionedContract
from pallas_ads.contracts.common import CanonicalMetric, MediaPlatform, ReportingTimeBasis
from pallas_ads.contracts.profile import CampaignScope, CampaignScopeMode, OperatingSystem
from pallas_ads.contracts.query import DateRange
from pallas_ads.contracts.source import SourceQueryPlan


class ImportFileRole(StrEnum):
    ENTITIES = "entities"
    OBSERVATIONS = "observations"


class ImportFileFormat(StrEnum):
    CSV = "csv"
    JSON = "json"


class DimensionState(StrEnum):
    VALUE = "value"
    ALL = "all"
    NOT_REQUESTED = "not_requested"
    NOT_SUPPORTED = "not_supported"
    NOT_APPLICABLE = "not_applicable"
    MISSING = "missing"


class MaturityStatus(StrEnum):
    PROVISIONAL = "provisional"
    MATURE = "mature"


class EntityType(StrEnum):
    ACCOUNT = "account"
    CAMPAIGN = "campaign"


class DimensionValue(ContractModel):
    """A dimension value whose absence always has an explicit meaning."""

    state: DimensionState
    value: str | None = Field(default=None, min_length=1)

    @model_validator(mode="after")
    def validate_value_state(self) -> Self:
        if self.state is DimensionState.VALUE and self.value is None:
            raise ValueError("dimension state 'value' requires a value")
        if self.state is not DimensionState.VALUE and self.value is not None:
            raise ValueError("non-value dimension states cannot contain a value")
        return self


class AttributionSpec(ContractModel):
    event_key: str = Field(min_length=1)
    click_window_days: int = Field(ge=0)
    view_window_days: int = Field(ge=0)


class CanonicalImportFile(ContractModel):
    role: ImportFileRole
    path: str = Field(min_length=1)
    format: ImportFileFormat
    content_sha256: str = Field(pattern=r"^sha256:[a-f0-9]{64}$")

    @model_validator(mode="after")
    def require_safe_relative_path(self) -> Self:
        candidate = PurePosixPath(self.path)
        if candidate.is_absolute() or ".." in candidate.parts or self.path.endswith("/"):
            raise ValueError("import file path must be a safe relative file path")
        expected_suffix = f".{self.format.value}"
        if candidate.suffix.lower() != expected_suffix:
            raise ValueError(f"import file path must end in {expected_suffix}")
        return self


class ImportMaturityPolicy(ContractModel):
    canonical_metric: CanonicalMetric
    metric_semantic_version: str = Field(pattern=r"^\d+\.\d+\.\d+$")
    reporting_time_basis: ReportingTimeBasis = ReportingTimeBasis.UNKNOWN
    policy_version: str = Field(min_length=1)
    maturity_verified: bool = True
    provisional_days: int = Field(ge=0)
    refresh_lookback_days: int = Field(ge=0)

    @model_validator(mode="after")
    def validate_lookback(self) -> Self:
        if self.refresh_lookback_days < self.provisional_days:
            raise ValueError("refresh lookback must cover the provisional period")
        return self


class ImportCoverage(ContractModel):
    """Source assertion of one complete, dense campaign report for the import period.

    The enumerated population includes campaigns with explicit zero observations.
    Its completeness is a source assertion, not inferred from the rows themselves.
    """

    campaign_scope: CampaignScope
    campaign_ids: list[str]
    metrics: list[CanonicalMetric] = Field(min_length=1)
    country: DimensionValue
    os: DimensionValue
    reporting_time_bases: dict[CanonicalMetric, ReportingTimeBasis]

    @model_validator(mode="after")
    def validate_coverage(self) -> Self:
        population = set(self.campaign_ids)
        if len(population) != len(self.campaign_ids) or any(
            not campaign_id.strip() for campaign_id in self.campaign_ids
        ):
            raise ValueError("coverage campaign_ids must be unique and nonblank")
        if len(self.metrics) != len(set(self.metrics)):
            raise ValueError("coverage metrics must be unique")
        if set(self.reporting_time_bases) != set(self.metrics):
            raise ValueError("coverage reporting_time_bases must exactly match coverage metrics")
        if any(
            basis in {ReportingTimeBasis.UNKNOWN, ReportingTimeBasis.MIXED}
            for basis in self.reporting_time_bases.values()
        ):
            raise ValueError("complete coverage requires verified, unmixed report-date semantics")
        if any(
            dimension.state not in {DimensionState.VALUE, DimensionState.ALL}
            for dimension in (self.country, self.os)
        ):
            raise ValueError("coverage dimensions must be explicit values or all")
        if self.os.state is DimensionState.VALUE:
            OperatingSystem(self.os.value)
        scope_ids = set(self.campaign_scope.campaign_ids)
        if self.campaign_scope.mode is CampaignScopeMode.INCLUDE and population != scope_ids:
            raise ValueError("included campaign population must exactly match the declared scope")
        if self.campaign_scope.mode is CampaignScopeMode.EXCLUDE and population & scope_ids:
            raise ValueError("campaign population cannot contain excluded campaign IDs")
        return self


class NativeReadLineage(ContractModel):
    read_id: str = Field(pattern=r"^read_[a-f0-9]{32}$")
    plan: SourceQueryPlan
    observed_at: AwareDatetime
    content_hash: str = Field(pattern=r"^sha256:[a-f0-9]{64}$")


class CanonicalImportManifest(VersionedContract):
    """Source-owned metadata required beside canonical CSV or JSON files."""

    import_format_version: str = Field(default="1.0.0", pattern=r"^\d+\.\d+\.\d+$")
    package_id: str = Field(pattern=r"^import_[a-z0-9][a-z0-9_-]*$")
    source_snapshot_id: str = Field(pattern=r"^snapshot_[a-z0-9][a-z0-9_-]*$")
    product_id: str = Field(pattern=r"^prod_[a-z0-9][a-z0-9_-]*$")
    platform: MediaPlatform
    account_id: str = Field(min_length=1)
    account_currency: str = Field(pattern=r"^[A-Z]{3}$")
    source_timezone: str = Field(min_length=1)
    observed_at: AwareDatetime
    effective_period: DateRange
    raw_retention_days: int = Field(default=90, ge=0)
    files: list[CanonicalImportFile] = Field(min_length=2)
    maturity_policies: list[ImportMaturityPolicy] = Field(min_length=1)
    coverage: ImportCoverage | None = None
    native_lineage: list[NativeReadLineage] = Field(default_factory=list)

    @model_validator(mode="after")
    def validate_manifest_inventory(self) -> Self:
        paths = [item.path for item in self.files]
        if len(paths) != len(set(paths)):
            raise ValueError("import file paths must be unique")
        roles = [item.role for item in self.files]
        for required_role in ImportFileRole:
            if roles.count(required_role) != 1:
                raise ValueError(f"manifest requires exactly one {required_role.value} file")
        policy_keys = [
            (item.canonical_metric, item.metric_semantic_version, item.reporting_time_basis)
            for item in self.maturity_policies
        ]
        if len(policy_keys) != len(set(policy_keys)):
            raise ValueError("maturity policies must be unique per metric version and time basis")
        return self


class CanonicalEntityRecord(ContractModel):
    entity_type: EntityType
    entity_id: str = Field(min_length=1)
    app_variant_id: str | None = Field(
        default=None,
        pattern=r"^variant_[a-z0-9][a-z0-9_-]*$",
    )
    campaign_type_native: str | None = Field(default=None, min_length=1)
    campaign_type: DimensionValue
    optimization_goal_native: str | None = Field(default=None, min_length=1)
    optimization_goal: DimensionValue
    status: str = Field(min_length=1)
    objective_native: str | None = Field(default=None, min_length=1)
    daily_budget: Decimal | None = Field(default=None, ge=0, allow_inf_nan=False)
    budget_currency: str | None = Field(default=None, pattern=r"^[A-Z]{3}$")
    attribution_spec: AttributionSpec | None = None
    source_updated_at: AwareDatetime | None = None

    @model_validator(mode="after")
    def validate_entity(self) -> Self:
        if (self.daily_budget is None) != (self.budget_currency is None):
            raise ValueError("daily_budget and budget_currency must be supplied together")
        if self.entity_type is EntityType.ACCOUNT:
            if self.app_variant_id is not None:
                raise ValueError("account entities cannot select an app variant")
            if self.campaign_type.state is not DimensionState.NOT_APPLICABLE:
                raise ValueError("account campaign_type must be not_applicable")
            if self.optimization_goal.state is not DimensionState.NOT_APPLICABLE:
                raise ValueError("account optimization_goal must be not_applicable")
        return self


class CanonicalObservationRecord(ContractModel):
    entity_type: EntityType
    entity_id: str = Field(min_length=1)
    app_variant_id: str | None = Field(
        default=None,
        pattern=r"^variant_[a-z0-9][a-z0-9_-]*$",
    )
    event_date: date
    reporting_time_basis: ReportingTimeBasis = ReportingTimeBasis.UNKNOWN
    country: DimensionValue
    os: DimensionValue
    campaign_type_native: str | None = Field(default=None, min_length=1)
    campaign_type: DimensionValue
    optimization_goal_native: str | None = Field(default=None, min_length=1)
    optimization_goal: DimensionValue
    attribution_spec: AttributionSpec | None = None
    metric_key: CanonicalMetric
    metric_semantic_version: str = Field(pattern=r"^\d+\.\d+\.\d+$")
    value: Decimal = Field(ge=0, allow_inf_nan=False)
    unit: str = Field(min_length=1)
    currency: str = Field(pattern=r"^[A-Z]{3}$")
    source_timezone: str = Field(min_length=1)
    maturity_status: MaturityStatus

    @model_validator(mode="after")
    def validate_os_value(self) -> Self:
        if self.os.state is DimensionState.VALUE:
            OperatingSystem(self.os.value)
        return self


class SourceSnapshot(VersionedContract):
    source_snapshot_id: str = Field(pattern=r"^snapshot_[a-z0-9][a-z0-9_-]*$")
    package_id: str = Field(pattern=r"^import_[a-z0-9][a-z0-9_-]*$")
    data_revision: int = Field(ge=1)
    product_id: str = Field(pattern=r"^prod_[a-z0-9][a-z0-9_-]*$")
    platform: MediaPlatform
    account_id: str = Field(min_length=1)
    account_currency: str = Field(pattern=r"^[A-Z]{3}$")
    source_timezone: str = Field(min_length=1)
    import_format_version: str = Field(pattern=r"^\d+\.\d+\.\d+$")
    effective_period: DateRange
    observed_at: AwareDatetime
    content_hash: str = Field(pattern=r"^sha256:[a-f0-9]{64}$")
    response_field_inventory: list[str] = Field(default_factory=list)
    raw_path: str = Field(min_length=1)
    retention_deadline: AwareDatetime

    @model_validator(mode="after")
    def validate_inventory(self) -> Self:
        if len(self.response_field_inventory) != len(set(self.response_field_inventory)):
            raise ValueError("response field inventory must be unique")
        return self


class EntitySnapshot(VersionedContract):
    entity_snapshot_id: str = Field(pattern=r"^entity_snapshot_[a-f0-9]{16}_r\d+$")
    entity_key: str = Field(pattern=r"^entity_[a-f0-9]{32}$")
    revision: int = Field(ge=1)
    data_revision: int = Field(ge=1)
    source_snapshot_id: str = Field(pattern=r"^snapshot_[a-z0-9][a-z0-9_-]*$")
    product_id: str = Field(pattern=r"^prod_[a-z0-9][a-z0-9_-]*$")
    platform: MediaPlatform
    account_id: str = Field(min_length=1)
    observed_at: AwareDatetime
    record: CanonicalEntityRecord


class ObservationRevision(VersionedContract):
    observation_id: str = Field(pattern=r"^observation_[a-f0-9]{16}_r\d+$")
    observation_key: str = Field(pattern=r"^observation_[a-f0-9]{32}$")
    revision: int = Field(ge=1)
    data_revision: int = Field(ge=1)
    source_snapshot_id: str = Field(pattern=r"^snapshot_[a-z0-9][a-z0-9_-]*$")
    product_id: str = Field(pattern=r"^prod_[a-z0-9][a-z0-9_-]*$")
    platform: MediaPlatform
    account_id: str = Field(min_length=1)
    observed_at: AwareDatetime
    record: CanonicalObservationRecord


class CanonicalImportResult(VersionedContract):
    package_id: str = Field(pattern=r"^import_[a-z0-9][a-z0-9_-]*$")
    source_snapshot_id: str = Field(pattern=r"^snapshot_[a-z0-9][a-z0-9_-]*$")
    platform: MediaPlatform
    data_revision: int = Field(ge=1)
    snapshot_reused: bool
    entity_revisions_created: int = Field(ge=0)
    observation_revisions_created: int = Field(ge=0)
    current_entity_count: int = Field(ge=0)
    current_observation_count: int = Field(ge=0)
