"""Versioned canonical metric definitions and deterministic computation results."""

from __future__ import annotations

from decimal import Decimal
from enum import StrEnum
from typing import Literal, Self

from pydantic import Field, model_validator

from pallas_ads.contracts.base import VersionedContract
from pallas_ads.contracts.common import CanonicalDimension, CanonicalMetric


class MetricAggregation(StrEnum):
    SUM = "sum"
    RATIO_OF_SUMS = "ratio_of_sums"


class MetricUnit(StrEnum):
    COUNT = "count"
    CURRENCY = "currency"
    RATIO = "ratio"
    CURRENCY_PER_ACTION = "currency_per_action"
    CURRENCY_PER_THOUSAND = "currency_per_thousand"


class MetricDefinition(VersionedContract):
    metric_key: CanonicalMetric
    semantic_version: str = Field(pattern=r"^\d+\.\d+\.\d+$")
    aggregation: MetricAggregation
    unit: MetricUnit
    numerator_metric: CanonicalMetric | None = None
    denominator_metric: CanonicalMetric | None = None
    scale: Decimal = Field(default=Decimal(1), gt=0, allow_inf_nan=False)
    valid_grains: list[CanonicalDimension] = Field(min_length=1)
    attribution_sensitive: bool = False
    importable: bool

    @model_validator(mode="after")
    def validate_formula(self) -> Self:
        formula_parts = (self.numerator_metric, self.denominator_metric)
        if self.aggregation is MetricAggregation.SUM:
            if any(part is not None for part in formula_parts) or self.scale != 1:
                raise ValueError("sum metrics cannot declare ratio formula fields")
            if not self.importable:
                raise ValueError("sum metrics must be importable")
        else:
            if any(part is None for part in formula_parts):
                raise ValueError("ratio_of_sums metrics require numerator and denominator")
            if self.importable:
                raise ValueError("derived ratio metrics cannot be imported directly")
        if len(self.valid_grains) != len(set(self.valid_grains)):
            raise ValueError("valid_grains must be unique")
        return self


class MetricNullReason(StrEnum):
    MISSING_COMPONENTS = "missing_components"
    MISSING_NUMERATOR = "missing_numerator"
    MISSING_DENOMINATOR = "missing_denominator"
    ZERO_DENOMINATOR = "zero_denominator"


class MetricInterpretationWarning(StrEnum):
    ZERO_SPEND_WITH_OUTCOMES = "zero_spend_with_outcomes"
    POSITIVE_SPEND_WITH_ZERO_OUTCOME = "positive_spend_with_zero_outcome_value"
    BOTH_COMPONENTS_ZERO = "both_components_zero"
    UNKNOWN_REPORTING_TIME_BASIS = "unknown_reporting_time_basis"
    PERIOD_FLOW_NOT_COHORT = "period_flow_not_cohort"


class MetricComputation(VersionedContract):
    metric_key: CanonicalMetric
    semantic_version: str = Field(pattern=r"^\d+\.\d+\.\d+$")
    value: Decimal | None = Field(default=None, allow_inf_nan=False)
    unit: MetricUnit
    null_reason: MetricNullReason | None = None
    calculation_policy_version: Literal["1.1.0"] = "1.1.0"
    claim_scope: Literal["arithmetic_only"] = "arithmetic_only"
    interpretation_warnings: list[MetricInterpretationWarning] = Field(default_factory=list)

    @model_validator(mode="after")
    def validate_result(self) -> Self:
        if (self.value is None) != (self.null_reason is not None):
            raise ValueError("null metric values require exactly one null_reason")
        return self
