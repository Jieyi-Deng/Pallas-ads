"""Canonical query contract; native platform queries are intentionally excluded."""

from __future__ import annotations

from datetime import date
from typing import Self

from pydantic import AwareDatetime, Field, model_validator

from pallas_ads.contracts.base import ContractModel, VersionedContract
from pallas_ads.contracts.common import (
    CanonicalDimension,
    CanonicalMetric,
    MediaPlatform,
    ReportingTimeBasis,
)
from pallas_ads.contracts.profile import OperatingSystem


class DateRange(ContractModel):
    start: date
    end: date

    @model_validator(mode="after")
    def validate_order(self) -> Self:
        if self.end < self.start:
            raise ValueError("date range end must be on or after start")
        return self


class QueryFilters(ContractModel):
    binding_ids: list[str] = Field(default_factory=list)
    campaign_ids: list[str] = Field(default_factory=list)
    countries: list[str] = Field(default_factory=list)
    operating_systems: list[OperatingSystem] = Field(default_factory=list)

    @model_validator(mode="after")
    def validate_unique_filters(self) -> Self:
        for field_name in ("binding_ids", "campaign_ids", "countries", "operating_systems"):
            values = getattr(self, field_name)
            if len(values) != len(set(values)):
                raise ValueError(f"{field_name} filters must be unique")
        return self


class CanonicalQuery(VersionedContract):
    query_id: str = Field(pattern=r"^query_[a-z0-9][a-z0-9_-]*$")
    product_id: str = Field(pattern=r"^prod_[a-z0-9][a-z0-9_-]*$")
    period: DateRange | None = None
    baseline: DateRange | None = None
    platforms: list[MediaPlatform] = Field(min_length=1)
    metrics: list[CanonicalMetric] = Field(min_length=1)
    grain: list[CanonicalDimension] = Field(
        default_factory=lambda: [
            CanonicalDimension.CHANNEL,
            CanonicalDimension.CAMPAIGN_TYPE,
            CanonicalDimension.OPTIMIZATION_GOAL,
        ]
    )
    filters: QueryFilters = Field(default_factory=QueryFilters)
    include_provisional: bool = False
    as_of: AwareDatetime | None = None
    as_of_data_revision: int | None = Field(default=None, ge=1)
    profile_revision: int | None = Field(default=None, ge=1)
    reporting_time_bases: dict[CanonicalMetric, ReportingTimeBasis] = Field(default_factory=dict)

    @model_validator(mode="after")
    def validate_query(self) -> Self:
        if self.as_of is not None and self.as_of_data_revision is not None:
            raise ValueError("select either as_of or as_of_data_revision, not both")
        if self.baseline is not None and self.period is None:
            raise ValueError("an explicit baseline requires an explicit period")
        if self.period is not None and self.baseline is not None:
            if self.baseline.end >= self.period.start:
                raise ValueError("baseline must end before the comparison period starts")
            if self.baseline.end - self.baseline.start != self.period.end - self.period.start:
                raise ValueError("baseline and comparison period must have equal lengths")
        if not self.grain:
            raise ValueError("grain cannot be empty")
        for field_name in ("platforms", "metrics", "grain"):
            values = getattr(self, field_name)
            if len(values) != len(set(values)):
                raise ValueError(f"{field_name} must be unique")
        return self
