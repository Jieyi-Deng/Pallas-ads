"""Portable setup diagnostics and host-owned Meta login; never reads host credentials."""

import json
import re
import shutil
import ssl
import subprocess
import sys
import threading
import tomllib
from pathlib import Path

from pallas_ads.contracts.host_mcp import META_HOST_URL, META_READ_TOOLS
from pallas_ads.local_state import WorkspaceRepository
from pallas_ads.provider_setup import load_setup

META_CALLBACK = "https://localhost:8765/callback/p3oJPar44nR2"
META_PORT = 8768


def executable():
    return Path(sys.executable).absolute().with_name("pallas")


def codex_executable():
    found = shutil.which("codex")
    if found:
        return found
    for app in ("Codex", "ChatGPT"):
        candidate = Path("/Applications") / (app + ".app/Contents/Resources/codex")
        if candidate.is_file():
            return str(candidate)
    return None


def meta_config(client_id):
    if not re.fullmatch(r"[0-9]{5,32}", client_id):
        raise ValueError("Invalid Meta application ID.")
    return {
        "url": META_HOST_URL,
        "enabled": True,
        "enabled_tools": list(META_READ_TOOLS),
        "default_tools_approval_mode": "prompt",
        "oauth": {
            "client_id": client_id,
            "callback_url": META_CALLBACK,
            "callback_port": META_PORT,
        },
    }


def read_meta(directory):
    path = directory / ".codex/config.toml"
    if path.is_symlink() or path.stat().st_size > 65536:
        raise ValueError("Invalid project configuration.")
    config = tomllib.loads(path.read_text())["mcp_servers"]["meta_official"]
    # Never forward arbitrary CLI overrides, headers, endpoints or credentials from a file.
    expected = meta_config(config["oauth"]["client_id"])
    if config != expected:
        raise ValueError("Meta configuration differs from the supported project setup.")
    return expected


def certificate_paths(directory):
    root = directory / ".pallas/certs"
    return root / "localhost.pem", root / "localhost-key.pem"


def prepare_certificate(directory, *, trust=False):
    """Generate a machine-local leaf; trust changes require the explicit CLI flag."""
    if sys.platform != "darwin":
        raise ValueError("This certificate setup currently supports macOS only.")
    read_meta(directory)
    cert, key = certificate_paths(directory)
    if any(p.is_symlink() for p in (cert, key, *cert.parents)):
        raise ValueError("Certificate paths cannot be symbolic links.")
    cert.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    if cert.exists() != key.exists():
        raise ValueError("Incomplete certificate pair; existing files were preserved.")
    if not cert.exists():
        openssl = shutil.which("openssl")
        if not openssl:
            raise ValueError("OpenSSL is required for local certificate generation.")
        import tempfile

        with tempfile.TemporaryDirectory(dir=cert.parent) as temporary:
            tmp = Path(temporary)
            config = tmp / "openssl.cnf"
            config.write_text(
                "[req]\nprompt=no\ndistinguished_name=dn\nx509_extensions=server\n"
                "[dn]\nCN=localhost\n[server]\nsubjectAltName=DNS:localhost,IP:127.0.0.1\n"
                "basicConstraints=critical,CA:FALSE\nkeyUsage=critical,digitalSignature,keyEncipherment\n"
                "extendedKeyUsage=serverAuth\n"
            )
            subprocess.run(
                [
                    openssl,
                    "req",
                    "-x509",
                    "-newkey",
                    "rsa:2048",
                    "-nodes",
                    "-days",
                    "365",
                    "-config",
                    str(config),
                    "-keyout",
                    str(tmp / "key.pem"),
                    "-out",
                    str(tmp / "cert.pem"),
                ],
                check=True,
                capture_output=True,
                timeout=30,
            )
            (tmp / "key.pem").chmod(0o600)
            (tmp / "cert.pem").chmod(0o600)
            # Exclusive publish, never replace another installation's files.
            for source, target in ((tmp / "key.pem", key), (tmp / "cert.pem", cert)):
                with target.open("xb") as handle:
                    target.chmod(0o600)
                    handle.write(source.read_bytes())
    context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    context.load_cert_chain(cert, key)
    if trust:
        # Current user's trust store only; no sudo, system root CA or shared private key.
        subprocess.run(
            [
                "/usr/bin/security",
                "add-trusted-cert",
                "-r",
                "trustRoot",
                "-p",
                "ssl",
                "-s",
                "localhost",
                "-k",
                str(Path.home() / "Library/Keychains/login.keychain-db"),
                str(cert),
            ],
            check=True,
            capture_output=True,
            timeout=120,
        )
    return {
        "certificate_created": True,
        "trust_requested": trust,
        "callback_url": META_CALLBACK,
        "browser_trust": "requires_browser_verification",
    }


def login_meta(directory):
    config = read_meta(directory)
    codex = codex_executable()
    if codex is None:
        raise ValueError("Codex CLI must be available on PATH.")
    cert, key = certificate_paths(directory)
    from pallas_ads.codex_https_callback import make_server

    # Codex 0.146 reads only the global callback fields and appends its callback ID.
    # Newer clients use the per-server full URL below. Keep this fallback local to
    # this subprocess: never change the user's global callback for other servers.
    overrides = [
        "-c",
        "mcp_oauth_callback_url=" + json.dumps(META_CALLBACK.rsplit("/", 1)[0]),
        "-c",
        f"mcp_oauth_callback_port={META_PORT}",
    ]
    for name, value in config.items():
        items = value.items() if isinstance(value, dict) else [(None, value)]
        for child, item in items:
            field = name + "." + child if child else name
            overrides.extend(["-c", "mcp_servers.meta_official." + field + "=" + json.dumps(item)])
    with make_server(META_CALLBACK, META_PORT, cert, key) as server:
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        try:
            # The official CLI opens consent and stores tokens. No capture or token inspection.
            return subprocess.call(
                [
                    codex,
                    "mcp",
                    "login",
                    "meta_official",
                    "--scopes",
                    "ads_read,ads_mcp_management",
                    *overrides,
                ],
                cwd=directory,
            )
        finally:
            server.shutdown()
            thread.join(timeout=5)


def doctor(directory, *, media="core"):
    """Offline diagnostics: presence is not a live authorization/permission claim."""
    directory = directory.absolute()
    if media not in ("core", "google", "meta", "tiktok", "all"):
        raise ValueError("Choose core, google, meta, tiktok or all.")
    rows = []

    def add(name, status, detail):
        rows.append({"check": name, "status": status, "detail": detail})

    repo = WorkspaceRepository(directory / ".pallas")
    try:
        manifest = repo.load_manifest()
        add("workspace", "ready", f"Product count: {len(manifest.profile_ids)}")
    except (OSError, ValueError):
        add("workspace", "blocked", "Run agent setup in a fresh project.")
    try:
        if (directory / ".codex/config.toml").is_file():
            config = tomllib.loads((directory / ".codex/config.toml").read_text())
            local = config["mcp_servers"]["pallas"]
            skills = directory / ".agents/skills"
        else:
            config = json.loads((directory / ".mcp.json").read_text())
            local = config["mcpServers"]["pallas"]
            skills = directory / ".claude/skills"
        ready = Path(local["command"]).is_file() and local["args"] == [
            "mcp",
            "serve",
            "--workspace",
            str(directory / ".pallas"),
        ]
        add(
            "local_mcp",
            "ready" if ready else "blocked",
            "Installed command/workspace check; host tool loading still needs verification.",
        )
        present = all(
            (skills / name / "SKILL.md").is_file()
            for name in ("pallas-workflow", "pallas-analysis")
        )
        add(
            "local_skills",
            "ready" if present else "blocked",
            "Project workflow and analysis skills.",
        )
    except (OSError, ValueError, KeyError, TypeError):
        add("local_mcp", "blocked", "Invalid or missing Pallas project configuration.")
    try:
        google = next((c for c in load_setup(repo).connections if c.platform == "google"), None)
        add(
            "google_application",
            "configured" if google else "blocked",
            "Application configured; user authorization and Cloud access unverified."
            if google
            else "Install the configured official wheel; do not ask users for JSON or tokens.",
        )
    except (OSError, ValueError):
        add("google_application", "blocked", "Invalid operator application configuration.")
    add(
        "tiktok_application",
        "ready",
        "Official MCP default; live consent/account access unverified.",
    )
    if (directory / ".codex/config.toml").is_file():
        add(
            "codex_cli",
            "ready" if codex_executable() else "blocked",
            "Codex CLI is needed for host login; desktop tool loading must be tested separately.",
        )
        try:
            read_meta(directory)
            cert, key = certificate_paths(directory)
            ready = cert.is_file() and key.is_file()
            add(
                "meta_application",
                "configured",
                "Pre-registered client; provider eligibility unverified.",
            )
            add(
                "meta_certificate",
                "configured" if ready else "blocked",
                "Browser trust unverified."
                if ready
                else "Run agent prepare-meta --trust-local-certificate.",
            )
        except (OSError, ValueError, KeyError, TypeError):
            add("meta_application", "blocked", "Set up with the operator's --meta-client-id.")
    elif (directory / ".mcp.json").is_file():
        add("meta_application", "host_managed", "Authenticate in Claude Code; access unverified.")
    else:
        add("agent_config", "blocked", "No project MCP configuration found.")
    add("live_authorization", "not_tested", "No browser opened, token read, or media request sent.")
    for row in rows:
        optional = (
            row["check"].startswith(("google_", "meta_", "tiktok_")) or row["check"] == "codex_cli"
        )
        requested = (
            media == "all"
            or row["check"].startswith(media + "_")
            or media == "meta"
            and row["check"] == "codex_cli"
        )
        row["required"] = not optional or requested
        if optional and not requested and row["status"] == "blocked":
            row["status"] = "optional_unavailable"
    return {
        "mode": media,
        "status": "blocked"
        if any(r["status"] == "blocked" for r in rows)
        else "ready_for_local_analysis"
        if media == "core"
        else "ready_for_live_test",
        "checks": rows,
        "credentials_inspected": False,
    }
