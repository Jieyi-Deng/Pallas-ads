"""Observed traffic arithmetic; never a claim of dense, mature or comparable coverage."""

from collections import defaultdict
from decimal import Decimal, localcontext

from pallas_ads.contracts.sync import TrafficAnalysis, TrafficSlice
from pallas_ads.metric_registry import MetricRegistry


def analyze_traffic(read, currency, timezone):
    groups = defaultdict(list)
    for record in read.records:
        groups[("total", "observed")].append(record)
        groups[("campaign", record.entity_id)].append(record)
        groups[("day", record.event_date.isoformat())].append(record)
    registry = MetricRegistry()
    slices = []
    for (grain, key), rows in sorted(groups.items()):
        components = {}
        missing = []
        for metric in ("spend", "impressions", "clicks"):
            values = [r.values.get(metric) for r in rows]
            if any(v is None for v in values):
                missing.append(metric)
            else:
                # Preserve source decimal precision during addition; ratios use registry policy.
                with localcontext() as context:
                    context.prec = max(
                        38,
                        sum(len(v.as_tuple().digits) + abs(v.as_tuple().exponent) for v in values)
                        + 10,
                    )
                    components[metric] = sum(values, Decimal(0))
        slices.append(
            TrafficSlice(
                grain=grain,
                key=key,
                observed_rows=len(rows),
                observed_dates=sorted({r.event_date for r in rows}),
                missing_components=missing,
                metrics=[
                    registry.compute(m, components)
                    for m in ("spend", "impressions", "clicks", "ctr", "cpc", "cpm")
                ],
            )
        )
    return TrafficAnalysis(
        read_id=read.read_id,
        period=read.plan.request.period,
        currency=currency,
        source_timezone=timezone,
        slices=slices,
        warnings=[
            "observed_rows_only",
            "missing_days_are_not_zero",
            "maturity_unverified",
            "no_canonical_outcome_mapping",
            "no_performance_ranking",
        ],
    )
