"""Atomic DuckDB monitor runs, materialized incidents and immutable audit history."""

from __future__ import annotations

import json
from datetime import UTC, datetime
from typing import Any

import duckdb
from pydantic import BaseModel

from pallas_ads.contracts.monitor import (
    MonitorDefinition,
    MonitorEvent,
    MonitorRun,
    MonitorTransition,
    SourceHealthObservation,
)
from pallas_ads.local_state import WorkspaceRepository
from pallas_ads.query_planner import content_hash

MONITOR_SCHEMA_STATEMENTS = (
    "CREATE TABLE IF NOT EXISTS monitor_definitions "
    "(monitor_id VARCHAR, version INTEGER, payload VARCHAR NOT NULL, "
    "PRIMARY KEY (monitor_id, version))",
    "CREATE TABLE IF NOT EXISTS source_health_observations "
    "(health_id VARCHAR PRIMARY KEY, payload VARCHAR NOT NULL)",
    "CREATE TABLE IF NOT EXISTS monitor_runs "
    "(run_id VARCHAR PRIMARY KEY, definition_hash VARCHAR, data_revision BIGINT, "
    "evaluated_at TIMESTAMPTZ, payload VARCHAR NOT NULL)",
    "CREATE TABLE IF NOT EXISTS monitor_events "
    "(event_id VARCHAR PRIMARY KEY, product_id VARCHAR, payload VARCHAR NOT NULL)",
    "CREATE TABLE IF NOT EXISTS monitor_actions "
    "(action_id VARCHAR PRIMARY KEY, request_hash VARCHAR, payload VARCHAR NOT NULL)",
)


class MonitorStateError(RuntimeError):
    """Invalid or unavailable local monitoring state; never repair by overwriting history."""


def _encode(model: BaseModel) -> str:
    payload = model.model_dump(mode="json")
    return json.dumps({"payload": payload, "hash": content_hash(payload)}, sort_keys=True)


def _decode[ModelT: BaseModel](raw: str, model: type[ModelT]) -> ModelT:
    try:
        envelope = json.loads(raw)
        if content_hash(envelope["payload"]) != envelope["hash"]:
            raise MonitorStateError("monitor state hash mismatch")
        return model.model_validate(envelope["payload"])
    except (ValueError, KeyError, TypeError) as error:
        raise MonitorStateError("monitor state is invalid") from error


class MonitorRepository:
    def __init__(self, workspace: WorkspaceRepository) -> None:
        self.database = str(workspace.layout.database_file)

    def save_definition(self, definition: MonitorDefinition) -> None:
        with duckdb.connect(self.database) as connection:
            row = connection.execute(
                "SELECT payload FROM monitor_definitions WHERE monitor_id = ? AND version = ?",
                [definition.monitor_id, definition.version],
            ).fetchone()
            if row is not None:
                if _decode(row[0], MonitorDefinition) != definition:
                    raise MonitorStateError("monitor version already exists with different content")
                return
            connection.execute(
                "INSERT INTO monitor_definitions VALUES (?, ?, ?)",
                [
                    definition.monitor_id,
                    definition.version,
                    _encode(definition),
                ],
            )

    def save_health(self, observation: SourceHealthObservation) -> None:
        with duckdb.connect(self.database) as connection:
            row = connection.execute(
                "SELECT payload FROM source_health_observations WHERE health_id = ?",
                [observation.health_id],
            ).fetchone()
            if row is not None:
                if _decode(row[0], SourceHealthObservation) != observation:
                    raise MonitorStateError("health ID already exists with different content")
                return
            connection.execute(
                "INSERT INTO source_health_observations VALUES (?, ?)",
                [
                    observation.health_id,
                    _encode(observation),
                ],
            )

    def health(self) -> list[SourceHealthObservation]:
        with duckdb.connect(self.database, read_only=True) as connection:
            rows = connection.execute(
                "SELECT payload FROM source_health_observations ORDER BY health_id"
            ).fetchall()
        return [_decode(row[0], SourceHealthObservation) for row in rows]

    def get_run(self, run_id: str) -> MonitorRun | None:
        with duckdb.connect(self.database, read_only=True) as connection:
            row = connection.execute(
                "SELECT payload FROM monitor_runs WHERE run_id = ?", [run_id]
            ).fetchone()
        return _decode(row[0], MonitorRun) if row else None

    def events(self, product_id: str) -> list[MonitorEvent]:
        with duckdb.connect(self.database, read_only=True) as connection:
            rows = connection.execute(
                "SELECT payload FROM monitor_events WHERE product_id = ? ORDER BY event_id",
                [product_id],
            ).fetchall()
        return [_decode(row[0], MonitorEvent) for row in rows]

    def publish(self, run: MonitorRun) -> MonitorRun:
        """Commit evaluation, event updates and their transition histories together."""
        with duckdb.connect(self.database) as connection:
            connection.execute("BEGIN TRANSACTION")
            try:
                previous = connection.execute(
                    "SELECT payload FROM monitor_runs WHERE run_id = ?", [run.run_id]
                ).fetchone()
                if previous:
                    connection.execute("ROLLBACK")
                    return _decode(previous[0], MonitorRun)
                cursor = connection.execute(
                    "SELECT data_revision, epoch_us(evaluated_at) FROM monitor_runs "
                    "WHERE definition_hash = ? "
                    "ORDER BY data_revision DESC, evaluated_at DESC LIMIT 1",
                    [run.definition_hash],
                ).fetchone()
                if cursor and (
                    run.data_revision < cursor[0]
                    or run.evaluated_at < datetime.fromtimestamp(cursor[1] / 1_000_000, tz=UTC)
                ):
                    raise MonitorStateError("out-of-order run cannot mutate current incidents")
                for evaluation in run.evaluations:
                    key = content_hash(
                        [
                            run.definition_hash,
                            run.definition.query.product_id,
                            evaluation.scope_key,
                            evaluation.period_key,
                        ]
                    )
                    event_id = "event_" + key[7:]
                    row = connection.execute(
                        "SELECT payload FROM monitor_events WHERE event_id = ?", [event_id]
                    ).fetchone()
                    event = _decode(row[0], MonitorEvent) if row else None
                    if event is not None and run.evaluated_at < event.transitions[-1].at:
                        raise MonitorStateError("run predates the latest incident transition")
                    if (
                        event is not None
                        and event.state == "resolved"
                        and run.definition.family != "data_health"
                        and run.data_revision <= event.last_data_revision
                    ):
                        # A policy/profile reevaluation of the same data cannot re-open
                        # a manually resolved incident. A later data revision is required.
                        run.events.append(event)
                        continue
                    if evaluation.outcome == "breach":
                        if event is None:
                            event = MonitorEvent(
                                event_id=event_id,
                                deduplication_key=key,
                                definition_hash=run.definition_hash,
                                monitor_id=run.definition.monitor_id,
                                product_id=run.definition.query.product_id,
                                scope_key=evaluation.scope_key,
                                period_key=evaluation.period_key,
                                state="detected",
                                severity=evaluation.severity,
                                first_seen_at=run.evaluated_at,
                                last_seen_at=run.evaluated_at,
                                last_data_revision=run.data_revision,
                                occurrence_count=1,
                                latest_evaluation=evaluation,
                                transitions=[
                                    MonitorTransition(
                                        from_state=None,
                                        to_state="detected",
                                        at=run.evaluated_at,
                                        data_revision=run.data_revision,
                                        trigger_ref=run.run_id,
                                        reason=evaluation.reason,
                                    )
                                ],
                            )
                        else:
                            event.occurrence_count += 1
                            event.last_seen_at = run.evaluated_at
                            event.last_data_revision = run.data_revision
                            event.latest_evaluation = evaluation
                            event.severity = evaluation.severity
                        if event.state in ("detected", "resolved"):
                            event = _transition(
                                event,
                                "open",
                                run.evaluated_at,
                                run.data_revision,
                                run.run_id,
                                evaluation.reason,
                            )
                    elif evaluation.outcome == "healthy" and evaluation.auto_resolve and event:
                        if event.state != "resolved":
                            event.latest_evaluation = evaluation
                            event = _transition(
                                event,
                                "resolved",
                                run.evaluated_at,
                                run.data_revision,
                                run.run_id,
                                "condition_cleared_with_valid_evidence",
                            )
                    if event:
                        connection.execute(
                            "INSERT OR REPLACE INTO monitor_events VALUES (?, ?, ?)",
                            [event.event_id, event.product_id, _encode(event)],
                        )
                        run.events.append(event)
                connection.execute(
                    "INSERT INTO monitor_runs VALUES (?, ?, ?, ?, ?)",
                    [
                        run.run_id,
                        run.definition_hash,
                        run.data_revision,
                        run.evaluated_at,
                        _encode(run),
                    ],
                )
                connection.execute("COMMIT")
                return run
            except Exception:
                connection.execute("ROLLBACK")
                raise

    def transition(
        self,
        event_id: str,
        *,
        action_id: str,
        state: str,
        reason: str,
        at: datetime,
        data_revision: int,
    ) -> MonitorEvent:
        request: dict[str, Any] = dict(
            event_id=event_id,
            action_id=action_id,
            state=state,
            reason=reason,
            at=at.isoformat(),
            data_revision=data_revision,
        )
        request_hash = content_hash(request)
        with duckdb.connect(self.database) as connection:
            connection.execute("BEGIN TRANSACTION")
            try:
                row = connection.execute(
                    "SELECT request_hash, payload FROM monitor_actions WHERE action_id = ?",
                    [action_id],
                ).fetchone()
                if row:
                    if row[0] != request_hash:
                        raise MonitorStateError("action ID already exists with different content")
                    connection.execute("ROLLBACK")
                    return _decode(row[1], MonitorEvent)
                row = connection.execute(
                    "SELECT payload FROM monitor_events WHERE event_id = ?", [event_id]
                ).fetchone()
                if not row:
                    raise MonitorStateError("monitor event does not exist")
                event = _decode(row[0], MonitorEvent)
                if at < event.transitions[-1].at or data_revision < event.last_data_revision:
                    raise MonitorStateError("transition cannot move incident history backwards")
                if state == "acknowledged" and event.state not in ("open", "acknowledged"):
                    raise MonitorStateError("only open events may be acknowledged")
                if state not in ("acknowledged", "resolved"):
                    raise MonitorStateError("manual transitions only acknowledge or resolve")
                if state != event.state:
                    event = _transition(event, state, at, data_revision, action_id, reason)
                connection.execute(
                    "UPDATE monitor_events SET payload = ? WHERE event_id = ?",
                    [
                        _encode(event),
                        event_id,
                    ],
                )
                connection.execute(
                    "INSERT INTO monitor_actions VALUES (?, ?, ?)",
                    [
                        action_id,
                        request_hash,
                        _encode(event),
                    ],
                )
                connection.execute("COMMIT")
                return event
            except Exception:
                connection.execute("ROLLBACK")
                raise


def _transition(
    event: MonitorEvent,
    state: Any,
    at: datetime,
    data_revision: int,
    trigger: str,
    reason: str,
) -> MonitorEvent:
    event.transitions.append(
        MonitorTransition(
            from_state=event.state,
            to_state=state,
            at=at,
            data_revision=data_revision,
            trigger_ref=trigger,
            reason=reason,
        )
    )
    # State and resolution metadata change as one validated object, not invalid interim assignments.
    updated = MonitorEvent.model_validate(
        {
            **event.model_dump(mode="json"),
            "state": state,
            "last_data_revision": data_revision,
            "resolution_reason": reason if state == "resolved" else None,
        }
    )
    return updated
