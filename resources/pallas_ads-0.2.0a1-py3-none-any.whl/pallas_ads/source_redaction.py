"""Redact source/auth material before public validation and raw-data retention."""

from __future__ import annotations

from decimal import Decimal
from urllib.parse import parse_qsl, urlsplit

from pallas_ads.contracts.base import reject_secret_material

SENSITIVE = {
    "code",
    "auth_code",
    "access_token",
    "refresh_token",
    "secret",
    "client_secret",
    "authorization",
    "password",
    "api_key",
    "token",
    "private_key",
    "appsecret_proof",
    "developer_token",
    "code_verifier",
    "state",
    "signed_request",
}


def redact(value, known_secrets: tuple[str, ...] = ()):
    if isinstance(value, dict):
        result = {}
        for key, child in value.items():
            normalized = str(key).lower().replace("-", "_")
            if (
                normalized in SENSITIVE and not (normalized == "code" and type(child) is int)
            ) or normalized.endswith(("_token", "_secret", "_api_key")):
                continue
            # Key names can also contain hostile strings; never reflect credential values there.
            safe_key = str(key)
            if any(secret and secret in safe_key for secret in known_secrets):
                continue
            result[safe_key] = redact(child, known_secrets)
        return result
    if isinstance(value, list):
        return [redact(item, known_secrets) for item in value]
    if isinstance(value, str):
        if any(secret and secret in value for secret in known_secrets):
            return "[REDACTED]"
        try:
            reject_secret_material(value)
            if value.startswith(("https://", "http://")) and any(
                k.lower() in SENSITIVE for k, _ in parse_qsl(urlsplit(value).query)
            ):
                return "[REDACTED]"
        except ValueError:
            return "[REDACTED]"
    if isinstance(value, Decimal):
        return str(value)
    return value
