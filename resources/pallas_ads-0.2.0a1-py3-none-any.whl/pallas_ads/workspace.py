"""Declarative local workspace layout; directory creation begins in Week 2."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True, slots=True)
class WorkspaceLayout:
    """Canonical paths below one user-controlled Pallas workspace root."""

    root: Path

    @property
    def workspace_file(self) -> Path:
        return self.root / "workspace.yaml"

    @property
    def profiles_dir(self) -> Path:
        return self.root / "profiles"

    @property
    def source_manifests_dir(self) -> Path:
        return self.root / "manifests" / "sources"

    @property
    def adapter_manifests_dir(self) -> Path:
        return self.root / "manifests" / "adapters"

    @property
    def database_file(self) -> Path:
        return self.root / "data" / "pallas.duckdb"

    @property
    def raw_data_dir(self) -> Path:
        return self.root / "data" / "raw"

    @property
    def reports_dir(self) -> Path:
        return self.root / "reports"

    @property
    def logs_dir(self) -> Path:
        return self.root / "logs"

    def profile_file(self, profile_id: str) -> Path:
        return self.profiles_dir / f"{profile_id}.yaml"
