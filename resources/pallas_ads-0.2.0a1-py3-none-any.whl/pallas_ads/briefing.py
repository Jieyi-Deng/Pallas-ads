"""One plain-text briefing model shared by agent guidance and both report renderers."""

from __future__ import annotations

import json
from decimal import Decimal, InvalidOperation, localcontext

from pallas_ads.analysis_service import validate_draft
from pallas_ads.contracts.analysis import MetricAggregate
from pallas_ads.contracts.common import TRAFFIC_METRICS
from pallas_ads.contracts.delivery import (
    AgentAnalysisContract,
    AgentAnalysisDraft,
    BriefingDocument,
    BriefingSection,
    BriefingTable,
)
from pallas_ads.contracts.evidence import EvidenceItem

METRICS = {
    "spend": "花费",
    "impressions": "展示",
    "clicks": "点击",
    "installs": "安装",
    "cpm": "CPM",
    "ctr": "CTR",
    "cpc": "CPC",
    "cpi": "CPI",
    "cpa_purchase_event": "购买事件 CPA",
    "cpa_optimization_event": "优化事件 CPA",
    "media_iap_roas": "媒体 IAP ROAS",
    "purchase_event_count": "购买事件数",
    "optimization_event_count": "优化事件数",
    "platform_attributed_iap_revenue": "媒体归因 IAP 收入",
}
PLATFORMS = {"meta": "Meta", "tiktok": "TikTok", "google": "Google"}
STATUSES = {
    "strictly_comparable": "严格可比",
    "directionally_comparable": "方向性可比",
    "not_comparable": "不可比",
    "insufficient_evidence": "证据不足",
    "detected": "已发现",
    "open": "待处理",
    "acknowledged": "已确认",
    "resolved": "已关闭",
    "breach": "触发",
    "healthy": "正常",
    "unknown": "无法评估",
}


def number(value: object, *, percent: bool = False) -> str:
    if value is None:
        return "—（无值）"
    try:
        result = Decimal(str(value))
        if not result.is_finite():
            return "—（非有限值）"
        if percent:
            with localcontext() as context:
                context.prec = max(context.prec, len(result.as_tuple().digits) + 2)
                result *= 100
        # Exact decimal display: no float conversion, rounding, or lost fractional credit.
        text = format(result, "f")
        if "." in text:
            text = text.rstrip("0").rstrip(".")
        return text + ("%" if percent else "")
    except InvalidOperation:
        return str(value)


def metric_value(value: object, metric: str, unit: str | None) -> str:
    if value is None:
        return number(value)
    if metric == "ctr":
        return number(value, percent=True)
    return number(value) + (f" {unit}" if unit and unit not in ("count", "ratio") else "")


def _json(value: object) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True)


def _aggregate(fact: EvidenceItem) -> MetricAggregate | None:
    if "aggregate_id" not in fact.details:
        return None
    return MetricAggregate.model_validate(fact.details)


def _scope(item: MetricAggregate) -> str:
    dimensions = item.dimensions
    parts = [PLATFORMS.get(item.platform, item.platform)]
    parts.extend(
        str(dimensions[k])
        for k in (
            "campaign_type",
            "optimization_goal",
            "campaign_id",
            "country",
            "os",
            "event_date",
        )
        if k in dimensions
    )
    return " · ".join(parts)


def _table(title: str, columns: list[str], rows: list[list[str]]) -> BriefingTable:
    return BriefingTable(title=title, columns=columns, rows=rows)


def build_document(contract: AgentAnalysisContract, draft: AgentAnalysisDraft) -> BriefingDocument:
    validate_draft(contract, draft)
    bundle = contract.evidence
    packet = bundle.comparison.packet
    plan = bundle.comparison.plan
    facts = packet.verified_facts
    aggregates = {f.evidence_id: _aggregate(f) for f in facts}
    labels = {a.scope_key: _scope(a) for a in aggregates.values() if a is not None}
    refs = {fact.evidence_id: f"F{i:02d}" for i, fact in enumerate(facts, 1)}
    cmp_refs = {c.comparison_id: f"C{i:02d}" for i, c in enumerate(packet.comparisons, 1)}
    readable_refs = {
        **refs,
        **cmp_refs,
        packet.packet_id: "主证据包",
        **{run.run_id: f"M{i:02d}" for i, run in enumerate(bundle.monitor_runs, 1)},
    }
    partial = bool(packet.missing_inputs) or any(
        e.outcome == "unknown" for run in bundle.monitor_runs for e in run.evaluations
    )
    status = "partial_result" if partial else "complete"
    scope = BriefingSection(
        section_id="scope",
        title="范围与数据状态",
        paragraphs=[
            f"当前期 {plan.period.start} 至 {plan.period.end}；"
            f"基线 {plan.baseline.start} 至 {plan.baseline.end}。",
            f"档案修订 {plan.profile_revision} · 数据修订 {plan.data_revision}。"
            + (
                "存在缺失输入或无法评估的监控范围。"
                if partial
                else "证据已生成；不代表所有指标均可比较。"
            ),
            f"结果证据门槛：{plan.evidence_policy.calibration}（{plan.evidence_policy.version}）。"
            "Synthetic 门槛不是生产默认值；导入数据不代表真实 Adapter 已通过对账。",
            "保留来源币种和来源日期边界；不同语义组不合成总分，也不宣布整体优胜渠道。",
        ],
    )
    scope.tables.append(
        _table(
            "来源与观测时点",
            ["媒体", "账户", "币种 / 时区", "来源观测时间", "有效范围"],
            [
                [
                    PLATFORMS.get(s.platform, s.platform),
                    s.account_id,
                    f"{s.account_currency} / {s.source_timezone}",
                    s.observed_at.isoformat(),
                    f"{s.effective_period.start} → {s.effective_period.end}",
                ]
                for source in plan.sources
                for s in source.snapshots
            ],
        )
    )
    highlighted = BriefingSection(section_id="facts", title="事实与重点变化")
    selected = set(draft.highlighted_claim_ids)
    for claim in packet.allowed_claims:
        if claim.claim_id not in selected:
            continue
        text = claim.statement
        if len(claim.evidence_refs) == 1:
            fact = next(f for f in facts if f.evidence_id == claim.evidence_refs[0])
            item = aggregates[fact.evidence_id]
            if item is not None:
                window = "当前期" if item.window == "current" else "基线"
                value = metric_value(fact.value, item.metric, fact.unit)
                text = (
                    f"{_scope(item)}：{window}{METRICS.get(item.metric, item.metric)}为 {value}。"
                )
                text += "完整观测范围。" if item.complete else "仅为部分观测范围。"
                text += "暂定数据。" if item.provisional else "成熟度按来源证据。"
                text += "这是带限定条件的算术结果，不代表整体优胜或因果关系。"
                reasons = sorted(
                    set(
                        item.reasons
                        + item.evidence_sufficiency_reasons
                        + [w.value for w in item.computation.interpretation_warnings]
                    )
                )
                if reasons:
                    text += " 限定条件：" + "; ".join(reasons)
        for key, label in labels.items():
            text = text.replace(key, label)
        highlighted.paragraphs.append(
            text + " [" + ", ".join(refs[r] for r in claim.evidence_refs) + "]"
        )
    if not highlighted.paragraphs:
        highlighted.paragraphs.append("未选择额外强调的结论；完整观测值、变化和限定条件列于下方。")
    comparisons = BriefingSection(
        section_id="comparisons",
        title="跨媒体比较与周期变化",
        paragraphs=[
            "跨媒体项只按各指标的可比性解读；周期变化为当期相对基线。"
            "不可比或证据不足的点估计不构成比较结论，方向性结果必须保留限定条件。",
        ],
    )
    for kind, title in (("cross_source", "跨媒体比较"), ("period_change", "周期变化 / 趋势")):
        rows = []
        for cell in packet.comparisons:
            if cell.comparison_type != kind:
                continue
            rows.append(
                [
                    cmp_refs[cell.comparison_id],
                    METRICS.get(cell.metric, cell.metric),
                    labels.get(cell.left_scope, cell.left_scope),
                    metric_value(cell.left_value, cell.metric, cell.left_unit),
                    labels.get(cell.right_scope, cell.right_scope),
                    metric_value(cell.right_value, cell.metric, cell.right_unit),
                    (
                        number(cell.delta_relative, percent=True)
                        if cell.status == "strictly_comparable"
                        or (
                            cell.status == "directionally_comparable"
                            and cell.metric in TRAFFIC_METRICS
                        )
                        else "—（不授权变化结论）"
                    )
                    if kind == "period_change"
                    else "不适用",
                    STATUSES[cell.status],
                    "; ".join(cell.reasons) or "语义与适用证据门槛通过",
                    ", ".join(refs[r] for r in cell.evidence_refs),
                ]
            )
        comparisons.tables.append(
            _table(
                title,
                [
                    "引用",
                    "指标",
                    "左侧范围（当前期）" if kind == "cross_source" else "当前范围",
                    "左值" if kind == "cross_source" else "当前值",
                    "右侧范围（当前期）" if kind == "cross_source" else "基线范围",
                    "右值" if kind == "cross_source" else "基线值",
                    "相对变化",
                    "可比性",
                    "限定条件",
                    "证据",
                ],
                rows,
            )
        )
    if not packet.comparisons:
        comparisons.paragraphs.append("没有可用比较单元；不能从缺失比较推断持平或胜负。")
    channels = BriefingSection(section_id="channels", title="各媒体独立表现")
    for platform in plan.query.platforms:
        rows = []
        for fact in facts:
            item = aggregates[fact.evidence_id]
            if item is None or item.platform != platform:
                continue
            warnings = list(item.reasons) + list(item.evidence_sufficiency_reasons)
            warnings += [w.value for w in item.computation.interpretation_warnings]
            if item.computation.null_reason:
                warnings.append(item.computation.null_reason.value)
            rows.append(
                [
                    refs[fact.evidence_id],
                    _scope(item),
                    "当前期" if item.window == "current" else "基线",
                    METRICS.get(item.metric, item.metric),
                    metric_value(fact.value, item.metric, fact.unit),
                    "完整" if item.complete else "部分数据",
                    "暂定" if item.provisional else "成熟",
                    "; ".join(sorted(set(warnings))) or "无附加警告",
                ]
            )
        channels.tables.append(
            _table(
                PLATFORMS.get(platform, platform),
                ["引用", "范围", "窗口", "指标", "观测值", "覆盖", "成熟度", "限定条件"],
                rows,
            )
        )
        if not rows:
            channels.paragraphs.append(
                f"{PLATFORMS.get(platform, platform)} 无匹配指标观测，不能补零。"
            )
    other = [f for f in facts if aggregates[f.evidence_id] is None]
    if other:
        channels.tables.append(
            _table(
                "其他来源事实",
                ["引用", "事实", "值"],
                [[refs[f.evidence_id], f.statement, _json(f.value)] for f in other],
            )
        )
    monitors = BriefingSection(
        section_id="monitors",
        title="监控事件与历史",
        paragraphs=[
            "以下为所选运行时保存的快照，不表示当前实时状态。配置和健康检查使用各自的修订/观测时间，"
            "不等同于报表期内的投放事实；没有提供运行也不等于没有事件。",
        ],
    )
    if not bundle.monitor_runs:
        monitors.paragraphs.append("本次未附监控运行，监控状态未评估。")
    for index, run in enumerate(bundle.monitor_runs, 1):
        monitors.paragraphs.append(
            f"M{index:02d} · {run.definition.name} · {run.definition.family} · "
            f"{run.evaluated_at.isoformat()} · data revision {run.data_revision} · "
            f"rule calibration {run.definition.calibration}"
        )
        rule = run.definition
        if rule.metric:
            monitors.paragraphs.append(
                f"指标：{METRICS.get(rule.metric, rule.metric)}；方向：{rule.direction}；"
                f"相对变化阈值：{number(rule.relative_threshold, percent=True)}；"
                f"严重阈值：{number(rule.critical_relative_threshold, percent=True)}。"
                "stop 规则检查停止投放，不使用相对阈值。"
            )
        monitor_cells = {
            c.left_scope: c
            for retained in bundle.monitor_comparisons
            if retained.packet.packet_id == run.packet_id
            for c in retained.packet.comparisons
            if c.comparison_type == "period_change"
        }
        evaluation_rows = []
        for evaluation in run.evaluations:
            cell = monitor_cells.get(evaluation.scope_key)
            current, baseline = evaluation.current, evaluation.baseline
            if cell is not None:
                display_current = metric_value(current, cell.metric, cell.left_unit)
                display_baseline = metric_value(baseline, cell.metric, cell.right_unit)
            else:
                display_current = current if isinstance(current, str) else _json(current)
                display_baseline = baseline if isinstance(baseline, str) else _json(baseline)
                if evaluation.scope_key.endswith("/freshness") and current is not None:
                    display_current += " 秒"
            evaluation_rows.append(
                [
                    labels.get(evaluation.scope_key, evaluation.scope_key),
                    STATUSES[evaluation.outcome],
                    display_current if current is not None else "—（无值）",
                    display_baseline if baseline is not None else "—（无值）",
                    evaluation.reason,
                ]
            )
        monitors.tables.append(
            _table(
                f"M{index:02d} 评估",
                ["范围", "状态", "当前", "基线", "原因"],
                evaluation_rows,
            )
        )
        monitors.tables.append(
            _table(
                f"M{index:02d} 事件历史",
                ["事件", "状态 / 严重度", "首次 / 最近发现", "发现次数", "状态历史", "关闭原因"],
                [
                    [
                        f"M{index:02d}.E{j:02d}",
                        f"{STATUSES[e.state]} / {e.severity}",
                        f"{e.first_seen_at.isoformat()} / {e.last_seen_at.isoformat()}",
                        str(e.occurrence_count),
                        " → ".join(
                            f"{STATUSES[t.to_state]} [r{t.data_revision}, {t.at.isoformat()}]"
                            for t in e.transitions
                        ),
                        e.resolution_reason or "—",
                    ]
                    for j, e in enumerate(run.events, 1)
                ],
            )
        )
        if run.warnings:
            monitors.paragraphs.append("运行警告：" + "; ".join(run.warnings))
        if not run.events:
            monitors.paragraphs.append("此运行没有关联事件；请结合评估结果区分正常与无法评估。")
    hypotheses = BriefingSection(
        section_id="hypotheses",
        title="假设与待验证解释",
        paragraphs=[
            "本节仅包含所选的证据支持候选解释，不是已验证事实或因果诊断。",
        ],
    )
    options = {o.option_id: o for o in contract.options}
    for key in draft.hypothesis_ids:
        option = options[key]
        hypotheses.paragraphs.append(
            option.statement
            + " 核查："
            + option.verification_step
            + " 引用："
            + ", ".join(readable_refs.get(ref, ref) for ref in option.evidence_refs)
        )
    if not draft.hypothesis_ids:
        hypotheses.paragraphs.append("未选择假设，当前证据不用于推断变化根因。")
    unknowns = BriefingSection(section_id="unknowns", title="未知、警告与建议检查")
    unknowns.tables.append(
        _table(
            "全部数据警告",
            ["代码", "说明", "影响证据"],
            [
                [w.code, w.message, ", ".join(refs[r] for r in w.affected_evidence_refs)]
                for w in packet.warnings
            ],
        )
    )
    unknowns.tables.append(
        _table(
            "缺失输入",
            ["范围", "原因", "需要"],
            [[m.field_path, m.reason, m.expected_type or "见原因"] for m in packet.missing_inputs],
        )
    )
    unknowns.tables.append(
        _table(
            "证据不足",
            ["对象", "原因", "需要的证据"],
            [
                [cmp_refs.get(i.subject, i.subject), i.reason, "; ".join(i.required_evidence)]
                for i in packet.insufficient_evidence
            ],
        )
    )
    for key in draft.check_ids:
        option = options[key]
        unknowns.paragraphs.append(
            option.statement
            + " "
            + option.verification_step
            + " 引用："
            + ", ".join(readable_refs.get(ref, ref) for ref in option.evidence_refs)
        )
    if not (packet.warnings or packet.missing_inputs or packet.insufficient_evidence):
        unknowns.paragraphs.append("包内未列出额外缺失或警告；这不证明来源已完成真实对账。")
    methodology = BriefingSection(
        section_id="methodology",
        title="指标口径、表述边界与证据",
        paragraphs=[
            "比率先合计兼容分量再相除；保留小数转化。零、缺失和分母为零分别处理。"
            "ROAS 为媒体归因 IAP 收入 / 媒体花费，不是财务 ROI。",
            "本报告数值采用 Decimal 原值；CTR 与相对变化以百分比显示。"
            "完整机器证据、原始精度、查询计划与分析选择保存在同目录 JSON 文件中。",
        ],
    )
    methodology.tables.append(
        _table(
            "监控历史索引",
            ["引用", "运行 / 事件 ID"],
            [
                row
                for i, run in enumerate(bundle.monitor_runs, 1)
                for row in [
                    [f"M{i:02d}", run.run_id],
                    *[
                        [f"M{i:02d}.E{j:02d}", event.event_id]
                        for j, event in enumerate(run.events, 1)
                    ],
                ]
            ],
        )
    )
    methodology.tables.append(
        _table(
            "证据门槛策略",
            ["字段", "值"],
            [
                [key, _json(value)]
                for key, value in plan.evidence_policy.model_dump(mode="json").items()
            ],
        )
    )
    for run in bundle.monitor_runs:
        methodology.paragraphs.extend(
            "监控表述边界：" + statement for statement in run.prohibited_claims
        )
    definitions = []
    for d in contract.metric_definitions:
        formula = (
            f"sum({d.metric_key})"
            if d.aggregation == "sum"
            else (f"sum({d.numerator_metric}) / sum({d.denominator_metric}) × {d.scale}")
        )
        definitions.append(
            [
                METRICS.get(d.metric_key, d.metric_key),
                d.metric_key,
                formula,
                d.unit,
                d.semantic_version,
            ]
        )
    methodology.tables.append(
        _table("指标定义", ["指标", "Canonical key", "公式", "单位", "语义版本"], definitions)
    )
    methodology.tables.append(
        _table(
            "逐项口径",
            ["证据", "来源时区", "报告日期口径", "归因", "汇率", "合计分量"],
            [
                [
                    refs[key],
                    ", ".join(a.source_timezones),
                    _json(a.model_dump(mode="json")["reporting_time_bases"]),
                    _json([s.model_dump(mode="json") for s in a.attribution_specs]),
                    _json([c.model_dump(mode="json") for c in a.currency_conversions]),
                    _json(a.model_dump(mode="json")["components"]),
                ]
                for key, a in aggregates.items()
                if a is not None
            ],
        )
    )
    methodology.tables.append(
        _table(
            "禁止表述",
            ["表述", "原因"],
            [[p.statement, p.reason] for p in packet.prohibited_claims],
        )
    )
    methodology.tables.append(
        _table(
            "证据索引",
            ["引用", "证据 ID", "来源快照"],
            [[refs[f.evidence_id], f.evidence_id, ", ".join(f.source_snapshot_ids)] for f in facts],
        )
    )
    methodology.tables.append(
        _table(
            "Lineage",
            ["字段", "值"],
            [[key, _json(value)] for key, value in packet.lineage.model_dump(mode="json").items()],
        )
    )
    return BriefingDocument(
        contract_id=contract.contract_id,
        title=f"{contract.product_name} · 买量简报",
        subtitle=f"{plan.period.start} — {plan.period.end} / 对比前期",
        status=status,
        cards={
            "媒体": str(len(plan.query.platforms)),
            "观测事实": str(len(facts)),
            "严格可比": str(sum(c.status == "strictly_comparable" for c in packet.comparisons)),
            "监控运行": str(len(bundle.monitor_runs)),
        },
        sections=[
            scope,
            highlighted,
            comparisons,
            channels,
            monitors,
            hypotheses,
            unknowns,
            methodology,
        ],
    )
