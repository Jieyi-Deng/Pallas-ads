"""Escaped offline HTML and Markdown from one canonical briefing document."""

from __future__ import annotations

import html
import re

from pallas_ads.contracts.delivery import BriefingDocument

CSS = """
:root{color-scheme:light;--ink:#17242a;--muted:#53656d;--line:#d8e1e3;--accent:#176b62}

*{box-sizing:border-box}
body{margin:0;background:#f3f5f2;color:var(--ink);font:15px/1.65
system-ui,-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif}
a{color:var(--accent)}

.shell{max-width:1280px;margin:auto;padding:44px 32px 80px}
.masthead{display:flex;
justify-content:space-between;gap:24px;border-bottom:2px solid var(--ink);padding-bottom:16px;
font-size:12px;letter-spacing:.16em}
.brand{font-weight:850;font-size:20px;letter-spacing:.24em}

header{padding:40px 0 24px}
h1{font-size:clamp(27px,4vw,44px);line-height:1.25;letter-spacing:-.03em;
margin:10px 0 14px}
h2{font-size:24px;line-height:1.3;margin:0 0 22px}
h3{font-size:15px;margin:25px 0 10px}

p{max-width:1040px;margin:10px 0;overflow-wrap:anywhere;white-space:pre-line}
.subtitle{color:var(--muted)}

.badge{display:inline-block;background:#e2eeea;color:#175b51;padding:5px 12px;border-radius:4px;
font-size:12px;font-weight:650}
.partial{background:#f8e8c7;color:#724915}
.cards{display:grid;
grid-template-columns:repeat(4,1fr);gap:16px;margin:22px 0 32px}
.card{padding:20px 24px;
background:#fff;border:1px solid var(--line);border-top:3px solid var(--accent)}

.card span{display:block;color:var(--muted);font-size:12px}
.card strong{font-size:32px;font-weight:650}

nav{display:flex;flex-wrap:wrap;gap:8px 22px;margin-bottom:28px;font-size:13px}
nav a{text-decoration:none}

section{background:#fff;border:1px solid var(--line);padding:30px;margin:0 0 20px;
scroll-margin-top:16px}

.section-no{display:block;font-size:11px;letter-spacing:.12em;color:var(--accent);margin-bottom:8px}

.table-wrap{overflow:auto;max-width:100%;border:1px solid var(--line);border-radius:4px}

table{border-collapse:collapse;width:100%;font-size:13px;text-align:left}
th{background:#edf2ef;
font-weight:650;color:#304a46}
td,th{padding:12px 14px;border-bottom:1px solid var(--line);
vertical-align:top;min-width:100px;max-width:340px;overflow-wrap:anywhere}
tr:last-child td{border-bottom:0}

tbody tr:nth-child(even){background:#fafbf9}
.empty{color:var(--muted);font-size:13px}

summary{cursor:pointer;font-size:24px;font-weight:650;margin-bottom:20px}
footer{color:var(--muted);
font-size:12px;margin-top:32px;border-top:1px solid var(--line);padding-top:18px}

@media(max-width:640px){.shell{padding:22px 14px 40px}
.masthead{font-size:10px;align-items:center}

header{padding-top:24px}
.cards{grid-template-columns:repeat(2,1fr);gap:10px}
.card{padding:14px 16px}

section{padding:20px 16px}
h2,summary{font-size:21px}
td,th{padding:10px}
nav{gap:8px 16px}
}

@media print{body{background:#fff}
.shell{padding:0;max-width:none}
nav{display:none}

section{break-inside:auto;padding:18px 0;border:0;border-top:1px solid var(--line)}

.table-wrap{overflow:visible}
table{font-size:10px}
td,th{min-width:0;padding:5px;max-width:none}

header{padding-top:18px}
h1{font-size:28px}
.cards{margin:12px 0}
footer{font-size:10px}
}

"""


def markdown_text(value: str) -> str:
    # Escape source strings as text, including table delimiters and HTML/autolink syntax.
    value = value.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
    value = re.sub(r"([\\`*_{}\[\]()#+.!|~\-])", r"\\\1", value)
    return value.replace("\r", " ").replace("\n", " ")


def render_markdown(document: BriefingDocument) -> str:
    escape = markdown_text
    lines = [
        f"# {escape(document.title)}",
        "",
        escape(document.subtitle),
        "",
        "数据状态：" + document.status,
        "",
    ]
    for section in document.sections:
        lines.extend([f"## {escape(section.title)}", ""])
        for paragraph in section.paragraphs:
            lines.extend([escape(paragraph), ""])
        for table in section.tables:
            lines.extend([f"### {escape(table.title)}", ""])
            if not table.rows:
                lines.extend(["无条目。", ""])
                continue
            lines.append("| " + " | ".join(escape(c) for c in table.columns) + " |")
            lines.append("| " + " | ".join("---" for _ in table.columns) + " |")
            lines.extend("| " + " | ".join(escape(c) for c in row) + " |" for row in table.rows)
            lines.append("")
    return "\n".join(lines).rstrip() + "\n"


def render_html(document: BriefingDocument) -> str:
    escape = html.escape
    blocks = []
    for index, section in enumerate(document.sections, 1):
        content = "".join(f"<p>{escape(p)}</p>" for p in section.paragraphs)
        for table in section.tables:
            content += f"<h3>{escape(table.title)}</h3>"
            if not table.rows:
                content += '<p class="empty">无条目。</p>'
                continue
            heads = "".join(f'<th scope="col">{escape(c)}</th>' for c in table.columns)
            rows = "".join(
                "<tr>" + "".join(f"<td>{escape(c)}</td>" for c in row) + "</tr>"
                for row in table.rows
            )
            content += (
                '<div class="table-wrap" tabindex="0" role="region" '
                f'aria-label="{escape(table.title)}">'
            )
            content += f"<table><thead><tr>{heads}</tr></thead><tbody>{rows}</tbody></table></div>"
        title = f"<h2>{escape(section.title)}</h2>"
        if section.section_id == "methodology":
            content = f"<details><summary>{escape(section.title)}</summary>{content}</details>"
            title = ""
        blocks.append(
            f'<section id="{escape(section.section_id)}"><span class="section-no">'
            f"{index:02d} / PALLAS BRIEFING</span>{title}{content}</section>"
        )
    cards = "".join(
        f'<div class="card"><span>{escape(k)}</span><strong>{escape(v)}</strong></div>'
        for k, v in sorted(document.cards.items())
    )
    navigation = "".join(
        f'<a href="#{escape(s.section_id)}">{escape(s.title)}</a>' for s in document.sections
    )
    badge = (
        "部分结果 · 请检查缺失项"
        if document.status == "partial_result"
        else "证据已生成 · 按可比性解读"
    )
    badge_class = "partial" if document.status == "partial_result" else ""
    return f"""<!doctype html>
<html lang="zh-CN"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta http-equiv="Content-Security-Policy" content="default-src 'none';
style-src 'unsafe-inline'; base-uri 'none'; form-action 'none'">
<meta name="referrer" content="no-referrer"><title>{escape(document.title)}</title>
<style>{CSS}</style></head>
<body><main class="shell"><div class="masthead"><span class="brand">PALLAS</span>
<span>LOCAL ACQUISITION INTELLIGENCE</span></div>
<header><span class="badge {badge_class}">{badge}</span>
<h1>{escape(document.title)}</h1><p class="subtitle">{escape(document.subtitle)}</p></header>
<div class="cards">{cards}</div><nav aria-label="报告章节">{navigation}</nav>{"".join(blocks)}
<footer>本地只读简报 · 无脚本、无遥测、无外部资源。完整口径与历史证据保留于报告包。</footer>
</main></body></html>
"""
