"""Meta official MCP OAuth using an operator-owned app and a local PKCE callback.

No DCR impersonation, app secret, token import, or advertising data calls.
Endpoints are pinned to the metadata verified on 2026-09-14.
"""

from __future__ import annotations

import base64
import hashlib
from urllib.parse import urlencode

from pallas_ads.contracts.source import SourceConnectionConfig
from pallas_ads.credential_store import CredentialError, TokenBundle

RESOURCE = "https://mcp.facebook.com/ads"
RESOURCE_METADATA = "https://mcp.facebook.com/.well-known/oauth-protected-resource/ads"
ISSUER = "https://www.facebook.com/ads"
SERVER_METADATA = "https://www.facebook.com/.well-known/oauth-authorization-server/ads"
AUTHORIZE = "https://www.facebook.com/v26.0/dialog/oauth"
TOKEN = "https://graph.facebook.com/v26.0/oauth/access_token"
SCOPES = {"ads_read", "ads_mcp_management"}


class MetaMCPOAuth:
    def __init__(self, transport):
        self.transport = transport

    @staticmethod
    def _config(config):
        validated = SourceConnectionConfig.model_validate(config.model_dump(mode="json"))
        if validated.platform != "meta" or validated.transport != "official_mcp":
            raise CredentialError("Meta official MCP configuration required")
        return validated

    def register(self, config):
        """Validate public metadata for a preconfigured app; do not register as Claude."""
        config = self._config(config)
        resource = self.transport.request("GET", RESOURCE_METADATA, headers={})
        p = resource.payload
        if (
            resource.status != 200
            or not isinstance(p, dict)
            or p.get("resource") != RESOURCE
            or p.get("authorization_servers") != [ISSUER]
        ):
            raise CredentialError("Meta MCP resource metadata rejected")
        server = self.transport.request("GET", SERVER_METADATA, headers={})
        p = server.payload
        if (
            server.status != 200
            or not isinstance(p, dict)
            or any(
                p.get(k) != v
                for k, v in {
                    "issuer": ISSUER,
                    "authorization_endpoint": AUTHORIZE,
                    "token_endpoint": TOKEN,
                }.items()
            )
        ):
            raise CredentialError("Meta MCP authorization metadata rejected")
        for key, values in {
            "response_types_supported": {"code"},
            "grant_types_supported": {"authorization_code"},
            "code_challenge_methods_supported": {"S256"},
            "token_endpoint_auth_methods_supported": {"none"},
            "scopes_supported": SCOPES,
        }.items():
            offered = p.get(key)
            if not isinstance(offered, list) or not values.issubset(offered):
                raise CredentialError("Meta MCP authorization capabilities changed")
        return config

    def authorization_url(self, config, redirect_uri, state, verifier):
        config = self._config(config)
        if redirect_uri != config.registered_redirect_uri:
            raise CredentialError("Meta MCP callback does not match configuration")
        challenge = base64.urlsafe_b64encode(hashlib.sha256(verifier.encode()).digest())
        return (
            AUTHORIZE
            + "?"
            + urlencode(
                {
                    "client_id": config.client_id,
                    "redirect_uri": redirect_uri,
                    "response_type": "code",
                    "resource": RESOURCE,
                    "scope": " ".join(sorted(SCOPES)),
                    "state": state,
                    "code_challenge": challenge.decode().rstrip("="),
                    "code_challenge_method": "S256",
                }
            )
        )

    def exchange(self, config, code, redirect_uri, verifier):
        config = self._config(config)
        if redirect_uri != config.registered_redirect_uri:
            raise CredentialError("Meta MCP callback does not match configuration")
        response = self.transport.request(
            "POST",
            TOKEN,
            headers={},
            form=True,
            body={
                "grant_type": "authorization_code",
                "client_id": config.client_id,
                "code": code,
                "redirect_uri": redirect_uri,
                "code_verifier": verifier,
                "resource": RESOURCE,
            },
        )
        p = response.payload
        try:
            if response.status != 200 or not isinstance(p, dict) or "error" in p:
                raise ValueError
            if str(p.get("token_type", "")).lower() != "bearer":
                raise ValueError
            value = p.get("access_token")
            if (
                not isinstance(value, str)
                or not 1 <= len(value) <= 32768
                or any(ord(c) < 33 or ord(c) > 126 for c in value)
            ):
                raise ValueError
            expiry = p.get("expires_in")
            if type(expiry) is not int or not 0 < expiry <= 90 * 86400:
                raise ValueError
            if "scope" in p and (
                not isinstance(p["scope"], str) or not SCOPES.issubset(p["scope"].split())
            ):
                raise ValueError
            # Meta may omit scope and refresh_token. Only retain the bounded access grant.
            return TokenBundle(access_token=value, expires_in=expiry)
        except Exception:
            raise CredentialError("Meta MCP token exchange failed; authorize again") from None

    def refresh(self, config, previous):
        self._config(config)
        raise CredentialError("Meta MCP requires browser reauthorization after expiry")

    def revoke(self, config, tokens):
        self._config(config)
        # Metadata advertises no revocation endpoint. Do not revoke an entire Meta app
        # grant or claim a remote revocation merely because a local credential was deleted.
        return False
