"""Shipped canonical metric registry and ratio-of-sums computation."""

from __future__ import annotations

from collections.abc import Mapping
from decimal import Decimal, InvalidOperation

from pallas_ads.contracts.common import CanonicalDimension, CanonicalMetric, ReportingTimeBasis
from pallas_ads.contracts.metrics import (
    MetricAggregation,
    MetricComputation,
    MetricDefinition,
    MetricInterpretationWarning,
    MetricNullReason,
    MetricUnit,
)

_ALL_GRAINS = list(CanonicalDimension)


def _sum_metric(metric: CanonicalMetric, unit: MetricUnit) -> MetricDefinition:
    return MetricDefinition(
        metric_key=metric,
        semantic_version="1.0.0",
        aggregation=MetricAggregation.SUM,
        unit=unit,
        valid_grains=_ALL_GRAINS,
        attribution_sensitive=metric
        in {
            CanonicalMetric.INSTALLS,
            CanonicalMetric.PURCHASE_EVENT_COUNT,
            CanonicalMetric.OPTIMIZATION_EVENT_COUNT,
            CanonicalMetric.PLATFORM_ATTRIBUTED_IAP_REVENUE,
        },
        importable=True,
    )


def _ratio_metric(
    metric: CanonicalMetric,
    numerator: CanonicalMetric,
    denominator: CanonicalMetric,
    unit: MetricUnit,
    *,
    scale: Decimal = Decimal(1),
    attribution_sensitive: bool = False,
) -> MetricDefinition:
    return MetricDefinition(
        metric_key=metric,
        semantic_version="1.0.0",
        aggregation=MetricAggregation.RATIO_OF_SUMS,
        unit=unit,
        numerator_metric=numerator,
        denominator_metric=denominator,
        scale=scale,
        valid_grains=_ALL_GRAINS,
        attribution_sensitive=attribution_sensitive,
        importable=False,
    )


SHIPPED_METRIC_DEFINITIONS = (
    _sum_metric(CanonicalMetric.SPEND, MetricUnit.CURRENCY),
    _sum_metric(CanonicalMetric.IMPRESSIONS, MetricUnit.COUNT),
    _sum_metric(CanonicalMetric.CLICKS, MetricUnit.COUNT),
    _sum_metric(CanonicalMetric.INSTALLS, MetricUnit.COUNT),
    _sum_metric(CanonicalMetric.PURCHASE_EVENT_COUNT, MetricUnit.COUNT),
    _sum_metric(CanonicalMetric.OPTIMIZATION_EVENT_COUNT, MetricUnit.COUNT),
    _sum_metric(CanonicalMetric.PLATFORM_ATTRIBUTED_IAP_REVENUE, MetricUnit.CURRENCY),
    _ratio_metric(
        CanonicalMetric.CPM,
        CanonicalMetric.SPEND,
        CanonicalMetric.IMPRESSIONS,
        MetricUnit.CURRENCY_PER_THOUSAND,
        scale=Decimal(1000),
    ),
    _ratio_metric(
        CanonicalMetric.CTR,
        CanonicalMetric.CLICKS,
        CanonicalMetric.IMPRESSIONS,
        MetricUnit.RATIO,
    ),
    _ratio_metric(
        CanonicalMetric.CPC,
        CanonicalMetric.SPEND,
        CanonicalMetric.CLICKS,
        MetricUnit.CURRENCY_PER_ACTION,
    ),
    _ratio_metric(
        CanonicalMetric.CPI,
        CanonicalMetric.SPEND,
        CanonicalMetric.INSTALLS,
        MetricUnit.CURRENCY_PER_ACTION,
        attribution_sensitive=True,
    ),
    _ratio_metric(
        CanonicalMetric.CPA_PURCHASE_EVENT,
        CanonicalMetric.SPEND,
        CanonicalMetric.PURCHASE_EVENT_COUNT,
        MetricUnit.CURRENCY_PER_ACTION,
        attribution_sensitive=True,
    ),
    _ratio_metric(
        CanonicalMetric.CPA_OPTIMIZATION_EVENT,
        CanonicalMetric.SPEND,
        CanonicalMetric.OPTIMIZATION_EVENT_COUNT,
        MetricUnit.CURRENCY_PER_ACTION,
        attribution_sensitive=True,
    ),
    _ratio_metric(
        CanonicalMetric.MEDIA_IAP_ROAS,
        CanonicalMetric.PLATFORM_ATTRIBUTED_IAP_REVENUE,
        CanonicalMetric.SPEND,
        MetricUnit.RATIO,
        attribution_sensitive=True,
    ),
)


class MetricRegistry:
    """Immutable registry used below the future comparison engine."""

    def __init__(self, definitions: tuple[MetricDefinition, ...] = SHIPPED_METRIC_DEFINITIONS):
        self._definitions = {definition.metric_key: definition for definition in definitions}
        if set(self._definitions) != set(CanonicalMetric):
            definition_keys = set(self._definitions)
            missing = sorted(metric.value for metric in set(CanonicalMetric) - definition_keys)
            extras = sorted(metric.value for metric in definition_keys - set(CanonicalMetric))
            raise ValueError(
                f"metric registry coverage mismatch; missing={missing}, extras={extras}"
            )
        if len(self._definitions) != len(definitions):
            raise ValueError("metric definitions must be unique by metric key")
        for definition in definitions:
            if definition.aggregation is MetricAggregation.RATIO_OF_SUMS:
                assert definition.numerator_metric is not None
                assert definition.denominator_metric is not None
                for component in (definition.numerator_metric, definition.denominator_metric):
                    component_definition = self._definitions[component]
                    if component_definition.aggregation is not MetricAggregation.SUM:
                        raise ValueError("ratio formulas must reference additive component metrics")

    @property
    def definitions(self) -> tuple[MetricDefinition, ...]:
        return tuple(self._definitions[metric] for metric in CanonicalMetric)

    def definition(self, metric: CanonicalMetric | str) -> MetricDefinition:
        return self._definitions[CanonicalMetric(metric)]

    def compute(
        self,
        metric: CanonicalMetric | str,
        summed_components: Mapping[CanonicalMetric, Decimal | int | float | None]
        | Mapping[str, Decimal | int | float | None],
        *,
        component_time_bases: Mapping[CanonicalMetric, ReportingTimeBasis | str]
        | Mapping[str, ReportingTimeBasis | str]
        | None = None,
    ) -> MetricComputation:
        """Return arithmetic and warnings, never comparison eligibility or a causal diagnosis.

        The caller must preserve missing components and align scope before summing. A zero
        numerator remains zero; undefined division remains null. No rows are filtered here.
        """

        definition = self.definition(metric)
        normalized: dict[CanonicalMetric, Decimal | None] = {}
        for key, value in summed_components.items():
            if value is None:
                normalized[CanonicalMetric(key)] = None
                continue
            try:
                number = Decimal(str(value))
            except InvalidOperation as error:
                raise ValueError("metric components must be finite non-negative numbers") from error
            if not number.is_finite() or number < 0:
                raise ValueError("metric components must be finite non-negative numbers")
            normalized[CanonicalMetric(key)] = number
        if definition.aggregation is MetricAggregation.SUM:
            value = normalized.get(definition.metric_key)
            return MetricComputation(
                metric_key=definition.metric_key,
                semantic_version=definition.semantic_version,
                value=value,
                unit=definition.unit,
                null_reason=None if value is not None else MetricNullReason.MISSING_NUMERATOR,
            )

        assert definition.numerator_metric is not None
        assert definition.denominator_metric is not None
        numerator = normalized.get(definition.numerator_metric)
        denominator = normalized.get(definition.denominator_metric)
        warnings = _interpretation_warnings(definition, normalized, component_time_bases)
        if numerator is None and denominator is None:
            return self._null_computation(definition, MetricNullReason.MISSING_COMPONENTS, warnings)
        if numerator is None:
            return self._null_computation(definition, MetricNullReason.MISSING_NUMERATOR, warnings)
        if denominator is None:
            return self._null_computation(
                definition, MetricNullReason.MISSING_DENOMINATOR, warnings
            )
        if denominator == 0:
            return self._null_computation(definition, MetricNullReason.ZERO_DENOMINATOR, warnings)
        return MetricComputation(
            metric_key=definition.metric_key,
            semantic_version=definition.semantic_version,
            value=(numerator / denominator) * definition.scale,
            unit=definition.unit,
            interpretation_warnings=warnings,
        )

    @staticmethod
    def _null_computation(
        definition: MetricDefinition,
        reason: MetricNullReason,
        warnings: list[MetricInterpretationWarning],
    ) -> MetricComputation:
        return MetricComputation(
            metric_key=definition.metric_key,
            semantic_version=definition.semantic_version,
            unit=definition.unit,
            null_reason=reason,
            interpretation_warnings=warnings,
        )


def _interpretation_warnings(
    definition: MetricDefinition,
    components: Mapping[CanonicalMetric, Decimal | None],
    time_bases: Mapping[CanonicalMetric, ReportingTimeBasis | str]
    | Mapping[str, ReportingTimeBasis | str]
    | None,
) -> list[MetricInterpretationWarning]:
    if not definition.attribution_sensitive:
        return []
    outcome_metric = (
        definition.denominator_metric
        if definition.numerator_metric is CanonicalMetric.SPEND
        else definition.numerator_metric
    )
    assert outcome_metric is not None
    spend = components.get(CanonicalMetric.SPEND)
    outcome = components.get(outcome_metric)
    warnings: list[MetricInterpretationWarning] = []
    if spend is not None and outcome is not None:
        if spend == 0 and outcome > 0:
            warnings.append(MetricInterpretationWarning.ZERO_SPEND_WITH_OUTCOMES)
        elif spend > 0 and outcome == 0:
            warnings.append(MetricInterpretationWarning.POSITIVE_SPEND_WITH_ZERO_OUTCOME)
        elif spend == 0 and outcome == 0:
            warnings.append(MetricInterpretationWarning.BOTH_COMPONENTS_ZERO)

    normalized_bases = {
        CanonicalMetric(key): ReportingTimeBasis(value) for key, value in (time_bases or {}).items()
    }
    spend_basis = normalized_bases.get(CanonicalMetric.SPEND, ReportingTimeBasis.UNKNOWN)
    outcome_basis = normalized_bases.get(outcome_metric, ReportingTimeBasis.UNKNOWN)
    if {spend_basis, outcome_basis} & {ReportingTimeBasis.UNKNOWN, ReportingTimeBasis.MIXED}:
        warnings.append(MetricInterpretationWarning.UNKNOWN_REPORTING_TIME_BASIS)
    elif not (
        spend_basis in {ReportingTimeBasis.DELIVERY_DATE, ReportingTimeBasis.AD_INTERACTION_DATE}
        and outcome_basis is ReportingTimeBasis.AD_INTERACTION_DATE
    ):
        warnings.append(MetricInterpretationWarning.PERIOD_FLOW_NOT_COHORT)
    return warnings


DEFAULT_METRIC_REGISTRY = MetricRegistry()
