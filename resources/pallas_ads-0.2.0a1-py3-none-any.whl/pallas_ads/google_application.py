"""Publisher-supplied Desktop application identity; never a user OAuth grant.

This module contains no credentials. Release builds inject a minimal resource outside Git.
Do not expose the resource through tool results, configuration exports or diagnostic logs.
"""

import json
import re
from pathlib import Path

RESOURCE = "pallas_ads/resources/google-desktop.json"


def validate_client(raw):
    installed = raw.get("installed") if isinstance(raw, dict) else None
    if not isinstance(installed, dict) or "web" in raw:
        raise ValueError("A Google Desktop application is required.")
    client, secret = installed.get("client_id"), installed.get("client_secret")
    if (
        not isinstance(client, str)
        or not re.fullmatch(r"[A-Za-z0-9_-]{1,240}\.apps\.googleusercontent\.com", client)
        or not isinstance(secret, str)
        or not secret
        or len(secret) > 4096
        or any(ord(c) < 32 for c in secret)
    ):
        raise ValueError("Invalid Desktop application configuration.")
    return {"installed": {"client_id": client, "client_secret": secret}}


def read_client(path):
    path = Path(path)
    if path.is_symlink() or path.stat().st_size > 65536:
        raise ValueError("Invalid Desktop application file.")
    return validate_client(json.loads(path.read_text()))


def bundled_path():
    return Path(__file__).parent / "resources/google-desktop.json"


def bundled_client():
    path = bundled_path()
    return read_client(path)["installed"] if path.exists() else None


def bundled_secret(client_id):
    app = bundled_client()
    if app and app["client_id"] == client_id:
        return app["client_secret"]
    return None
