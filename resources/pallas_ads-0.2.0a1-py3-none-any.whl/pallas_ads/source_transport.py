"""Bounded HTTPS transport. URLs, credentials and remote errors never enter exceptions."""

from __future__ import annotations

import json
import ssl
import time
from dataclasses import dataclass, field
from decimal import Decimal
from typing import Any, Protocol
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode, urlsplit
from urllib.request import HTTPRedirectHandler, Request, build_opener


class SourceHTTPError(ValueError):
    def __init__(self, code: str, *, retriable: bool = False) -> None:
        super().__init__(code)
        self.code = code
        self.retriable = retriable


@dataclass(repr=False)
class HTTPResponse:
    status: int
    payload: Any = field(repr=False)
    headers: dict[str, str] = field(default_factory=dict, repr=False)


class Transport(Protocol):
    def request(
        self,
        method: str,
        url: str,
        *,
        headers: dict[str, str],
        parameters: dict[str, Any] | None = None,
        body: dict[str, Any] | None = None,
        form: bool = False,
    ) -> HTTPResponse: ...


class _NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


class HTTPTransport:
    def __init__(self, *, timeout: float = 20, max_bytes: int = 8_000_000) -> None:
        if not 0 < timeout <= 60 or not 0 < max_bytes <= 32_000_000:
            raise ValueError("invalid transport limits")
        self.timeout, self.max_bytes = timeout, max_bytes

    def request(self, method, url, *, headers, parameters=None, body=None, form=False):
        parsed = urlsplit(url)
        if (
            parsed.scheme != "https"
            or parsed.username
            or parsed.password
            or parsed.port not in (None, 443)
            or parsed.query
            or parsed.fragment
            or parsed.hostname
            not in {
                "graph.facebook.com",
                "business-api.tiktok.com",
                "googleads.googleapis.com",
                "oauth2.googleapis.com",
                "www.facebook.com",
                "mcp.facebook.com",
            }
        ):
            raise SourceHTTPError("unapproved_endpoint")
        if parsed.hostname in {"www.facebook.com", "mcp.facebook.com"} and (
            parsed.hostname,
            parsed.path,
        ) not in {
            ("www.facebook.com", "/.well-known/oauth-authorization-server/ads"),
            ("mcp.facebook.com", "/.well-known/oauth-protected-resource/ads"),
            ("mcp.facebook.com", "/ads"),
        }:
            raise SourceHTTPError("unapproved_endpoint")
        try:
            if parameters:
                url += "?" + urlencode(parameters)
            wire_headers = dict(headers)
            data = None
            if body is not None:
                data = (urlencode(body) if form else json.dumps(body)).encode()
                wire_headers["Content-Type"] = (
                    "application/x-www-form-urlencoded" if form else "application/json"
                )
            request = Request(url, data=data, headers=wire_headers, method=method)
            opener = build_opener(_NoRedirect())
            try:
                response = opener.open(request, timeout=self.timeout)
            except HTTPError as error:
                response = error
            with response:
                if 300 <= response.code < 400:
                    raise SourceHTTPError("redirect_rejected")
                content_type = response.headers.get("Content-Type", "").split(";")[0].lower()
                if content_type == "text/event-stream":
                    if (
                        response.code != 200
                        or (parsed.hostname, parsed.path)
                        not in {
                            ("business-api.tiktok.com", "/open_mcp/tt-ads-mcp-flat"),
                            ("mcp.facebook.com", "/ads"),
                        }
                        or not body
                        or body.get("jsonrpc") != "2.0"
                        or "id" not in body
                    ):
                        raise SourceHTTPError("unexpected_event_stream")
                    decoded = self._read_mcp_event(response, body["id"])
                    return HTTPResponse(response.code, decoded, dict(response.headers.items()))
                payload = response.read(self.max_bytes + 1)
                if len(payload) > self.max_bytes:
                    raise SourceHTTPError("response_too_large")
                if response.code == 204 or not payload.strip():
                    decoded = {}
                else:
                    try:
                        decoded = json.loads(payload, parse_float=Decimal)
                    except (ValueError, UnicodeError):
                        raise SourceHTTPError("invalid_response") from None
                return HTTPResponse(response.code, decoded, dict(response.headers.items()))
        except SourceHTTPError:
            raise
        except (URLError, TimeoutError, OSError, ValueError, ssl.SSLError):
            raise SourceHTTPError("transport_unavailable", retriable=True) from None

    def _read_mcp_event(self, response, request_id):
        """Bound SSE by bytes, events and time; stop at our response without waiting for EOF."""
        size, events, data = 0, 0, []
        deadline = time.monotonic() + self.timeout
        while time.monotonic() < deadline:
            line = response.readline(self.max_bytes - size + 1)
            size += len(line)
            if size > self.max_bytes:
                raise SourceHTTPError("response_too_large")
            if not line:
                break
            line = line.rstrip(b"\r\n")
            if line.startswith(b"data:"):
                data.append(line[5:].removeprefix(b" "))
            elif not line and data:
                events += 1
                if events > 100:
                    raise SourceHTTPError("mcp_event_limit")
                try:
                    event = json.loads(b"\n".join(data), parse_float=Decimal)
                except (ValueError, UnicodeError):
                    raise SourceHTTPError("invalid_response") from None
                data = []
                if not isinstance(event, dict) or event.get("jsonrpc") != "2.0":
                    raise SourceHTTPError("invalid_response")
                if "id" in event:
                    if type(event["id"]) is not int or event["id"] != request_id:
                        raise SourceHTTPError("mcp_response_id_mismatch")
                    return event
                # Notifications are untrusted: discard without running actions or displaying text.
        raise SourceHTTPError("mcp_response_incomplete")
