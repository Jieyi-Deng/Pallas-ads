"""Offline distribution metadata and explicit skill export; no agent settings mutations."""

from __future__ import annotations

import json
import shutil
from pathlib import Path
from typing import Annotated

import typer


def register(app):
    acceptance = typer.Typer(help="Keep local test results and prepare reviewed feedback.")
    app.add_typer(acceptance, name="acceptance")

    @acceptance.command("start")
    def start_test(directory: Annotated[Path, typer.Option("--directory")]):
        from pallas_ads.acceptance import start

        try:
            result = start(directory)
        except (OSError, ValueError):
            typer.echo("Choose a new local test directory; existing files are preserved.", err=True)
            raise typer.Exit(1) from None
        typer.echo(json.dumps(result, ensure_ascii=False))

    @acceptance.command("pack")
    def pack_test(
        directory: Annotated[Path, typer.Option("--directory")],
        reviewed: Annotated[bool, typer.Option("--reviewed")] = False,
    ):
        from pallas_ads.acceptance import pack

        try:
            result = pack(directory, reviewed=reviewed)
        except ValueError as error:
            typer.echo(str(error), err=True)  # Only fixed diagnostics, never matched values.
            raise typer.Exit(1) from None
        except OSError:
            typer.echo("Cannot package local feedback; check directory permissions.", err=True)
            raise typer.Exit(1) from None
        typer.echo(json.dumps(result, ensure_ascii=False))

    release = typer.Typer(help="Prepare self-contained new-machine test materials.")
    app.add_typer(release, name="release")

    @release.command("bundle")
    def bundle(
        wheel: Annotated[Path, typer.Option("--wheel")],
        output_dir: Annotated[Path, typer.Option("--output-dir")],
    ):
        """Package a core or optionally configured release wheel for local testing."""
        from pallas_ads.release_bundle import build_bundle

        try:
            result = build_bundle(wheel, output_dir)
        except Exception:
            typer.echo(
                "Bundle requires the matching release wheel and new output "
                "directory. No secret values are printed.",
                err=True,
            )
            raise typer.Exit(1) from None
        typer.echo(json.dumps(result))

    agent = typer.Typer(help="Set up a fresh project folder for Codex or Claude Code.")
    app.add_typer(agent, name="agent")

    @agent.command("setup")
    def setup(
        directory: Annotated[Path, typer.Option("--directory")],
        client: Annotated[str, typer.Option("--client", help="claude or codex")],
        meta_client_id: Annotated[str | None, typer.Option("--meta-client-id")] = None,
        mode: Annotated[str, typer.Option("--mode", help="core (default) or live")] = "core",
    ):
        from pallas_ads.agent_setup import setup_agent

        try:
            result = setup_agent(directory, client, meta_client_id=meta_client_id, mode=mode)
        except (ValueError, OSError):
            typer.echo("Setup requires an installed wheel and a new or empty directory.", err=True)
            raise typer.Exit(1) from None
        typer.echo(json.dumps(result, ensure_ascii=False))

    @agent.command("refresh-skills")
    def update_skills(directory: Annotated[Path, typer.Option("--directory")]):
        """Update Pallas Skills only, retaining a local backup of the previous copies."""
        from pallas_ads.agent_setup import refresh_skills

        try:
            result = refresh_skills(directory)
        except (ValueError, OSError):
            typer.echo("Skill update failed; inspect the project and retained backups.", err=True)
            raise typer.Exit(1) from None
        typer.echo(json.dumps(result))

    @agent.command("doctor")
    def check(
        directory: Annotated[Path, typer.Option("--directory")],
        media: Annotated[str, typer.Option("--media")] = "core",
    ):
        """Offline setup check; never opens OAuth or reads tokens."""
        from pallas_ads.machine_setup import doctor

        try:
            result = doctor(directory, media=media)
        except ValueError:
            typer.echo("Choose --media core, google, meta, tiktok or all.", err=True)
            raise typer.Exit(2) from None
        typer.echo(json.dumps(result, ensure_ascii=False))
        if result["status"] == "blocked":
            raise typer.Exit(2)

    @agent.command("prepare-meta")
    def prepare_meta(
        directory: Annotated[Path, typer.Option("--directory")],
        trust_local_certificate: bool = False,
    ):
        """Generate local Meta TLS; explicit flag trusts localhost in macOS user keychain."""
        from pallas_ads.machine_setup import prepare_certificate

        try:
            result = prepare_certificate(directory.absolute(), trust=trust_local_certificate)
        except Exception:
            typer.echo(
                "Meta setup failed. Check macOS, project config and system permission; "
                "existing credentials were not replaced.",
                err=True,
            )
            raise typer.Exit(1) from None
        typer.echo(json.dumps(result))

    @agent.command("login-meta")
    def login_meta(directory: Annotated[Path, typer.Option("--directory")]):
        """Open Codex Meta consent with the packaged HTTPS callback forwarder."""
        from pallas_ads.machine_setup import login_meta as login

        try:
            status = login(directory.absolute())
        except KeyboardInterrupt:
            raise typer.Exit(130) from None
        except Exception:
            typer.echo(
                "Meta login unavailable. Run agent doctor; check Codex CLI, certificate "
                "and ports 8765/8768. No host credentials were read.",
                err=True,
            )
            raise typer.Exit(1) from None
        raise typer.Exit(status)

    @agent.command("guard-meta", hidden=True)
    def guard():
        import sys

        from pallas_ads.agent_setup import guard_meta

        try:
            raw = sys.stdin.buffer.read(2 * 1024 * 1024 + 1)
            event = json.loads(raw) if len(raw) <= 2 * 1024 * 1024 else None
        except (ValueError, RecursionError):
            event = None
        typer.echo(json.dumps(guard_meta(event)))

    @app.command("release-status")
    def release_status():
        """Print shipped adapter validation limits and privacy posture."""
        path = Path(__file__).parent / "resources/release-status.json"
        from pallas_ads.google_application import bundled_client

        status = json.loads(path.read_text())
        status["first_use"]["google_application_embedded"] = bundled_client() is not None
        typer.echo(json.dumps(status, ensure_ascii=False))

    skills = typer.Typer(help="Export portable skills without changing agent settings.")
    app.add_typer(skills, name="skills")

    @skills.command("export")
    def export(output_dir: Annotated[Path, typer.Option("--output-dir")]):
        """Copy bundled skill folders to a new directory; never overwrite existing files."""
        source = Path(__file__).parent / "resources/skills"
        if not source.is_dir():
            source = Path(__file__).parents[2] / "skills"
        try:
            shutil.copytree(source, output_dir)
        except OSError:
            typer.echo("Skill export needs a new writable destination directory.", err=True)
            raise typer.Exit(1) from None
        typer.echo(str(output_dir.resolve()))
