"""Pallas command-line interface."""

from __future__ import annotations

import json
import os
import sys
from pathlib import Path
from typing import Annotated

import typer
from pydantic import Field

from pallas_ads import __version__
from pallas_ads.config import Settings
from pallas_ads.contracts.base import ContractModel
from pallas_ads.contracts.schemas import export_schemas, render_schema, schema_names
from pallas_ads.contracts.status import OperationEnvelope, OperationStatus
from pallas_ads.research.conversation import ConversationCase

app = typer.Typer(
    help="Local-first cross-media acquisition intelligence runtime.",
    no_args_is_help=True,
)
schema_app = typer.Typer(help="Export versioned Pallas data-contract schemas.")
app.add_typer(schema_app, name="schema")


class DoctorResult(ContractModel):
    pallas_version: str = Field(pattern=r"^\d+\.\d+\.\d+(?:(?:a|b|rc)\d+)?$")
    python_version: str = Field(pattern=r"^\d+\.\d+\.\d+$")
    data_dir: str = Field(min_length=1)
    data_dir_parent_writable: bool


def _nearest_existing_parent(path: Path) -> Path:
    candidate = path
    while not candidate.exists() and candidate != candidate.parent:
        candidate = candidate.parent
    return candidate


@app.command()
def version() -> None:
    """Print the Pallas version."""
    typer.echo(__version__)


@app.command()
def doctor(
    json_output: Annotated[
        bool,
        typer.Option("--json", help="Return the shared operation envelope as JSON."),
    ] = False,
) -> None:
    """Check the local non-secret runtime environment."""
    settings = Settings.from_environment()
    writable_parent = _nearest_existing_parent(settings.data_dir)
    result = DoctorResult(
        pallas_version=__version__,
        python_version=".".join(str(part) for part in sys.version_info[:3]),
        data_dir=str(settings.data_dir),
        data_dir_parent_writable=os.access(writable_parent, os.W_OK),
    )
    envelope = OperationEnvelope[DoctorResult](
        operation="doctor",
        status=OperationStatus.COMPLETE,
        result=result,
    )
    if json_output:
        typer.echo(json.dumps(envelope.model_dump(mode="json"), ensure_ascii=False, sort_keys=True))
        return
    typer.echo(f"status: {envelope.status.value}")
    for key, value in result.model_dump(mode="python").items():
        typer.echo(f"{key}: {value}")


@schema_app.command("list")
def list_schemas() -> None:
    """List public runtime contract schemas."""
    for name in schema_names():
        typer.echo(name)


@schema_app.command("export")
def export_schema(
    name: Annotated[str, typer.Argument(help="Schema name from `pallas schema list`.")],
    output: Annotated[
        Path | None,
        typer.Option("--output", "-o", help="Write the schema to this path."),
    ] = None,
) -> None:
    """Export one public runtime contract schema."""
    try:
        rendered = render_schema(name)
    except ValueError as error:
        raise typer.BadParameter(str(error), param_hint="name") from error
    if output is None:
        typer.echo(rendered)
        return
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(f"{rendered}\n", encoding="utf-8")
    typer.echo(str(output))


@schema_app.command("export-all")
def export_all_contract_schemas(
    output_dir: Annotated[
        Path,
        typer.Option("--output-dir", "-o", help="Directory for generated schemas."),
    ] = Path("schemas/contracts"),
) -> None:
    """Export every public runtime contract schema."""
    for output in export_schemas(output_dir):
        typer.echo(str(output))


@schema_app.command("conversation-case", hidden=True)
def export_conversation_case_schema(
    output: Annotated[
        Path | None,
        typer.Option("--output", "-o", help="Write the schema to this path."),
    ] = None,
) -> None:
    """Export the legacy research-only conversation-case schema."""
    rendered = json.dumps(ConversationCase.model_json_schema(), indent=2, ensure_ascii=False)
    if output is None:
        typer.echo(rendered)
        return
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(f"{rendered}\n", encoding="utf-8")
    typer.echo(str(output))


from pallas_ads.integration_cli import register  # noqa: E402

register(app)

from pallas_ads.distribution import register as register_distribution  # noqa: E402

register_distribution(app)

if __name__ == "__main__":
    app()
