"""Local Week 4 compare operation: resolve, aggregate, constrain, and retain evidence."""

from __future__ import annotations

from datetime import UTC, datetime
from itertools import combinations

from pydantic import ValidationError

from pallas_ads import __version__
from pallas_ads.aggregation import aggregate
from pallas_ads.comparison_policy import claims_for_comparisons, compare_aggregates
from pallas_ads.contracts.analysis import EvidencePolicy, MetricAggregate, ResolvedQueryPlan
from pallas_ads.contracts.common import CanonicalDimension, ComparisonStatus
from pallas_ads.contracts.evidence import (
    AllowedClaim,
    EvidenceItem,
    EvidenceKind,
    EvidenceLineage,
    EvidencePacket,
    EvidenceScope,
    EvidenceWarning,
    InsufficientEvidenceItem,
    ProhibitedClaim,
)
from pallas_ads.contracts.query import CanonicalQuery
from pallas_ads.contracts.status import (
    IssueSeverity,
    MissingInput,
    OperationEnvelope,
    OperationIssue,
    OperationStatus,
)
from pallas_ads.evidence_store import EvidenceStore, EvidenceStoreError
from pallas_ads.local_state import WorkspaceRepository
from pallas_ads.metric_registry import DEFAULT_METRIC_REGISTRY
from pallas_ads.query_planner import AnalysisContext, AnalysisInputError, QueryPlanner, content_hash


class ComparisonService:
    """Import-backed analysis only; no sync, LLM calls, monitoring, or report renderer."""

    def __init__(
        self,
        workspace: WorkspaceRepository,
        *,
        evidence_policies: dict[str, EvidencePolicy] | None = None,
    ) -> None:
        self.planner = QueryPlanner(workspace, evidence_policies)
        self.store = EvidenceStore(workspace.layout.root / "data" / "evidence")

    def plan(self, query: CanonicalQuery) -> OperationEnvelope[ResolvedQueryPlan]:
        try:
            plan = self.planner.resolve(query).plan
            return OperationEnvelope(
                operation="plan_comparison", status=OperationStatus.COMPLETE, result=plan
            )
        except AnalysisInputError as error:
            return OperationEnvelope(
                operation="plan_comparison",
                status=OperationStatus.NEEDS_INPUT,
                missing_inputs=[MissingInput(field_path=error.field_path, reason=error.reason)],
            )

    def compare(self, query: CanonicalQuery) -> OperationEnvelope[EvidencePacket]:
        try:
            context = self.planner.resolve(query)
            packet_id = "evidence_" + context.plan.plan_hash.removeprefix("sha256:")
            path = self.store.root / f"{packet_id}.json"
            if path.exists() or path.is_symlink():
                saved_plan, packet = self.store.load(packet_id)
                if saved_plan != context.plan:
                    raise EvidenceStoreError(
                        "stored plan differs from its content-addressed identity"
                    )
                return _envelope(packet)
            packet = _packet(context, aggregate(context), packet_id)
            try:
                self.store.save(context.plan, packet)
            except EvidenceStoreError:
                # Identical concurrent runs may differ only in their first publication time.
                saved_plan, saved_packet = self.store.load(packet_id)
                if saved_plan != context.plan or saved_packet.model_dump(
                    exclude={"created_at"}
                ) != packet.model_dump(exclude={"created_at"}):
                    raise
                packet = saved_packet
            return _envelope(packet)
        except AnalysisInputError as error:
            return OperationEnvelope(
                operation="compare_acquisition",
                status=OperationStatus.NEEDS_INPUT,
                missing_inputs=[MissingInput(field_path=error.field_path, reason=error.reason)],
            )
        except EvidenceStoreError:
            return OperationEnvelope(
                operation="compare_acquisition",
                status=OperationStatus.NEEDS_INPUT,
                missing_inputs=[
                    MissingInput(
                        field_path="/evidence_store",
                        reason="immutable evidence could not be read or retained; "
                        "inspect local storage without overwriting history",
                    )
                ],
            )
        except ValidationError:
            return OperationEnvelope(
                operation="compare_acquisition",
                status=OperationStatus.NEEDS_INPUT,
                missing_inputs=[
                    MissingInput(field_path="/query", reason="analysis contract validation failed")
                ],
            )


def _envelope(packet: EvidencePacket) -> OperationEnvelope[EvidencePacket]:
    partial = bool(packet.missing_inputs)
    return OperationEnvelope(
        operation="compare_acquisition",
        result=packet,
        status=OperationStatus.PARTIAL_RESULT if partial else OperationStatus.COMPLETE,
        missing_inputs=packet.missing_inputs,
        issues=[
            OperationIssue(
                code="incomplete_comparison_inputs",
                severity=IssueSeverity.WARNING,
                message="Some source/metric scopes are incomplete; affected claims are prohibited.",
            )
        ]
        if partial
        else [],
    )


def _packet(
    context: AnalysisContext, aggregates: list[MetricAggregate], packet_id: str
) -> EvidencePacket:
    plan = context.plan
    # Channel totals cannot become complete merely because an entirely absent
    # selected account failed to seed an aggregate. Its goal membership is unknown,
    # so conservatively qualify every scope on that platform for the affected window.
    incomplete_platform_windows = {
        (source.platform, window)
        for source in plan.sources
        for window in ("current", "baseline")
        if not any(
            source.binding_id in item.binding_ids and item.window == window for item in aggregates
        )
    }
    for item in aggregates:
        if (item.platform, item.window) in incomplete_platform_windows:
            item.complete = False
            item.reasons = sorted(set(item.reasons) | {"missing_selected_source_window"})
    snapshots = {s.source_snapshot_id: s for source in plan.sources for s in source.snapshots}
    facts = []
    warnings = [
        EvidenceWarning(code=code, message=code.replace("_", " ")) for code in plan.warnings
    ]
    missing = []
    allowed = []
    by_id = {}
    observations = {}
    for item in aggregates:
        evidence_id = "ev_" + item.aggregate_id.removeprefix("agg_")
        by_id[item.aggregate_id] = evidence_id
        if not item.source_snapshot_ids:
            # A group seeded by another metric still has source context, not invented rows.
            item.source_snapshot_ids = sorted(snapshots)
        fact = EvidenceItem(
            evidence_id=evidence_id,
            kind=EvidenceKind.METRIC,
            metric=item.metric,
            statement=f"{item.window} {item.dimensions}: {item.metric.value}; "
            + (
                "complete measured scope"
                if item.complete
                else "incomplete observed scope, not a complete period total"
            ),
            value=None if item.computation.value is None else str(item.computation.value),
            unit=_fact_unit(item),
            source_snapshot_ids=item.source_snapshot_ids,
            details=item.model_dump(mode="json"),
        )
        facts.append(fact)
        if item.computation.value is not None:
            qualifiers = sorted(
                set(item.reasons) | {w.value for w in item.computation.interpretation_warnings}
            )
            allowed.append(
                AllowedClaim(
                    claim_id="claim_fact_" + item.aggregate_id.removeprefix("agg_"),
                    statement=f"Observed {item.metric.value} arithmetic: {item.computation.value}; "
                    f"scope={item.scope_key}, window={item.window}. "
                    f"Qualifications: {', '.join(qualifiers) or 'none'}. "
                    "This is not a winner or causal claim.",
                    evidence_refs=[evidence_id],
                )
            )
        codes = (
            set(item.reasons)
            | set(item.evidence_sufficiency_reasons)
            | {w.value for w in item.computation.interpretation_warnings}
        )
        for code in sorted(codes):
            warnings.append(
                EvidenceWarning(
                    code=code, message=code.replace("_", " "), affected_evidence_refs=[evidence_id]
                )
            )
        if not item.complete:
            missing.append(
                MissingInput(
                    field_path=f"/aggregates/{item.aggregate_id}",
                    reason="; ".join(item.reasons) or "incomplete coverage",
                )
            )
    for source in plan.sources:
        for window, period in (("current", plan.period), ("baseline", plan.baseline)):
            if any(
                source.binding_id in item.binding_ids and item.window == window
                for item in aggregates
            ):
                continue
            missing.append(
                MissingInput(
                    field_path=f"/sources/{source.binding_id}/windows/{window}",
                    reason=f"selected source has no matching observations in the {window} "
                    f"window ({period.start} through {period.end}); "
                    "no zero values were invented",
                )
            )
            if source.snapshots:
                facts.append(
                    EvidenceItem(
                        evidence_id="ev_source_" + content_hash([source.binding_id, window])[7:31],
                        kind=EvidenceKind.DATA_HEALTH,
                        statement=f"Selected source has no matching {window}-window "
                        "performance observations.",
                        source_snapshot_ids=[s.source_snapshot_id for s in source.snapshots],
                        details={
                            "binding_id": source.binding_id,
                            "platform": source.platform.value,
                            "window": window,
                            "period": period.model_dump(mode="json"),
                        },
                    )
                )
    comparisons = []
    missing_period_claims = []
    current = [item for item in aggregates if item.window == "current"]
    baseline = {
        (item.scope_key, item.metric): item for item in aggregates if item.window == "baseline"
    }
    for left, right in combinations(current, 2):
        if left.metric != right.metric or left.platform == right.platform:
            continue
        if any(
            left.dimensions.get(key) != right.dimensions.get(key)
            for key in ("country", "os", "event_date")
        ):
            continue
        comparisons.append(
            compare_aggregates(
                left,
                right,
                profile=context.profile.profile,
                policy=plan.evidence_policy,
                evidence_refs=[by_id[left.aggregate_id], by_id[right.aggregate_id]],
            )
        )
    if CanonicalDimension.EVENT_DATE not in plan.effective_grain:
        current_by_scope = {(item.scope_key, item.metric): item for item in current}
        for scope in sorted(set(current_by_scope) | set(baseline)):
            left = current_by_scope.get(scope)
            right = baseline.get(scope)
            if left is not None and right is not None:
                comparisons.append(
                    compare_aggregates(
                        left,
                        right,
                        profile=context.profile.profile,
                        policy=plan.evidence_policy,
                        evidence_refs=[by_id[left.aggregate_id], by_id[right.aggregate_id]],
                        comparison_type="period_change",
                    )
                )
                continue
            present = left if left is not None else right
            assert present is not None
            missing_window = "baseline" if left is not None else "current"
            reason = (
                f"no {missing_window} aggregate matches the exact semantic scope for "
                f"{present.metric.value}; no zero value or period change was inferred"
            )
            missing.append(
                MissingInput(
                    field_path=f"/comparisons/{present.scope_key}/{present.metric.value}/"
                    f"{missing_window}",
                    reason=reason,
                )
            )
            warnings.append(
                EvidenceWarning(
                    code="missing_period_counterpart",
                    message=reason,
                    affected_evidence_refs=[by_id[present.aggregate_id]],
                )
            )
            missing_period_claims.append(
                ProhibitedClaim(
                    statement=f"Report a {present.metric.value} period change for scope "
                    f"{present.scope_key} using an absent {missing_window} counterpart.",
                    reason=reason,
                )
            )
    else:
        warnings.append(
            EvidenceWarning(
                code="daily_grain_no_period_delta",
                message="Daily facts are preserved; baseline-day alignment is not inferred.",
            )
        )
    comparison_claims, prohibited = claims_for_comparisons(comparisons)
    allowed.extend(comparison_claims)
    prohibited.extend(missing_period_claims)
    prohibited.extend(
        [
            ProhibitedClaim(
                statement="Do not claim causation, statistical significance, an overall winner, "
                "free acquisition, unique-payer CAC, or financial ROI.",
                reason="Media-side observational arithmetic does not establish these claims.",
            ),
            ProhibitedClaim(
                statement="Do not rank outcomes from directional, not-comparable, or "
                "insufficient-evidence cells; do not hide warnings or omitted scopes.",
                reason="Only explicitly permitted metric-specific claims are supported.",
            ),
            ProhibitedClaim(
                statement="Do not describe synthetic data or policies as live reconciliation.",
                reason="Import-based engineering validation is separate from Adapter validation.",
            ),
        ]
    )
    for cell in context.cells.values():
        for row in cell.records:
            if any(row.observation_id in item.observation_ids for item in aggregates):
                observations[row.observation_id] = row.revision
    metric_versions = {
        metric: DEFAULT_METRIC_REGISTRY.definition(metric).semantic_version
        for metric in set(plan.query.metrics) | set(plan.component_metrics)
    }
    return EvidencePacket(
        packet_id=packet_id,
        created_at=datetime.now(UTC),
        scope=EvidenceScope(
            product_id=plan.query.product_id,
            period=plan.period,
            baseline=plan.baseline,
            platforms=plan.query.platforms,
        ),
        verified_facts=facts,
        comparisons=comparisons,
        warnings=warnings,
        missing_inputs=missing,
        allowed_claims=allowed,
        prohibited_claims=prohibited,
        insufficient_evidence=[
            InsufficientEvidenceItem(
                subject=cell.comparison_id,
                reason="; ".join(cell.reasons),
                required_evidence=[
                    "compatible mature observations and a configured versioned sufficiency policy"
                ],
            )
            for cell in comparisons
            if cell.status is ComparisonStatus.INSUFFICIENT_EVIDENCE
        ],
        lineage=EvidenceLineage(
            pallas_version=__version__,
            profile_revision=plan.profile_revision,
            profile_hash=plan.profile_hash,
            data_revision=plan.data_revision,
            query_id=plan.query.query_id,
            metric_semantic_versions=metric_versions,
            query_plan_hashes=[plan.plan_hash],
            source_snapshot_ids=sorted(snapshots),
            observation_revisions=observations,
            calculation_policy_version="1.1.0",
            comparison_policy_version="1.0.0",
            evidence_policy_version=plan.evidence_policy.version,
            evidence_policy_hash=content_hash(plan.evidence_policy.model_dump(mode="json")),
            source_content_hashes={key: snapshots[key].content_hash for key in sorted(snapshots)},
            import_format_versions={
                key: snapshots[key].import_format_version for key in sorted(snapshots)
            },
            maturity_policy_versions={
                key: sorted({p.policy_version for p in context.manifests[key].maturity_policies})
                for key in sorted(snapshots)
            },
            coverage_snapshot_ids=sorted(
                key for key in snapshots if context.manifests[key].coverage is not None
            ),
        ),
    )


def _fact_unit(item: MetricAggregate) -> str:
    unit = item.computation.unit.value
    if unit == "currency":
        return item.currency or "unknown_currency"
    if unit == "currency_per_action":
        return f"{item.currency or 'unknown_currency'}/action"
    if unit == "currency_per_thousand":
        return f"{item.currency or 'unknown_currency'}/1000_impressions"
    return unit
