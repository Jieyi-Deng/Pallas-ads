"""Build a self-contained acceptance bundle, explicitly excluding old user state."""

import hashlib
import json
import shutil
import tempfile
import zipfile
from pathlib import Path


def build_bundle(wheel: Path, output: Path):
    from pallas_ads import __version__

    if wheel.name != f"pallas_ads-{__version__}-py3-none-any.whl" or wheel.is_symlink():
        raise ValueError("Use the matching built Pallas wheel.")
    from pallas_ads.google_application import RESOURCE, validate_client

    with zipfile.ZipFile(wheel) as archive:
        if "pallas_ads/machine_setup.py" not in archive.namelist():
            raise ValueError("Wheel lacks new-machine setup.")
        embedded = RESOURCE in archive.namelist()
        if embedded:
            if archive.getinfo(RESOURCE).file_size > 65536:
                raise ValueError("Invalid application resource size.")
            application = json.loads(archive.read(RESOURCE))
            if application != validate_client(application):
                raise ValueError("Release resource must contain only Desktop application fields.")
    if output.exists() or output.is_symlink() or any(p.is_symlink() for p in output.parents):
        raise ValueError("Choose a new private output directory.")
    resources = Path(__file__).parent / "resources/distribution"
    if not resources.is_dir():
        resources = Path(__file__).parents[2]
        installer = resources / "examples/distribution/install_macos.py"
        guide = resources / "docs/NEW_MACHINE_TESTING.md"
    else:
        installer, guide = resources / "install_macos.py", resources / "NEW_MACHINE_TESTING.md"
    output.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(dir=output.parent) as temporary:
        stage = Path(temporary) / "bundle"
        stage.mkdir(mode=0o700)
        for source in (wheel, installer, guide):
            shutil.copyfile(source, stage / source.name)
        file_guide = guide.with_name("FILE_IMPORT.md")
        shutil.copyfile(file_guide, stage / "FILE_IMPORT.md")
        samples = Path(__file__).parent / "resources/file_samples"
        shutil.copytree(samples, stage / "samples")
        (stage / "release-manifest.json").write_text(
            json.dumps(
                {
                    "version": __version__,
                    "wheel": wheel.name,
                    "sha256": hashlib.sha256(wheel.read_bytes()).hexdigest(),
                    "target": "macOS + Codex / Claude Code",
                    "default_mode": "core",
                    "google_application_embedded": embedded,
                    "requires_google_configuration_file": False,
                    "contains_user_oauth_tokens": False,
                    "contains_localhost_private_key": False,
                },
                indent=2,
            )
            + "\n"
        )
        for file in stage.iterdir():
            file.chmod(0o700 if file.is_dir() else 0o600)
        stage.rename(output)
    return {
        "directory": str(output.absolute()),
        "self_contained_bundle": True,
        "next_step": "Read NEW_MACHINE_TESTING.md; platform eligibility needs live verification.",
    }
