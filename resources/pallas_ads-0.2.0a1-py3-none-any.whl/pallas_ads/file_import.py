"""Bounded local export preview/confirmation. No OAuth, network or canonical writes."""

import csv
import hashlib
import io
import json
import re
import zipfile
from datetime import UTC, date, datetime
from decimal import Decimal, InvalidOperation
from itertools import islice
from pathlib import Path
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

from pallas_ads.contracts.base import reject_secret_material
from pallas_ads.contracts.source import SourceRecord
from pallas_ads.contracts.status import OperationEnvelope, OperationIssue
from pallas_ads.observation_diagnostics import diagnose
from pallas_ads.observation_rendering import dump, save_report

MAX_BYTES = 8 * 1024 * 1024
MAX_ROWS = 50000
FIELDS = {
    "date": ["date", "day", "reporting starts", "日期", "天"],
    "date_end": ["reporting ends", "结束日期"],
    "account_id": ["account_id", "account id", "customer id", "advertiser id", "账户编号"],
    "campaign_id": ["campaign_id", "campaign id", "campaign ID", "广告系列编号"],
    "campaign_name": ["campaign_name", "campaign name", "campaign", "广告系列名称"],
    "spend": ["spend", "cost", "amount spent", "amount spent (usd)", "花费", "费用"],
    "impressions": ["impressions", "impr.", "展示次数"],
    "clicks": ["clicks", "clicks (all)", "点击次数", "点击量（全部）"],
    "currency": ["currency", "currency code", "币种"],
    "timezone": ["timezone", "time zone", "时区"],
    "conversions": ["conversions", "purchases", "转化次数"],
    "conversion_value": ["conversion_value", "conversion value", "conv. value", "转化价值"],
}
REQUIRED = {"date", "campaign_id", "spend", "impressions", "clicks"}


class ExportError(ValueError):
    """Safe, actionable diagnostic: never include a cell's supplied value."""


def read_table(path, options):
    if path.is_symlink() or not path.is_file() or path.stat().st_size > MAX_BYTES:
        raise ExportError("Use a regular CSV/XLSX file up to 8 MiB; links are not accepted.")
    raw = path.read_bytes()
    if len(raw) > MAX_BYTES:
        raise ExportError("File exceeds 8 MiB.")
    if path.suffix.lower() == ".csv":
        try:
            rows = list(
                islice(
                    csv.reader(
                        io.StringIO(raw.decode("utf-8-sig")),
                        delimiter=options.delimiter,
                        strict=True,
                    ),
                    MAX_ROWS + 21,
                )
            )
        except (UnicodeError, csv.Error):
            raise ExportError("CSV must be UTF-8 with the selected delimiter.") from None
        sheet = None
    elif path.suffix.lower() == ".xlsx":
        try:
            with zipfile.ZipFile(io.BytesIO(raw)) as archive:
                infos = archive.infolist()
                if len(infos) > 500 or sum(i.file_size for i in infos) > 40 * 1024 * 1024:
                    raise ExportError("Workbook exceeds the decompressed-size limit.")
                if any("vbaProject" in i.filename for i in infos):
                    raise ExportError("Macro-enabled workbooks are not supported.")
                # Reject DTDs before any XML is parsed, including shared strings.
                if any(
                    b"<!DOCTYPE" in archive.read(i).upper()
                    for i in infos
                    if i.filename.endswith(".xml")
                ):
                    raise ExportError("Workbook XML declarations are not supported.")
            from openpyxl import load_workbook

            book = load_workbook(io.BytesIO(raw), read_only=True, data_only=False, keep_links=False)
            try:
                if options.sheet is None and len(book.sheetnames) != 1:
                    raise ExportError("Select one worksheet by name; sheets are never combined.")
                sheet = options.sheet or book.sheetnames[0]
                if sheet not in book.sheetnames:
                    raise ExportError("Selected worksheet does not exist.")
                ws = book[sheet]
                if (ws.max_row or 0) > MAX_ROWS + 20 or (ws.max_column or 0) > 100:
                    raise ExportError("Worksheet exceeds 50,000 data rows or 100 columns.")
                ws.reset_dimensions()  # Do not trust stale/incorrect producer dimensions.
                rows = []
                for cells in ws.iter_rows():
                    if len(cells) > 100:
                        raise ExportError("Worksheet exceeds 100 columns.")
                    if any(c.data_type in ("f", "e") for c in cells):
                        raise ExportError(
                            "Export values only: formulas and Excel errors are not accepted."
                        )
                    row_values = [c.value for c in cells]
                    # OOXML omits trailing empty cells; preserve them as nulls.
                    if len(rows) >= options.header_row:
                        width = len(rows[options.header_row - 1])
                        row_values.extend([None] * max(0, width - len(row_values)))
                    rows.append(row_values)
                    if len(rows) > MAX_ROWS + 20:
                        raise ExportError("Too many worksheet rows.")
            finally:
                book.close()
        except ExportError:
            raise
        except Exception:
            raise ExportError(
                "Cannot read this XLSX; use an unencrypted values-only export."
            ) from None
    else:
        raise ExportError("Only .csv and .xlsx are supported; legacy .xls is not supported.")
    if not options.header_row <= len(rows):
        raise ExportError("Header row is outside the file.")
    headers = [str(v).strip() if v is not None else "" for v in rows[options.header_row - 1]]
    if (
        not headers
        or len(headers) > 100
        or any(not h for h in headers)
        or len(set(headers)) != len(headers)
    ):
        raise ExportError("Use 1–100 nonempty, unique column headers.")
    if len(rows) - options.header_row > MAX_ROWS:
        raise ExportError("File exceeds 50,000 data rows.")
    body = []
    for line, row in enumerate(rows[options.header_row :], options.header_row + 1):
        if all(v is None or str(v).strip() == "" for v in row):
            continue
        if len(row) != len(headers):
            raise ExportError(f"Row {line}: column count differs from the header.")
        try:
            reject_secret_material(dict(zip(headers, row, strict=True)))
        except ValueError:
            raise ExportError(f"Row {line}: credential-shaped data is not accepted.") from None
        body.append((line, dict(zip(headers, row, strict=True))))
    if not body:
        raise ExportError("No data rows; an empty file does not establish zero spend.")
    return raw, headers, body, sheet


def text_cell(value, field, line):
    if value is None or str(value).strip() == "":
        return None
    if (
        isinstance(value, bool)
        or isinstance(value, (float, int))
        and (not isinstance(value, int) or abs(value) >= 10**15)
    ):
        raise ExportError(
            f"Row {line}: {field} must be text; Excel numeric IDs can lose precision."
        )
    text = str(value).strip()
    if len(text) > 300 or any(ord(c) < 32 for c in text):
        raise ExportError(f"Row {line}: invalid {field} text.")
    return text


def decimal_cell(value, field, line):
    if value is None or str(value).strip() in ("", "—", "--", "N/A", "null"):
        return None
    s = str(value).strip()
    if isinstance(value, bool) or not re.fullmatch(r"(?:\d{1,3}(?:,\d{3})+|\d+)(?:\.\d+)?", s):
        raise ExportError(
            f"Row {line}: {field} requires a nonnegative decimal; no symbols or percentages."
        )
    try:
        number = Decimal(s.replace(",", ""))
    except InvalidOperation:
        raise ExportError(f"Row {line}: invalid {field}.") from None
    exponent = number.as_tuple().exponent
    if number > Decimal("1e18") or not isinstance(exponent, int) or -exponent > 12:
        raise ExportError(f"Row {line}: {field} exceeds supported numeric precision.")
    if field in ("impressions", "clicks") and number != number.to_integral_value():
        raise ExportError(f"Row {line}: {field} must be an integer count.")
    return number


def date_cell(value, line):
    if isinstance(value, datetime):
        if value.time().isoformat() != "00:00:00":
            raise ExportError(f"Row {line}: daily dates cannot include a time.")
        return value.date().isoformat()
    if isinstance(value, date):
        return value.isoformat()
    if not isinstance(value, str) or not re.fullmatch(r"\d{4}-\d{2}-\d{2}", value.strip()):
        raise ExportError(f"Row {line}: use ISO YYYY-MM-DD dates (daily campaign rows only).")
    try:
        return date.fromisoformat(value.strip()).isoformat()
    except ValueError:
        raise ExportError(f"Row {line}: invalid calendar date.") from None


def prepare(path, options):
    raw, headers, body, sheet = read_table(path, options)
    mapping = {}
    if set(options.column_mapping) - set(FIELDS):
        raise ExportError("Mapping contains unsupported target fields; use the documented schema.")
    for target, aliases in FIELDS.items():
        candidates = [h for h in headers if h.casefold() in {a.casefold() for a in aliases}]
        if target in options.column_mapping:
            candidates = [options.column_mapping[target]]
        if len(candidates) > 1:
            raise ExportError(
                f"Multiple columns match {target}; choose one explicit column_mapping."
            )
        if candidates:
            if candidates[0] not in headers:
                raise ExportError(f"Mapped column for {target} is absent.")
            mapping[target] = candidates[0]
    if REQUIRED - mapping.keys():
        raise ExportError("Map required columns: " + ", ".join(sorted(REQUIRED - mapping.keys())))
    if len(set(mapping.values())) != len(mapping):
        raise ExportError("Each input column may map to only one field.")
    metadata: dict[str, str] = {}
    missing_metadata = []
    for field in ("account_id", "currency", "timezone"):
        observed = (
            {text_cell(r.get(mapping[field]), field, line) for line, r in body}
            if field in mapping
            else set()
        )
        observed.discard(None)
        if len(observed) > 1:
            raise ExportError(
                f"Multiple {field} values; export one account/currency/timezone per file."
            )
        supplied = getattr(options, field)
        if observed and supplied is not None and supplied not in observed:
            raise ExportError(f"Supplied {field} conflicts with file values.")
        resolved = supplied or next(iter(observed), None)
        if resolved is None:
            missing_metadata.append(field)
        else:
            metadata[field] = resolved
    if missing_metadata:
        raise ExportError("Confirm missing import_options: " + ", ".join(missing_metadata))
    if not re.fullmatch(r"[A-Z]{3}", metadata["currency"]):
        raise ExportError("Currency must be an uppercase three-letter ISO code.")
    try:
        ZoneInfo(metadata["timezone"])
    except (ZoneInfoNotFoundError, ValueError):
        raise ExportError(
            "Timezone must be a valid IANA name, such as America/Los_Angeles."
        ) from None
    # Currency-bearing headers are explicit evidence, even with a custom spend mapping.
    m = re.search(r"\(([A-Za-z]{3})\)$", mapping["spend"])
    if m and m[1].upper() != metadata["currency"]:
        raise ExportError("Spend header currency conflicts with the selected currency.")
    rows, seen, names = [], set(), {}
    for line, source in body:
        item = {f: source.get(h) for f, h in mapping.items()}
        day = date_cell(item["date"], line)
        if item.get("date_end") is not None and date_cell(item["date_end"], line) != day:
            raise ExportError(f"Row {line}: aggregated date ranges are not daily observations.")
        campaign = text_cell(item["campaign_id"], "campaign_id", line)
        if not campaign:
            raise ExportError(f"Row {line}: campaign_id is required; remove summary rows.")
        key = campaign, day
        if key in seen:
            raise ExportError(f"Row {line}: duplicate campaign/date; remove totals or breakdowns.")
        seen.add(key)
        name = text_cell(item.get("campaign_name"), "campaign_name", line) or campaign
        if campaign in names and names[campaign] != name:
            raise ExportError(f"Row {line}: conflicting campaign names; retain a consistent label.")
        names[campaign] = name
        values = {
            f: decimal_cell(item.get(f), f, line)
            for f in ("spend", "impressions", "clicks", "conversions", "conversion_value")
        }
        rows.append({"campaign_id": campaign, "date": day, "source_row": line, **values})
    observed_dates = sorted({r["date"] for r in rows})
    expected = (
        date.fromisoformat(observed_dates[-1]) - date.fromisoformat(observed_dates[0])
    ).days + 1
    continuous = len(observed_dates) == expected
    summary = {
        "platform": str(options.platform),
        **metadata,
        "grain": "campaign_day",
        "sheet": sheet,
        "row_count": len(rows),
        "campaign_count": len(names),
        "period": {"start": observed_dates[0], "end": observed_dates[-1]},
        "observed_dates_continuous": continuous,
        "column_mapping": mapping,
        "ignored_columns": [h for h in headers if h not in mapping.values()],
        "missing_values": {
            f: sum(r[f] is None for r in rows) for f in ("spend", "impressions", "clicks")
        },
        "conversion_event": options.conversion_event,
        "attribution_window": options.attribution_window,
        "reporting_time_basis": options.reporting_time_basis,
        "coverage": "file_rows_only_not_verified_against_platform",
    }
    content = {
        "format_version": "1.0",
        "source_sha256": hashlib.sha256(raw).hexdigest(),
        "options": options.model_dump(mode="json"),
        "summary": summary,
        "campaign_names": names,
        "rows": rows,
    }
    encoded = dump(content).encode()
    return content, encoded, hashlib.sha256(encoded).hexdigest()


def stage_file(workspace, request):
    if not request.file_path or request.import_options is None:
        raise ExportError(
            "Supply file_path and import_options.platform; no media authorization is needed."
        )
    content, encoded, digest = prepare(Path(request.file_path), request.import_options)
    identifier = "file_" + digest
    if request.action == "file_preview":
        return OperationEnvelope(
            operation="source_connect_or_import",
            status="pending_user_action",
            issues=[
                OperationIssue(
                    code="file_interpretation_confirmation",
                    severity="info",
                    message="Confirm the preview before importing.",
                )
            ],
            result={
                "review_hash": digest,
                "summary": content["summary"],
                "preview_rows": json.loads(dump(content["rows"][:5])),
                "next_step": (
                    "Show account, platform, period, mapping, units and missing values; "
                    "confirm this interpretation before file_import."
                ),
                "canonical_data_written": False,
            },
        )
    if request.review_hash != digest or request.user_confirmed is not True:
        raise ExportError(
            "Confirm this exact interpretation; changed files/options need a new preview."
        )
    root = workspace.layout.root / "file_imports"
    if root.is_symlink():
        raise ExportError("Import storage cannot be a symlink.")
    root.mkdir(mode=0o700, parents=True, exist_ok=True)
    path = root / (identifier + ".json")
    reused = path.exists()
    if reused:
        if path.is_symlink() or path.read_bytes() != encoded:
            raise ExportError("Retained file integrity mismatch; existing data was preserved.")
    else:
        with path.open("xb") as handle:
            path.chmod(0o600)
            handle.write(encoded)
    return OperationEnvelope(
        operation="source_connect_or_import",
        status="complete",
        result={
            "dataset_id": identifier,
            "summary": content["summary"],
            "reused": reused,
            "canonical_data_written": False,
            "next_step": "build_report(action=file_review,dataset_id=...)",
        },
    )


def file_report(workspace, identifier):
    path = workspace.layout.root / "file_imports" / (identifier + ".json")
    if path.is_symlink() or path.parent.is_symlink() or path.stat().st_size > 64 * 1024 * 1024:
        raise ExportError("Invalid retained dataset.")
    raw = path.read_bytes()
    if "file_" + hashlib.sha256(raw).hexdigest() != identifier:
        raise ExportError("Retained dataset integrity mismatch.")
    data = json.loads(raw)
    s = data["summary"]
    records = [
        SourceRecord(
            account_id=s["account_id"],
            entity_id=r["campaign_id"],
            event_date=date.fromisoformat(r["date"]),
            values={f: r[f] for f in ("spend", "impressions", "clicks")},
        )
        for r in data["rows"]
    ]
    d = diagnose(records)
    if not s["observed_dates_continuous"]:
        d["change"] = None
        d["anomalies"] = []
        d["insights"] = [i for i in d["insights"] if i["title"] == "花费集中度"]
    d["restart_experiments"] = []
    positive = sorted(
        {r["date"] for r in data["rows"] if r["spend"] is not None and Decimal(r["spend"]) > 0}
    )
    context = {
        "campaign_configuration": [
            {"campaign_id": k, "native": {"name": v}} for k, v in data["campaign_names"].items()
        ],
        "product_resolution": [],
        "optimization_context": [],
    }
    limitations = [
        "用户文件快照；没有读取媒体账户，不能据此确认当前授权或完整历史。",
        "只汇总文件中的系列/日期行；缺失日期及空值不补零，文件外的系列未纳入。",
        "比率用汇总分子/分母计算；媒体点击口径、历史优化目标和转化归因仍待核实。",
        "CPM/CTR 对 CPC 的分解是算术关系，不证明竞价、素材或受众变化的因果。",
        "不同文件独立保存；重复导入幂等，重叠文件不自动相加或覆盖。",
    ]
    if not s["observed_dates_continuous"]:
        limitations.append("文件存在日期断档，未生成前后区间变化结论。")
    report = {
        "schema_version": "2.0.0",
        "kind": "account_observation_report",
        "evidence_mode": "user_file",
        "created_at": datetime.now(UTC).isoformat(),
        "scope": {
            **s,
            "selection": "file_snapshot",
            "requested_period": s["period"],
            "first_observed_spend_date": positive[0] if positive else None,
            "last_observed_spend_date": positive[-1] if positive else None,
            "diagnostic_comparison_period": s["period"],
            "diagnostic_comparison_policy": "explicit_period",
            "canonical_imported": False,
            "dense_coverage_verified": False,
        },
        "context": context,
        "diagnostics": d,
        "native_outcomes": [],
        "delivered_audience": [],
        "attempts": [],
        "limitations": limitations,
        "file_source": {"dataset_id": identifier, **data},
        "evidence": [],
    }
    artifacts = save_report(workspace, report)
    return OperationEnvelope(
        operation="build_report",
        status="partial_result",
        issues=[
            OperationIssue(
                code="file_coverage_unverified",
                severity="warning",
                message="File coverage and business outcome semantics remain unverified.",
            )
        ],
        result={
            "dataset_id": identifier,
            "scope": report["scope"],
            "diagnostics": d,
            "limitations": limitations,
            "artifacts": artifacts,
            "next_step": (
                "Separate facts, arithmetic drivers and business hypotheses; "
                "ask only missing business context."
            ),
        },
    )
