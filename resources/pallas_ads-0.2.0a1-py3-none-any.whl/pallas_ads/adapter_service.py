"""Execute closed adapter plans, retain sanitized evidence, and expose qualified source facts."""

from __future__ import annotations

import hashlib
import hmac
import json
import os
import re
import shutil
import tempfile
from datetime import UTC, date, datetime, timedelta
from decimal import Decimal, InvalidOperation, localcontext
from uuid import uuid4
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

from pallas_ads.adapter_plans import plan_read
from pallas_ads.contracts.adapter import QueryMode
from pallas_ads.contracts.source import SourceReadRequest, SourceReadResult, SourceRecord
from pallas_ads.contracts.status import MissingInput, OperationEnvelope, OperationIssue
from pallas_ads.credential_store import CredentialError, CredentialStore
from pallas_ads.query_planner import content_hash
from pallas_ads.source_redaction import redact
from pallas_ads.source_state import SourceStateStore
from pallas_ads.source_transport import HTTPTransport, SourceHTTPError, Transport


def _get(row, path):
    value = row
    for key in path.split("."):
        if not isinstance(value, dict) or key not in value:
            return None
        value = value[key]
    return value


def _decimal(value, *, micros=False):
    if value is None or isinstance(value, bool):
        return None
    try:
        result = Decimal(str(value))
        if not result.is_finite() or result < 0:
            return None
        if micros:
            with localcontext() as context:
                context.prec = max(context.prec, len(result.as_tuple().digits) + 6)
                result /= 1_000_000
        return result
    except InvalidOperation:
        return None


def _pages(platform, mode, payload):
    """Return rows and an opaque cursor. Never follow a provider-supplied next URL."""
    if not isinstance(payload, dict):
        raise SourceHTTPError("response_schema_changed")
    if platform == "meta":
        if "error" in payload:
            code = payload["error"].get("code") if isinstance(payload["error"], dict) else None
            raise SourceHTTPError(
                "authentication_failed" if code == 190 else "provider_request_failed"
            )
        rows = [payload] if mode == QueryMode.ACCOUNT_CONTEXT else payload.get("data")
        paging = payload.get("paging", {})
        cursor = _get(paging, "cursors.after") if paging.get("next") else None
        if paging.get("next") and not cursor:
            raise SourceHTTPError("pagination_schema_changed")
    elif platform == "tiktok":
        if payload.get("code") != 0:
            raise SourceHTTPError("provider_request_failed")
        data = payload.get("data")
        rows = (
            data
            if mode == QueryMode.ACCOUNT_CONTEXT and isinstance(data, list)
            else _get(data, "list")
        )
        page_info = _get(data, "page_info")
        cursor = None
        if isinstance(page_info, dict):
            try:
                page, total = int(page_info["page"]), int(page_info["total_page"])
                if page < 1 or total < 0 or (total and total < page):
                    raise ValueError
                cursor = page + 1 if page < total else None
            except (KeyError, ValueError, TypeError):
                raise SourceHTTPError("pagination_schema_changed") from None
        elif mode in (
            QueryMode.ENTITY_CONFIGURATION,
            QueryMode.TRAFFIC_PERFORMANCE,
            QueryMode.CONVERSION_PERFORMANCE,
        ):
            raise SourceHTTPError("pagination_schema_changed")
    else:
        if "error" in payload:
            raise SourceHTTPError("provider_request_failed")
        if mode == QueryMode.CAPABILITY_PROBE:
            names = payload.get("resourceNames", [])
            if not isinstance(names, list) or any(not isinstance(v, str) for v in names):
                raise SourceHTTPError("response_schema_changed")
            rows = [{"account_id": value.removeprefix("customers/")} for value in names]
        else:
            if "results" not in payload and set(payload) - {
                "fieldMask",
                "requestId",
                "totalResultsCount",
                "queryResourceConsumption",
            }:
                raise SourceHTTPError("response_schema_changed")
            rows = payload.get("results", [])
        cursor = payload.get("nextPageToken")
    if not isinstance(rows, list) or any(not isinstance(r, dict) for r in rows):
        raise SourceHTTPError("response_schema_changed")
    if cursor is not None and (
        isinstance(cursor, bool) or not isinstance(cursor, (str, int)) or len(str(cursor)) > 2048
    ):
        raise SourceHTTPError("pagination_schema_changed")
    return rows, cursor


def _record(plan, row):
    request = plan.request
    platform, mode = request.platform, request.mode
    warnings = []
    for field in plan.required_fields:
        if mode == QueryMode.CAPABILITY_PROBE and platform == "google":
            continue
        if _get(row, field) is None:
            warnings.append("missing_native_field:" + field)
    account = request.account_id
    if mode == QueryMode.CAPABILITY_PROBE:
        account = str(
            _get(
                row,
                {"meta": "account_id", "tiktok": "advertiser_id", "google": "account_id"}[platform],
            )
            or ""
        )
    elif mode == QueryMode.ACCOUNT_HIERARCHY:
        account = str(_get(row, "customerClient.id") or "")
    elif platform == "meta":
        returned = row.get("account_id")
        if returned is not None and str(returned) != account:
            raise SourceHTTPError("response_scope_mismatch")
    elif platform == "google" and mode == QueryMode.ACCOUNT_CONTEXT:
        if str(_get(row, "customer.id")) != account:
            raise SourceHTTPError("response_scope_mismatch")
    elif (
        platform == "tiktok"
        and mode == QueryMode.ACCOUNT_CONTEXT
        and str(row.get("advertiser_id")) != account
    ):
        raise SourceHTTPError("response_scope_mismatch")
    if not account or re.fullmatch(r"[0-9]+", account) is None:
        raise SourceHTTPError("response_schema_changed")
    entity = None
    if not request.context_kind and mode in (
        QueryMode.ENTITY_CONFIGURATION,
        QueryMode.TRAFFIC_PERFORMANCE,
        QueryMode.CONVERSION_PERFORMANCE,
    ):
        key = {
            "meta": "id" if mode == QueryMode.ENTITY_CONFIGURATION else "campaign_id",
            "tiktok": "campaign_id"
            if mode == QueryMode.ENTITY_CONFIGURATION
            else "dimensions.campaign_id",
            "google": "campaign.id",
        }[platform]
        if request.report_level == "adgroup":
            key = "adset_id" if platform == "meta" else "dimensions.adgroup_id"
        entity = _get(row, key)
        if entity is None or re.fullmatch(r"[0-9]+", str(entity)) is None:
            raise SourceHTTPError("response_schema_changed")
        entity = str(entity)
        if (
            request.report_level == "campaign"
            and request.campaign_ids
            and entity not in request.campaign_ids
        ):
            raise SourceHTTPError("response_scope_mismatch")
    observed_date = None
    values = {}
    metadata = dict(row)
    if mode in (QueryMode.ACCOUNT_CONTEXT, QueryMode.CAPABILITY_PROBE):
        currency = (
            _get(row, "customer.currencyCode") if platform == "google" else row.get("currency")
        )
        timezone = (
            _get(row, "customer.timeZone")
            if platform == "google"
            else row.get("timezone_name" if platform == "meta" else "timezone")
        )
        if currency is not None and re.fullmatch(r"[A-Z]{3}", str(currency)) is None:
            warnings.append("invalid_account_currency")
        if timezone is not None:
            try:
                ZoneInfo(str(timezone))
            except (ZoneInfoNotFoundError, ValueError):
                warnings.append("unverified_source_timezone")
        if mode == QueryMode.ACCOUNT_CONTEXT:
            metadata["account_currency"] = currency
            metadata["source_timezone"] = timezone
    if request.period or (request.query_lifetime and platform == "meta"):
        raw_date = _get(
            row,
            {"meta": "date_start", "tiktok": "dimensions.stat_time_day", "google": "segments.date"}[
                platform
            ],
        )
        try:
            observed_date = date.fromisoformat(str(raw_date)[:10])
        except ValueError:
            raise SourceHTTPError("response_date_invalid") from None
        if request.period and not request.period.start <= observed_date <= request.period.end:
            raise SourceHTTPError("response_scope_mismatch")
        if platform == "meta" and row.get("date_stop") != row.get("date_start"):
            raise SourceHTTPError("response_grain_mismatch")
    if mode == QueryMode.TRAFFIC_PERFORMANCE:
        fields = {"spend": "spend", "impressions": "impressions", "clicks": "clicks"}
        source = row if platform == "meta" else row.get("metrics", {})
        if platform == "google":
            fields["spend"] = "costMicros"
        for key, native in fields.items():
            values[key] = _decimal(
                source.get(native), micros=platform == "google" and key == "spend"
            )
            if values[key] is None:
                warnings.append("missing_or_invalid_metric:" + key)
        metadata["reporting_time_basis"] = "delivery_date"
        warnings.append("maturity_and_dense_coverage_unverified")
    if mode == QueryMode.CONVERSION_PERFORMANCE:
        warnings.append("native_conversion_semantics_unmapped")
        metadata["canonical_outcomes_authorized"] = False
    if mode == QueryMode.ENTITY_CONFIGURATION:
        metadata["configuration_context"] = "current_snapshot_only"
        metadata["canonical_optimization_goal"] = None
        warnings.append("campaign_goal_and_attribution_require_verified_context")
    if request.audience_dimension:
        dimension = request.audience_dimension
        native = "country_code" if platform == "tiktok" and dimension == "country" else dimension
        label = _get(row, "dimensions." + native) if platform == "tiktok" else row.get(native)
        if platform == "google":
            label = _get(
                row,
                {
                    "age": "adGroupCriterion.ageRange.type",
                    "gender": "adGroupCriterion.gender.type",
                    "country": "userLocationView.countryCriterionId",
                }[dimension],
            )
        if not isinstance(label, str) or len(label) > 128:
            raise SourceHTTPError("response_grain_mismatch")
        metadata["audience_segment"] = label
    if request.context_kind:
        from pallas_ads.context_plans import context_identity

        entity = context_identity(request, row)
    return SourceRecord(
        account_id=account,
        entity_id=entity,
        event_date=observed_date,
        values=values,
        metadata=metadata,
        warnings=warnings,
    )


class AdapterService:
    def __init__(
        self,
        workspace,
        *,
        credentials: CredentialStore | None = None,
        transport: Transport | None = None,
        clock=lambda: datetime.now(UTC),
        raw_retention_days: int = 90,
    ):
        if not 0 <= raw_retention_days <= 3650:
            raise ValueError("invalid raw retention period")
        self.workspace = workspace
        self.store = SourceStateStore(workspace.layout.root)
        self.credentials = credentials or CredentialStore()
        self.transport = transport or HTTPTransport()
        self.clock = clock
        self.raw_retention_days = raw_retention_days

    def read(self, connection_id: str, request: SourceReadRequest):
        pages, records, issues = [], [], []
        fd = None
        try:
            plan = plan_read(
                request
            )  # Regenerate internally; caller cannot submit a tampered native plan.
            request = plan.request
            fd = self.store.lock(connection_id)
            connection = self.store.load(connection_id)
            if (
                connection is None
                or connection.state != "connected"
                or connection.config.platform != request.platform
            ):
                raise CredentialError("source connection unavailable")
            if connection.expires_at is not None and self.clock() >= connection.expires_at:
                raise CredentialError("source credential expired")
            config = connection.config
            if config.transport == "official_mcp" and config.platform == "meta":
                raise SourceHTTPError("meta_mcp_data_adapter_pending")
            tokens = self.credentials.tokens(connection.credential_ref)
            if config.transport == "official_mcp":
                from pallas_ads.tiktok_mcp_reports import read_mcp

                return read_mcp(self, connection, request, tokens)
            sensitive = [tokens.access_token.get_secret_value()]
            if tokens.refresh_token:
                sensitive.append(tokens.refresh_token.get_secret_value())
            headers = {
                "Access-Token" if request.platform == "tiktok" else "Authorization": sensitive[0]
                if request.platform == "tiktok"
                else "Bearer " + sensitive[0]
            }
            parameters, body = (
                dict(plan.parameters),
                dict(plan.body) if plan.body is not None else None,
            )
            if request.query_lifetime and request.platform == "tiktok":
                parameters["query_lifetime"] = "true"
            if request.platform == "meta" and config.app_credential_ref is not None:
                value = self.credentials.read(config.app_credential_ref)
                proof = hmac.new(value.encode(), sensitive[0].encode(), hashlib.sha256).hexdigest()
                parameters["appsecret_proof"] = proof
                sensitive.extend([value, proof])
            if request.platform == "google":
                # Access is now attached to the OAuth Cloud project, not developer tokens.
                manager = request.manager_account_id or (
                    None if request.ignore_configured_manager else config.login_customer_id
                )
                if manager and request.mode != QueryMode.CAPABILITY_PROBE:
                    headers["login-customer-id"] = manager
            if request.platform == "tiktok" and request.mode == QueryMode.CAPABILITY_PROBE:
                if config.app_credential_ref is None or config.client_id is None:
                    raise CredentialError("TikTok app credential required for advertiser discovery")
                value = self.credentials.read(config.app_credential_ref)
                sensitive.append(value)
                parameters.update(app_id=config.client_id, secret=value)
            complete, seen = False, set()
            records_by_key = {}
            for _ in range(request.max_pages):
                try:
                    response = self.transport.request(
                        plan.method,
                        plan.endpoint,
                        headers=headers,
                        parameters=parameters,
                        body=body,
                    )
                    if response.status in (401, 403):
                        raise SourceHTTPError("authentication_or_permission_failed")
                    if response.status == 429 or response.status >= 500:
                        raise SourceHTTPError("provider_temporarily_unavailable", retriable=True)
                    if response.status != 200:
                        raise SourceHTTPError("provider_request_failed")
                    payload = redact(response.payload, tuple(sensitive))
                    if request.context_kind == "apps" and request.platform == "tiktok":
                        from pallas_ads.context_plans import sanitize_apps

                        payload = sanitize_apps(payload, request.account_id)
                    pages.append(payload)
                    rows, cursor = _pages(request.platform, request.mode, payload)
                    for row in rows:
                        try:
                            record = _record(plan, row)
                            key = (
                                record.account_id,
                                record.entity_id,
                                record.event_date,
                                _get(record.metadata, "segments.conversionAction"),
                                record.metadata.get("audience_segment"),
                            )
                            if key in records_by_key:
                                previous = records_by_key[key]
                                if previous is not None and previous != record:
                                    records.remove(previous)
                                    records_by_key[key] = None
                                issues.append(
                                    OperationIssue(
                                        code="duplicate_source_scope",
                                        message="Duplicate source scope excluded; conflicting rows "
                                        "are withheld. Inspect retained pages before retrying.",
                                    )
                                )
                            else:
                                records_by_key[key] = record
                                records.append(record)
                        except (ValueError, TypeError, AttributeError) as error:
                            code = (
                                error.code
                                if isinstance(error, SourceHTTPError)
                                else "response_schema_changed"
                            )
                            issues.append(
                                OperationIssue(
                                    code=code,
                                    message="A source row was excluded; inspect retained evidence.",
                                )
                            )
                    if cursor is None:
                        complete = True
                        break
                    if str(cursor) in seen:
                        raise SourceHTTPError("pagination_cycle")
                    seen.add(str(cursor))
                    if request.platform == "meta":
                        parameters["after"] = cursor
                    elif request.platform == "tiktok":
                        parameters["page"] = cursor
                    else:
                        assert body is not None
                        body["pageToken"] = cursor
                except SourceHTTPError as error:
                    issues.append(
                        OperationIssue(
                            code=error.code,
                            message="Source read incomplete; "
                            "inspect credentials, permissions or adapter compatibility.",
                            retriable=error.retriable,
                        )
                    )
                    break
            if not complete and not issues:
                issues.append(
                    OperationIssue(
                        code="page_limit_reached",
                        message="Read stopped at the configured page limit.",
                    )
                )
            if request.mode == QueryMode.ACCOUNT_CONTEXT and not records:
                issues.append(
                    OperationIssue(
                        code="missing_account_context",
                        message="Account settings were not returned.",
                    )
                )
            warnings = sorted({w for row in records for w in row.warnings})
            degraded = any(w.startswith(("missing_", "invalid_", "unverified_")) for w in warnings)
            if degraded:
                issues.append(
                    OperationIssue(
                        code="source_fields_incomplete",
                        message="Some returned source fields are missing or unverified.",
                    )
                )
            result = SourceReadResult(
                read_id="read_" + uuid4().hex,
                plan=plan,
                observed_at=self.clock(),
                records=records,
                pages_received=len(pages),
                pagination_complete=complete,
                warnings=warnings,
            )
            if self.raw_retention_days:
                result.artifact_path = self._retain(result, pages)
            status = "partial_result" if issues else "complete"
            if (
                issues
                and not records
                and any(
                    i.code in {"response_schema_changed", "pagination_schema_changed"}
                    for i in issues
                )
            ):
                status = "adapter_refresh_required"
            return OperationEnvelope(
                operation="source_read", status=status, result=result, issues=issues
            )
        except SourceHTTPError as error:
            return OperationEnvelope(
                operation="source_read",
                status="needs_input",
                missing_inputs=[
                    MissingInput(
                        field_path="/source",
                        reason="Check source authorization, account scope "
                        "and protocol compatibility.",
                    )
                ],
                issues=[
                    OperationIssue(
                        code=error.code,
                        message="Source read did not complete.",
                        retriable=error.retriable,
                    )
                ],
            )
        except (ValueError, OSError, TypeError):
            return OperationEnvelope(
                operation="source_read",
                status="needs_input",
                missing_inputs=[
                    MissingInput(
                        field_path="/source",
                        reason="Check source connection, credential references, "
                        "request scope and local storage. Credentials are not exposed.",
                    )
                ],
            )
        finally:
            if fd is not None:
                self.store.unlock(fd)

    def _retain(self, result, pages):
        root = self.workspace.layout.raw_data_dir / "adapter_reads"
        if root.is_symlink() or self.workspace.layout.raw_data_dir.is_symlink():
            raise ValueError("source evidence cannot use symlink directories")
        root.mkdir(parents=True, exist_ok=True)
        target = root / result.read_id
        temporary = tempfile.mkdtemp(prefix=".read-", dir=root)
        try:
            payload = {
                "result": result.model_dump(mode="json"),
                "pages": pages,
                "raw_retention_deadline": (
                    result.observed_at + timedelta(days=self.raw_retention_days)
                ).isoformat(),
            }
            payload["content_hash"] = content_hash(payload)
            with open(os.path.join(temporary, "evidence.json"), "x") as handle:
                json.dump(payload, handle, ensure_ascii=False, sort_keys=True, indent=2)
                handle.flush()
                os.fsync(handle.fileno())
            os.rename(temporary, target)
        finally:
            if os.path.exists(temporary):
                shutil.rmtree(temporary)
        return str(target / "evidence.json")

    def prune_expired_reads(self):
        """Explicit local maintenance; never touches canonical imports or customer files."""
        root = self.workspace.layout.raw_data_dir / "adapter_reads"
        removed = 0
        issues = []
        if root.is_symlink() or self.workspace.layout.raw_data_dir.is_symlink():
            return OperationEnvelope(
                operation="source_prune",
                status="needs_input",
                missing_inputs=[
                    MissingInput(field_path="/source", reason="Inspect raw storage path.")
                ],
            )
        for directory in sorted(root.glob("read_*")):
            try:
                if (
                    directory.is_symlink()
                    or re.fullmatch(r"read_[a-f0-9]{32}", directory.name) is None
                ):
                    continue
                path = directory / "evidence.json"
                if path.is_symlink() or not path.is_file():
                    raise ValueError
                payload = json.loads(path.read_text())
                saved_hash = payload.pop("content_hash")
                if (
                    content_hash(payload) != saved_hash
                    or payload["result"]["read_id"] != directory.name
                ):
                    raise ValueError
                deadline = datetime.fromisoformat(payload["raw_retention_deadline"])
                if deadline.tzinfo is None:
                    raise ValueError
                if self.clock() >= deadline:
                    # Extra files may belong to a person: leave the entire directory untouched.
                    if set(directory.iterdir()) != {path}:
                        raise ValueError
                    shutil.rmtree(directory)
                    removed += 1
            except (ValueError, KeyError, TypeError, OSError):
                issues.append(
                    OperationIssue(
                        code="raw_retention_inspection_required",
                        message="An unexpected or corrupt artifact was retained for inspection.",
                    )
                )
        return OperationEnvelope(
            operation="source_prune",
            status="partial_result" if issues else "complete",
            result={"removed": removed},
            issues=issues,
        )
