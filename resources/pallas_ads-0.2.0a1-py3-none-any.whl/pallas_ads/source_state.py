"""Atomic, locked non-secret connection metadata, separate from the credential store."""

from __future__ import annotations

import fcntl
import os
import re
import stat
import tempfile
from pathlib import Path

from pallas_ads.contracts.source import SourceConnection, SourceConnectionConfig


class SourceStateStore:
    def __init__(self, root: Path) -> None:
        self.root = root / "connections"

    def _path(self, identifier: str) -> Path:
        if re.fullmatch(r"connection_[a-z0-9][a-z0-9_-]*", identifier) is None:
            raise ValueError("invalid connection identifier")
        if self.root.is_symlink():
            raise ValueError("connection directory cannot be a symlink")
        return self.root / f"{identifier}.json"

    def lock(self, identifier: str) -> int:
        path = self._path(identifier).with_suffix(".lock")
        self.root.mkdir(parents=True, exist_ok=True)
        fd = os.open(path, os.O_CREAT | os.O_RDWR | os.O_NOFOLLOW, 0o600)
        try:
            if not stat.S_ISREG(os.fstat(fd).st_mode):
                raise ValueError("connection lock must be a file")
            fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
            return fd
        except Exception:
            os.close(fd)
            raise

    @staticmethod
    def unlock(fd: int) -> None:
        fcntl.flock(fd, fcntl.LOCK_UN)
        os.close(fd)

    def load(self, identifier: str) -> SourceConnection | None:
        path = self._path(identifier)
        try:
            fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
        except FileNotFoundError:
            return None
        with os.fdopen(fd, "r") as handle:
            if not stat.S_ISREG(os.fstat(handle.fileno()).st_mode):
                raise ValueError("connection must be a file")
            result = SourceConnection.model_validate_json(handle.read(65537))
        if result.config.connection_id != identifier:
            raise ValueError("connection identity mismatch")
        return result

    def save(self, connection: SourceConnection) -> None:
        # Caller holds the connection lock, including during OAuth exchange.
        path = self._path(connection.config.connection_id)
        self._write(path, connection.model_dump_json(indent=2) + "\n")

    def load_registration(self, identifier: str) -> SourceConnectionConfig | None:
        path = self._path(identifier).with_suffix(".client.json")
        try:
            fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
        except FileNotFoundError:
            return None
        with os.fdopen(fd, "r") as handle:
            if not stat.S_ISREG(os.fstat(handle.fileno()).st_mode):
                raise ValueError("registration must be a file")
            result = SourceConnectionConfig.model_validate_json(handle.read(65537))
        if result.connection_id != identifier or result.transport != "official_mcp":
            raise ValueError("registration identity mismatch")
        return result

    def save_registration(self, config: SourceConnectionConfig) -> None:
        # Caller holds the same lock used by authorization and connection updates.
        path = self._path(config.connection_id).with_suffix(".client.json")
        self._write(path, config.model_dump_json(indent=2) + "\n")

    def _write(self, path: Path, value: str) -> None:
        if path.is_symlink():
            raise ValueError("connection cannot be a symlink")
        fd, temporary = tempfile.mkstemp(prefix=".connection-", dir=self.root)
        try:
            with os.fdopen(fd, "w") as handle:
                handle.write(value)
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(temporary, path)
        finally:
            Path(temporary).unlink(missing_ok=True)
