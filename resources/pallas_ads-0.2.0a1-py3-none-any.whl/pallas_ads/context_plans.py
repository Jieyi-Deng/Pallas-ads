# ruff: noqa: E501
"""Fixed read-only context recipes; source text never selects an endpoint or a query."""

import json

from pallas_ads.oauth_provider import META_ROOT, TIKTOK_ROOT
from pallas_ads.source_transport import SourceHTTPError

TIKTOK_FIELDS = {
    "optimization": [
        "campaign_id",
        "adgroup_id",
        "optimization_goal",
        "optimization_event",
        "billing_event",
        "bid_type",
        "bid_price",
        "conversion_bid_price",
        "deep_cpa_bid",
        "app_id",
        "pixel_id",
        "age_groups",
        "gender",
        "location_ids",
        "operating_systems",
        "interest_category_ids",
        "modify_time",
    ],
    "creative": [
        "campaign_id",
        "adgroup_id",
        "ad_id",
        "ad_text",
        "landing_page_url",
        "app_name",
        "call_to_action",
        "modify_time",
    ],
}
META_FIELDS = {
    "optimization": "id,campaign_id,optimization_goal,billing_event,bid_strategy,bid_amount,promoted_object,targeting,updated_time",
    "creative": "id,campaign_id,adset_id,creative{id,title,body,object_story_spec,asset_feed_spec},updated_time",
}
GOOGLE = {
    "google_custom_goals": (
        "custom_conversion_goal",
        "custom_conversion_goal.resource_name, custom_conversion_goal.conversion_actions, custom_conversion_goal.status",
        "customConversionGoal.resourceName",
    ),
    "optimization": (
        "campaign",
        "campaign.id, campaign.bidding_strategy_type, campaign.target_cpa.target_cpa_micros, campaign.target_roas.target_roas, campaign.app_campaign_setting.app_id, campaign.app_campaign_setting.app_store, campaign.selective_optimization.conversion_actions",
        "campaign.id",
    ),
    "creative": (
        "ad_group_ad",
        "campaign.id, ad_group_ad.ad.id, ad_group_ad.ad.final_urls",
        "adGroupAd.ad.id",
    ),
    "google_goals": (
        "campaign_conversion_goal",
        "campaign.id, campaign_conversion_goal.resource_name, campaign_conversion_goal.category, campaign_conversion_goal.origin, campaign_conversion_goal.biddable",
        "campaignConversionGoal.resourceName",
    ),
    "google_actions": (
        "conversion_action",
        "conversion_action.id, conversion_action.resource_name, conversion_action.name, conversion_action.category, conversion_action.origin, conversion_action.type, conversion_action.status, conversion_action.primary_for_goal",
        "conversionAction.id",
    ),
    "google_goal_config": (
        "conversion_goal_campaign_config",
        "campaign.id, conversion_goal_campaign_config.resource_name, conversion_goal_campaign_config.goal_config_level, conversion_goal_campaign_config.custom_conversion_goal",
        "conversionGoalCampaignConfig.resourceName",
    ),
}


def context_recipe(request, endpoint):
    kind, platform = request.context_kind, request.platform
    if platform == "tiktok":
        if kind == "apps":
            return (
                TIKTOK_ROOT + "/app/list/",
                {"advertiser_id": request.account_id},
                None,
                ["app_id"],
            )
        if kind not in TIKTOK_FIELDS:
            raise ValueError("unsupported context")
        return (
            TIKTOK_ROOT + ("/adgroup/get/" if kind == "optimization" else "/ad/get/"),
            {
                "advertiser_id": request.account_id,
                "page": 1,
                "page_size": 100,
                "fields": json.dumps(TIKTOK_FIELDS[kind]),
            },
            None,
            ["campaign_id", "adgroup_id" if kind == "optimization" else "ad_id"],
        )
    if platform == "meta":
        return (
            META_ROOT
            + f"/act_{request.account_id}/"
            + ("adsets" if kind == "optimization" else "ads"),
            {"fields": META_FIELDS[kind], "limit": 100},
            None,
            ["id", "campaign_id"],
        )
    resource, selection, identifier = GOOGLE[kind]
    return endpoint, {}, {"query": f"SELECT {selection} FROM {resource}"}, [identifier]


def context_identity(request, row):
    from pallas_ads.adapter_service import _get

    if request.context_kind == "apps":
        value = row.get("app_id")
        if not isinstance(value, str) or not value.isdigit():
            raise SourceHTTPError("response_schema_changed")
        return value
    field = (
        GOOGLE[request.context_kind][2]
        if request.platform == "google"
        else "id"
        if request.platform == "meta"
        else "adgroup_id"
        if request.context_kind == "optimization"
        else "ad_id"
    )
    value = _get(row, field)
    if (
        not isinstance(value, (str, int))
        or isinstance(value, bool)
        or not str(value)
        or len(str(value)) > 512
    ):
        raise SourceHTTPError("response_schema_changed")
    return str(value)


def sanitize_apps(payload, account):
    if payload.get("code") != 0:
        raise SourceHTTPError("provider_request_failed")
    data = payload.get("data", {})
    rows = data.get("apps") if isinstance(data, dict) else None
    if (
        not isinstance(rows, list)
        or len(rows) > 10000
        or data.get("page_info")
        or data.get("next_cursor")
    ):
        raise SourceHTTPError("response_schema_changed")
    clean = []
    for row in rows:
        if not isinstance(row, dict) or row.get("advertiser_id") != account:
            raise SourceHTTPError("response_scope_mismatch")
        clean.append(
            {
                k: row.get(k)
                for k in (
                    "advertiser_id",
                    "app_id",
                    "app_platform_id",
                    "app_name",
                    "download_url",
                    "package_name",
                    "platform",
                )
            }
        )
    return {"code": 0, "data": {"list": clean, "page_info": {"page": 1, "total_page": 1}}}
