"""Coverage-aware, non-overlapping sums with row-level safety evidence."""

from __future__ import annotations

from collections import defaultdict
from decimal import Decimal
from typing import Literal

from pallas_ads.contracts.analysis import MetricAggregate
from pallas_ads.contracts.common import OUTCOME_METRICS, ReportingTimeBasis
from pallas_ads.contracts.common import CanonicalDimension as D
from pallas_ads.contracts.common import CanonicalMetric as M
from pallas_ads.contracts.data import (
    DimensionState,
    DimensionValue,
    MaturityStatus,
    ObservationRevision,
)
from pallas_ads.contracts.metrics import MetricComputation, MetricNullReason
from pallas_ads.contracts.profile import ConversionDirection, CurrencyConversion
from pallas_ads.contracts.query import DateRange
from pallas_ads.metric_registry import DEFAULT_METRIC_REGISTRY as REGISTRY
from pallas_ads.query_planner import AnalysisContext, content_hash, dates, metric_components


def _label(dimension: DimensionValue) -> str:
    return (
        dimension.value
        if dimension.state is DimensionState.VALUE and dimension.value
        else dimension.state.value
    )


def _fx(
    context: AnalysisContext, binding_id: str, row: ObservationRevision, period: DateRange
) -> tuple[Decimal, str, CurrencyConversion | None, list[str]]:
    record = row.record
    configured = [
        rate
        for rate in context.profile.profile.comparison_policy.currency_conversions
        if binding_id in rate.binding_ids and rate.source_currency == record.currency
    ]
    if not configured:
        return record.value, record.currency, None, []
    # Validate the whole requested window before converting ANY of its rows. Partial
    # validity must not create two apparently complete (native/converted) periods.
    by_day = {
        day: [
            rate
            for rate in configured
            if rate.effective_date <= day <= (rate.valid_through or rate.effective_date)
        ]
        for day in dates(period)
    }
    reasons = []
    if any(not rates for rates in by_day.values()):
        reasons.append("missing_exchange_rate")
    if any(len(rates) > 1 for rates in by_day.values()):
        reasons.append("ambiguous_exchange_rate")
    if len({rate.target_currency for rates in by_day.values() for rate in rates}) > 1:
        reasons.append("mixed_exchange_targets")
    if reasons:
        return record.value, record.currency, None, reasons
    rate = by_day[record.event_date][0]
    value = record.value
    if record.unit == "currency":
        value = (
            value * rate.rate
            if rate.direction is ConversionDirection.MULTIPLY_SOURCE_TO_TARGET
            else value / rate.rate
        )
    return value, rate.target_currency, rate, []


def _dimensions(
    context: AnalysisContext, row: ObservationRevision, currency: str | None
) -> dict[str, str]:
    record = row.record
    result = {
        "channel": row.platform.value,
        "campaign_type": _label(record.campaign_type),
        "optimization_goal": _label(record.optimization_goal),
    }
    if currency is not None:
        result["currency"] = currency
    for dimension, value in (
        (D.CAMPAIGN, f"{row.account_id}/{record.entity_id}"),
        (D.COUNTRY, _label(record.country)),
        (D.OS, _label(record.os)),
        (D.EVENT_DATE, record.event_date.isoformat()),
    ):
        if dimension in context.plan.effective_grain:
            result[dimension.value] = value
    return result


def aggregate(context: AnalysisContext) -> list[MetricAggregate]:
    results: list[MetricAggregate] = []
    for window, period in (("current", context.plan.period), ("baseline", context.plan.baseline)):
        for metric in context.plan.query.metrics:
            monetary = (
                REGISTRY.definition(metric).unit.value.startswith("currency")
                or metric is M.MEDIA_IAP_ROAS
            )
            grouped: dict[str, list[tuple[str, ObservationRevision]]] = defaultdict(list)
            dimensions = {}
            for source in context.plan.sources:
                for day in dates(period):
                    for component in context.plan.component_metrics:
                        state = context.cells.get((source.binding_id, day, component))
                        if state is None:
                            continue
                        for row in state.records:
                            currency = (
                                _fx(context, source.binding_id, row, period)[1]
                                if monetary
                                else None
                            )
                            dims = _dimensions(context, row, currency)
                            key = content_hash(dims).removeprefix("sha256:")[:24]
                            grouped[key].append((source.binding_id, row))
                            dimensions[key] = dims
            for scope_key in sorted(grouped):
                results.append(
                    _aggregate_metric(
                        context,
                        scope_key,
                        dimensions[scope_key],
                        grouped[scope_key],
                        metric,
                        window,
                    )
                )
    return results


def _aggregate_metric(
    context: AnalysisContext,
    scope_key: str,
    dimensions: dict[str, str],
    grouped_rows: list[tuple[str, ObservationRevision]],
    metric: M,
    window: Literal["current", "baseline"] | str,
) -> MetricAggregate:
    period = context.plan.period if window == "current" else context.plan.baseline
    primary = set(metric_components(metric))
    auxiliary: set[M] = set()
    policy = context.plan.evidence_policy
    if (
        metric in {M.MEDIA_IAP_ROAS, M.PLATFORM_ATTRIBUTED_IAP_REVENUE}
        and policy.minimum_outcome_events is not None
    ):
        auxiliary.add(M.PURCHASE_EVENT_COUNT)
    if metric in OUTCOME_METRICS and policy.minimum_spend is not None:
        auxiliary.add(M.SPEND)
    auxiliary -= primary
    selected = [
        (binding, row)
        for binding, row in grouped_rows
        if row.record.metric_key in primary | auxiliary
    ]
    bindings = sorted({binding for binding, _ in grouped_rows})
    reasons: set[str] = set()
    sufficiency: set[str] = set()
    source_ids = {row.source_snapshot_id for _, row in selected}
    for binding in bindings:
        for day in dates(period):
            for component in primary | auxiliary:
                state = context.cells.get((binding, day, component))
                target = reasons if component in primary else sufficiency
                if state is None:
                    target.add("missing_component")
                else:
                    target.update(state.reasons)
                    if state.snapshot is not None:
                        source_ids.add(state.snapshot.source_snapshot_id)
    if dimensions["optimization_goal"].lower() in {
        "missing",
        "unknown",
        "unmapped",
        "all",
        "not_requested",
        "not_supported",
        "not_applicable",
    }:
        reasons.add("unknown_dimension")
    if dimensions["campaign_type"].lower() in {
        "missing",
        "unknown",
        "unmapped",
        "not_requested",
        "not_supported",
    }:
        reasons.add("unknown_dimension")
    atomic: dict[tuple[str, str, str], dict[M, list[ObservationRevision]]] = defaultdict(
        lambda: defaultdict(list)
    )
    for binding, row in selected:
        atomic[(binding, row.record.entity_id, row.record.event_date.isoformat())][
            row.record.metric_key
        ].append(row)
    components: dict[M, Decimal] = {}
    component_currencies: dict[M, set[str]] = defaultdict(set)
    bases: dict[M, set[ReportingTimeBasis]] = defaultdict(set)
    conversions: dict[str, CurrencyConversion] = {}
    primary_rows = [row for _, row in selected if row.record.metric_key in primary]
    provisional = any(
        row.record.maturity_status is MaturityStatus.PROVISIONAL for row in primary_rows
    )
    if provisional and not context.plan.query.include_provisional:
        reasons.add("unrequested_provisional")
    attribution = {
        content_hash(
            row.record.attribution_spec.model_dump(mode="json")
        ): row.record.attribution_spec
        for row in primary_rows
        if row.record.attribution_spec is not None
        and REGISTRY.definition(row.record.metric_key).attribution_sensitive
    }
    complete = not reasons
    for (binding, _, _), cell in atomic.items():
        row_values: dict[M, Decimal] = {}
        row_bases = {}
        for component in primary | auxiliary:
            candidates = cell.get(component, [])
            target = reasons if component in primary else sufficiency
            if len(candidates) != 1:
                target.add("missing_component" if not candidates else "ambiguous_series")
                continue
            row = candidates[0]
            value, effective_currency, conversion, fx_reasons = _fx(context, binding, row, period)
            if row.record.unit == "currency":
                target.update(fx_reasons)
                component_currencies[component].add(effective_currency)
            if conversion is not None and row.record.unit == "currency":
                conversions[content_hash(conversion.model_dump(mode="json"))] = conversion
            bases[component].add(row.record.reporting_time_basis)
            row_bases[component] = row.record.reporting_time_basis
            row_values[component] = value
            if component in auxiliary:
                if row.record.maturity_status is MaturityStatus.PROVISIONAL:
                    sufficiency.add("provisional_sufficiency_component")
                expected_bases = (
                    {ReportingTimeBasis.DELIVERY_DATE, ReportingTimeBasis.AD_INTERACTION_DATE}
                    if component is M.SPEND
                    else {ReportingTimeBasis.AD_INTERACTION_DATE}
                )
                if row.record.reporting_time_basis not in expected_bases:
                    sufficiency.add("unaligned_sufficiency_component")
                if component is not M.SPEND and (
                    row.record.attribution_spec is None
                    or content_hash(row.record.attribution_spec.model_dump(mode="json"))
                    not in attribution
                ):
                    sufficiency.add("sufficiency_attribution_mismatch")
            components[component] = components.get(component, Decimal(0)) + value
        # Even zero-cost / zero-event rows that disappear in a positive aggregate retain warnings.
        computation = REGISTRY.compute(metric, row_values, component_time_bases=row_bases)
        reasons.update(warning.value for warning in computation.interpretation_warnings)
    for component, currencies in component_currencies.items():
        if len(currencies) > 1:
            target = reasons if component in primary else sufficiency
            target.add("mixed_component_currencies")
            components.pop(component, None)
    normalized_bases = {
        component: next(iter(choices)) if len(choices) == 1 else ReportingTimeBasis.MIXED
        for component, choices in bases.items()
    }
    computation = REGISTRY.compute(metric, components, component_time_bases=normalized_bases)
    undefined_scope = reasons & {
        "ambiguous_series",
        "missing_component",
        "unrequested_provisional",
        "ambiguous_exchange_rate",
        "missing_exchange_rate",
        "mixed_exchange_targets",
        "mixed_component_currencies",
    }
    if undefined_scope:
        computation = MetricComputation(
            metric_key=metric,
            semantic_version=computation.semantic_version,
            unit=computation.unit,
            null_reason=MetricNullReason.MISSING_COMPONENTS,
            interpretation_warnings=computation.interpretation_warnings,
        )
    complete = complete and not bool(undefined_scope)
    if sufficiency:
        for component in auxiliary:
            components.pop(component, None)
    row_ids = sorted({row.observation_id for _, row in selected})
    definition = REGISTRY.definition(metric)
    # Count metrics have no monetary unit, but raw currencies are retained in details.
    currency = (
        dimensions["currency"]
        if (definition.unit.value.startswith("currency") or metric is M.MEDIA_IAP_ROAS)
        else None
    )
    identity = {
        "scope": scope_key,
        "window": window,
        "metric": metric.value,
        "period": period.model_dump(mode="json"),
        "observations": row_ids,
    }
    return MetricAggregate(
        aggregate_id="agg_" + content_hash(identity).removeprefix("sha256:")[:24],
        scope_key=scope_key,
        window="current" if window == "current" else "baseline",
        period=period,
        dimensions=dimensions,
        platform=grouped_rows[0][1].platform,
        binding_ids=bindings,
        metric=metric,
        computation=computation,
        components=components,
        component_currencies={
            m: sorted(currencies) for m, currencies in component_currencies.items()
        },
        currency=currency,
        source_currencies=sorted({r.record.currency for r in primary_rows}),
        source_timezones=sorted({r.record.source_timezone for r in primary_rows}),
        reporting_time_bases={m: sorted(choices) for m, choices in bases.items()},
        optimization_goals=sorted({_label(r.record.optimization_goal) for r in primary_rows}),
        attribution_specs=[attribution[key] for key in sorted(attribution)],
        complete=complete,
        provisional=provisional,
        reasons=sorted(reasons),
        evidence_sufficiency_reasons=sorted(sufficiency),
        observation_ids=row_ids,
        source_snapshot_ids=sorted(source_ids),
        currency_conversions=[conversions[key] for key in sorted(conversions)],
    )
