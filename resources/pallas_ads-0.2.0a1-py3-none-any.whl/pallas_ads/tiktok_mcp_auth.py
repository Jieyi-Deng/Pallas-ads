"""Public-client OAuth for one pinned TikTok official MCP resource (no developer secret)."""

from __future__ import annotations

import base64
import hashlib
from datetime import UTC, datetime, timedelta
from urllib.parse import urlencode

from pallas_ads.contracts.source import SourceConnectionConfig
from pallas_ads.credential_store import CredentialError, TokenBundle
from pallas_ads.source_transport import Transport

MCP_RESOURCE = "https://business-api.tiktok.com/open_mcp/tt-ads-mcp-flat"
MCP_AUTHORIZATION = "https://business-api.tiktok.com/portal/mcp-tt4b-authorize"
MCP_SCOPE = "mcp:tt4b"


class TikTokMCPOAuth:
    def __init__(self, transport: Transport, *, clock=lambda: datetime.now(UTC)):
        self.transport, self.clock = transport, clock

    @staticmethod
    def _config(config):
        validated = SourceConnectionConfig.model_validate(config.model_dump(mode="json"))
        if validated.transport != "official_mcp":
            raise CredentialError("official MCP configuration required")
        return validated

    def register(self, config):
        config = self._config(config)
        response = self.transport.request(
            "GET", MCP_RESOURCE + "/oauth/.well-known/openid-configuration", headers={}
        )
        metadata = response.payload
        expected = {
            "issuer": MCP_RESOURCE + "/oauth",
            "authorization_endpoint": MCP_AUTHORIZATION,
            "token_endpoint": MCP_RESOURCE + "/oauth/token",
            "registration_endpoint": MCP_RESOURCE + "/oauth/register",
            "revocation_endpoint": MCP_RESOURCE + "/oauth/revoke",
        }
        # Never follow arbitrary URLs supplied by discovery, including other TikTok paths.
        if (
            response.status != 200
            or not isinstance(metadata, dict)
            or any(metadata.get(key) not in (value, value + "/") for key, value in expected.items())
        ):
            raise CredentialError("MCP authorization metadata rejected")
        for key, required in {
            "response_types_supported": {"code"},
            "grant_types_supported": {"authorization_code", "refresh_token"},
            "code_challenge_methods_supported": {"S256"},
            "token_endpoint_auth_methods_supported": {"none"},
            "scopes_supported": {MCP_SCOPE},
        }.items():
            offered = metadata.get(key)
            if not isinstance(offered, list) or not required.issubset(offered):
                raise CredentialError("MCP authorization capabilities changed")
        body = {
            "client_name": "Pallas local TikTok account validation",
            "redirect_uris": [config.registered_redirect_uri],
            "token_endpoint_auth_method": "none",
            "grant_types": ["authorization_code", "refresh_token"],
            "response_types": ["code"],
        }
        response = self.transport.request(
            "POST", metadata["registration_endpoint"], headers={}, body=body
        )
        payload = response.payload
        if (
            response.status not in (200, 201)
            or not isinstance(payload, dict)
            or "error" in payload
            or "client_secret" in payload
            or any(
                payload.get(key) != body[key]
                for key in (
                    "redirect_uris",
                    "token_endpoint_auth_method",
                    "grant_types",
                    "response_types",
                )
            )
            or not isinstance(payload.get("client_id"), str)
            or not 1 <= len(payload["client_id"]) <= 256
        ):
            raise CredentialError("MCP client registration failed")
        return SourceConnectionConfig.model_validate(
            {**config.model_dump(mode="json"), "client_id": payload["client_id"]}
        )

    def authorization_url(self, config, redirect_uri, state, verifier):
        config = self._config(config)
        if not config.client_id or redirect_uri != config.registered_redirect_uri:
            raise CredentialError("MCP client registration required")
        challenge = base64.urlsafe_b64encode(hashlib.sha256(verifier.encode()).digest())
        return (
            MCP_AUTHORIZATION
            + "?"
            + urlencode(
                {
                    "response_type": "code",
                    "resource": MCP_RESOURCE,
                    "client_id": config.client_id,
                    "redirect_uri": redirect_uri,
                    "scope": MCP_SCOPE,
                    "state": state,
                    "code_challenge": challenge.decode().rstrip("="),
                    "code_challenge_method": "S256",
                }
            )
        )

    def _tokens(self, response, *, previous=None):
        try:
            payload = response.payload
            if response.status != 200 or not isinstance(payload, dict) or "error" in payload:
                raise ValueError
            if (
                payload.get("token_type", "").lower() != "bearer"
                or payload.get("scope") != MCP_SCOPE
            ):
                raise ValueError
            for key, maximum in (("expires_in", 86400), ("refresh_token_expires_in", 2592000)):
                value = payload.get(key)
                if type(value) is not int or not 0 < value <= maximum:
                    raise ValueError
            for key in ("access_token", "refresh_token"):
                value = payload.get(key)
                if (
                    not isinstance(value, str)
                    or not 1 <= len(value) <= 32768
                    or any(ord(c) < 33 or ord(c) > 126 for c in value)
                ):
                    raise ValueError
            # Ignore provider-supplied absolute timestamps; derive and cap locally.
            tokens = TokenBundle.model_validate(
                {key: payload[key] for key in ("access_token", "refresh_token", "expires_in")}
            )
            expiry = self.clock() + timedelta(seconds=payload["refresh_token_expires_in"])
            if previous is not None:
                expiry = min(expiry, previous.refresh_expires_at)
            tokens.refresh_expires_at = expiry
            return tokens
        except Exception:
            raise CredentialError("MCP token exchange failed; authorize again") from None

    def exchange(self, config, code, redirect_uri, verifier):
        config = self._config(config)
        if not config.client_id or redirect_uri != config.registered_redirect_uri:
            raise CredentialError("MCP callback does not match registration")
        response = self.transport.request(
            "POST",
            MCP_RESOURCE + "/oauth/token",
            headers={},
            form=True,
            body={
                "grant_type": "authorization_code",
                "code": code,
                "code_verifier": verifier,
                "redirect_uri": redirect_uri,
            },
        )
        return self._tokens(response)

    def refresh(self, config, previous):
        self._config(config)
        if (
            previous.refresh_token is None
            or previous.refresh_expires_at is None
            or self.clock() >= previous.refresh_expires_at
        ):
            raise CredentialError("MCP refresh window ended; authorize again")
        response = self.transport.request(
            "POST",
            MCP_RESOURCE + "/oauth/token",
            headers={},
            form=True,
            body={
                "grant_type": "refresh_token",
                "refresh_token": previous.refresh_token.get_secret_value(),
            },
        )
        return self._tokens(response, previous=previous)

    def revoke(self, config, tokens):
        self._config(config)
        confirmed = True
        # Revocation of one token does not document revocation of its paired token.
        # Attempt both, including when the access token has already expired.
        for hint, token in (
            ("access_token", tokens.access_token),
            ("refresh_token", tokens.refresh_token),
        ):
            if token is None:
                continue
            try:
                response = self.transport.request(
                    "POST",
                    MCP_RESOURCE + "/oauth/revoke",
                    headers={},
                    form=True,
                    body={"token": token.get_secret_value(), "token_type_hint": hint},
                )
                ok = (
                    response.status == 200
                    and isinstance(response.payload, dict)
                    and response.payload.get("revoked") is True
                )
            except Exception:
                ok = False
            confirmed = confirmed and ok
        return confirmed
