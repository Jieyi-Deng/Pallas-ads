"""Report language routing and source-owned message translation.

The host identifies the language of the user's request. The runtime maps Chinese
locales to Simplified Chinese and all other languages to English. Source data,
names, identifiers and evidence are never passed through a text replacement pass.
"""

import json
from contextlib import contextmanager
from contextvars import ContextVar
from functools import lru_cache
from pathlib import Path
from typing import Annotated, Literal

from pydantic import BeforeValidator


def normalize_language(value: str) -> Literal["en", "zh-CN"]:
    if not isinstance(value, str) or not value.strip() or len(value) > 64:
        raise ValueError("Supply the user's conversation language code.")
    code = value.strip().lower().replace("_", "-")
    return (
        "zh-CN" if code == "zh" or code.startswith("zh-") or code in ("chinese", "中文") else "en"
    )


ReportLanguage = Annotated[Literal["en", "zh-CN"], BeforeValidator(normalize_language)]
# Legacy direct Python calls retain their historical presentation. New tool requests
# select English when no language was supplied; hosts must always pass the user's language.
_language: ContextVar[Literal["en", "zh-CN"]] = ContextVar(
    "pallas_report_language", default="zh-CN"
)


def current_language() -> Literal["en", "zh-CN"]:
    return _language.get()


@contextmanager
def report_language(value):
    token = _language.set(normalize_language(value))
    try:
        yield
    finally:
        _language.reset(token)


@lru_cache
def messages():
    return json.loads((Path(__file__).parent / "resources/report_messages.en.json").read_text())


def tr(message: str, **values) -> str:
    """Translate a developer-authored message before inserting unmodified values."""
    catalogue = messages() if current_language() == "en" else chinese_messages()
    translated = catalogue.get(message, message)
    return translated.format(**values) if values else translated


class Labels(dict):
    """Translate static label maps at use time, never at module import time."""

    def __getitem__(self, key):
        return tr(super().__getitem__(key))

    def get(self, key, default=None):
        return self[key] if key in self else default  # noqa: SIM401


@lru_cache
def chinese_messages():
    return json.loads((Path(__file__).parent / "resources/report_messages.zh-CN.json").read_text())
