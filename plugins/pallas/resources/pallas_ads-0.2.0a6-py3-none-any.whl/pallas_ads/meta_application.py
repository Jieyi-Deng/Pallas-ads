"""Publisher-owned public Meta client; user grants never belong in this resource."""

import json
import re
from pathlib import Path

RESOURCE = "pallas_ads/resources/meta-mcp.json"
CALLBACK = "https://pallas-ads.com/oauth/meta/callback"


def validate_client(raw):
    if (
        not isinstance(raw, dict)
        or set(raw) != {"client_id", "redirect_uri"}
        or not isinstance(raw["client_id"], str)
        or not re.fullmatch(r"[0-9]{5,32}", raw["client_id"])
        or raw["redirect_uri"] != CALLBACK
    ):
        raise ValueError("Expected a public Meta application and the Pallas HTTPS callback.")
    return dict(raw)


def read_client(path):
    path = Path(path)
    if path.is_symlink() or path.stat().st_size > 4096:
        raise ValueError("Invalid publisher Meta application file.")
    return validate_client(json.loads(path.read_text()))


def bundled_path():
    return Path(__file__).parent / "resources/meta-mcp.json"


def bundled_client():
    path = bundled_path()
    return read_client(path) if path.exists() else None
