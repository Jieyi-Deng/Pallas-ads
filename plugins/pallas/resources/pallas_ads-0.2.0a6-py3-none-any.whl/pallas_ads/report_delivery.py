"""Reject successful report operations that did not actually produce local HTML."""

import hashlib
import json
from pathlib import Path

from pallas_ads.contracts.status import MissingInput, OperationIssue, OperationStatus


def check_html_delivery(response, workspace):
    if response.result is None or response.status in ("needs_input", "adapter_refresh_required"):
        return response
    result = response.result
    data = result.model_dump(mode="json") if hasattr(result, "model_dump") else result
    filename = data.get("artifacts", {}).get("html") or data.get("html_path")
    if not filename and data.get("directory"):
        filename = str(Path(data["directory"]) / "report.html")
    valid = False
    if filename:
        path = Path(filename)
        if path.is_absolute() and path.resolve().is_relative_to(workspace.resolve()):
            try:
                markup = path.read_text()
                valid = "<html" in markup.lower() and "</html>" in markup.lower()
            except OSError:
                pass
    if valid:
        return response
    return response.model_copy(
        update={
            "status": OperationStatus.NEEDS_INPUT,
            "issues": [
                *response.issues,
                OperationIssue(
                    code="report_html_missing",
                    message="Report HTML is missing or invalid; delivery failed.",
                ),
            ],
            "missing_inputs": [
                *response.missing_inputs,
                MissingInput(
                    field_path="/artifacts/html",
                    reason="Repair report generation before delivery; do not substitute chat text.",
                ),
            ],
        }
    )


def verify_report_artifacts(response, workspace):
    """Verify generated analysis files and their installed template before command delivery."""
    from pallas_ads.observation_rendering import RENDERER_VERSION, template_path

    result = response.result
    data = result.model_dump(mode="json") if hasattr(result, "model_dump") else result
    filename = data.get("artifacts", {}).get("html") or data.get("html_path")
    if not filename and data.get("directory"):
        filename = str(Path(data["directory"]) / "report.html")
    if not filename:
        raise ValueError("Missing HTML")
    html = Path(filename)
    root = workspace.resolve()
    if not html.is_absolute() or not html.resolve().is_relative_to(root):
        raise ValueError("HTML outside workspace")
    folder = html.parent

    def read(path):
        if not path.resolve().is_relative_to(folder.resolve()):
            raise ValueError("Artifact outside report")
        if any(p.is_symlink() for p in (path, *path.parents) if p.is_relative_to(root)):
            raise ValueError("Symlinked report artifact")
        return path.read_bytes()

    markup = read(html).lower()
    if b"<html" not in markup or b"</html>" not in markup:
        raise ValueError("Invalid HTML")
    manifest = json.loads(read(folder / "manifest.json"))
    files = manifest.get("files", manifest.get("artifact_hashes", {}))
    if html.name not in files:
        raise ValueError("Missing HTML hash")
    for name, expected in files.items():
        relative = Path(name)
        if relative.is_absolute() or ".." in relative.parts:
            raise ValueError("Invalid manifest path")
        digest = hashlib.sha256(read(folder / relative)).hexdigest()
        if "artifact_hashes" in manifest:
            digest = "sha256:" + digest
        if digest != expected:
            raise ValueError("Artifact checksum mismatch")
    if "files" in manifest:
        if manifest.get("renderer_version") not in (RENDERER_VERSION, "host-2.0.0", "host-2.1.0"):
            raise ValueError("Renderer mismatch")
        if (
            manifest.get("template_sha256")
            != hashlib.sha256(template_path().read_bytes()).hexdigest()
        ):
            raise ValueError("Template mismatch")
    return {
        "verified": True,
        "html": str(html.resolve()),
        "scope": "local artifact integrity, not live data accuracy or completeness",
    }
