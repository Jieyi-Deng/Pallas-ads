"""Internal (first-party) conversion files and their explicit match to one advertising file.

No network, no OAuth and no model call. Matching is rule-based and documented in
skills/pallas-workflow/references/internal-conversions.md: local date, confirmed platform
value and exact campaign ID. Names, fuzzy text and inferred channels never create a match.
"""

import hashlib
import json
from datetime import date
from decimal import Decimal
from pathlib import Path
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

from pallas_ads.contracts.status import OperationEnvelope, OperationIssue
from pallas_ads.file_import import ExportError, date_cell, decimal_cell, read_table, text_cell
from pallas_ads.observation_rendering import dump
from pallas_ads.report_language import Labels
from pallas_ads.report_language import tr as _t

FIELDS = {
    "date": ["date", "day", "signup_date", "acquisition_date", "日期"],
    "channel": ["channel", "acquisition_channel", "channel_group", "渠道"],
    "platform": ["platform", "source", "utm_source", "media_source", "媒体"],
    "campaign_id": ["campaign_id", "utm_campaign_id", "campaign id", "广告系列编号"],
    "new_users": ["new_users", "signups", "installs", "new users", "新增用户"],
    "conversions": ["conversions", "purchasers", "first_purchases", "转化次数", "转化用户"],
    "revenue": ["revenue", "conversion_value", "收入"],
    "retained_users": ["retained_users", "retained", "d7_retained", "留存用户"],
}
REQUIRED = {"date", "channel"}
COUNTS = ("new_users", "conversions", "retained_users")
METRICS = (*COUNTS, "revenue")
AUTO_CHANNEL = {"paid": "paid", "organic": "organic"}
AUTO_PLATFORM = {"google": "google", "meta": "meta", "tiktok": "tiktok"}
# Display threshold for a group's denominator. It is not a significance test.
MIN_GROUP_USERS = 30


def _count(value, field, line):
    number = decimal_cell(value, field, line)
    if number is not None and number != number.to_integral_value():
        raise ExportError(f"Row {line}: {field} must be an integer count.")
    return number


def prepare(path, options):
    raw, headers, body, sheet = read_table(path, options)
    if set(options.column_mapping) - set(FIELDS):
        raise ExportError("Mapping contains unsupported target fields; use the documented schema.")
    mapping = {}
    for target, aliases in FIELDS.items():
        candidates = [h for h in headers if h.casefold() in {a.casefold() for a in aliases}]
        if target in options.column_mapping:
            candidates = [options.column_mapping[target]]
        if len(candidates) > 1:
            raise ExportError(
                f"Multiple columns match {target}; choose one explicit column_mapping."
            )
        if candidates:
            if candidates[0] not in headers:
                raise ExportError(f"Mapped column for {target} is absent.")
            mapping[target] = candidates[0]
    if REQUIRED - mapping.keys():
        raise ExportError("Map required columns: " + ", ".join(sorted(REQUIRED - mapping.keys())))
    if not {"new_users", "conversions"} & mapping.keys():
        raise ExportError("Map new_users or conversions; a channel list alone has no outcome.")
    if len(set(mapping.values())) != len(mapping):
        raise ExportError("Each input column may map to only one field.")
    try:
        ZoneInfo(options.timezone)
    except (ZoneInfoNotFoundError, ValueError):
        raise ExportError("Timezone must be a valid IANA name.") from None
    if "revenue" in mapping and options.currency is None:
        raise ExportError("Confirm the revenue currency before importing revenue.")
    if "retained_users" in mapping and options.retention_definition is None:
        raise ExportError("Confirm retention_definition before importing retained users.")
    if {f for item in options.omitted_zero_rows for f in item.metrics} - mapping.keys():
        raise ExportError("Omitted-zero confirmation names a metric this file does not map.")
    channels = {k.casefold(): v for k, v in AUTO_CHANNEL.items()}
    channels.update({k.casefold(): v for k, v in options.channel_mapping.items()})
    platforms = {k.casefold(): v for k, v in AUTO_PLATFORM.items()}
    platforms.update({k.casefold(): str(v) for k, v in options.platform_mapping.items()})
    rows, seen, unmapped_channels, unmapped_platforms = [], set(), set(), set()
    for line, source in body:
        item = {f: source.get(h) for f, h in mapping.items()}
        day = date_cell(item["date"], line)
        channel_raw = text_cell(item["channel"], "channel", line)
        if not channel_raw:
            raise ExportError(f"Row {line}: channel is required; remove summary rows.")
        platform_raw = text_cell(item.get("platform"), "platform", line)
        campaign = text_cell(item.get("campaign_id"), "campaign_id", line)
        key = (day, channel_raw, platform_raw, campaign)
        if key in seen:
            raise ExportError(f"Row {line}: duplicate date/channel/platform/campaign row.")
        seen.add(key)
        channel = channels.get(channel_raw.casefold())
        if channel is None:
            unmapped_channels.add(channel_raw)
        platform = None
        if platform_raw is not None:
            platform = platforms.get(platform_raw.casefold())
            if platform is None and channel == "paid":
                unmapped_platforms.add(platform_raw)
        values = {f: _count(item.get(f), f, line) for f in COUNTS}
        values["revenue"] = decimal_cell(item.get("revenue"), "revenue", line)
        rows.append(
            {
                "date": day,
                "channel": channel,
                "channel_raw": channel_raw,
                "platform": platform,
                "platform_raw": platform_raw,
                "campaign_id": campaign,
                "source_row": line,
                **values,
            }
        )
    dates = sorted({r["date"] for r in rows})
    summary = {
        "kind": "internal_conversions",
        "timezone": options.timezone,
        "currency": options.currency,
        "sheet": sheet,
        "row_count": len(rows),
        "period": {"start": dates[0], "end": dates[-1]},
        "observed_dates_continuous": len(dates)
        == (date.fromisoformat(dates[-1]) - date.fromisoformat(dates[0])).days + 1,
        "column_mapping": mapping,
        "ignored_columns": [h for h in headers if h not in mapping.values()],
        "channels": {
            c: sum(r["channel"] == c for r in rows)
            for c in ("paid", "organic", "excluded", "unknown")
        },
        # Shown in the preview (like preview rows) so the user can map them; never in errors.
        "channel_values_unmapped": sorted(unmapped_channels)[:50],
        "paid_platform_values_unmapped": sorted(unmapped_platforms)[:20],
        "campaign_ids_present": any(r["campaign_id"] for r in rows),
        "missing_values": {f: sum(r[f] is None for r in rows) for f in METRICS if f in mapping},
        "unavailable_fields": [
            f for f in (*METRICS, "platform", "campaign_id") if f not in mapping
        ],
        "conversion_definition": options.conversion_definition,
        "attribution_basis": options.attribution_basis,
        "cohort_basis": options.cohort_basis,
        "new_user_definition": options.new_user_definition,
        "retention_definition": options.retention_definition,
        # User-confirmed full coverage with zero-valued rows omitted, per date range and metric.
        "omitted_zero_rows": options.model_dump(mode="json")["omitted_zero_rows"],
        "coverage": "internal_file_rows_only_not_reconciled_with_platform",
    }
    content = {
        "format_version": "1.0",
        "source_sha256": hashlib.sha256(raw).hexdigest(),
        "options": options.model_dump(mode="json"),
        "summary": summary,
        "rows": rows,
    }
    encoded = dump(content).encode()
    return content, encoded, hashlib.sha256(encoded).hexdigest()


def stage_internal(workspace, request):
    if not request.file_path or request.internal_options is None:
        raise ExportError("Supply file_path and internal_options for internal conversion data.")
    content, encoded, digest = prepare(Path(request.file_path), request.internal_options)
    identifier = "internal_" + digest
    if request.action == "internal_preview":
        return OperationEnvelope(
            operation="source_connect_or_import",
            status="pending_user_action",
            issues=[
                OperationIssue(
                    code="internal_interpretation_confirmation",
                    severity="info",
                    message="Confirm channel, platform, date basis and definitions first.",
                ),
                *(
                    [
                        OperationIssue(
                            code="internal_channel_mapping_required",
                            severity="warning",
                            message="Map channel values listed in channel_values_unmapped.",
                        )
                    ]
                    if content["summary"]["channel_values_unmapped"]
                    else []
                ),
            ],
            result={
                "review_hash": digest,
                "summary": content["summary"],
                "preview_rows": json.loads(dump(content["rows"][:5])),
                "next_step": (
                    "Show channel/platform mapping, timezone, cohort basis, conversion and "
                    "retention definitions, missing fields and any omitted-zero confirmation; "
                    "confirm before internal_import."
                ),
                "canonical_data_written": False,
            },
        )
    if request.review_hash != digest or request.user_confirmed is not True:
        raise ExportError(
            "Confirm this exact interpretation; changed files/options need a new preview."
        )
    if content["summary"]["channel_values_unmapped"]:
        raise ExportError(
            "Map every channel value listed in the preview to paid/organic/excluded/unknown."
        )
    root = workspace.layout.root / "file_imports"
    if root.is_symlink():
        raise ExportError("Import storage cannot be a symlink.")
    root.mkdir(mode=0o700, parents=True, exist_ok=True)
    path = root / (identifier + ".json")
    reused = path.exists()
    if reused:
        if path.is_symlink() or path.read_bytes() != encoded:
            raise ExportError("Retained file integrity mismatch; existing data was preserved.")
    else:
        with path.open("xb") as handle:
            path.chmod(0o600)
            handle.write(encoded)
    return OperationEnvelope(
        operation="source_connect_or_import",
        status="complete",
        result={
            "internal_dataset_id": identifier,
            "summary": content["summary"],
            "reused": reused,
            "canonical_data_written": False,
            "next_step": "build_report(action=file_review,dataset_id=...,internal_dataset_id=...)",
        },
    )


NAMES = Labels(
    {
        "new_users": "新增用户",
        "conversions": "转化",
        "revenue": "收入",
        "retained_users": "留存用户",
    }
)


def _d(value):
    return None if value is None else Decimal(str(value))


def _sum(rows, field):
    """Advertising totals: any blank makes the total unknown instead of an undercount."""
    if not rows:
        return None
    values = [_d(r.get(field)) for r in rows]
    return None if any(v is None for v in values) else sum(values, Decimal(0))


def _total(rows, field, zero_days=()):
    """Internal total from the provided values; blanks and absent rows are never zero.

    Only rows the user confirmed as omitted zeros count as zero. No observation gives None.
    """
    values = [_d(r[field]) for r in rows if r.get(field) is not None]
    return sum(values, Decimal(0)) if values or zero_days else None


def _ratio(numerator, denominator):
    return numerator / denominator if numerator is not None and denominator else None


def _why(numerator, denominator, names):
    """Why a ratio is unavailable: a missing operand or a zero denominator, never a zero."""
    if numerator is None:
        return _t("缺少{v0}，不计算。", v0=(names[0]))
    if denominator is None:
        return _t("缺少{v0}，不计算。", v0=(names[1]))
    if denominator == 0:
        return _t("{v0}为 0，分母为零，不计算。", v0=(names[1]))
    return None


def _confirmed(summary, days):
    """Dates per metric the user confirmed as complete with zero-valued rows omitted."""
    confirmed = {f: set() for f in METRICS}
    for item in summary.get("omitted_zero_rows", []):
        for field in item["metrics"]:
            confirmed[field] |= {d for d in days if item["start"] <= d <= item["end"]}
    return confirmed


def _coverage(rows, scope, fields, confirmed, campaign_days=None):
    """Raw gaps of one group: scope dates without rows, blank values and absent campaigns."""
    have = {r["date"] for r in rows}
    missing = scope - have
    coverage = {
        "dates_with_rows": len(have & scope),
        "missing_dates": sorted(missing),
        "missing_value_dates": {
            f: sorted({r["date"] for r in rows if r.get(f) is None})
            for f in fields
            if any(r.get(f) is None for r in rows)
        },
        # Absent rows the user confirmed as omitted zeros; read as zero for these metrics only.
        "confirmed_zero_dates": {
            f: sorted(missing & confirmed[f]) for f in fields if missing & confirmed[f]
        },
    }
    if campaign_days is not None:
        internal = {}
        for r in rows:
            if r["campaign_id"]:
                internal.setdefault(r["campaign_id"], set()).add(r["date"])
        coverage["campaign_missing_dates"] = {
            c: sorted(days - internal.get(c, set()))
            for c, days in sorted(campaign_days.items())
            if days - internal.get(c, set())
        }
    return coverage


def _group(rows, fields, coverage):
    totals = {"rows": len(rows)}
    for field in fields:
        totals[field] = _total(rows, field, coverage["confirmed_zero_dates"].get(field))
    return totals


def _dates(days):
    return "、".join(days[:5]) + (_t(" 等 {v0} 天", v0=(len(days))) if len(days) > 5 else "")


def _facts(coverage, fields, label, confirmed, names=None):
    """Factual gaps behind a metric's operands; confirmed omitted zero rows are not gaps."""
    facts, absent, blank = [], set(), False
    missing, open_days = set(coverage["missing_dates"]), set()
    for field in fields:
        if missing - confirmed[field]:
            open_days |= missing - confirmed[field]
            absent.add(field)
    if open_days:
        facts.append(_t("{v0}在 {v1} 没有内部记录。", v0=(label), v1=(_dates(sorted(open_days)))))
    campaigns = {}
    for identifier, days in coverage.get("campaign_missing_dates", {}).items():
        gap = set()
        for field in fields:
            if set(days) - missing - confirmed[field]:
                gap |= set(days) - missing - confirmed[field]
                absent.add(field)
        if gap:
            campaigns[identifier] = sorted(gap)
    for identifier, days in list(campaigns.items())[:5]:
        name = (names or {}).get(identifier, identifier)
        shown = identifier if name == identifier else f"{name}（{identifier}）"
        facts.append(_t("系列 {v0} 在 {v1} 没有匹配的内部记录。", v0=(shown), v1=(_dates(days))))
    if len(campaigns) > 5:
        facts.append(_t("另有 {v0} 个系列存在同类情况，见 coverage。", v0=(len(campaigns) - 5)))
    for field in fields:
        days = coverage["missing_value_dates"].get(field)
        if days:
            blank = True
            facts.append(
                _t(
                    "{v0}的{v1}在 {v2} 为空值，未按 0 计入。",
                    v0=(label),
                    v1=(NAMES[field]),
                    v2=(_dates(days)),
                )
            )
    return facts, absent, blank


def _note(*parts):
    """Basis label and the warning placed beside a metric; never claims data was lost."""
    facts, absent = [], set()
    for f, a, _ in parts:
        facts += f
        absent |= a
    facts = list(dict.fromkeys(facts))
    if not facts:
        return {"basis": "complete", "warnings": []}
    named = "、".join(NAMES[f] for f in METRICS if f in absent)
    facts.append(
        _t("此指标按已提供数据计算；")
        + (
            _t("请确认缺少记录代表{v0}为 0，还是导出不完整。", v0=(named))
            if absent
            else _t("请确认缺少的记录或空值后补齐。")
        )
    )
    return {"basis": "provided_data", "warnings": facts}


def integrate(ad, internal):
    """Deterministic match of one retained ad file and one internal file."""
    a, s = ad["summary"], internal["summary"]
    present = [f for f in METRICS if f in s["column_mapping"]]
    limitations = [
        _t("内部数据按用户确认的渠道和媒体取值匹配；系列名称、模糊文本和推断渠道不参与匹配。"),
        _t(
            "付费与自然用户的差异是描述性对比，不是增量或因果测量；自然渠道可能受到广告的间接影响。"
        ),
        _t("内部归因口径为“")
        + s["attribution_basis"]
        + _t("”，与媒体归因窗口不同，两者转化数不应相加。"),
        _t("缺少的内部记录和空值不按 0 计入；受影响的指标按已提供数据计算，并在指标旁注明。"),
    ]
    if s["cohort_basis"] == "event_date":
        limitations.append(
            _t("内部转化按事件发生日期记录，不是获客日同批用户；转化率和人均收入只是同期比率。")
        )
    tz_match = a["timezone"] == s["timezone"]
    ad_dates = {r["date"] for r in ad["rows"]}
    internal_dates = {r["date"] for r in internal["rows"]}
    confirmed = _confirmed(s, ad_dates)
    # A date the user confirmed as complete belongs to the overlap even when every row is zero.
    covered = internal_dates.union(*confirmed.values())
    overlap = sorted(ad_dates & covered)
    alignment = {
        "ad_timezone": a["timezone"],
        "internal_timezone": s["timezone"],
        "timezone_match": tz_match,
        "daily_join": tz_match and bool(overlap),
        "overlap": {"start": overlap[0], "end": overlap[-1]} if overlap else None,
        "overlap_dates": len(overlap),
        "ad_dates_outside_overlap": len(ad_dates - covered),
        "internal_dates_outside_overlap": len(internal_dates - ad_dates),
        "currency_match": (s["currency"] == a["currency"]) if "revenue" in present else None,
    }
    result = {
        "status": "integrated",
        "platform": a["platform"],
        "internal_summary": s,
        "alignment": alignment,
        "matching_rules": [
            _t("日期：两份文件都存在的本地日期；时区不同则不按日匹配。"),
            _t("媒体：内部付费行的 platform 取值经确认映射为本广告文件的媒体。"),
            _t("系列：仅当内部数据提供 campaign_id 时按完全相同的编号匹配。"),
            _t("渠道：paid/organic/excluded/unknown 由用户确认；unknown 不并入任何一方。"),
            _t(
                '缺口：缺少的行和空值保持缺失；只有用户确认省略的零值行按 0'
                ' 读取，且仅限确认的日期和指标。'
            ),
        ],
        "limitations": limitations,
        "unavailable": [],
    }
    if not overlap:
        result["status"] = "not_integrable"
        result["unavailable"].append(
            {"metric": "all", "reason": _t("广告文件与内部文件没有共同日期，不能匹配。")}
        )
        return result
    if not tz_match:
        result["status"] = "not_integrable"
        result["unavailable"].append(
            {
                "metric": "all",
                "reason": _t(
                    "两份文件的日期时区不同，同一日期代表不同时段；请按同一时区重新导出。"
                ),
            }
        )
        return result
    window = set(overlap)
    confirmed = {f: days & window for f, days in confirmed.items()}
    ad_rows = [r for r in ad["rows"] if r["date"] in window]
    rows = [r for r in internal["rows"] if r["date"] in window]
    names = ad["campaign_names"]
    has_platform = any(r["platform_raw"] is not None for r in rows)
    groups = {
        "paid_platform": [
            r for r in rows if r["channel"] == "paid" and r["platform"] == a["platform"]
        ],
        "paid_other_platform": [
            r for r in rows if r["channel"] == "paid" and r["platform"] not in (None, a["platform"])
        ],
        "paid_unattributed": [r for r in rows if r["channel"] == "paid" and r["platform"] is None],
        "organic": [r for r in rows if r["channel"] == "organic"],
        "unknown": [r for r in rows if r["channel"] == "unknown"],
    }
    # When paid rows are split by campaign ID, an ad campaign's date without its own internal
    # row is a factual gap; another campaign's row that day does not stand in for it.
    campaign_days = None
    if any(r["campaign_id"] for r in groups["paid_platform"]):
        campaign_days = {}
        for r in ad_rows:
            campaign_days.setdefault(r["campaign_id"], set()).add(r["date"])
    coverage = {
        k: _coverage(v, window, present, confirmed, campaign_days if k == "paid_platform" else None)
        for k, v in groups.items()
    }
    result["coverage"] = coverage
    result["groups"] = {k: _group(v, present, coverage[k]) for k, v in groups.items()}
    labels = {
        "paid_platform": _t("本媒体付费行"),
        "paid_other_platform": _t("其他媒体付费行"),
        "paid_unattributed": _t("未标媒体的付费行"),
        "organic": _t("自然渠道行"),
        "unknown": _t("未知渠道行"),
    }
    for key, totals in result["groups"].items():
        totals.update(_note(_facts(coverage[key], present, labels[key], confirmed, names)))
    result["groups"]["excluded"] = {"rows": sum(r["channel"] == "excluded" for r in rows)}
    ad_totals = {
        f: _sum(ad_rows, f)
        for f in ("spend", "impressions", "clicks", "conversions", "conversion_value")
    }
    result["ad_totals"] = ad_totals
    paid = result["groups"]["paid_platform"]
    if not has_platform:
        result["unavailable"].append(
            {
                "metric": "cac",
                "reason": _t("内部数据没有媒体字段，付费用户不能归到本媒体，不计算获客成本。"),
            }
        )
    efficiency, notes = {}, {}
    if has_platform and paid["rows"]:
        spend = ad_totals["spend"]
        users, conversions = paid.get("new_users"), paid.get("conversions")
        specs = (
            ("internal_cac", "new_users", spend, users, (_t("广告花费"), _t("本媒体付费新增用户"))),
            (
                "cost_per_internal_conversion",
                "conversions",
                spend,
                conversions,
                (_t("广告花费"), _t("本媒体付费转化")),
            ),
            (
                "internal_revenue_to_spend",
                "revenue",
                paid.get("revenue"),
                spend,
                (_t("本媒体付费收入"), _t("广告花费")),
            ),
            (
                "platform_to_internal_conversion_ratio",
                "conversions",
                ad_totals["conversions"],
                conversions,
                (_t("媒体转化"), _t("本媒体付费转化")),
            ),
        )
        for metric, field, numerator, denominator, operands in specs:
            efficiency[metric] = _ratio(numerator, denominator)
            if field not in present:
                continue
            if metric == "internal_revenue_to_spend" and not alignment["currency_match"]:
                efficiency[metric] = None
                reason = _t("收入币种与广告花费币种不同。")
            elif metric == "platform_to_internal_conversion_ratio" and numerator is None:
                reason = _t("广告文件没有完整的媒体转化列。")
            elif spend is None and _t("广告花费") in operands:
                reason = _t("广告花费在共同日期存在空值，不计算效率。")
            else:
                reason = _why(numerator, denominator, operands)
            if reason:
                result["unavailable"].append({"metric": metric, "reason": reason})
            notes[metric] = _note(
                _facts(coverage["paid_platform"], (field,), _t("本媒体付费行"), confirmed, names)
            )
    result["efficiency"] = efficiency
    result["metric_notes"] = notes
    comparisons = []
    # Without platform values, paid users cannot be tied to this medium's spend, but
    # paid-versus-organic quality can still be described for all confirmed paid users.
    label = "paid_platform" if has_platform else "paid_all"
    paid_key = "paid_platform" if has_platform else "paid_unattributed"
    sides = (
        ("paid", result["groups"][paid_key], coverage[paid_key], _t("付费组")),
        ("organic", result["groups"]["organic"], coverage["organic"], _t("自然组")),
    )
    for metric, numerator in (
        ("conversion_rate", "conversions"),
        ("revenue_per_new_user", "revenue"),
        ("retention_rate", "retained_users"),
    ):
        if numerator not in present or "new_users" not in present:
            result["unavailable"].append(
                {"metric": metric, "reason": _t("内部文件缺少 {v0} 或 new_users。", v0=(numerator))}
            )
            continue
        row = {"metric": metric, "paid_group": label}
        reasons, parts = [], []
        for side, g, cov, name in sides:
            n = g.get("new_users")
            row[side + "_new_users"] = n
            row[side] = _ratio(g.get(numerator), n)
            reason = _why(g.get(numerator), n, (name + NAMES[numerator], name + _t("新增用户")))
            if reason:
                reasons.append(reason)
            parts.append(_facts(cov, (numerator, "new_users"), name, confirmed, names))
        if metric == "revenue_per_new_user" and s["currency"] is None:
            reasons.append(_t("收入币种未确认。"))
        if not reasons and min(row["paid_new_users"], row["organic_new_users"]) < MIN_GROUP_USERS:
            reasons.append(_t("至少一组新增用户少于 {v0}，不展示高低比较。", v0=(MIN_GROUP_USERS)))
        row["eligible"] = not reasons
        row["reason"] = "".join(reasons) or None
        row["difference"] = row["paid"] - row["organic"] if row["eligible"] else None
        row.update(_note(*parts))
        comparisons.append(row)
    result["quality_comparison"] = comparisons
    # Campaign match: exact IDs, paid rows for this platform only.
    campaign = {"available": False}
    if campaign_days is not None:
        ad_ids = set(campaign_days)
        by_id = {}
        for r in groups["paid_platform"]:
            if r["campaign_id"]:
                by_id.setdefault(r["campaign_id"], []).append(r)
        matched = []
        for identifier in sorted(set(by_id) & ad_ids):
            # Both operands use every date either side reports for this ID.
            ad_campaign = [r for r in ad_rows if r["campaign_id"] == identifier]
            ad_days = {r["date"] for r in ad_campaign}
            internal_days = {r["date"] for r in by_id[identifier]}
            scope = ad_days | internal_days
            cov = _coverage(by_id[identifier], scope, present, confirmed)
            g = _group(by_id[identifier], present, cov)
            spend = _sum(ad_campaign, "spend")
            fields = [f for f in ("new_users", "conversions") if f in present]
            facts = _facts(cov, fields, _t("该系列内部数据"), confirmed)
            if scope - ad_days:
                facts[0].append(
                    _t(
                        "广告文件在 {v0} 没有该系列的行；花费按已提供的广告行计算。",
                        v0=(_dates(sorted(scope - ad_days))),
                    )
                )
            unavailable = {}
            if "new_users" in present:
                unavailable["internal_cac"] = (
                    _t("该系列广告花费存在空值，不计算。")
                    if spend is None
                    else _why(spend, g["new_users"], (_t("该系列广告花费"), _t("该系列新增用户")))
                )
            if {"new_users", "conversions"} <= set(present):
                unavailable["conversion_rate"] = _why(
                    g["conversions"], g["new_users"], (_t("该系列转化"), _t("该系列新增用户"))
                )
            matched.append(
                {
                    "campaign_id": identifier,
                    "campaign_name": names.get(identifier, identifier),
                    "spend": spend,
                    **g,
                    "missing_ad_dates": sorted(scope - ad_days),
                    "missing_internal_dates": sorted(scope - internal_days),
                    "internal_cac": _ratio(spend, g.get("new_users")),
                    "conversion_rate": _ratio(g.get("conversions"), g.get("new_users")),
                    **_note(facts),
                    "unavailable": {k: v for k, v in unavailable.items() if v},
                }
            )
        campaign = {
            "available": True,
            "matched": matched,
            "internal_ids_without_ad_rows": sorted(set(by_id) - ad_ids)[:50],
            "ad_campaigns_without_internal_rows": sorted(ad_ids - set(by_id))[:50],
            "paid_rows_without_campaign_id": sum(
                1 for r in groups["paid_platform"] if not r["campaign_id"]
            ),
        }
    else:
        result["unavailable"].append(
            {
                "metric": "campaign_match",
                "reason": _t("内部付费行没有 campaign_id，只能做媒体级整合。"),
            }
        )
    result["campaigns"] = campaign
    daily = []
    daily_fields = [f for f in ("new_users", "conversions") if f in present]
    for day in overlap:
        day_ad = [r for r in ad_rows if r["date"] == day]
        entry = {"date": day, "spend": _sum(day_ad, "spend")}
        gaps = []
        for key, name in (("paid_platform", _t("本媒体付费行")), ("organic", _t("自然渠道行"))):
            day_rows = [r for r in groups[key] if r["date"] == day]
            for f in daily_fields:
                # An absent row stays unknown unless the user confirmed omitted zeros that day.
                zero = () if day_rows or day not in confirmed[f] else (day,)
                entry[f"{key}_{f}"] = _total(day_rows, f, zero)
            day_coverage = {
                "missing_dates": [] if day_rows else [day],
                "missing_value_dates": {
                    f: [day] for f in daily_fields if any(r.get(f) is None for r in day_rows)
                },
                "campaign_missing_dates": {
                    c: [day]
                    for c, days in coverage[key].get("campaign_missing_dates", {}).items()
                    if day in days
                },
            }
            gaps += _facts(day_coverage, daily_fields, name, confirmed, names)[0]
        entry["basis"] = "provided_data" if gaps else "complete"
        entry["gaps"] = gaps
        daily.append(entry)
    result["daily"] = daily
    result["organic_trend"] = _organic_trend(daily, present)
    return result


def _organic_trend(daily, present):
    """Equal-length halves of a contiguous overlap; descriptive, not a forecast."""
    if "new_users" not in present or len(daily) < 8:
        return None
    first, last = date.fromisoformat(daily[0]["date"]), date.fromisoformat(daily[-1]["date"])
    if (last - first).days + 1 != len(daily):
        return None
    half = len(daily) // 2
    before, after = daily[:half], daily[len(daily) - half :]
    out = {
        "before": {"start": before[0]["date"], "end": before[-1]["date"]},
        "after": {"start": after[0]["date"], "end": after[-1]["date"]},
    }
    for label, part in (("before", before), ("after", after)):
        for column in ("organic_new_users", "organic_conversions", "paid_platform_new_users"):
            values = [r[column] for r in part if r.get(column) is not None]
            out[label][column] = sum(values, Decimal(0)) if values else None
        out[label]["organic_conversion_rate"] = _ratio(
            out[label]["organic_conversions"], out[label]["organic_new_users"]
        )
        spend = [r.get("spend") for r in part]
        out[label]["spend"] = None if any(v is None for v in spend) else sum(spend, Decimal(0))
        out[label]["basis"] = (
            "provided_data" if any(r["basis"] != "complete" for r in part) else "complete"
        )
        out[label]["gap_dates"] = [r["date"] for r in part if r["gaps"]]
    return out
