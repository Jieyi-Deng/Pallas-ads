"""Build a self-contained acceptance bundle, explicitly excluding old user state."""

import hashlib
import json
import shutil
import tempfile
import zipfile
from pathlib import Path


def oauth_inventory(archive):
    """Exact, normalized publisher identities; never authorize extra files or token fields."""
    from pallas_ads import google_application, meta_application

    if len(archive.namelist()) != len(set(archive.namelist())):
        raise ValueError("Duplicate runtime wheel entries.")
    inventory = {}
    for platform, module in (("google", google_application), ("meta", meta_application)):
        if module.RESOURCE not in archive.namelist():
            continue
        if archive.getinfo(module.RESOURCE).file_size > 65536:
            raise ValueError("Invalid application resource size.")
        raw = archive.read(module.RESOURCE)
        application = json.loads(raw)
        if application != module.validate_client(application):
            raise ValueError("Release resource must contain only public application fields.")
        inventory[platform] = hashlib.sha256(raw).hexdigest()
    return inventory


def validate_publisher_wheel(wheel, manifest, *, allow_publisher_oauth=False):
    with zipfile.ZipFile(wheel) as archive:
        inventory = oauth_inventory(archive)
    if inventory and not allow_publisher_oauth:
        raise ValueError("Publisher OAuth applications require explicit distribution selection.")
    if manifest.get("oauth_applications", {}) != inventory:
        raise ValueError("Publisher OAuth inventory mismatch.")
    if manifest.get("google_application_embedded", False) != ("google" in inventory):
        raise ValueError("Google application inventory mismatch.")
    return inventory


def build_bundle(wheel: Path, output: Path):
    from pallas_ads import __version__

    if wheel.name != f"pallas_ads-{__version__}-py3-none-any.whl" or wheel.is_symlink():
        raise ValueError("Use the matching built Pallas wheel.")
    with zipfile.ZipFile(wheel) as archive:
        if "pallas_ads/machine_setup.py" not in archive.namelist():
            raise ValueError("Wheel lacks new-machine setup.")
        applications = oauth_inventory(archive)
    if output.exists() or output.is_symlink() or any(p.is_symlink() for p in output.parents):
        raise ValueError("Choose a new private output directory.")
    resources = Path(__file__).parent / "resources/distribution"
    if not resources.is_dir():
        resources = Path(__file__).parents[2]
        installer = resources / "examples/distribution/install_macos.py"
        guide = resources / "docs/NEW_MACHINE_TESTING.md"
    else:
        installer, guide = resources / "install_macos.py", resources / "NEW_MACHINE_TESTING.md"
    output.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(dir=output.parent) as temporary:
        stage = Path(temporary) / "bundle"
        stage.mkdir(mode=0o700)
        for source in (wheel, installer, guide):
            shutil.copyfile(source, stage / source.name)
        file_guide = guide.with_name("FILE_IMPORT.md")
        shutil.copyfile(file_guide, stage / "FILE_IMPORT.md")
        samples = Path(__file__).parent / "resources/file_samples"
        shutil.copytree(samples, stage / "samples")
        (stage / "release-manifest.json").write_text(
            json.dumps(
                {
                    "version": __version__,
                    "wheel": wheel.name,
                    "sha256": hashlib.sha256(wheel.read_bytes()).hexdigest(),
                    "target": "macOS + Codex / Claude Code",
                    "default_mode": "core",
                    "google_application_embedded": "google" in applications,
                    "oauth_applications": applications,
                    "requires_google_configuration_file": False,
                    "contains_user_oauth_tokens": False,
                    "contains_localhost_private_key": False,
                },
                indent=2,
            )
            + "\n"
        )
        for file in stage.iterdir():
            file.chmod(0o700 if file.is_dir() else 0o600)
        stage.rename(output)
    return {
        "directory": str(output.absolute()),
        "self_contained_bundle": True,
        "next_step": "Read NEW_MACHINE_TESTING.md; platform eligibility needs live verification.",
    }
