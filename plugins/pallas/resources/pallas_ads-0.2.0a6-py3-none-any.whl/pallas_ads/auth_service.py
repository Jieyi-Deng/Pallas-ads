"""Non-blocking local OAuth sessions with a private loopback receiver and OS credentials."""

from __future__ import annotations

import secrets
import ssl
import threading
import time
import webbrowser
from collections.abc import Callable
from contextlib import suppress
from dataclasses import dataclass, field
from datetime import UTC, datetime, timedelta
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlsplit
from uuid import uuid4

from pallas_ads.contracts.credentials import CredentialRef
from pallas_ads.contracts.source import AuthSessionResult, SourceConnection, SourceConnectionConfig
from pallas_ads.contracts.status import MissingInput, OperationEnvelope, OperationIssue
from pallas_ads.credential_store import CredentialStore
from pallas_ads.oauth_provider import OAuthProvider
from pallas_ads.source_recovery import (
    REFRESH_SKEW,
    SourceAccessError,
    access_failure,
    issue,
    locally_expired,
)
from pallas_ads.source_state import SourceStateStore
from pallas_ads.source_transport import HTTPTransport, SourceHTTPError, Transport


def _needs(operation: str, reason: str):
    return OperationEnvelope(
        operation=operation,
        status="needs_input",
        missing_inputs=[MissingInput(field_path="/source", reason=reason)],
    )


@dataclass(repr=False)
class _Session:
    public: AuthSessionResult
    config: SourceConnectionConfig
    nonce: str = field(repr=False)
    verifier: str = field(repr=False)
    descriptor: int | None = None
    server: ThreadingHTTPServer | None = field(default=None, repr=False)
    timer: threading.Timer | None = field(default=None, repr=False)


class AuthService:
    def __init__(
        self,
        workspace,
        *,
        credentials: CredentialStore | None = None,
        transport: Transport | None = None,
        browser_open: Callable = webbrowser.open,
        clock: Callable = lambda: datetime.now(UTC),
    ) -> None:
        self.workspace = workspace
        self.store = SourceStateStore(workspace.layout.root)
        self.credentials = credentials or CredentialStore()
        self.provider = OAuthProvider(transport or HTTPTransport(), self.credentials, clock=clock)
        self.browser_open, self.clock = browser_open, clock
        self._sessions: dict[str, _Session] = {}
        self._mutex = threading.RLock()
        self.sleep = time.sleep

    def prepare_mcp(self, config: SourceConnectionConfig):
        """Prepare platform-specific public OAuth; never reuse another client's identity."""
        fd = None
        try:
            from pallas_ads.tiktok_mcp_auth import TikTokMCPOAuth

            config = SourceConnectionConfig.model_validate(config.model_dump(mode="json"))
            if config.transport != "official_mcp":
                raise ValueError
            self.credentials._secure_backend()
            if config.platform == "meta":
                config = self.provider._mcp(config).register(config)
                return OperationEnvelope(
                    operation="source_mcp_register", status="complete", result=config
                )
            fd = self.store.lock(config.connection_id)
            cached = self.store.load_registration(config.connection_id)
            if cached is not None:
                if (
                    not cached.client_id
                    or (
                        cached.model_dump(exclude={"client_id"})
                        != config.model_dump(exclude={"client_id"})
                    )
                    or config.client_id not in (None, cached.client_id)
                ):
                    raise ValueError
                config = cached
            else:
                if config.client_id is not None:
                    raise ValueError
                config = TikTokMCPOAuth(self.provider.transport).register(config)
                self.store.save_registration(config)
            return OperationEnvelope(
                operation="source_mcp_register", status="complete", result=config
            )
        except Exception:
            return _needs(
                "source_mcp_register",
                "Check official MCP availability, OS keychain, "
                "local storage and registered advertiser/callback configuration.",
            )
        finally:
            if fd is not None:
                self.store.unlock(fd)

    def start(
        self,
        config: SourceConnectionConfig,
        *,
        open_browser: bool = True,
        ttl=600,
        callback_tls: ssl.SSLContext | None = None,
        reauthorize: bool = False,
    ):
        descriptor, server = None, None
        try:
            config = SourceConnectionConfig.model_validate(config.model_dump(mode="json"))
            if not 30 <= ttl <= 900:
                raise ValueError
            if not config.client_id:
                return _needs("source_connect", "Provide a developer app client ID locally.")
            from pallas_ads.meta_application import CALLBACK

            relay = config.platform == "meta" and config.registered_redirect_uri == CALLBACK
            secure_callback = bool(
                config.registered_redirect_uri
                and not relay
                and urlsplit(config.registered_redirect_uri).scheme == "https"
            )
            if secure_callback != (callback_tls is not None):
                return _needs(
                    "source_connect",
                    "HTTPS callbacks require a local TLS certificate/context; "
                    "HTTP callbacks must not use a TLS context.",
                )
            if callback_tls is not None and (
                callback_tls.protocol != ssl.PROTOCOL_TLS_SERVER
                or callback_tls.minimum_version < ssl.TLSVersion.TLSv1_2
            ):
                return _needs("source_connect", "Use a server TLS context with TLS 1.2 or newer.")
            if config.platform != "google" and config.registered_redirect_uri is None:
                return _needs(
                    "source_connect",
                    "Provide a provider-approved loopback redirect "
                    "for your developer app, or attach an environment/keychain reference.",
                )
            if config.platform != "google":
                self.provider._app_value(config)
            self.credentials._secure_backend()
            descriptor = self.store.lock(config.connection_id)
            existing = self.store.load(config.connection_id)
            if (
                existing
                and existing.state == "connected"
                and (not reauthorize or existing.config.platform != config.platform)
            ):
                raise ValueError("explicit reauthorization required to replace a connection")
            identifier = "auth_" + uuid4().hex
            nonce, verifier = secrets.token_urlsafe(32), secrets.token_urlsafe(48)
            service = self

            class CallbackServer(ThreadingHTTPServer):
                def handle_error(self, request, client_address):
                    # TLS/client disconnect errors must not emit callback URLs or codes.
                    pass

            class Handler(BaseHTTPRequestHandler):
                def log_message(self, format, *args):
                    pass

                def setup(self):
                    self.request.settimeout(5)
                    if isinstance(self.request, ssl.SSLSocket):
                        self.request.do_handshake()
                    super().setup()

                def do_GET(self):
                    expected_host = urlsplit(local_redirect).netloc
                    accepted = (
                        self.headers.get_all("Host") == [expected_host]
                        and len(self.path) <= 4096
                        and service._callback(identifier, self.path)
                    )
                    self.send_response(200 if accepted else 400)
                    self.send_header("Content-Type", "text/plain; charset=utf-8")
                    self.send_header("Cache-Control", "no-store")
                    self.send_header("Referrer-Policy", "no-referrer")
                    self.send_header("Content-Security-Policy", "default-src 'none'")
                    self.end_headers()
                    self.wfile.write(
                        b"Return to Pallas to check authorization status."
                        if accepted
                        else b"Authorization callback rejected."
                    )

            port = (
                urlsplit(config.registered_redirect_uri).port
                if config.registered_redirect_uri and not relay
                else 0
            )
            server = CallbackServer(("127.0.0.1", port or 0), Handler)
            server.daemon_threads = True
            if callback_tls is not None:
                server.socket = callback_tls.wrap_socket(
                    server.socket,
                    server_side=True,
                    do_handshake_on_connect=False,
                )
            redirect = (
                config.registered_redirect_uri or f"http://127.0.0.1:{server.server_port}/callback"
            )
            local_redirect = (
                f"http://127.0.0.1:{server.server_port}/callback" if relay else redirect
            )
            if relay:
                nonce = f"pallas1_{server.server_port}_{nonce}"
            public = AuthSessionResult(
                session_id=identifier,
                connection_id=config.connection_id,
                platform=config.platform,
                state="pending",
                expires_at=self.clock() + timedelta(seconds=ttl),
                authorization_url=self.provider.authorization_url(
                    config, redirect, nonce, verifier
                ),
                redirect_uri=redirect,
                callback_uri=local_redirect,
            )
            session = _Session(public, config, nonce, verifier, descriptor, server)
            with self._mutex:
                self._sessions[identifier] = session
            threading.Thread(
                target=server.serve_forever, kwargs={"poll_interval": 0.1}, daemon=True
            ).start()
            session.timer = threading.Timer(ttl, self._expire, args=(identifier,))
            session.timer.daemon = True
            session.timer.start()
            descriptor, server = None, None  # session owns cleanup
            if open_browser:
                try:
                    public.browser_opened = bool(self.browser_open(public.authorization_url))
                except Exception:
                    public.browser_opened = False
            return self.status(identifier)
        except Exception:
            if server:
                server.server_close()
            if descriptor is not None:
                self.store.unlock(descriptor)
            return _needs(
                "source_connect",
                "Check local app/credential references, callback port, "
                "existing connection and OS keychain availability.",
            )

    def _finish(self, session, state: str) -> None:
        session.public.state = state
        session.public.authorization_url = None
        session.nonce = session.verifier = ""
        if session.timer:
            session.timer.cancel()
        if session.server:
            server, session.server = session.server, None

            # shutdown must never block the callback or the state mutex.
            def stop():
                server.shutdown()
                server.server_close()

            threading.Thread(target=stop, daemon=True).start()
        if session.descriptor is not None:
            self.store.unlock(session.descriptor)
            session.descriptor = None

    def _expire(self, identifier):
        with self._mutex:
            session = self._sessions.get(identifier)
            if session and session.public.state in ("pending", "exchanging"):
                self._finish(session, "expired")

    def _callback(self, identifier: str, target: str) -> bool:
        try:
            parsed = urlsplit(target)
            if parsed.path != "/callback" or parsed.fragment or parsed.scheme or parsed.netloc:
                return False
            params = parse_qs(parsed.query, keep_blank_values=True, max_num_fields=12)
            if any(len(v) != 1 for v in params.values()):
                return False
            with self._mutex:
                session = self._sessions.get(identifier)
                if session is None or session.public.state != "pending":
                    return False
                if self.clock() >= session.public.expires_at:
                    self._finish(session, "expired")
                    return False
                if not secrets.compare_digest(
                    params.get("state", [""])[0].encode(), session.nonce.encode()
                ):
                    return False
                if "error" in params:
                    self._finish(session, "cancelled")
                    return True
                code_key = (
                    "auth_code"
                    if session.config.platform == "tiktok"
                    and session.config.transport == "native_api"
                    else "code"
                )
                code = params.get(code_key, [""])[0]
                if not code or len(code) > 2048:
                    return False
                session.public.state = "exchanging"
                verifier = session.verifier
                redirect = session.public.redirect_uri
            assert redirect is not None
            tokens = self.provider.exchange(session.config, code, redirect, verifier)
            with self._mutex:
                if session.public.state != "exchanging":
                    return False
                if self.clock() >= session.public.expires_at:
                    self._finish(session, "expired")
                    return False
                ref = CredentialRef(
                    credential_id="credential_" + uuid4().hex,
                    provider="os_keychain",
                    locator="pallas." + uuid4().hex,
                    platform=session.config.platform,
                    created_at=self.clock(),
                )
                previous = self.store.load(session.config.connection_id)
                connection = SourceConnection(
                    config=session.config,
                    credential_ref=ref,
                    credential_owned=True,
                    state="connected",
                    revision=previous.revision + 1 if previous else 1,
                    updated_at=self.clock(),
                    expires_at=self.clock() + timedelta(seconds=tokens.expires_in)
                    if tokens.expires_in
                    else None,
                )
                self.credentials.write(ref, tokens)
                try:
                    self.store.save(connection)
                except Exception:
                    self.credentials.delete(ref)
                    raise
                session.public.connection = connection
                # Reauthorization commits the new grant before deleting the old one.
                # Cancellation or exchange/storage failure leaves the prior grant usable.
                if previous and previous.credential_owned:
                    with suppress(Exception):
                        self.credentials.delete(previous.credential_ref)
                self._finish(session, "connected")
            return True
        except Exception:
            with self._mutex:
                session = self._sessions.get(identifier)
                if session and session.public.state in ("pending", "exchanging"):
                    self._finish(session, "failed")
            return False

    def status(self, identifier):
        with self._mutex:
            session = self._sessions.get(identifier)
            if session is None:
                return _needs(
                    "source_auth_status", "Unknown session; after a process restart, start again."
                )
            if self.clock() >= session.public.expires_at and session.public.state in (
                "pending",
                "exchanging",
            ):
                self._finish(session, "expired")
            result = session.public.model_copy(deep=True)
        pending = result.state in ("pending", "exchanging")
        return OperationEnvelope(
            operation="source_auth_status",
            status="pending_user_action" if pending else "complete",
            result=result,
            issues=(
                [
                    OperationIssue(
                        code="authorization_pending",
                        severity="info",
                        message="Complete authorization in the system browser, then check status.",
                    )
                ]
                if pending
                else []
            )
            + (
                [
                    OperationIssue(
                        code="browser_open_failed",
                        severity="warning",
                        message="The system browser did not open. Use authorization_url while this "
                        "session is pending; do not claim that a login window was opened.",
                    )
                ]
                if pending and result.browser_opened is False
                else []
            ),
        )

    def cancel(self, identifier):
        with self._mutex:
            session = self._sessions.get(identifier)
            if session and session.public.state in ("pending", "exchanging"):
                self._finish(session, "cancelled")
        return self.status(identifier)

    def close(self):
        for identifier in list(self._sessions):
            self.cancel(identifier)

    def attach(self, config: SourceConnectionConfig, ref: CredentialRef):
        fd = None
        try:
            if config.transport == "official_mcp":
                raise ValueError("MCP credentials require browser authorization")
            if ref.platform not in (None, config.platform):
                raise ValueError
            self.credentials.tokens(ref)
            fd = self.store.lock(config.connection_id)
            previous = self.store.load(config.connection_id)
            if previous and previous.state == "connected":
                raise ValueError
            connection = SourceConnection(
                config=config,
                credential_ref=ref,
                state="connected",
                credential_owned=False,
                revision=previous.revision + 1 if previous else 1,
                updated_at=self.clock(),
            )
            self.store.save(connection)
            return OperationEnvelope(
                operation="source_attach", status="complete", result=connection
            )
        except Exception:
            return _needs(
                "source_attach",
                "Check credential reference and disconnect existing connections first.",
            )
        finally:
            if fd is not None:
                self.store.unlock(fd)

    def connection(self, identifier):
        """Persisted metadata plus an observational usability note; no reads or refresh."""
        try:
            result = self.store.load(identifier)
            if result is None:
                raise ValueError
            return OperationEnvelope(
                operation="source_status",
                status="complete",
                result=result,
                issues=self._usability(result),
            )
        except Exception:
            return _needs("source_status", "Connection metadata is missing or invalid.")

    def _usability(self, connection):
        issues = [
            OperationIssue(
                code="usability_not_live_checked",
                severity="info",
                message="Saved state only: no provider request, token read or refresh was "
                "performed. A connected state is not proof of current access.",
            )
        ]
        if connection.state != "connected" or not locally_expired(connection, self.clock()):
            return issues
        issues.append(issue("source_credential_expired", "warning"))
        native_google = (
            connection.config.platform == "google" and connection.config.transport == "native_api"
        )
        if not connection.credential_owned or not native_google:
            issues.append(issue("refresh_not_supported", "warning"))
            return issues
        try:
            self._refresh_config(connection.config)
        except SourceAccessError as error:
            issues.append(issue(error.code, "warning"))
            return issues
        issues.append(
            OperationIssue(
                code="refresh_pending_next_read",
                severity="info",
                message="Pallas attempts one refresh before the next discovery or read. Expiry "
                "alone does not prove the refresh grant is invalid; the outcome is unknown.",
            )
        )
        return issues

    def _refresh_config(self, config):
        """Use a same-client operator app reference; never mix OAuth client identities."""
        if (
            config.platform != "google"
            or config.transport != "native_api"
            or config.app_credential_ref is not None
        ):
            return config
        from pallas_ads.google_application import bundled_secret
        from pallas_ads.provider_setup import load_setup

        if bundled_secret(config.client_id) is not None:
            return config
        try:
            template = next(
                (c for c in load_setup(self.workspace).connections if c.platform == "google"),
                None,
            )
        except (OSError, ValueError):
            template = None
        if template is not None and template.client_id != config.client_id:
            raise SourceAccessError("refresh_client_mismatch")
        if template is None or template.app_credential_ref is None:
            raise SourceAccessError("refresh_app_config_unavailable")
        return config.model_copy(update={"app_credential_ref": template.app_credential_ref})

    def recover(self, identifier, *, attempts=3, wait=0.25):
        """At most one refresh of a locally expired Google credential before a read."""
        try:
            connection = self.store.load(identifier)
        except (OSError, ValueError):
            return None  # The read reports invalid local state itself.
        if (
            connection is None
            or connection.state != "connected"
            or not connection.credential_owned  # User-managed references may be rotated.
            or connection.config.platform != "google"
            or connection.config.transport != "native_api"
            or not locally_expired(connection, self.clock(), REFRESH_SKEW)
        ):
            return None
        for attempt in range(attempts):
            response = self.refresh(identifier, only_if_expired=True)
            busy = any(i.code == "source_busy" for i in response.issues)
            if not busy or attempt + 1 == attempts:
                return response
            self.sleep(wait)  # A held lock never triggers a second provider request.
        return None

    def refresh(self, identifier, *, only_if_expired=False):
        fd = None
        try:
            try:
                fd = self.store.lock(identifier)
            except BlockingIOError:
                raise SourceAccessError("source_busy") from None
            connection = self.store.load(identifier)
            if connection is None or connection.state != "connected":
                raise SourceAccessError("source_connection_unavailable")
            if only_if_expired and not locally_expired(connection, self.clock(), REFRESH_SKEW):
                # Another operation refreshed while this one waited: no second provider request.
                return OperationEnvelope(
                    operation="source_refresh", status="complete", result=connection
                )
            if not connection.credential_owned:
                raise SourceAccessError("refresh_not_supported")
            config = self._refresh_config(connection.config)
            try:
                previous = self.credentials.tokens(connection.credential_ref)
            except Exception:
                raise SourceAccessError("source_credential_unavailable") from None
            tokens = self.provider.refresh(config, previous)
            # A new locator makes rollback possible without overwriting the previous credential.
            ref = connection.credential_ref.model_copy(
                update={
                    "credential_id": "credential_" + uuid4().hex,
                    "locator": "pallas." + uuid4().hex,
                    "created_at": self.clock(),
                }
            )
            refreshed = connection.model_copy(
                update={
                    "config": config,
                    "credential_ref": ref,
                    "revision": connection.revision + 1,
                    "updated_at": self.clock(),
                    "expires_at": self.clock() + timedelta(seconds=tokens.expires_in)
                    if tokens.expires_in
                    else None,
                }
            )
            self.credentials.write(ref, tokens)
            try:
                self.store.save(refreshed)
            except Exception:
                self.credentials.delete(ref)
                raise
            try:
                self.credentials.delete(connection.credential_ref)
            except Exception:
                return OperationEnvelope(
                    operation="source_refresh",
                    status="partial_result",
                    result=refreshed,
                    issues=[
                        OperationIssue(
                            code="credential_cleanup_required",
                            severity="warning",
                            message="Refresh succeeded; "
                            "remove the previous credential locator from OS keychain.",
                        )
                    ],
                )
            return OperationEnvelope(
                operation="source_refresh", status="complete", result=refreshed
            )
        except SourceAccessError as error:
            return access_failure("source_refresh", error.code)
        except SourceHTTPError as error:
            code = "refresh_temporarily_unavailable" if error.retriable else "refresh_failed"
            return access_failure("source_refresh", code)
        except Exception:
            return access_failure("source_refresh", "refresh_failed")
        finally:
            if fd is not None:
                self.store.unlock(fd)

    def disconnect(self, identifier):
        fd = None
        try:
            fd = self.store.lock(identifier)
            connection = self.store.load(identifier)
            if connection is None:
                raise ValueError
            issues = []
            # Disable locally before revocation; a failed revoke must not keep reads enabled.
            disconnected = connection.model_copy(
                update={
                    "state": "disconnected",
                    "revision": connection.revision + 1,
                    "updated_at": self.clock(),
                }
            )
            self.store.save(disconnected)
            try:
                revoked = self.provider.revoke(
                    connection.config, self.credentials.tokens(connection.credential_ref)
                )
            except Exception:
                revoked = False
            if not revoked:
                issues.append(
                    OperationIssue(
                        code="provider_revocation_unconfirmed",
                        message="Local connection "
                        "disabled; verify revocation in the provider's app permissions.",
                    )
                )
            if connection.credential_owned:
                try:
                    self.credentials.delete(connection.credential_ref)
                except Exception:
                    issues.append(
                        OperationIssue(
                            code="credential_cleanup_required",
                            message="Remove the "
                            "connection credential locator from the OS keychain.",
                        )
                    )
            else:
                issues.append(
                    OperationIssue(
                        code="external_credential_retained",
                        severity="info",
                        message="User-managed credential retained; remove it locally when unused.",
                    )
                )
            return OperationEnvelope(
                operation="source_disconnect",
                status="partial_result" if issues else "complete",
                result=disconnected,
                issues=issues,
            )
        except Exception:
            return _needs(
                "source_disconnect", "Could not update connection; inspect local metadata."
            )
        finally:
            if fd is not None:
                self.store.unlock(fd)
