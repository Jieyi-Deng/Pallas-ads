# ruff: noqa: E501
"""Competitor research report rendered from a validated, cited research brief.

No browsing, scraping or model call happens here. The host agent researches public sources;
the contract checks evidence rules and this module renders local, self-contained files.
Unavailable metrics are rendered as text, never plotted, and estimates stay visually distinct.
"""

from __future__ import annotations

import base64
import hashlib
import math
import os
from collections import Counter, defaultdict
from datetime import UTC, datetime
from decimal import Decimal
from pathlib import Path
from string import Template
from typing import Any
from urllib.parse import urlsplit
from uuid import uuid4

from pallas_ads.contracts.competitors import RELIABILITY, CompetitorBrief
from pallas_ads.contracts.status import OperationEnvelope, OperationIssue
from pallas_ads.observation_rendering import csv_text, dump, esc

RENDERER_VERSION = "2.1.0"
SKILL_ASSETS = "skills/pallas-competitors/assets"
ROLE_ORDER = {"subject": 0, "direct": 1, "adjacent": 2, "benchmark": 3}
TIER_ORDER = ("disclosed", "third_party_estimate", "observed_signal", "inferred", "unavailable")
TIER_CHIP = {
    "disclosed": "c-verified",
    "third_party_estimate": "c-estimate",
    "observed_signal": "c-observed",
    "inferred": "c-inference",
    "unavailable": "c-unavailable",
}
TIER_DOT = {
    "disclosed": "d-full",
    "third_party_estimate": "d-hatch",
    "observed_signal": "d-half",
    "inferred": "d-dash",
    "unavailable": "d-empty",
}
BASIS_CHIP = {
    "verified": "c-verified",
    "observed": "c-observed",
    "estimate": "c-estimate",
    "inference": "c-inference",
}
STAGE_COLORS = ("#17191c", "#3a3e44", "#5b616a", "#80868f")
MONTHS = {
    "en": ("JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"),
    "zh-CN": tuple(f"{m}月" for m in range(1, 13)),
}
DATA_REQUEST = {
    "en": "Public data is insufficient to validate these signals. If you have internal sales, campaign, traffic, or customer data, you can provide it to Pallas for additional comparison.",
    "zh-CN": "公开数据不足以验证这些信号。如果你有内部的销售、广告活动、流量或客户数据，可以提供给 Pallas 做进一步对比。",
}
LABELS: dict[str, dict[str, Any]] = {
    "en": {
        "kicker": "Competitive Intelligence Report",
        "title": "{name} competitor research",
        "meta": ("Subject", "Category", "Market", "Scope", "Period"),
        "scope_line": "{p} profiles · {s} sources · public sources only",
        "scope_synthetic": "{p} profiles · {s} sources · synthetic fixture",
        "period_line": "{period} · researched {date}",
        "key": "Evidence key",
        "key_items": (
            ("c-verified", "Verified", "Confirmed by a reliable public source"),
            ("c-observed", "Observed", "Seen directly on a public page, listing or ad library"),
            ("c-estimate", "Estimate", "Third-party or modelled figure; publisher named"),
            ("c-inference", "Inference", "Reasoned from cited evidence; not measured"),
            ("c-hypothesis", "Hypothesis", "To validate with a test"),
            ("c-unavailable", "Unavailable", "No reliable public data; never zero"),
        ),
        "synthetic": "Synthetic example",
        "synthetic_text": "Invented brands, sources and figures that demonstrate the format and evidence rules. This is not market research.",
        "sec_summary": "Executive summary",
        "sec_context": "Product, audience & market",
        "sec_landscape": "Competitive landscape",
        "sec_gtm": "Go-to-market & acquisition",
        "sec_perf": "Investment & performance signals",
        "sec_position": "{name} competitive position",
        "sec_patterns": "Patterns & opportunities",
        "sec_band": "Decision limits & next evidence",
        "sec_signals": "Observable activity signals",
        "signal_note": "These signals describe visible activity, not spend, reach or effectiveness.",
        "missing_summary": "{n} metrics lack supporting public data. They are retained in metrics.csv, not treated as zero or used to rank competitors.",
        "evidence_kind": {
            "paid_ad": "Paid ad",
            "owned_content": "Official content",
            "store_listing": "Store listing",
            "organic_content": "Organic content",
            "other": "Public activity",
        },
        "pattern_kind": {
            "cross_competitor": "Across competitors",
            "single_example": "Single example",
            "measurement_proposal": "Measurement proposal",
        },
        "boundary": "Evidence limit",
        "objective": "Objective",
        "answered_of": "{a} of {n} answered",
        "status": {
            "answered": "Answered",
            "partial": "Partial",
            "insufficient_evidence": "Insufficient evidence",
        },
        "dimension": {"product": "Product", "audience": "Audience", "market": "Market"},
        "market_signals": "Market-level signals",
        "seasonality": "Seasonality calendar",
        "event_window": "Event window",
        "lead_time": "Lead time before the window",
        "classes": "Competitor classes",
        "role": {
            "subject": "Subject",
            "direct": "Direct",
            "adjacent": "Adjacent",
            "benchmark": "Benchmark",
        },
        "role_def": {
            "direct": "Same problem, audience and format or model",
            "adjacent": "Competes for the same need, budget, time or attention",
            "benchmark": "Reference point for product, growth, brand or go-to-market",
        },
        "profile": "Profile",
        "class": "Class",
        "why": "Why it is compared",
        "not_established": "—",
        "not_established_note": "“—” means the attribute was not established in this research. It does not mean the competitor lacks it.",
        "more_attributes": "Further profile evidence",
        "profiles_n": "Sourced · {n} profiles",
        "obs_chip": "Observed sample · {n}",
        "where": "Where they acquire users",
        "where_note": "Cells identify the kind of evidence retained. “–” means not observed in this sample. A store listing or official post does not establish paid activity.",
        "channel": "Channel",
        "what": "What they use to acquire users",
        "seen_in": "Seen in",
        "subject_seen": "Observed ({n})",
        "subject_not_seen": "Not observed in sample",
        "journey": "Observed user journey",
        "observations": "Observation log",
        "obs_cols": (
            "ID",
            "Profile",
            "Channel",
            "Proposition",
            "What was seen",
            "Format · CTA",
            "Seen",
            "Sources",
        ),
        "public_metric": "Public metric: {v}",
        "active": "active at access",
        "inactive": "inactive at access",
        "obs_more": "Showing {k} of {n} observations. The full log is in observations.csv.",
        "csv_link": "observations.csv",
        "perf_lead": "Metrics follow the evidence hierarchy: disclosed, third-party estimate, observed signal, inferred, unavailable. Unavailable values are never charted or counted as zero.",
        "tier": {
            "disclosed": "Disclosed",
            "third_party_estimate": "Estimate",
            "observed_signal": "Observed signal",
            "inferred": "Inferred",
            "unavailable": "Unavailable",
        },
        "unavailable_n": "{n} unavailable",
        "availability": "Data availability",
        "chart_note_range": "Bars show published low–high ranges and diamonds show single values. Hatched marks are third-party estimates. Rows without reliable data are listed as text. The axis starts at zero.",
        "chart_note_bar": "Bars start at zero. Hatched bars are third-party estimates. Rows without reliable data are listed as text and are not plotted.",
        "metric_cols": ("Metric", "Profile", "Value", "Evidence", "Period", "Note"),
        "market": "Market",
        "estimate_by": "Estimate · {p}",
        "na": "n/a",
        "quadrant": {
            "strength": "Strengths",
            "weakness": "Weaknesses",
            "opportunity": "Opportunities",
            "threat": "Threats",
        },
        "quadrant_tag": {
            "strength": "INTERNAL · +",
            "weakness": "INTERNAL · −",
            "opportunity": "EXTERNAL · +",
            "threat": "EXTERNAL · −",
        },
        "hypotheses_chip": "Hypotheses to validate",
        "patterns_lead": "Each pattern follows observation → evidence → implication → hypothesis. Competitor behaviour is a reason to test, not a proven best practice.",
        "oeih": (
            "Observation",
            "Evidence",
            "Implication",
            "Hypothesis",
            "Potential test",
            "Success measure",
        ),
        "lever": "Lever",
        "confidence": "Confidence",
        "answers": "Answers",
        "refs": "Evidence",
        "matrix": "Priority matrix",
        "qualitative": "Qualitative",
        "matrix_q": ("QUICK WINS", "MAJOR BETS", "FILL-INS", "DEPRIORITISE"),
        "impact": "IMPACT →",
        "effort": "EFFORT →",
        "matrix_note": "Placement is an editorial judgement from the research, not a quantified impact estimate.",
        "you_can_provide": "You can provide to Pallas",
        "no_gaps": "No specific evidence gaps were recorded. Competitor spend, conversion and channel returns are still not publicly available.",
        "sources_method": "Sources & method",
        "method": "Method",
        "queries": "Search queries",
        "source_line": "{publisher} · {title} · {type} · reliability {rel} · accessed {acc}",
        "published": " · published {d}",
        "reliability_rule": "Source reliability is derived from the source type, not declared by the researcher. Low-reliability sources (community posts, third-party estimates) cannot verify a claim on their own.",
        "files": "Files",
        "file_links": (
            ("report.json", "Research record"),
            ("sources.csv", "Sources"),
            ("observations.csv", "Observations"),
            ("metrics.csv", "Metrics"),
            ("manifest.json", "Manifest"),
        ),
        "endline": "Pallas · Competitive Intelligence",
        "conf": {"low": "low confidence", "medium": "medium confidence"},
        "basis": {
            "verified": "Verified",
            "observed": "Observed",
            "estimate": "Estimate",
            "inference": "Inference",
        },
        "level": {"low": "Low", "medium": "Medium", "high": "High"},
        "subject_type": {
            "product": "Product",
            "brand": "Brand",
            "app": "App",
            "game": "Game",
            "service": "Service",
            "other": "Other",
        },
        "business_model": {
            "one_time_purchase": "One-time purchase",
            "subscription": "Subscription",
            "in_app_purchase": "In-app purchase",
            "advertising": "Ad-supported",
            "marketplace": "Marketplace",
            "freemium": "Freemium",
            "licensing": "Licensing",
            "services": "Services",
            "other": "Other",
        },
        "channel_type": {
            "search": "Search",
            "paid_social": "Paid social",
            "organic_social": "Organic social",
            "app_store": "App stores",
            "creators": "Creators",
            "retail": "Retail",
            "marketplace": "Marketplaces",
            "partnerships": "Partnerships",
            "affiliates": "Affiliates",
            "community": "Communities",
            "content_seo": "Content / SEO",
            "email_crm": "Email / CRM",
            "events": "Events",
            "other": "Other",
        },
        "proposition_type": {
            "product": "Product",
            "feature": "Feature",
            "content": "Content",
            "creative_concept": "Creative concept",
            "value_proposition": "Value proposition",
            "offer": "Offer",
            "user_scenario": "User scenario",
            "social_proof": "Social proof",
            "brand_positioning": "Brand positioning",
            "other": "Other",
        },
        "levers": {
            "creative": "Creative",
            "messaging": "Messaging",
            "format": "Format",
            "audience_targeting": "Audience targeting",
            "bidding": "Bidding",
            "budget_allocation": "Budget allocation",
            "landing_page": "Landing page",
            "offer": "Offer",
            "pricing": "Pricing",
            "product_packaging": "Product packaging",
            "channel_mix": "Channel mix",
            "test_design": "Test design",
        },
        "source_type": {
            "official_site": "Official site",
            "app_store": "App store",
            "marketplace_listing": "Marketplace listing",
            "social_profile": "Social profile",
            "company_filing": "Company filing",
            "ad_library": "Ad library",
            "transparency_center": "Ads transparency center",
            "creative_center": "Creative center",
            "press_release": "Press release",
            "news": "News",
            "industry_report": "Industry report",
            "community": "Community",
            "third_party_estimate": "Third-party estimate",
            "other": "Other",
        },
        "md_answers": "Executive summary",
        "md_patterns": "Patterns and hypotheses",
        "md_metrics": "Metric evidence",
        "md_gaps": "Evidence gaps",
        "md_sources": "Sources",
        "md_html": "HTML report",
        "sep": ", ",
        "range": "–",
    },
    "zh-CN": {
        "kicker": "竞品信息收集",
        "title": "{name} 竞品研究",
        "meta": ("研究对象", "品类", "市场", "范围", "时间"),
        "scope_line": "{p} 个对象 · {s} 个来源 · 仅公开来源",
        "scope_synthetic": "{p} 个对象 · {s} 个来源 · 合成示例",
        "period_line": "{period} · 研究于 {date}",
        "key": "证据标识",
        "key_items": (
            ("c-verified", "已核实", "由可靠的公开来源确认"),
            ("c-observed", "已观察", "在公开页面、商品页或广告资料库中直接看到"),
            ("c-estimate", "估算", "第三方或模型估算，注明发布方"),
            ("c-inference", "推断", "基于所引证据的推理，未经测量"),
            ("c-hypothesis", "假设", "需要通过测试验证"),
            ("c-unavailable", "不可得", "没有可靠的公开数据，不等于零"),
        ),
        "synthetic": "合成示例",
        "synthetic_text": "本报告使用虚构的品牌、来源和数字，仅用于展示格式与证据规则，不是真实市场研究。",
        "sec_summary": "核心结论",
        "sec_context": "产品、受众与市场",
        "sec_landscape": "竞争格局",
        "sec_gtm": "市场进入与获客",
        "sec_perf": "投入与表现信号",
        "sec_position": "{name} 的竞争位置",
        "sec_patterns": "规律与机会",
        "sec_band": "决策边界与待补证据",
        "sec_signals": "可观察的活动信号",
        "signal_note": "以下信号仅反映可见活动，不代表花费、触达或效果。",
        "missing_summary": "另有 {n} 项所需指标尚未核实，完整记录保留在 metrics.csv；不按零处理，也不据此给竞品排名。",
        "evidence_kind": {
            "paid_ad": "付费广告",
            "owned_content": "官方内容",
            "store_listing": "商店信息",
            "organic_content": "自然传播",
            "other": "公开活动",
        },
        "pattern_kind": {
            "cross_competitor": "跨竞品发现",
            "single_example": "单一样本启发",
            "measurement_proposal": "测量方案",
        },
        "boundary": "证据边界",
        "objective": "研究目的",
        "answered_of": "已回答 {a}/{n}",
        "status": {
            "answered": "已回答",
            "partial": "部分回答",
            "insufficient_evidence": "证据不足",
        },
        "dimension": {"product": "产品", "audience": "受众", "market": "市场"},
        "market_signals": "市场层面信号",
        "seasonality": "季节性日历",
        "event_window": "节点窗口",
        "lead_time": "窗口前的准备期",
        "classes": "竞品类型",
        "role": {
            "subject": "研究对象",
            "direct": "直接竞品",
            "adjacent": "相邻竞品",
            "benchmark": "品类标杆",
        },
        "role_def": {
            "direct": "解决相同问题、面向相同受众，形式或商业模式相近",
            "adjacent": "争夺相同的需求、预算、时间或注意力",
            "benchmark": "在产品、增长、品牌或市场进入上可作参照",
        },
        "profile": "对象",
        "class": "类型",
        "why": "为什么比较",
        "not_established": "—",
        "not_established_note": "“—”表示本次研究未能确认该项，不代表竞品没有。",
        "more_attributes": "更多对象证据",
        "profiles_n": "有来源 · {n} 个对象",
        "obs_chip": "观察样本 · {n} 条",
        "where": "他们在哪里获客",
        "where_note": "单元格标明留存证据的类型。“–”表示本次样本未观察到，不代表没有；商店信息或官方内容不证明付费投放。",
        "channel": "渠道",
        "what": "他们用什么获客",
        "seen_in": "见于",
        "subject_seen": "已观察到（{n}）",
        "subject_not_seen": "样本中未观察到",
        "journey": "观察到的用户路径",
        "observations": "观察明细",
        "obs_cols": (
            "编号",
            "对象",
            "渠道",
            "诉求",
            "看到了什么",
            "格式 · 行动号召",
            "可见时间",
            "来源",
        ),
        "public_metric": "公开指标：{v}",
        "active": "访问时在投",
        "inactive": "访问时已停止",
        "obs_more": "仅展示 {k}/{n} 条观察，完整记录见 observations.csv。",
        "csv_link": "observations.csv",
        "perf_lead": "指标按证据层级标注：公开披露、第三方估算、观察信号、推断、不可得。不可得的指标不作图，也不按零计算。",
        "tier": {
            "disclosed": "公开披露",
            "third_party_estimate": "估算",
            "observed_signal": "观察信号",
            "inferred": "推断",
            "unavailable": "不可得",
        },
        "unavailable_n": "{n} 项不可得",
        "availability": "数据可得性",
        "chart_note_range": "条形为公开的最低–最高区间，菱形为单一数值；斜线填充为第三方估算；没有可靠数据的行以文字列出；坐标从零开始。",
        "chart_note_bar": "条形从零开始；斜线填充为第三方估算；没有可靠数据的行以文字列出，不作图。",
        "metric_cols": ("指标", "对象", "数值", "证据", "时间", "说明"),
        "market": "市场",
        "estimate_by": "估算 · {p}",
        "na": "不可得",
        "quadrant": {
            "strength": "优势",
            "weakness": "劣势",
            "opportunity": "机会",
            "threat": "威胁",
        },
        "quadrant_tag": {
            "strength": "内部 · +",
            "weakness": "内部 · −",
            "opportunity": "外部 · +",
            "threat": "外部 · −",
        },
        "hypotheses_chip": "待验证的假设",
        "patterns_lead": "每条规律按“观察 → 证据 → 含义 → 假设”展开。竞品的做法是值得测试的理由，不是已被证明的最佳实践。",
        "oeih": ("观察", "证据", "含义", "假设", "可做的测试", "衡量标准"),
        "lever": "可调因素",
        "confidence": "置信度",
        "answers": "对应问题",
        "refs": "依据",
        "matrix": "优先级矩阵",
        "qualitative": "定性",
        "matrix_q": ("快速见效", "重大投入", "顺手可做", "暂缓"),
        "impact": "↑ 影响",
        "effort": "投入 →",
        "matrix_note": "位置是基于研究的定性判断，不是量化的影响估计。",
        "you_can_provide": "你可以提供给 Pallas",
        "no_gaps": "本次未记录具体证据缺口。竞品花费、转化和渠道回报仍然无法从公开来源取得。",
        "sources_method": "来源与方法",
        "method": "方法",
        "queries": "检索词",
        "source_line": "{publisher} ·《{title}》· {type} · 可靠性{rel} · 访问于 {acc}",
        "published": " · 发布于 {d}",
        "reliability_rule": "来源可靠性由来源类型决定，而不是由研究者自行声明。低可靠性来源（社区帖子、第三方估算）不能单独核实结论。",
        "files": "文件",
        "file_links": (
            ("report.json", "完整研究记录"),
            ("sources.csv", "来源清单"),
            ("observations.csv", "观察明细"),
            ("metrics.csv", "指标明细"),
            ("manifest.json", "文件校验清单"),
        ),
        "endline": "Pallas · 竞争情报",
        "conf": {"low": "低置信度", "medium": "中置信度"},
        "basis": {
            "verified": "已核实",
            "observed": "已观察",
            "estimate": "估算",
            "inference": "推断",
        },
        "level": {"low": "低", "medium": "中", "high": "高"},
        "subject_type": {
            "product": "产品",
            "brand": "品牌",
            "app": "应用",
            "game": "游戏",
            "service": "服务",
            "other": "其他",
        },
        "business_model": {
            "one_time_purchase": "一次性购买",
            "subscription": "订阅",
            "in_app_purchase": "应用内购买",
            "advertising": "广告变现",
            "marketplace": "平台/市场",
            "freemium": "免费增值",
            "licensing": "授权",
            "services": "服务",
            "other": "其他",
        },
        "channel_type": {
            "search": "搜索",
            "paid_social": "付费社交",
            "organic_social": "自然社交",
            "app_store": "应用商店",
            "creators": "达人",
            "retail": "零售",
            "marketplace": "电商平台",
            "partnerships": "合作",
            "affiliates": "联盟",
            "community": "社区",
            "content_seo": "内容 / SEO",
            "email_crm": "邮件 / CRM",
            "events": "活动",
            "other": "其他",
        },
        "proposition_type": {
            "product": "产品",
            "feature": "功能",
            "content": "内容",
            "creative_concept": "创意概念",
            "value_proposition": "价值主张",
            "offer": "优惠",
            "user_scenario": "使用场景",
            "social_proof": "社会证明",
            "brand_positioning": "品牌定位",
            "other": "其他",
        },
        "levers": {
            "creative": "素材制作",
            "messaging": "卖点与文案",
            "format": "广告格式",
            "audience_targeting": "受众定向",
            "bidding": "出价策略",
            "budget_allocation": "预算分配",
            "landing_page": "落地页",
            "offer": "自有优惠",
            "pricing": "定价",
            "product_packaging": "产品组合",
            "channel_mix": "渠道组合",
            "test_design": "测试设计",
        },
        "source_type": {
            "official_site": "官方网站",
            "app_store": "应用商店",
            "marketplace_listing": "电商商品页",
            "social_profile": "社交主页",
            "company_filing": "公司披露",
            "ad_library": "广告资料库",
            "transparency_center": "广告透明度中心",
            "creative_center": "创意中心",
            "press_release": "新闻稿",
            "news": "新闻报道",
            "industry_report": "行业报告",
            "community": "社区",
            "third_party_estimate": "第三方估算",
            "other": "其他",
        },
        "md_answers": "核心结论",
        "md_patterns": "规律与假设",
        "md_metrics": "指标证据",
        "md_gaps": "证据缺口",
        "md_sources": "来源",
        "md_html": "HTML 报告",
        "sep": "、",
        "range": "–",
    },
}


def asset_path(name):
    bundled = Path(__file__).parent / "resources" / SKILL_ASSETS / name
    return bundled if bundled.is_file() else Path(__file__).parents[2] / SKILL_ASSETS / name


def template_path():
    return asset_path("report.html")


def logo_path():
    return asset_path("pallas-logo.png")


def amount(value):
    """Plain decimal text with thousands separators and no trailing zeros."""
    v = Decimal(value).normalize()
    text = format(v, ",f")
    return "0" if text in {"-0", "0"} else text


def with_unit(text, unit):
    if not unit:
        return text
    return f"{text}{unit}" if unit in {"%", "×", "x"} else f"{text} {unit}"


def numeric(m):
    return m.value is not None or m.low is not None


def midpoint(m):
    return m.value if m.value is not None else (m.low + m.high) / 2


def top_value(m):
    return m.value if m.value is not None else m.high


def nice_axis(top):
    raw = float(top) / 4
    magnitude = 10 ** math.floor(math.log10(raw))
    for multiple in (1, 2, 2.5, 5, 10):
        if multiple * magnitude >= raw:
            return Decimal(str(multiple * magnitude * 4))
    return Decimal(str(10 * magnitude * 4))


class Report:
    def __init__(self, brief: CompetitorBrief):
        self.b = brief
        self.lang = brief.report_language
        self.t = LABELS[self.lang]
        self.sources = {s.source_id: s for s in brief.sources}
        self.profiles = {p.profile_id: p for p in brief.profiles}
        self.subject = next((p for p in brief.profiles if p.role == "subject"), None)
        self.synthetic = brief.evidence_mode == "synthetic_fixture"
        self.number = 0

    # Small building blocks ------------------------------------------------------------------
    def chip(self, cls, text, *, mini=False):
        return f'<span class="chip {cls}{" mini" if mini else ""}">{esc(text)}</span>'

    def cite(self, ids):
        if not ids:
            return ""
        links = ", ".join(f'<a href="#{esc(i)}">{esc(i)}</a>' for i in ids)
        return f'<span class="cite">[{links}]</span>'

    def basis(self, item, *, mini=True):
        if item.basis is None:
            return ""
        text = self.t["basis"][item.basis]
        if item.basis == "estimate":
            publishers = sorted({self.sources[i].publisher for i in item.source_ids})
            text = self.t["estimate_by"].format(p=self.t["sep"].join(publishers))
        if item.confidence:
            text += " · " + self.t["conf"][item.confidence]
        return self.chip(BASIS_CHIP[item.basis], text, mini=mini)

    def ev(self, item, *, mini=True):
        return f'<span class="ev">{self.basis(item, mini=mini)}{self.cite(item.source_ids)}</span>'

    def tier_chip(self, m, *, mini=True):
        text = self.t["tier"][m.tier]
        if m.tier == "third_party_estimate":
            publishers = sorted({self.sources[i].publisher for i in m.source_ids})
            text = self.t["estimate_by"].format(p=self.t["sep"].join(publishers))
        if m.confidence:
            text += " · " + self.t["conf"][m.confidence]
        return self.chip(TIER_CHIP[m.tier], text, mini=mini)

    def metric_text(self, m):
        if m.tier == "unavailable":
            return self.t["na"]
        if m.display:
            return m.display
        if m.value is not None:
            return with_unit(amount(m.value), m.unit)
        return with_unit(f"{amount(m.low)}{self.t['range']}{amount(m.high)}", m.unit)

    def name(self, profile_id):
        return self.profiles[profile_id].name if profile_id else self.t["market"]

    def section(self, title, body, *, chip="", cls="sec"):
        self.number += 1
        return (
            f'<section class="{cls}" id="sec-{self.number}"><div class="sec-head"><span class="num">{self.number:02d}</span>'
            f"<h2>{esc(title)}</h2>{chip}</div>{body}</section>"
        )

    # Header ---------------------------------------------------------------------------------
    def header(self):
        s, scope, t = self.b.subject, self.b.scope, self.t
        site = f" ({urlsplit(s.website).hostname})" if s.website else ""
        models = t["sep"].join(t["business_model"][m] for m in s.business_models)
        scope_text = (t["scope_synthetic"] if self.synthetic else t["scope_line"]).format(
            p=len(self.b.profiles), s=len(self.b.sources)
        )
        rows = (
            (t["meta"][0], f"{s.name}{site}"),
            (t["meta"][1], f"{s.category} · {t['subject_type'][s.subject_type]} · {models}"),
            (t["meta"][2], f"{t['sep'].join(s.markets)} · {t['sep'].join(s.audiences)}"),
            (t["meta"][3], scope_text),
            (
                t["meta"][4],
                t["period_line"].format(
                    period=scope.period_note, date=scope.researched_on.isoformat()
                ),
            ),
        )
        meta = "".join(f'<span class="k">{esc(k)}</span><span>{esc(v)}</span>' for k, v in rows)
        key = f'<span class="lab">{esc(t["key"])}</span>' + "".join(
            f"<span>{self.chip(cls, label)}{esc(text)}</span>"
            for cls, label, text in t["key_items"]
        )
        banner = (
            f'<div class="banner">{self.chip("c-inference", t["synthetic"])}<span>{esc(t["synthetic_text"])}</span></div>'
            if self.synthetic
            else ""
        )
        return meta, key, banner

    # 1. Executive summary --------------------------------------------------------------------
    def summary(self):
        t = self.t
        questions = {q.question_id: q for q in self.b.scope.questions}
        rows = []
        for a in self.b.answers:
            if a.status == "insufficient_evidence":
                evidence = self.chip("c-unavailable", t["status"][a.status], mini=True) + self.cite(
                    self.answer_sources(a)
                )
            else:
                evidence = self.basis(a) + self.cite(self.answer_sources(a))
            q = questions.get(a.question_id)
            question = f'<p class="small">{esc(q.question)}</p>' if q and q.origin == "user" else ""
            rows.append(
                f'<article class="finding"><div>{question}<h3>{esc(a.headline)}</h3></div>'
                f'<div class="finding-body"><p>{esc(a.answer)}</p><div class="ev">{evidence}</div></div></article>'
            )
        body = f'<div class="findings">{"".join(rows)}</div>'
        body += f'<div class="line">{self.chip("c-verified", t["objective"])}<span>{esc(self.b.scope.objective)}</span></div>'
        return self.section(t["sec_summary"], body)

    # 2. Product, audience and market ---------------------------------------------------------
    def tiles(self, metrics):
        out = []
        for m in metrics:
            cls = {"unavailable": " na", "third_party_estimate": " est", "inferred": " inf"}.get(
                m.tier, ""
            )
            note = f'<span class="small">{esc(m.note)}</span>' if m.note else ""
            period = f" · {esc(m.period)}" if m.period else ""
            out.append(
                f'<div class="tile{cls}" id="{esc(m.metric_id)}"><span class="v">{esc(self.metric_text(m))}</span>'
                f'<span class="l">{esc(m.label)}{period}</span><span class="ev">{self.tier_chip(m)}{self.cite(m.source_ids)}</span>{note}</div>'
            )
        return f'<div class="tiles">{"".join(out)}</div>'

    def calendar(self):
        t, months = self.t, MONTHS[self.lang]
        cells = ['<div class="cal"><div style="grid-row:1;grid-column:1"></div>']
        cells += [
            f'<div class="m" style="grid-row:1;grid-column:{2 + i * 2} / span 2">{m}</div>'
            for i, m in enumerate(months)
        ]
        notes = []
        for row, w in enumerate(self.b.seasonality, 2):
            cells.append(
                f'<div class="ev-lbl" style="grid-row:{row}"><span>{esc(w.label)}</span><span class="ev">{self.ev(w)}</span></div>'
            )
            start, end = w.start_month, w.end_month
            # Half-month columns 0..23; windows and lead times wrap across the year end.
            spans = (
                [((start - 1) * 2, (end - start + 1) * 2)]
                if start <= end
                else [((start - 1) * 2, (13 - start) * 2), (0, end * 2)]
            )
            if w.lead_weeks:
                halves = max(1, math.ceil(w.lead_weeks / 2))
                first = (start - 1) * 2 - halves
                lead = (
                    [(first, halves)] if first >= 0 else [(24 + first, -first), (0, halves + first)]
                )
                cells += [
                    f'<div class="lt" style="grid-row:{row};grid-column:{2 + c} / span {n}"></div>'
                    for c, n in lead
                    if n > 0
                ]
            cells += [
                f'<div class="win" style="grid-row:{row};grid-column:{2 + c} / span {n}"></div>'
                for c, n in spans
            ]
            if w.note:
                notes.append(f"{w.label}: {w.note}")
        cells.append("</div>")
        legend = (
            f'<div class="legend"><span><span class="hatch" style="background:var(--ink);border-color:var(--ink)"></span>{esc(t["event_window"])}</span>'
            f'<span><span class="hatch"></span>{esc(t["lead_time"])}</span></div>'
        )
        note = f'<p class="note">{esc(" · ".join(notes))}</p>' if notes else ""
        return f'<div class="sub"><div class="subhead"><h3>{esc(t["seasonality"])}</h3>{legend}</div><div class="scroll">{"".join(cells)}</div>{note}</div>'

    def context(self):
        t = self.t
        market_metrics = [
            m
            for m in self.b.metrics
            if m.profile_id is None and m.tier not in {"unavailable", "inferred"}
        ]
        if not (self.b.context or market_metrics or self.b.seasonality):
            return ""
        body = ""
        if self.b.context:
            order = {"product": 0, "audience": 1, "market": 2}
            cards = "".join(
                f'<div class="card"><span class="lab">{esc(t["dimension"][c.dimension])}</span><h3>{esc(c.aspect)}</h3>'
                f'<p>{esc(c.statement)}</p><div class="foot">{self.ev(c)}</div></div>'
                for c in sorted(self.b.context, key=lambda c: order[c.dimension])
            )
            body += f'<div class="cards" style="--min:190px">{cards}</div>'
        if market_metrics:
            body += f'<div class="sub"><h3>{esc(t["market_signals"])}</h3>{self.tiles(market_metrics)}</div>'
        if self.b.seasonality:
            body += self.calendar()
        return self.section(t["sec_context"], body)

    # 3. Landscape ----------------------------------------------------------------------------
    def landscape(self):
        t = self.t
        profiles = sorted(self.b.profiles, key=lambda p: ROLE_ORDER[p.role])
        if not profiles:
            return ""
        coverage = Counter(a.label for p in profiles for a in p.attributes)
        columns = [label for label, n in coverage.most_common() if n >= 2][:4]
        roles = Counter(p.role for p in profiles if p.role != "subject")
        legend = "".join(
            f"<span>{self.chip('c-observed', f'{t["role"][r]} · {roles[r]}', mini=True)}{esc(t['role_def'][r])}</span>"
            for r in ("direct", "adjacent", "benchmark")
            if roles[r]
        )
        head = (
            f'<tr><th scope="col" class="profile-col">{esc(t["profile"])}</th>'
            f'<th scope="col" class="class-col">{esc(t["class"])}</th>'
            + "".join(f'<th scope="col">{esc(c)}</th>' for c in columns)
            + f'<th scope="col">{esc(t["why"])}</th></tr>'
        )
        rows, extra = [], []
        for p in profiles:
            attrs = {a.label: a for a in p.attributes}
            cells = []
            for c in columns:
                a = attrs.get(c)
                if a is None:
                    cells.append(
                        f'<td class="none" title="{esc(t["not_established_note"])}">{t["not_established"]}</td>'
                    )
                    continue
                mark = "" if a.basis == "verified" else self.basis(a)
                cells.append(
                    f'<td>{esc(a.value)} <span class="ev">{mark}{self.cite(a.source_ids)}</span></td>'
                )
            desc = f'<div class="desc">{esc(p.descriptor)}</div>' if p.descriptor else ""
            role = self.chip(
                "c-subject" if p.role == "subject" else "c-observed", t["role"][p.role], mini=True
            )
            rows.append(
                f'<tr class="{"subj" if p.role == "subject" else ""}" id="{esc(p.profile_id)}"><td><div class="name">{esc(p.name)}</div>{desc}</td>'
                f'<td>{role}</td>{"".join(cells)}<td class="muted">{esc(p.selection_reason)} {self.cite(p.source_ids)}</td></tr>'
            )
            rest = [a for a in p.attributes if a.label not in columns]
            if rest:
                lines = "".join(
                    f'<p><span class="lab">{esc(a.label)}</span><br>{esc(a.value)} {self.ev(a)}</p>'
                    for a in rest
                )
                extra.append(
                    f'<div class="card{" acc" if p.role == "subject" else ""}"><h3>{esc(p.name)}</h3>{lines}</div>'
                )
        body = (
            f'<div class="legend"><span class="lab">{esc(t["classes"])}</span>{legend}</div>'
            if legend
            else ""
        )
        # Reserve identity space, then add a readable width budget per attribute.
        min_width = 450 + 130 * len(columns)
        body += (
            f'<div class="scroll" tabindex="0" role="region" aria-label="{esc(t["sec_landscape"])}">'
            f'<table class="landscape-table" style="--landscape-min:{min_width}px">'
            f"<thead>{head}</thead><tbody>{''.join(rows)}</tbody></table></div>"
        )
        if columns:
            body += f'<p class="note">{esc(t["not_established_note"])}</p>'
        if extra:
            body += f'<div class="sub"><h3>{esc(t["more_attributes"])}</h3><div class="cards" style="--min:260px">{"".join(extra)}</div></div>'
        chip = self.chip("c-verified", t["profiles_n"].format(n=len(profiles)))
        return self.section(t["sec_landscape"], body, chip=chip)

    # 4. Go-to-market and acquisition ---------------------------------------------------------
    def acquisition(self):
        t, obs = self.t, self.b.observations
        if not (obs or self.b.journey):
            return ""
        body = ""
        if obs:
            seen = [
                p
                for p in sorted(self.b.profiles, key=lambda p: ROLE_ORDER[p.role])
                if any(o.profile_id == p.profile_id for o in obs)
            ]
            channels = list(dict.fromkeys(o.channel for o in obs))
            head = (
                f'<tr><th scope="col">{esc(t["channel"])}</th>'
                + "".join(f'<th scope="col">{esc(p.name)}</th>' for p in seen)
                + "</tr>"
            )
            rows = ""
            for channel in channels:
                rows += f'<tr><th scope="row">{esc(channel)}</th>'
                for p in seen:
                    kinds = list(
                        dict.fromkeys(
                            o.evidence_kind
                            for o in obs
                            if o.channel == channel and o.profile_id == p.profile_id
                        )
                    )
                    text = t["sep"].join(t["evidence_kind"][k] for k in kinds) or "–"
                    rows += f"<td>{esc(text)}</td>"
                rows += "</tr>"
            body += (
                f'<div class="sub"><h3>{esc(t["where"])}</h3><div class="scroll" tabindex="0" role="region" aria-label="{esc(t["where"])}">'
                f'<table class="w640"><thead>{head}</thead><tbody>{rows}</tbody></table></div>'
                f'<p class="note">{esc(t["where_note"])}</p></div>'
            )
            records = []
            # Preserve every cited anchor; long evidence is readable in a single record, not eight narrow columns.
            for o in obs:
                metadata = [o.region, o.advertiser, o.format, o.call_to_action]
                when = " – ".join(d.isoformat() for d in (o.first_seen, o.last_seen) if d)
                if when:
                    metadata.append(when)
                if o.active_when_accessed is not None:
                    metadata.append(t["active"] if o.active_when_accessed else t["inactive"])
                metadata.append(o.evidence_locator)
                detail = " · ".join(dict.fromkeys(x for x in metadata if x))
                extra = (
                    f'<p class="small">{esc(t["public_metric"].format(v=o.public_metric))}</p>'
                    if o.public_metric
                    else ""
                )
                limit = (
                    f'<p class="note"><b>{esc(t["boundary"])}：</b>{esc(o.limitation)}</p>'
                    if o.limitation
                    else ""
                )
                records.append(
                    f'<article class="observation" id="{esc(o.observation_id)}"><div class="observation-context">'
                    f"<h4>{esc(self.name(o.profile_id))}</h4><p>{esc(o.channel)}</p>"
                    f"{self.chip('c-observed', t['evidence_kind'][o.evidence_kind], mini=True)}</div>"
                    f'<div class="observation-body"><h4>{esc(o.proposition)}</h4><p>{esc(o.description)}</p>{limit}'
                    f'<p class="small">{esc(detail)}</p>{extra}{self.cite(o.source_ids)}</div></article>'
                )
            body += f'<div class="sub"><h3>{esc(t["observations"])}</h3><div class="observation-list">{"".join(records)}</div></div>'
        if self.b.journey:
            stages = ""
            for i, stage in enumerate(self.b.journey):
                color = STAGE_COLORS[min(i, len(STAGE_COLORS) - 1)]
                tactics = "".join(f"<li>{esc(x)}</li>" for x in stage.tactics)
                stages += f'<div class="stage"><h4 class="chev" style="background:{color}">{esc(stage.stage)}</h4><ul>{tactics}</ul>{self.ev(stage)}</div>'
            body += f'<div class="sub"><h3>{esc(t["journey"])}</h3><div class="journey">{stages}</div></div>'
        return self.section(t["sec_gtm"], body)

    # 5. Investment and performance -----------------------------------------------------------
    def chart(self, label, unit, metrics):
        t = self.t
        plotted = [m for m in metrics if numeric(m)]
        ranged = any(m.low is not None for m in plotted)
        axis = nice_axis(max(top_value(m) for m in plotted))
        ordered = sorted(plotted, key=midpoint) + [m for m in metrics if not numeric(m)]
        ticks = "".join(
            f'<span style="left:{i * 25}%">{esc(with_unit(amount(axis * i / 4), unit) if i == 4 else amount(axis * i / 4))}</span>'
            for i in range(5)
        )
        rows = f'<div></div><div class="axis">{ticks}</div><div></div>'
        for m in ordered:
            subj = self.subject is not None and m.profile_id == self.subject.profile_id
            s = " subj" if subj else ""
            est = " est" if m.tier == "third_party_estimate" else ""
            if not numeric(m):
                reason = m.note if m.tier == "unavailable" else m.display
                track = f'<div class="track na">{esc(reason or self.t["na"])}</div>'
            elif m.value is not None and ranged:
                track = f'<div class="track"><div class="dot{s}{est}" style="left:{float(m.value / axis * 100):.2f}%"></div></div>'
            elif m.value is not None:
                track = f'<div class="track"><div class="bar{s}{est}" style="left:0;width:{max(0.6, float(m.value / axis * 100)):.2f}%"></div></div>'
            else:
                left = float(m.low / axis * 100)
                width = max(0.6, float((m.high - m.low) / axis * 100))
                track = f'<div class="track"><div class="bar{s}{est}" style="left:{left:.2f}%;width:{width:.2f}%"></div></div>'
            rows += (
                f'<div class="who{s}" id="{esc(m.metric_id)}">{esc(self.name(m.profile_id))}</div>{track}'
                f'<div class="lbl{s}"><span class="val">{esc(self.metric_text(m))}</span><span class="ev">{self.tier_chip(m)}{self.cite(m.source_ids)}</span></div>'
            )
        periods = sorted({m.period for m in metrics if m.period})
        caption = t["chart_note_range"] if ranged else t["chart_note_bar"]
        sub = esc(" · ".join(periods)) if periods else ""
        return (
            f'<div class="sub"><div class="subhead"><h3>{esc(label)}{f" ({esc(unit)})" if unit else ""}</h3><span class="small">{sub}</span></div>'
            f'<div class="chart">{rows}</div><p class="note">{esc(caption)}</p></div>'
        )

    def performance(self):
        t = self.t
        metrics = [
            m
            for m in self.b.metrics
            if m.profile_id is not None and m.tier not in {"unavailable", "inferred"}
        ]
        if not metrics:
            return ""
        groups = defaultdict(list)
        for m in metrics:
            groups[(m.label, m.unit, m.period, m.geography)].append(m)
        signals_only = all(m.tier == "observed_signal" for m in metrics)
        body = f'<p class="lead">{esc(t["signal_note"] if signals_only else t["perf_lead"])}</p>'
        table_rows = []
        for (label, unit, period, _geography), items in groups.items():
            values = [m for m in items if numeric(m)]
            if (
                period
                and _geography
                and len({m.profile_id for m in values}) >= 2
                and all(top_value(m) > 0 for m in values)
                and all((m.low or 0) >= 0 for m in values)
            ):
                body += self.chart(label, unit, items)
            else:
                table_rows += items
        if table_rows:
            rows = ""
            for m in table_rows:
                scope = " · ".join(x for x in (m.period, m.geography) if x)
                rows += (
                    f'<tr id="{esc(m.metric_id)}"><th scope="row">{esc(m.label)}<div class="desc">{esc(self.name(m.profile_id))}</div></th>'
                    f'<td class="val">{esc(self.metric_text(m))}<div>{self.tier_chip(m)}</div></td>'
                    f'<td><p>{esc(m.note or "")}</p><p class="small">{esc(scope)}</p>{self.cite(m.source_ids)}</td></tr>'
                )
            cols = (t["metric_cols"][0], t["metric_cols"][2], t["metric_cols"][5])
            head = "".join(f'<th scope="col">{esc(c)}</th>' for c in cols)
            body += f'<div class="scroll" tabindex="0" role="region" aria-label="{esc(t["md_metrics"])}"><table class="metrics-table"><thead><tr>{head}</tr></thead><tbody>{rows}</tbody></table></div>'
        return self.section(t["sec_signals"] if signals_only else t["sec_perf"], body)

    # 6. Position ----------------------------------------------------------------------------
    def position(self):
        t = self.t
        if not self.b.position or self.subject is None:
            return ""
        quads = ""
        for q in ("strength", "weakness", "opportunity", "threat"):
            items = [p for p in self.b.position if p.quadrant == q]
            if not items:
                continue
            lis = "".join(
                f"<li><span>{esc(p.statement)} {self.ev(p)}{self.refs_text(p.pattern_ids)}</span></li>"
                for p in items
            )
            quads += (
                f'<div class="quad {q}"><div class="qh"><h3>{esc(t["quadrant"][q])}</h3><span class="lab">{esc(t["quadrant_tag"][q])}</span></div>'
                f"<ul>{lis}</ul></div>"
            )
        return self.section(
            t["sec_position"].format(name=self.subject.name), f'<div class="swot">{quads}</div>'
        )

    def refs_text(self, ids):
        names = {p.pattern_id: p.title for p in self.b.patterns}
        return " ".join(
            f'<a class="refs" href="#{esc(i)}">{esc(names[i])}</a>' for i in ids if i in names
        )

    def pattern_sources(self, pattern):
        ids = list(pattern.source_ids)
        for item in [*self.b.observations, *self.b.metrics]:
            identity = getattr(item, "observation_id", getattr(item, "metric_id", None))
            if identity in pattern.observation_ids + pattern.metric_ids:
                ids.extend(item.source_ids)
        return list(dict.fromkeys(ids))

    def answer_sources(self, answer):
        ids = list(answer.source_ids)
        for pattern in self.b.patterns:
            if pattern.pattern_id in answer.pattern_ids:
                ids.extend(self.pattern_sources(pattern))
        for metric in self.b.metrics:
            if metric.metric_id in answer.metric_ids:
                ids.extend(metric.source_ids)
        return list(dict.fromkeys(ids))

    # 7. Patterns and opportunities ----------------------------------------------------------
    def patterns(self):
        t = self.t
        if not self.b.patterns:
            return ""
        rows = ""
        for p in self.b.patterns:
            k = t["oeih"]
            fields = [
                (k[0], p.observation),
                (k[1], p.evidence),
                (k[2], p.implication),
                (k[3], p.hypothesis),
                (k[4], p.test),
                (k[5], p.success_measure),
            ]
            pairs = "".join(
                f'<div class="reason-pair"><dt>{esc(label)}</dt><dd>{esc(value)}</dd></div>'
                for label, value in fields
                if value
            )
            meta = self.chip("c-hypothesis", t["pattern_kind"][p.kind], mini=True)
            meta += self.chip("c-inference", t["conf"][p.confidence], mini=True)
            if p.lever:
                meta += f"<span>{esc(t['levers'][p.lever])}</span>"
            rows += (
                f'<article class="opp" id="{esc(p.pattern_id)}"><h3>{esc(p.title)}</h3>'
                f'<div class="pattern-meta">{meta}</div><dl class="reasoning">{pairs}</dl>'
                f'<div class="ev">{self.cite(self.pattern_sources(p))}</div></article>'
            )
        return self.section(t["sec_patterns"], f'<div class="opps">{rows}</div>')

    def matrix(self):
        t = self.t
        placed = [
            (i, p, p.effort, p.impact)
            for i, p in enumerate(self.b.patterns, 1)
            if p.impact and p.effort
        ]
        if len(placed) < 2:
            return ""
        # Three qualitative levels per axis map to the centres of a 3 x 3 grid, never to a line.
        x = {"low": 16.7, "medium": 50, "high": 83.3}
        y = {"high": 16.7, "medium": 50, "low": 83.3}
        cells = Counter((effort, impact) for _, _, effort, impact in placed)
        seen = Counter()
        points = ""
        for i, p, effort, impact in placed:
            cell = (effort, impact)
            offset = (seen[cell] - (cells[cell] - 1) / 2) * 11
            seen[cell] += 1
            cls = "pt" if p.confidence == "medium" else "pt low"
            points += f'<span class="{cls}" style="left:{x[effort] + offset:.1f}%;top:{y[impact]}%" title="{esc(p.title)}">{i:02d}</span>'
        q = t["matrix_q"]
        quadrants = (
            f'<span class="q" style="left:8px;top:6px">{esc(q[0])}</span><span class="q" style="right:8px;top:6px">{esc(q[1])}</span>'
            f'<span class="q" style="left:8px;bottom:6px">{esc(q[2])}</span><span class="q" style="right:8px;bottom:6px">{esc(q[3])}</span>'
        )
        return (
            f'<div class="matrix-box"><div class="subhead"><h3>{esc(t["matrix"])}</h3>{self.chip("c-inference", t["qualitative"])}</div>'
            f'<div class="matrix"><div class="ax y">{esc(t["impact"])}</div><div class="plane">{quadrants}{points}</div><div></div><div class="ax">{esc(t["effort"])}</div></div>'
            f'<div class="legend"><span><span class="d d-full"></span>{esc(t["conf"]["medium"])}</span>'
            f'<span><span class="d d-empty" style="border-color:var(--ink)"></span>{esc(t["conf"]["low"])}</span></div>'
            f'<p class="note">{esc(t["matrix_note"])}</p></div>'
        )

    # 8. Gaps band ---------------------------------------------------------------------------
    def band(self):
        t = self.t
        missing = sum(m.tier == "unavailable" for m in self.b.metrics)
        if not self.b.gaps and not missing:
            return ""
        items = ""
        for g in self.b.gaps:
            ask = (
                f'<div class="ask"><h4>{esc(t["you_can_provide"])}</h4><p>{esc(g.user_data)}</p></div>'
                if g.user_data
                else ""
            )
            items += f'<article class="band-item"><h3>{esc(g.topic)}</h3><div class="gap-detail"><p>{esc(g.reason)}</p>{ask}</div></article>'
        body = (
            f'<p class="lead">{esc(t["missing_summary"].format(n=missing))}</p>' if missing else ""
        )
        return self.section(
            t["sec_band"], body + f'<div class="band-grid">{items}</div>', cls="sec band"
        )

    # Footer ---------------------------------------------------------------------------------
    def footer(self):
        sources = "".join(
            f'<li id="{esc(s.source_id)}"><span class="source-publisher">{esc(s.publisher)}</span>'
            f'<span>{esc(s.title)}</span><a href="{esc(s.url)}" rel="noreferrer noopener">{esc(s.url)}</a></li>'
            for s in self.b.sources
        )
        return f'<div class="block"><h2>{esc(self.t["md_sources"])}</h2><ol class="sources">{sources}</ol></div>'

    # Assembly -------------------------------------------------------------------------------
    def html(self):
        t, s = self.t, self.b.subject
        title = t["title"].format(name=s.name)
        meta, key, banner = self.header()
        sections = "".join(
            part()
            for part in (
                self.summary,
                self.context,
                self.landscape,
                self.acquisition,
                self.performance,
                self.position,
                self.patterns,
                self.band,
            )
        )
        logo = "data:image/png;base64," + base64.b64encode(logo_path().read_bytes()).decode()
        return Template(template_path().read_text(encoding="utf-8")).substitute(
            lang=esc(self.lang),
            title=esc(title),
            kicker=esc(t["kicker"]),
            subtitle=esc(self.b.scope.objective),
            meta=meta,
            key=key,
            banner=banner,
            sections=sections,
            footer=self.footer(),
            logo=logo,
            endline_left=esc(t["endline"]),
            endline_right=esc(f"{s.name} · {self.b.scope.researched_on.isoformat()}"),
        )

    def markdown(self):
        t, b = self.t, self.b
        md = f"# {t['title'].format(name=b.subject.name)}\n\n"
        if self.synthetic:
            md += f"> {t['synthetic']}: {t['synthetic_text']}\n\n"
        md += f"{t['objective']}: {b.scope.objective}\n\n## {t['sec_summary']}\n\n"
        for a in b.answers:
            label = t["basis"][a.basis] if a.basis else t["status"][a.status]
            cites = " ".join(f"[{i}]" for i in self.answer_sources(a))
            md += f"- **{a.headline}** [{label}]: {a.answer} {cites}".rstrip() + "\n"
        if b.patterns:
            md += f"\n## {t['md_patterns']}\n\n"
            for p in b.patterns:
                md += f"- **{p.title}** ({t['pattern_kind'][p.kind]})\n"
                for label, value in zip(
                    t["oeih"],
                    (
                        p.observation,
                        p.evidence,
                        p.implication,
                        p.hypothesis,
                        p.test,
                        p.success_measure,
                    ),
                    strict=True,
                ):
                    if value:
                        md += f"  - {label}: {value}\n"
                md += "  " + " ".join(f"[{i}]" for i in self.pattern_sources(p)) + "\n"
        metrics = [m for m in b.metrics if m.tier not in {"unavailable", "inferred"}]
        if metrics:
            md += f"\n## {t['md_metrics']}\n\n"
            md += (
                "\n".join(
                    f"- {m.label} · {self.name(m.profile_id)}: {self.metric_text(m)} [{t['tier'][m.tier]}]"
                    + (f" ({m.note})" if m.note else "")
                    + "".join(f" [{i}]" for i in m.source_ids)
                    for m in metrics
                )
                + "\n"
            )
        missing = sum(m.tier == "unavailable" for m in b.metrics)
        if b.gaps or missing:
            md += f"\n## {t['sec_band']}\n\n"
            if missing:
                md += t["missing_summary"].format(n=missing) + "\n\n"
            md += "\n".join(
                f"- {g.topic}: {g.reason}"
                + (f" {t['you_can_provide']}: {g.user_data}" if g.user_data else "")
                for g in b.gaps
            )
        md += f"\n\n## {t['md_sources']}\n\n" + "\n".join(
            f"- {s.publisher} · {s.title} · {s.url}" for s in b.sources
        )
        return md + f"\n\n[{t['md_html']}](report.html)\n"


def render(brief: CompetitorBrief):
    report = Report(brief)
    return report.html(), report.markdown()


def build_competitor_report(workspace, brief: CompetitorBrief):
    root = workspace.layout.root / "reports/competitors"
    root.mkdir(parents=True, exist_ok=True)
    identifier = "competitor_" + uuid4().hex
    pending, destination = root / ("." + identifier), root / identifier
    pending.mkdir(mode=0o700)
    html_text, md = render(brief)
    record = {
        "schema_version": "2.0.0",
        "kind": "competitor_research_report",
        "evidence_mode": brief.evidence_mode,
        "created_at": datetime.now(UTC).isoformat(),
        "brief": brief.model_dump(mode="json"),
    }
    files = {
        "report.html": html_text,
        "report.md": md,
        "chat.md": md,
        "report.json": dump(record),
        "sources.csv": csv_text(
            [
                {**s.model_dump(mode="json"), "reliability": RELIABILITY[s.source_type]}
                for s in brief.sources
            ],
            [
                "source_id",
                "source_type",
                "reliability",
                "publisher",
                "title",
                "url",
                "accessed_on",
                "published_on",
            ],
        ),
        "observations.csv": csv_text(
            [
                {**o.model_dump(mode="json"), "source_ids": " ".join(o.source_ids)}
                for o in brief.observations
            ],
            [
                "observation_id",
                "profile_id",
                "channel_type",
                "channel",
                "proposition_type",
                "proposition",
                "description",
                "evidence_kind",
                "advertiser",
                "evidence_locator",
                "limitation",
                "format",
                "region",
                "call_to_action",
                "first_seen",
                "last_seen",
                "active_when_accessed",
                "public_metric",
                "source_ids",
            ],
        ),
        "metrics.csv": csv_text(
            [
                {**m.model_dump(mode="json"), "source_ids": " ".join(m.source_ids)}
                for m in brief.metrics
            ],
            [
                "metric_id",
                "profile_id",
                "label",
                "unit",
                "tier",
                "value",
                "low",
                "high",
                "display",
                "period",
                "geography",
                "confidence",
                "note",
                "source_ids",
            ],
        ),
    }
    # Keep deterministic text exports consistent with the repository and manifest hashes.
    files = {name: text.replace("\r\n", "\n") for name, text in files.items()}
    for name, text in files.items():
        (pending / name).write_text(text, encoding="utf-8")
    manifest = {
        "renderer": "competitor_report",
        "renderer_version": RENDERER_VERSION,
        "template_sha256": hashlib.sha256(template_path().read_bytes()).hexdigest(),
        "logo_sha256": hashlib.sha256(logo_path().read_bytes()).hexdigest(),
        "report_id": identifier,
        "evidence_mode": brief.evidence_mode,
        "report_language": brief.report_language,
        "files": {n: hashlib.sha256(t.encode()).hexdigest() for n, t in files.items()},
    }
    (pending / "manifest.json").write_text(dump(manifest), encoding="utf-8")
    os.rename(pending, destination)
    issues = []
    if brief.evidence_mode == "synthetic_fixture":
        issues.append(
            OperationIssue(
                code="synthetic_fixture",
                severity="warning",
                message="Synthetic example: invented brands, sources and figures, not market research.",
            )
        )
    competitors = [p for p in brief.profiles if p.role != "subject"]
    if not competitors or all(a.status == "insufficient_evidence" for a in brief.answers):
        issues.append(
            OperationIssue(
                code="competitor_evidence_insufficient",
                severity="warning",
                message="No sourced competitors or supported findings; conclusions are limited.",
            )
        )
    roles: Counter[str] = Counter(p.role for p in brief.profiles)
    return OperationEnvelope(
        operation="build_report",
        status="partial_result" if issues else "complete",
        issues=issues,
        result={
            "report_id": identifier,
            "evidence_mode": brief.evidence_mode,
            "report_language": brief.report_language,
            "counts": {
                "sources": len(brief.sources),
                "profiles": {r: roles[r] for r in ROLE_ORDER if roles[r]},
                "observations": len(brief.observations),
                "metrics": dict(Counter(m.tier for m in brief.metrics)),
                "patterns": len(brief.patterns),
                "answers": dict(Counter(a.status for a in brief.answers)),
                "gaps": len(brief.gaps),
            },
            "artifacts": {
                "html": str(destination / "report.html"),
                "markdown": str(destination / "report.md"),
                "data": str(destination / "report.json"),
                "sources": str(destination / "sources.csv"),
                "observations": str(destination / "observations.csv"),
                "metrics": str(destination / "metrics.csv"),
                "manifest": str(destination / "manifest.json"),
            },
            "next_step": (
                "Lead with decision-relevant findings and their evidence limits. "
                "State unavailable metrics as unavailable, frame patterns as hypotheses to test, "
                "ask for the user's own data where a gap blocks the decision, and link the HTML."
            ),
        },
    )
