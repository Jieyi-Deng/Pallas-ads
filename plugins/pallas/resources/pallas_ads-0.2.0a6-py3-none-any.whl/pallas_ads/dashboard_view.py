"""Self-contained interactive dashboard. Inline code is authorized by an exact CSP hash."""

import base64
import hashlib
import json
import re
from html import escape
from pathlib import Path
from string import Template


def render_interactive(state, today, assets: Path, payload=None):
    from pallas_ads.dashboard_data import view_data

    payload = payload if payload is not None else view_data(state, today)
    language = payload.get("report_language", "en")
    catalogue = json.loads((assets / "dashboard.zh-CN.json").read_text())
    template = (assets / "dashboard.html").read_text().replace('lang="en"', 'lang="$lang"')
    if language == "zh-CN":
        # Only localize the static template, before any user data is substituted.
        template = re.sub(r">([^<>]+)<", lambda m: ">" + catalogue.get(m[1], m[1]) + "<", template)
        template = re.sub(
            r'(aria-label|title|placeholder)="([^"]+)"',
            lambda m: f'{m[1]}="{catalogue.get(m[2], m[2])}"',
            template,
        )
    encoded = (
        json.dumps(payload, ensure_ascii=True, separators=(",", ":"))
        .replace("<", "\\u003c")
        .replace(">", "\\u003e")
        .replace("&", "\\u0026")
    )
    messages = (
        json.dumps(catalogue if language == "zh-CN" else {}, ensure_ascii=True)
        .replace("<", "\\u003c")
        .replace(">", "\\u003e")
        .replace("&", "\\u0026")
    )
    script = (
        "const DASHBOARD = "
        + encoded
        + ";\nconst REPORT_MESSAGES = "
        + messages
        + ";\n"
        + (assets / "dashboard.js").read_text()
    )
    digest = base64.b64encode(hashlib.sha256(script.encode()).digest()).decode()
    return Template(template).substitute(
        lang=language,
        title=escape(state["title"]),
        script=script,
        script_hash=digest,
        css=(assets / "dashboard.css").read_text(),
        logo="data:image/png;base64,"
        + base64.b64encode((assets / "pallas-logo.png").read_bytes()).decode(),
        synthetic=(
            '<span class="demo">'
            + ("合成数据" if language == "zh-CN" else "Synthetic data")
            + "</span>"
        )
        if payload["synthetic"]
        else "",
    )
