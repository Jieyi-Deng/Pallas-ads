"""Reusable local entrypoints shipped with the dashboard skill and runtime."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

from pallas_ads.contracts.dashboard import DashboardRequest
from pallas_ads.dashboard import FORMAT_VERSION, RENDERER_VERSION, template_path
from pallas_ads.dashboard_data import DashboardData
from pallas_ads.dashboard_import import normalize_file


def sha(path):
    if path.is_symlink():
        raise ValueError("Unexpected symlink")
    return hashlib.sha256(path.read_bytes()).hexdigest()


def inventory(workspace):
    """Only inspect the selected workspace; never create a workspace or query accounts."""
    results = []
    if (workspace / "dashboards").is_symlink():
        raise ValueError("Unexpected symlink")
    for path in sorted((workspace / "dashboards").glob("dash_*/state.json")):
        if path.is_symlink() or path.parent.is_symlink():
            raise ValueError("Unexpected symlink")
        state = json.loads(path.read_bytes())
        DashboardRequest(op="status", dashboard_id=state["dashboard_id"])
        if state["dashboard_id"] != path.parent.name or state["format_version"] != FORMAT_VERSION:
            raise ValueError("Unsupported or mismatched state")
        results.append(
            {
                "dashboard_id": state["dashboard_id"],
                "title": state["title"],
                "sources": list(state["sources"]),
                "format_version": state["format_version"],
                "state_path": str(path.resolve()),
                "html_path": str(path.with_name("dashboard.html").resolve()),
            }
        )
    return results


def verify(workspace, dashboard_id):
    DashboardRequest(op="status", dashboard_id=dashboard_id)
    folder = workspace / "dashboards" / dashboard_id
    if folder.is_symlink() or folder.parent.is_symlink():
        raise ValueError("Unexpected symlink")
    sha(folder / "manifest.json")
    manifest = json.loads((folder / "manifest.json").read_bytes())
    names = {"dashboard.html", "data.json", "rows.csv", "status.json"}
    if set(manifest["files"]) != names:
        raise ValueError("Unexpected artifact inventory")
    if any(sha(folder / name) != manifest["files"][name] for name in names):
        raise ValueError("Artifact checksum mismatch; do not deliver this dashboard")
    expected = {
        name: sha(template_path().parent / name)
        for name in (
            "dashboard.html",
            "dashboard.css",
            "dashboard.js",
            "dashboard.zh-CN.json",
            "pallas-logo.png",
        )
    }
    if manifest.get("template_assets_sha256") != expected:
        raise ValueError("Template assets differ from the installed runtime")
    if manifest.get("renderer_version") != RENDERER_VERSION:
        raise ValueError("Renderer version mismatch")
    if manifest.get("state_sha256") != sha(folder / "state.json"):
        raise ValueError("State/artifact generation mismatch; regenerate using dashboard status")
    state = json.loads((folder / "state.json").read_bytes())
    if state["format_version"] != FORMAT_VERSION or state["dashboard_id"] != dashboard_id:
        raise ValueError("Unsupported or mismatched state")
    payload = json.loads((folder / "data.json").read_bytes())
    html = (folder / "dashboard.html").read_text()
    embedded = json.loads(html.split("const DASHBOARD = ", 1)[1].split(";\n", 1)[0])
    if embedded != payload or payload["id"] != dashboard_id:
        raise ValueError("HTML does not embed the saved view data")
    return {
        "verified": True,
        "html": str((folder / "dashboard.html").resolve()),
        "scope": "local artifact integrity, not live data accuracy or completeness",
        "data_status": json.loads((folder / "status.json").read_bytes()),
    }


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    normalizer = commands.add_parser("normalize")
    normalizer.add_argument("--raw", type=Path, required=True)
    normalizer.add_argument("--mapping", type=Path, required=True)
    normalizer.add_argument("--output-dir", type=Path, required=True)
    validator = commands.add_parser("validate")
    validator.add_argument("path", type=Path)
    for name in ("list", "verify"):
        command = commands.add_parser(name)
        command.add_argument("--workspace", type=Path, required=True)
        if name == "verify":
            command.add_argument("--dashboard", required=True)
    args = parser.parse_args(argv)
    try:
        if args.command == "normalize":
            result = normalize_file(args.raw, args.mapping, args.output_dir)
        elif args.command == "validate":
            value = DashboardData.model_validate_json(args.path.read_bytes())
            result = {"valid": True, "campaign_rows": len(value.rows)}
        elif args.command == "list":
            result = inventory(args.workspace.resolve())
        else:
            result = verify(args.workspace.resolve(), args.dashboard)
    except (ValueError, OSError, KeyError, IndexError) as error:
        parser.exit(
            1,
            f"Dashboard {args.command} failed: {type(error).__name__}. "
            "Check the mapping, schema, retained files and runtime version.\n",
        )
    print(json.dumps(result, ensure_ascii=False))


if __name__ == "__main__":
    main()
