"""Operator-owned provider templates; never expose developer settings to the end-user flow."""

from pathlib import Path

from pydantic import Field, model_validator

from pallas_ads.contracts.base import VersionedContract
from pallas_ads.contracts.source import SourceConnectionConfig
from pallas_ads.platform_support import is_link


class ProviderSetup(VersionedContract):
    connections: list[SourceConnectionConfig] = Field(default_factory=list, max_length=3)

    @model_validator(mode="after")
    def unique_platforms(self):
        if len({c.platform for c in self.connections}) != len(self.connections):
            raise ValueError("one operator template per platform")
        for c in self.connections:
            if c.platform in ("meta", "google") and not c.client_id:
                raise ValueError("operator OAuth client required")
            if (
                c.platform == "meta"
                and c.transport == "native_api"
                and (not c.app_credential_ref or not c.meta_config_id)
            ):
                raise ValueError("operator Meta app/configuration required")
            if (
                c.platform == "meta"
                and c.transport == "native_api"
                and not (c.registered_redirect_uri or "").startswith("https://")
            ):
                raise ValueError("operator Meta HTTPS callback required")
            if c.login_customer_id or c.mcp_advertiser_id:
                raise ValueError("operator templates cannot preselect advertising accounts")
        return self


def setup_layer(workspace):
    """The single configuration layer in effect: workspace, OS user, then packaged identity."""
    path = workspace.layout.root / "settings/providers.json"
    # Whole workspace file wins, including an explicitly empty configuration.
    if path.exists():
        return "workspace", path
    path = user_setup_path()
    if path.exists():
        return "user_default", path
    return "packaged", None


def load_setup(workspace):
    layer, path = setup_layer(workspace)
    if path is None:
        from pallas_ads.google_application import bundled_client
        from pallas_ads.meta_application import bundled_client as meta_client

        app = bundled_client()
        connections = []
        if app:
            connections.append(
                SourceConnectionConfig(
                    connection_id="connection_google_template",
                    platform="google",
                    client_id=app["client_id"],
                )
            )
        meta = meta_client()
        if meta:
            connections.append(
                SourceConnectionConfig(
                    connection_id="connection_meta_template",
                    platform="meta",
                    transport="official_mcp",
                    client_id=meta["client_id"],
                    registered_redirect_uri=meta["redirect_uri"],
                )
            )
        return ProviderSetup(connections=connections)
    if any(is_link(p) for p in (path, *path.parents)) or path.stat().st_size > 65536:
        raise ValueError("invalid operator setup")
    return ProviderSetup.model_validate_json(path.read_text(encoding="utf-8"))


def google_setup(workspace, executable="pallas"):
    """Credential-free Google configuration source and the exact remaining operator step."""
    from pallas_ads.platform_support import shell_command

    layer, path = setup_layer(workspace)
    location = str(path) if path else None
    arguments = [executable, "providers", "google-desktop", "--input", "DESKTOP_CLIENT.json"]
    arguments += (
        ["--workspace", str(workspace.layout.root)] if layer == "workspace" else ["--user-default"]
    )
    command = shell_command(arguments)
    try:
        google = next(
            (c for c in load_setup(workspace).connections if c.platform == "google"), None
        )
    except (OSError, ValueError):
        return {
            "status": "invalid_configuration",
            "source": layer,
            "path": location,
            "next_step": "The operator repairs or replaces this configuration file; it was "
            "not modified.",
        }
    if google is not None:
        return {
            "status": "configured",
            "source": layer,
            "path": location,
            "application_identity": "operator_keychain_reference"
            if google.app_credential_ref
            else "packaged",
            "user_authorization": "not_verified",
        }
    if layer == "workspace":
        step = (
            "This workspace's settings/providers.json has no Google application and overrides "
            "the OS-user default. The operator removes that file to use the OS-user default, "
            f"or imports Google into it: {command}."
        )
    else:
        step = (
            "The operator imports the Google Desktop OAuth client once for the OS user that "
            f"runs the agent, using this runtime: {command}. The client secret goes to the OS "
            "keychain; a plugin runtime update keeps this configuration."
        )
    return {
        "status": "operator_setup_required",
        "source": layer,
        "path": location,
        "operator_command": command,
        "next_step": step,
    }


def install_setup(workspace, input_path: Path):
    """Explicit local operator action. Only references, never literal secrets in this schema."""
    if input_path.stat().st_size > 65536:
        raise ValueError("operator setup too large")
    setup = ProviderSetup.model_validate_json(input_path.read_text(encoding="utf-8"))
    destination = workspace.layout.root / "settings/providers.json"
    if is_link(destination.parent):
        raise ValueError("invalid operator directory")
    destination.parent.mkdir(exist_ok=True)
    # First installation is exclusive; updates are explicit file maintenance by the operator.
    with destination.open("x") as handle:
        handle.write(setup.model_dump_json(indent=2) + "\n")
    destination.chmod(0o600)
    return destination


def user_setup_path():
    """One operator installation per OS user; no account tokens or profile inheritance."""
    return Path.home() / ".config/pallas/providers.json"


def import_google_desktop(input_path, destination, *, credentials=None):
    """Operator-only import of a Google installed-app download into local credential storage."""
    import json
    import os
    from datetime import UTC, datetime
    from uuid import uuid4

    from pallas_ads.contracts.credentials import CredentialRef
    from pallas_ads.credential_store import CredentialStore

    credentials = credentials or CredentialStore()
    if is_link(input_path) or input_path.stat().st_size > 65536:
        raise ValueError("invalid Desktop OAuth file")
    raw = json.loads(input_path.read_text(encoding="utf-8"))
    installed = raw.get("installed") if isinstance(raw, dict) else None
    if not isinstance(installed, dict) or "web" in raw:
        raise ValueError("Google Desktop OAuth client required")
    client = installed.get("client_id", "")
    secret = installed.get("client_secret", "")
    if not isinstance(client, str) or not client.endswith(".apps.googleusercontent.com"):
        raise ValueError("invalid Desktop OAuth client")
    if (
        not isinstance(secret, str)
        or not secret
        or len(secret) > 4096
        or any(ord(c) < 32 for c in secret)
    ):
        raise ValueError("invalid Desktop OAuth configuration")
    destination = Path(destination)
    if any(is_link(p) for p in (destination, *destination.parents)):
        raise ValueError("invalid configuration location")
    existing = ProviderSetup()
    if destination.exists():
        if destination.stat().st_size > 65536:
            raise ValueError("invalid configuration size")
        existing = ProviderSetup.model_validate_json(destination.read_text(encoding="utf-8"))
    if any(c.platform == "google" for c in existing.connections):
        raise ValueError("Google is already configured; existing settings were preserved")
    ref = CredentialRef(
        credential_id="credential_" + uuid4().hex,
        provider="os_keychain",
        locator="pallas.google.desktop." + uuid4().hex,
        platform="google",
        created_at=datetime.now(UTC),
    )
    config = SourceConnectionConfig(
        connection_id="connection_google_template",
        platform="google",
        client_id=client,
        app_credential_ref=ref,
    )
    setup = ProviderSetup(connections=[*existing.connections, config])
    destination.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    lock = destination.with_suffix(".lock")
    fd = os.open(lock, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
    temporary = destination.with_name("." + uuid4().hex + ".tmp")
    stored = False
    try:
        # Recheck after acquiring the writer lock to avoid losing operator updates.
        current = (
            ProviderSetup.model_validate_json(destination.read_text(encoding="utf-8"))
            if destination.exists()
            else ProviderSetup()
        )
        if current != existing:
            raise ValueError("configuration changed; retry")
        backend = credentials._secure_backend()
        backend.set_password("pallas-ads", ref.locator, secret)
        stored = True
        with open(temporary, "x", opener=lambda path, flags: os.open(path, flags, 0o600)) as handle:
            handle.write(setup.model_dump_json(indent=2) + "\n")
        os.replace(temporary, destination)
        stored = False
    finally:
        os.close(fd)
        lock.unlink(missing_ok=True)
        temporary.unlink(missing_ok=True)
        if stored:
            credentials.delete(ref)
    return destination
