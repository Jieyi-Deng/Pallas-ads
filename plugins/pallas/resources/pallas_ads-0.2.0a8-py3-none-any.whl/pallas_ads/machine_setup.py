"""Portable setup diagnostics and host-owned Meta login; never reads host credentials."""

import json
import re
import shutil
import ssl
import subprocess
import sys
import threading
import tomllib
from pathlib import Path

from pallas_ads.contracts.host_mcp import META_HOST_URL, META_READ_TOOLS
from pallas_ads.local_state import WorkspaceRepository
from pallas_ads.platform_support import is_link, runtime_executable
from pallas_ads.provider_setup import google_setup

META_CALLBACK = "https://localhost:8765/callback/p3oJPar44nR2"
META_PORT = 8768


def executable():
    return runtime_executable("pallas")


def runtime_identity(project=None):
    """The runtime answering this call, so a different executable cannot report readiness."""
    from pallas_ads import __version__

    prefix = Path(sys.prefix).absolute()
    managed = prefix.parent.name == "runtimes" and re.fullmatch(r"[0-9a-f]{64}", prefix.name)
    result = {
        "version": __version__,
        "origin": "plugin_managed" if managed else "standalone",
        "executable": str(executable()),
    }
    if project is not None:
        binding = Path(project) / ".pallas/plugin-install.json"
        try:
            data = json.loads(binding.read_text(encoding="utf-8")) if binding.is_file() else None
        except (OSError, ValueError):
            data = {}
        if data is not None:
            result["plugin_binding"] = {
                "plugin_version": data.get("pluginVersion"),
                "serving_runtime_is_bound": bool(managed)
                and prefix.name == data.get("wheelSha256"),
            }
    found = shutil.which("pallas")
    if found and Path(found).resolve() != executable().resolve():
        # A legacy PATH executable can have different code and configuration behavior.
        result["path_pallas_differs"] = found
    return result


def codex_executable():
    found = shutil.which("codex")
    if found:
        return found
    for app in ("Codex", "ChatGPT"):
        candidate = Path("/Applications") / (app + ".app/Contents/Resources/codex")
        if candidate.is_file():
            return str(candidate)
    return None


def meta_config(client_id):
    if not re.fullmatch(r"[0-9]{5,32}", client_id):
        raise ValueError("Invalid Meta application ID.")
    return {
        "url": META_HOST_URL,
        "enabled": True,
        "enabled_tools": list(META_READ_TOOLS),
        "default_tools_approval_mode": "prompt",
        "oauth": {
            "client_id": client_id,
            "callback_url": META_CALLBACK,
            "callback_port": META_PORT,
        },
    }


def read_meta(directory):
    path = directory / ".codex/config.toml"
    if is_link(path) or path.stat().st_size > 65536:
        raise ValueError("Invalid project configuration.")
    config = tomllib.loads(path.read_text(encoding="utf-8"))["mcp_servers"]["meta_official"]
    # Never forward arbitrary CLI overrides, headers, endpoints or credentials from a file.
    expected = meta_config(config["oauth"]["client_id"])
    if config != expected:
        raise ValueError("Meta configuration differs from the supported project setup.")
    return expected


def certificate_paths(directory):
    root = directory / ".pallas/certs"
    return root / "localhost.pem", root / "localhost-key.pem"


def prepare_certificate(directory, *, trust=False):
    """Generate a machine-local leaf; trust changes require the explicit CLI flag."""
    if sys.platform != "darwin":
        raise ValueError("This certificate setup currently supports macOS only.")
    read_meta(directory)
    cert, key = certificate_paths(directory)
    if any(is_link(p) for p in (cert, key, *cert.parents)):
        raise ValueError("Certificate paths cannot be symbolic links.")
    cert.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    if cert.exists() != key.exists():
        raise ValueError("Incomplete certificate pair; existing files were preserved.")
    if not cert.exists():
        openssl = shutil.which("openssl")
        if not openssl:
            raise ValueError("OpenSSL is required for local certificate generation.")
        import tempfile

        with tempfile.TemporaryDirectory(dir=cert.parent) as temporary:
            tmp = Path(temporary)
            config = tmp / "openssl.cnf"
            config.write_text(
                "[req]\nprompt=no\ndistinguished_name=dn\nx509_extensions=server\n"
                "[dn]\nCN=localhost\n[server]\nsubjectAltName=DNS:localhost,IP:127.0.0.1\n"
                "basicConstraints=critical,CA:FALSE\nkeyUsage=critical,digitalSignature,keyEncipherment\n"
                "extendedKeyUsage=serverAuth\n",
                encoding="utf-8",
                newline="\n",
            )
            subprocess.run(
                [
                    openssl,
                    "req",
                    "-x509",
                    "-newkey",
                    "rsa:2048",
                    "-nodes",
                    "-days",
                    "365",
                    "-config",
                    str(config),
                    "-keyout",
                    str(tmp / "key.pem"),
                    "-out",
                    str(tmp / "cert.pem"),
                ],
                check=True,
                capture_output=True,
                timeout=30,
            )
            (tmp / "key.pem").chmod(0o600)
            (tmp / "cert.pem").chmod(0o600)
            # Exclusive publish, never replace another installation's files.
            for source, target in ((tmp / "key.pem", key), (tmp / "cert.pem", cert)):
                with target.open("xb") as handle:
                    target.chmod(0o600)
                    handle.write(source.read_bytes())
    context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    context.load_cert_chain(cert, key)
    if trust:
        # Current user's trust store only; no sudo, system root CA or shared private key.
        subprocess.run(
            [
                "/usr/bin/security",
                "add-trusted-cert",
                "-r",
                "trustRoot",
                "-p",
                "ssl",
                "-s",
                "localhost",
                "-k",
                str(Path.home() / "Library/Keychains/login.keychain-db"),
                str(cert),
            ],
            check=True,
            capture_output=True,
            timeout=120,
        )
    return {
        "certificate_created": True,
        "trust_requested": trust,
        "callback_url": META_CALLBACK,
        "browser_trust": "requires_browser_verification",
    }


def login_meta(directory):
    config = read_meta(directory)
    codex = codex_executable()
    if codex is None:
        raise ValueError("Codex CLI must be available on PATH.")
    cert, key = certificate_paths(directory)
    from pallas_ads.codex_https_callback import make_server

    # Codex 0.146 reads only the global callback fields and appends its callback ID.
    # Newer clients use the per-server full URL below. Keep this fallback local to
    # this subprocess: never change the user's global callback for other servers.
    overrides = [
        "-c",
        "mcp_oauth_callback_url=" + json.dumps(META_CALLBACK.rsplit("/", 1)[0]),
        "-c",
        f"mcp_oauth_callback_port={META_PORT}",
    ]
    for name, value in config.items():
        items = value.items() if isinstance(value, dict) else [(None, value)]
        for child, item in items:
            field = name + "." + child if child else name
            overrides.extend(["-c", "mcp_servers.meta_official." + field + "=" + json.dumps(item)])
    with make_server(META_CALLBACK, META_PORT, cert, key) as server:
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        try:
            # The official CLI opens consent and stores tokens. No capture or token inspection.
            return subprocess.call(
                [
                    codex,
                    "mcp",
                    "login",
                    "meta_official",
                    "--scopes",
                    "ads_read,ads_mcp_management",
                    *overrides,
                ],
                cwd=directory,
            )
        finally:
            server.shutdown()
            thread.join(timeout=5)


def _legacy_local(directory, add):
    if (directory / ".codex/config.toml").is_file():
        config = tomllib.loads((directory / ".codex/config.toml").read_text(encoding="utf-8"))
        local = config["mcp_servers"]["pallas"]
        skills = directory / ".agents/skills"
    else:
        config = json.loads((directory / ".mcp.json").read_text(encoding="utf-8"))
        local = config["mcpServers"]["pallas"]
        skills = directory / ".claude/skills"
    ready = Path(local["command"]).is_file() and local["args"] == [
        "mcp",
        "serve",
        "--workspace",
        str(directory / ".pallas"),
    ]
    add(
        "local_mcp",
        "ready" if ready else "blocked",
        "Installed command/workspace check; host tool loading still needs verification.",
    )
    present = all(
        (skills / name / "SKILL.md").is_file() for name in ("pallas-workflow", "pallas-analysis")
    )
    add(
        "local_skills",
        "ready" if present else "blocked",
        "Project workflow and analysis skills.",
    )


def doctor(directory, *, media="core"):
    """Offline diagnostics: presence is not a live authorization/permission claim."""
    directory = directory.absolute()
    if media not in ("core", "google", "meta", "tiktok", "all"):
        raise ValueError("Choose core, google, meta, tiktok or all.")
    rows = []

    def add(name, status, detail):
        rows.append({"check": name, "status": status, "detail": detail})

    repo = WorkspaceRepository(directory / ".pallas")
    try:
        manifest = repo.load_manifest()
        add("workspace", "ready", f"Product count: {len(manifest.profile_ids)}")
    except (OSError, ValueError):
        add("workspace", "blocked", "Run agent setup in a fresh project.")
    identity = runtime_identity(directory)
    binding = identity.get("plugin_binding")
    add(
        "runtime",
        "ready" if binding is None or binding["serving_runtime_is_bound"] else "blocked",
        f"Pallas {identity['version']} ({identity['origin']}) at {identity['executable']}."
        + (
            ""
            if binding is None or binding["serving_runtime_is_bound"]
            else " This project is bound to the native plugin runtime; run the plugin doctor "
            "(node <plugin>/scripts/pallas.mjs doctor --project PROJECT) instead of this "
            "executable."
        )
        + (
            f" A different pallas is first on PATH ({identity['path_pallas_differs']}); "
            "do not use it for this project."
            if "path_pallas_differs" in identity
            else ""
        ),
    )
    try:
        if binding is not None:
            add(
                "local_mcp",
                "ready" if binding["serving_runtime_is_bound"] else "blocked",
                "Native plugin binding; host tool loading still needs verification.",
            )
            add("local_skills", "ready", "Provided by the native plugin.")
        else:
            _legacy_local(directory, add)
    except (OSError, ValueError, KeyError, TypeError):
        add("local_mcp", "blocked", "Invalid or missing Pallas project configuration.")
    google = google_setup(repo, str(executable()))
    add(
        "google_application",
        "configured" if google["status"] == "configured" else "blocked",
        f"Application configured from {google['source']}; user authorization and Cloud access "
        "unverified."
        if google["status"] == "configured"
        else f"{google['status']} ({google['source']}): {google['next_step']} This installation "
        "has no effective Google application. File analysis is unaffected; never ask users "
        "for JSON or tokens.",
    )
    add(
        "tiktok_application",
        "ready",
        "Official MCP default; live consent/account access unverified.",
    )
    from pallas_ads.host_mcp import meta_registration
    from pallas_ads.provider_setup import load_setup

    registration = meta_registration(directory)
    try:
        native_meta = any(c.platform == "meta" for c in load_setup(repo).connections)
    except (OSError, ValueError):
        native_meta = False
    if native_meta:
        add(
            "meta_application",
            "configured",
            "Pallas-owned browser OAuth; account access unverified.",
        )
    elif sys.platform == "win32":
        add(
            "meta_application",
            "blocked",
            "Obtain a publisher-configured build for Pallas browser OAuth. Legacy Meta "
            "host hooks and local-certificate setup are not supported on Windows.",
        )
    elif registration["client"] == "codex":
        add(
            "codex_cli",
            "ready" if codex_executable() else "blocked",
            "Codex CLI is needed for host login; desktop tool loading must be tested separately.",
        )
        try:
            read_meta(directory)
            cert, key = certificate_paths(directory)
            ready = cert.is_file() and key.is_file()
            add(
                "meta_application",
                "configured",
                "Pre-registered client; provider eligibility unverified.",
            )
            add(
                "meta_certificate",
                "configured" if ready else "blocked",
                "Browser trust unverified."
                if ready
                else "Run agent prepare-meta --trust-local-certificate.",
            )
        except (OSError, ValueError, KeyError, TypeError):
            add("meta_application", "blocked", "Set up with the operator's --meta-client-id.")
    elif (directory / ".mcp.json").is_file() or binding is not None:
        from pallas_ads.host_mcp import host_connection_instructions

        meta = host_connection_instructions(directory)
        ready = meta.result["state"] == "registered_authentication_unknown"
        add(
            "meta_application",
            "host_managed" if ready else "blocked",
            meta.issues[0].message
            + " Host authentication is unknown to Pallas; account access is unverified.",
        )
        add(
            "meta_host_registration",
            "host_managed" if ready else "blocked",
            f"{meta.result['state']}; host authentication and account access remain unverified.",
        )
    else:
        add("agent_config", "blocked", "No project MCP configuration found.")
    add("live_authorization", "not_tested", "No browser opened, token read, or media request sent.")
    for row in rows:
        optional = (
            row["check"].startswith(("google_", "meta_", "tiktok_")) or row["check"] == "codex_cli"
        )
        requested = (
            media == "all"
            or row["check"].startswith(media + "_")
            or media == "meta"
            and row["check"] == "codex_cli"
        )
        row["required"] = not optional or requested
        if optional and not requested and row["status"] == "blocked":
            row["status"] = "optional_unavailable"
    return {
        "mode": media,
        "status": "blocked"
        if any(r["status"] == "blocked" for r in rows)
        else "ready_for_local_analysis"
        if media == "core"
        else "ready_for_live_test",
        "checks": rows,
        "credentials_inspected": False,
    }
