"""Small OS boundary for launch paths, non-blocking locks and safe regular files.

Windows support targets local disks. Credentials use Credential Manager separately;
workspace files inherit the user's directory ACL, not POSIX chmod semantics.
"""

from __future__ import annotations

import errno
import os
import shlex
import stat
import sys
from pathlib import Path


def runtime_executable(name: str, prefix: Path | None = None) -> Path:
    root = Path(sys.prefix) if prefix is None else Path(prefix)
    return (
        root
        / ("Scripts" if os.name == "nt" else "bin")
        / (name + ".exe" if os.name == "nt" else name)
    )


def shell_command(arguments: list[str], *, windows: bool | None = None) -> str:
    """Display a copyable POSIX-shell or Windows PowerShell command, never execute it."""
    windows = os.name == "nt" if windows is None else windows
    if windows:
        return "& " + " ".join("'" + part.replace("'", "''") + "'" for part in arguments)
    return shlex.join(arguments)


def is_link(path: Path) -> bool:
    """Include Windows junctions and other reparse points, including broken links."""
    try:
        info = path.lstat()
    except FileNotFoundError:
        return False
    return stat.S_ISLNK(info.st_mode) or bool(
        getattr(info, "st_file_attributes", 0) & stat.FILE_ATTRIBUTE_REPARSE_POINT
    )


def lock_file(fd: int) -> None:
    if os.name == "nt":
        import msvcrt

        position = os.lseek(fd, 0, os.SEEK_CUR)
        try:
            os.lseek(fd, 0, os.SEEK_SET)
            msvcrt.locking(fd, msvcrt.LK_NBLCK, 1)
        except OSError as error:
            if error.errno in (errno.EACCES, errno.EAGAIN, errno.EDEADLK):
                raise BlockingIOError(errno.EAGAIN, "File is locked by another operation") from None
            raise
        finally:
            os.lseek(fd, position, os.SEEK_SET)
    else:
        import fcntl

        fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)


def unlock_file(fd: int) -> None:
    if os.name == "nt":
        import msvcrt

        position = os.lseek(fd, 0, os.SEEK_CUR)
        try:
            os.lseek(fd, 0, os.SEEK_SET)
            msvcrt.locking(fd, msvcrt.LK_UNLCK, 1)
        finally:
            os.lseek(fd, position, os.SEEK_SET)
    else:
        import fcntl

        fcntl.flock(fd, fcntl.LOCK_UN)


def open_regular(path: Path, flags: int = os.O_RDONLY, mode: int = 0o600) -> int:
    """Open without following the final link, then validate the opened object.

    Never emulate O_NOFOLLOW by dropping it on Windows: inspect the reparse-point
    handle before handing it to Python. Callers own the returned descriptor.
    """
    if os.name == "nt":
        fd = _windows_open(Path(path), flags)
    else:
        fd = os.open(path, flags | os.O_NOFOLLOW | os.O_NONBLOCK, mode)
    try:
        if not stat.S_ISREG(os.fstat(fd).st_mode):
            raise OSError(errno.EINVAL, "Expected a regular file")
        return fd
    except BaseException:
        os.close(fd)
        raise


def _windows_open(path: Path, flags: int) -> int:
    if sys.platform != "win32":
        raise OSError("Win32 file handles are available only on Windows")
    import ctypes
    import msvcrt
    from ctypes import wintypes

    # Only the read and read/write-create forms used for evidence/state/locks.
    if flags not in (os.O_RDONLY, os.O_RDWR | os.O_CREAT):
        raise ValueError("Unsupported safe file access mode")
    path = path.absolute()
    if not path.drive or path.drive.startswith("\\\\") or ":" in str(path)[2:]:
        raise ValueError("Use a local Windows drive, not a network/device/stream path")
    if any(is_link(p) for p in (path, *path.parents)):
        raise OSError(errno.ELOOP, "State and evidence paths cannot traverse reparse points")

    kernel = ctypes.WinDLL("kernel32", use_last_error=True)
    create = kernel.CreateFileW
    create.argtypes = [
        wintypes.LPCWSTR,
        wintypes.DWORD,
        wintypes.DWORD,
        wintypes.LPVOID,
        wintypes.DWORD,
        wintypes.DWORD,
        wintypes.HANDLE,
    ]
    create.restype = wintypes.HANDLE
    close = kernel.CloseHandle
    close.argtypes, close.restype = [wintypes.HANDLE], wintypes.BOOL
    get_type = kernel.GetFileType
    get_type.argtypes, get_type.restype = [wintypes.HANDLE], wintypes.DWORD
    info = kernel.GetFileInformationByHandleEx
    info.argtypes = [wintypes.HANDLE, ctypes.c_int, wintypes.LPVOID, wintypes.DWORD]
    info.restype = wintypes.BOOL

    class AttributeTag(ctypes.Structure):
        _fields_ = [("attributes", wintypes.DWORD), ("tag", wintypes.DWORD)]

    writable = bool(flags & os.O_RDWR)
    handle = create(
        "\\\\?\\" + str(path),
        0xC0000000 if writable else 0x80000000,
        0x3 if writable else 0x7,
        None,
        4 if flags & os.O_CREAT else 3,
        0x00200080,
        None,
    )
    if handle == wintypes.HANDLE(-1).value:
        raise ctypes.WinError(ctypes.get_last_error())
    try:
        attributes = AttributeTag()
        if not info(handle, 9, ctypes.byref(attributes), ctypes.sizeof(attributes)):
            raise ctypes.WinError(ctypes.get_last_error())
        if get_type(handle) != 1 or attributes.attributes & (0x400 | 0x10):
            raise OSError(errno.EINVAL, "Expected a regular file, not a reparse point")
        fd = msvcrt.open_osfhandle(handle, (os.O_RDWR if writable else os.O_RDONLY) | os.O_BINARY)
        handle = None  # Descriptor now owns the non-inheritable Win32 handle.
        return fd
    finally:
        if handle is not None:
            close(handle)
